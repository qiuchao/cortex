/**
 * shims/opencode/plugin.js —— Synapse 的 opencode 全局 plugin(自包含,零依赖)。
 *
 * ## 为什么存在
 * opencode 没有原生 shell hook(不像 CC/Codex/Gemini),CLI hook stdin 那套 inject/report
 * curl 薄壳对 opencode 不生效。opencode 的接入点是 **plugin**:装到
 * `~/.config/opencode/plugins/` 后由 opencode 启动时自动加载(见 synapse install opencode)。
 *
 * ## 职责(薄壳,业务逻辑全在 daemon —— 见 DECISIONS D1)
 * 本 plugin 只做「把 opencode 事件转发给常驻 daemon,拿回上下文注入/工具判定」。
 *
 * 每轮无感 KH 检索需要「用户本轮输入」当 query,OpenCode 1.17.11+ 分三个阶段:
 *   - chat.message                          有 message/parts(query),但不是注入点
 *   - experimental.chat.system.transform    可追加真实的请求级 system prompt
 *   - experimental.chat.messages.transform  在 toModelMessagesEffect 前拿到真实消息
 * 故使用分层注入:
 *   ① chat.message:拿本轮用户输入 → POST /inject 查 KH → 结果按 sessionID 缓存
 *   ② system.transform:把受信控制追加到 system prompt
 *   ③ messages.transform:把不受信的知识正文追加到 user text part
 * report:
 *   ④ event:session.idle(opencode 的「回合结束」信号,无 session.ended)→ POST /report
 * guard:
 *   ⑤ tool.execute.before:把真实工具名/参数发给 /guard；daemon deny 时抛错阻断
 *
 * hook 名与事件名对齐 @opencode-ai/plugin v1.17.11+:chat.message /
 * experimental.chat.system.transform / experimental.chat.messages.transform /
 * tool.execute.before / event。
 * session 终态事件是 session.idle(回合完成)
 * 与 session.deleted,**没有 session.ended**。
 *
 * ## 传输(双通路)
 * 读 daemon 写的 runtime.env($XDG_CACHE_HOME/synapse/runtime.env,回落 ~/.cache/...):
 *   - 有 SYNAPSE_PORT → loopback TCP + Bearer token(Windows 主通路;curl/http 连 127.0.0.1)。
 *   - 否则 → unix socket(POSIX,连上即认证,OS fs 权限把关,无需 bearer)。socket 路径与
 *     transport/discovery.ts::socketPath 对齐:$XDG_RUNTIME_DIR/synapse/synapse.sock,
 *     回落 ~/.synapse/run/synapse.sock。
 * **本文件不 import bundle 内模块**——它被拷到 opencode 全局 plugin 目录后独立运行,
 * 路径无法回指 bundle,故所有逻辑内联、零依赖。
 *
 * ## 容错
 * inject/report 断连继续静默降级。guard 断连时，普通回合继续放行；daemon 已明确
 * 标记的 capability 受控回合 fail-closed，避免模型改用浏览器/桌面 UI 模拟人工操作。
 */

import { request } from "node:http"
import { randomUUID } from "node:crypto"
import { chmodSync, lstatSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs"
import { homedir } from "node:os"
import { basename, join } from "node:path"
import { fileURLToPath } from "node:url"

const KNOWLEDGE_MARKER = "[synapse:opencode-context]"
const CONTROL_MARKER = "[synapse:opencode-control]"
const RECEIPT_PRESENTATION_MARKER = "[synapse:opencode-receipt]"
const PROVENANCE_MARKER = "[synapse:opencode-provenance]"
const ATTACHMENT_CACHE_TTL_MS = 24 * 60 * 60_000
const MAX_ATTACHMENTS = 20
const MAX_ATTACHMENT_CACHE_BYTES = 1024 * 1024 * 1024
const MAX_ATTACHMENT_CACHE_ENTRIES = 100
const ATTACHMENT_RULES = new Map([
  ["image/jpeg", { extension: "jpg", extensions: ["jpg", "jpeg"], maxBytes: 10 * 1024 * 1024 }],
  ["image/png", { extension: "png", extensions: ["png"], maxBytes: 10 * 1024 * 1024 }],
  ["image/gif", { extension: "gif", extensions: ["gif"], maxBytes: 10 * 1024 * 1024 }],
  ["video/mp4", { extension: "mp4", extensions: ["mp4"], maxBytes: 500 * 1024 * 1024 }],
  ["text/plain", { extension: "txt", extensions: ["log", "txt"], maxBytes: 20 * 1024 * 1024 }],
  ["text/markdown", { extension: "md", extensions: ["md"], maxBytes: 20 * 1024 * 1024 }],
])
const KNOWLEDGE_PROVENANCE = [
  "Synapse automatically retrieved the adjacent knowledge context for this turn before model execution. This counts as Synapse / brain knowledge retrieval even though it does not appear as a model-initiated tool call.",
  "If the response uses any fact from that context, append exactly: 来源：主脑自动检索",
  "Do not claim the content was invented merely because no explicit tool call is present.",
].join("\n")

/** daemon unix socket 路径(与 transport/discovery.ts::socketPath 对齐)。 */
function socketPath() {
  const xdg = process.env.XDG_RUNTIME_DIR
  if (xdg && xdg.trim()) return join(xdg, "synapse", "synapse.sock")
  return join(homedir(), ".synapse", "run", "synapse.sock")
}

/** runtime.env 路径(daemon 写,与 discovery.ts::runtimeEnvPath 对齐)。 */
function runtimeEnvPath() {
  const xdg = process.env.XDG_CACHE_HOME
  const base = xdg && xdg.trim() ? xdg : join(homedir(), ".cache")
  return join(base, "synapse", "runtime.env")
}

function attachmentCacheRoot() {
  const xdg = process.env.XDG_CACHE_HOME
  const base = xdg && xdg.trim() ? xdg : join(homedir(), ".cache")
  return join(base, "synapse", "opencode-attachments")
}

function prepareAttachmentCache(root) {
  mkdirSync(root, { recursive: true, mode: 0o700 })
  const info = lstatSync(root)
  if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("Synapse OpenCode attachment cache must be a real directory.")
  if (typeof process.getuid === "function" && info.uid !== process.getuid()) {
    throw new Error("Synapse OpenCode attachment cache must be owned by the current user.")
  }
  if (process.platform !== "win32") {
    chmodSync(root, 0o700)
    if ((lstatSync(root).mode & 0o077) !== 0) throw new Error("Synapse OpenCode attachment cache must be private.")
  }
}

function enforceAttachmentCacheBudget(root, incomingBytes, incomingEntries) {
  const cutoff = Date.now() - ATTACHMENT_CACHE_TTL_MS
  const entries = []
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory() || !/^[a-f0-9-]{36}$/.test(entry.name)) continue
    const path = join(root, entry.name)
    try {
      const info = lstatSync(path)
      if (!info.isDirectory() || info.isSymbolicLink()) continue
      if (info.mtimeMs < cutoff) {
        rmSync(path, { recursive: true, force: true })
        continue
      }
      let bytes = 0
      for (const child of readdirSync(path, { withFileTypes: true })) {
        if (!child.isFile()) continue
        const childInfo = lstatSync(join(path, child.name))
        if (!childInfo.isSymbolicLink()) bytes += childInfo.size
      }
      entries.push({ path, bytes, mtimeMs: info.mtimeMs })
    } catch {
      // A concurrent cleanup does not invalidate the remaining budget scan.
    }
  }
  entries.sort((left, right) => left.mtimeMs - right.mtimeMs)
  let totalBytes = entries.reduce((total, entry) => total + entry.bytes, 0)
  while (entries.length && (entries.length + incomingEntries > MAX_ATTACHMENT_CACHE_ENTRIES
    || totalBytes + incomingBytes > MAX_ATTACHMENT_CACHE_BYTES)) {
    const oldest = entries.shift()
    rmSync(oldest.path, { recursive: true, force: true })
    totalBytes -= oldest.bytes
  }
  if (incomingEntries > MAX_ATTACHMENT_CACHE_ENTRIES || totalBytes + incomingBytes > MAX_ATTACHMENT_CACHE_BYTES) {
    throw new Error("Synapse OpenCode attachment cache capacity exceeded.")
  }
}

function validatedFileName(value, fallback, mimeType) {
  const supplied = typeof value === "string" && value.trim() ? value.trim() : fallback
  if (!supplied || supplied.length > 512 || basename(supplied) !== supplied || /[\\/\u0000-\u001f\u007f]/.test(supplied)) {
    throw new Error("Synapse cannot preserve an invalid OpenCode attachment file name.")
  }
  const extension = supplied.toLowerCase().split(".").pop() ?? ""
  const rule = mimeType ? ATTACHMENT_RULES.get(mimeType) : [...ATTACHMENT_RULES.values()].find((item) => item.extensions.includes(extension))
  if (!rule || !rule.extensions.includes(extension)) {
    throw new Error(`Synapse cannot preserve an OpenCode attachment whose MIME and extension disagree: ${supplied}`)
  }
  return supplied
}

function decodedDataFile(part) {
  const url = typeof part?.url === "string" ? part.url : ""
  const comma = url.indexOf(",")
  const header = comma >= 0 ? url.slice(0, comma) : ""
  const headerMatch = header.match(/^data:([^;,]+);base64$/i)
  if (!headerMatch) throw new Error("Synapse cannot preserve this OpenCode attachment: expected a local file or base64 data URL.")
  const mimeType = headerMatch[1].trim().toLowerCase()
  const rule = ATTACHMENT_RULES.get(mimeType)
  if (!rule) throw new Error(`Synapse cannot preserve unsupported OpenCode attachment MIME: ${mimeType}`)
  const encoded = url.slice(comma + 1)
  if (!encoded || encoded.length > Math.ceil(rule.maxBytes / 3) * 4 + Math.ceil(rule.maxBytes / 76) * 2) {
    throw new Error("Synapse cannot preserve an invalid or oversized OpenCode attachment.")
  }
  const compact = encoded.replace(/[\r\n]/g, "")
  if (!compact || compact.length > Math.ceil(rule.maxBytes / 3) * 4
    || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(compact)) {
    throw new Error("Synapse cannot preserve an invalid or oversized OpenCode attachment.")
  }
  const bytes = Buffer.from(compact, "base64")
  if (!bytes.length || bytes.length > rule.maxBytes || bytes.toString("base64") !== compact) {
    throw new Error("Synapse cannot preserve an invalid or oversized OpenCode attachment.")
  }
  const fileName = validatedFileName(part.filename, `attachment.${rule.extension}`, mimeType)
  return { bytes, fileName, mimeType }
}

function normalizeLocalFilePart(part) {
  const mimeType = typeof part.mime === "string" && part.mime.trim()
    ? part.mime.trim().toLowerCase().split(";", 1)[0]
    : undefined
  let path
  if (typeof part.path === "string" && part.path.trim()) path = part.path.trim()
  else if (typeof part.url === "string" && part.url.toLowerCase().startsWith("file:")) path = fileURLToPath(part.url)
  else return undefined
  const fileName = validatedFileName(part.filename, basename(path), mimeType)
  return { type: "file", path, fileName, ...(mimeType ? { mimeType } : {}) }
}

function materializeDataFiles(files) {
  if (!files.length) return []
  const root = attachmentCacheRoot()
  prepareAttachmentCache(root)
  enforceAttachmentCacheBudget(
    root,
    files.reduce((total, file) => total + file.bytes.length, 0),
    files.length,
  )
  const directories = []
  try {
    return files.map((file) => {
      const directory = join(root, randomUUID())
      mkdirSync(directory, { mode: 0o700 })
      directories.push(directory)
      const target = join(directory, file.fileName)
      writeFileSync(target, file.bytes, { flag: "wx", mode: 0o600 })
      return { type: "file", path: target, fileName: file.fileName, mimeType: file.mimeType }
    })
  } catch (error) {
    for (const directory of directories) rmSync(directory, { recursive: true, force: true })
    throw error
  }
}

function normalizeOpenCodeParts(parts) {
  if (!Array.isArray(parts)) return []
  const fileParts = parts.filter((part) => part && typeof part === "object" && part.type === "file")
  if (fileParts.length > MAX_ATTACHMENTS) throw new Error(`Synapse supports at most ${MAX_ATTACHMENTS} OpenCode attachments per turn.`)
  const dataFiles = []
  const normalized = parts.map((part) => {
    if (!part || typeof part !== "object" || part.type !== "file") return part
    const local = normalizeLocalFilePart(part)
    if (local) return local
    const index = dataFiles.push(decodedDataFile(part)) - 1
    return { dataFileIndex: index }
  })
  const materialized = materializeDataFiles(dataFiles)
  return normalized.map((part) => part && typeof part === "object" && "dataFileIndex" in part
    ? materialized[part.dataFileIndex]
    : part)
}

/**
 * 解析传输配置:读 runtime.env。有 SYNAPSE_PORT → TCP(带 token);否则 unix socket。
 * 全程容错:文件不存在/坏 → 回落 unix socket。
 */
function resolveTransport() {
  try {
    const txt = readFileSync(runtimeEnvPath(), "utf8")
    const kv = {}
    for (const line of txt.split("\n")) {
      const i = line.indexOf("=")
      if (i > 0) {
        // 值可能被单引号包裹(lifecycle.writeRuntimeEnv 为 sh source 安全加的);剥掉。
        const raw = line.slice(i + 1).trim()
        const val = raw.startsWith("'") && raw.endsWith("'") ? raw.slice(1, -1) : raw
        kv[line.slice(0, i).trim()] = val
      }
    }
    if (kv.SYNAPSE_PORT) {
      let token = ""
      try {
        token = kv.SYNAPSE_TOKEN_FILE ? readFileSync(kv.SYNAPSE_TOKEN_FILE, "utf8").trim() : ""
      } catch {
        /* token 读不到 → 仍试 TCP,daemon 会 401,不崩 */
      }
      return { tcp: true, port: parseInt(kv.SYNAPSE_PORT, 10), token }
    }
  } catch {
    /* 无 runtime.env → 回落 unix socket */
  }
  return { tcp: false }
}

/**
 * 向 daemon POST 一个 verb(/inject 或 /report),返回解析后的 JSON(失败返回 null)。
 * 全程容错:socket/TCP 不通 / 超时 / 非 JSON → resolve(null),绝不 reject。
 */
function postToDaemon(verb, payload, timeoutMs) {
  return new Promise((resolve) => {
    let done = false
    const finish = (v) => {
      if (done) return
      done = true
      resolve(v)
    }

    let body
    try {
      body = JSON.stringify(payload ?? {})
    } catch {
      return finish(null)
    }

    const t = resolveTransport()
    const headers = {
      "content-type": "application/json",
      "X-Synapse-Client": "opencode",
      "content-length": Buffer.byteLength(body),
    }
    if (t.tcp && t.token) headers["Authorization"] = `Bearer ${t.token}`
    const opts = t.tcp
      ? { host: "127.0.0.1", port: t.port, path: `/${verb}`, method: "POST", headers, timeout: timeoutMs }
      : { socketPath: socketPath(), path: `/${verb}`, method: "POST", headers, timeout: timeoutMs }

    const req = request(
      opts,
      (res) => {
        const chunks = []
        res.on("data", (c) => chunks.push(c))
        res.on("end", () => {
          try {
            finish(JSON.parse(Buffer.concat(chunks).toString("utf8")))
          } catch {
            finish(null)
          }
        })
      },
    )
    req.on("error", () => finish(null))
    req.on("timeout", () => {
      req.destroy()
      finish(null)
    })
    req.end(body)
  })
}

/**
 * Synapse opencode plugin 入口。opencode 启动时以 async 工厂调用,返回 hooks 对象。
 */
export const SynapsePlugin = async (ctx) => {
  const directory = ctx?.directory ?? ctx?.worktree ?? process.cwd()

  // sessionID → 本轮待注入的 context(由 chat.message 填,messages.transform 每次都注入,
  // event:session.idle 回合结束才清)。generation 防止慢旧响应覆盖快新回合。
  const pendingContext = new Map()
  // OpenCode 的 tool hook 没有 messageID。官方事件会先发布 assistant message(parentID
  // 指向 user message)，再发布 tool part(callID + assistant messageID)，据此把每个调用
  // 绑定到原始用户回合；迟到调用不得落到同 session 的新回合。
  const currentTurns = new Map()
  const turnsByUserMessage = new Map()
  const turnsByAssistantMessage = new Map()
  const turnsByToolCall = new Map()
  let nextTurnGeneration = 0
  const CLOSED_TURN_TTL_MS = 10 * 60 * 1000
  const CLOSED_TURN_MAX_ENTRIES = 256

  const scopedKey = (sessionID, id) => `${sessionID}\u0000${id}`
  const pruneClosedTurns = () => {
    const now = Date.now()
    const closedTurns = []
    for (const turn of turnsByUserMessage.values()) {
      if (turn.closedAt) closedTurns.push(turn)
    }
    if (closedTurns.length === 0) return
    closedTurns.sort((a, b) => a.closedAt - b.closedAt)
    const stale = new Set(closedTurns.filter((turn) => turn.closedAt + CLOSED_TURN_TTL_MS <= now))
    for (let index = 0; index < closedTurns.length - CLOSED_TURN_MAX_ENTRIES; index += 1) {
      stale.add(closedTurns[index])
    }
    if (stale.size > 0) {
      for (const map of [turnsByUserMessage, turnsByAssistantMessage, turnsByToolCall]) {
        for (const [key, turn] of map) if (stale.has(turn)) map.delete(key)
      }
    }
  }
  const clearSessionBindings = (sessionID) => {
    const prefix = `${sessionID}\u0000`
    for (const map of [turnsByUserMessage, turnsByAssistantMessage, turnsByToolCall]) {
      for (const key of map.keys()) if (key.startsWith(prefix)) map.delete(key)
    }
  }
  const closeTurn = (turn) => {
    if (!turn || turn.closedAt) return
    turn.closedAt = Date.now()
  }

  return {
    // ── ① chat.message:拿本轮用户输入 → 查 KH → 缓存 context(待 ② 注入)──
    "chat.message": async (input, output) => {
      pruneClosedTurns()
      const sessionID = input?.sessionID ?? ""
      if (!sessionID) return
      const generation = ++nextTurnGeneration
      const messageID = typeof input?.messageID === "string" && input.messageID
        ? input.messageID
        : typeof output?.message?.id === "string"
          ? output.message.id
          : ""
      const turn = { sessionID, messageID, generation, guardRequired: false }
      currentTurns.set(sessionID, turn)
      if (messageID) turnsByUserMessage.set(scopedKey(sessionID, messageID), turn)
      // 新用户消息先撤销上一轮缓存。该 hook 会在模型开始前 await /inject，成功响应后
      // 再按 daemon 的 toolGuardRequired 标记精确回合。旧回合的调用绑定必须保留，
      // 直到真正的 session.idle，才能识别并阻断迟到工具调用。
      pendingContext.delete(sessionID)
      const resp = await postToDaemon(
        "inject",
        {
          event: "chat.message",
          sessionID,
          cwd: directory,
          // daemon parser 从 message.parts 抽 user_input(见 core/parsers/opencode.ts)
          message: output?.message ?? {},
          parts: normalizeOpenCodeParts(output?.parts ?? []),
        },
        // 显式工作项 ID 会触发固定快照分页、正文和 receipt 读取，daemon 预算为 18s。
        // plugin 必须覆盖该预算，否则外层提前断开会丢失缺失项提醒和 receipt。
        20000,
      )
      if (currentTurns.get(sessionID) !== turn) return
      if (!resp || typeof resp !== "object") return
      turn.guardRequired = resp.toolGuardRequired === true
      const hasSplitContext = typeof resp.trustedContext === "string" || typeof resp.untrustedContext === "string"
      const trusted = typeof resp.trustedContext === "string"
        ? resp.trustedContext.trim()
        : typeof resp.resultInjection === "string"
          ? resp.resultInjection.trim()
          : ""
      const untrusted = hasSplitContext
        ? (typeof resp.untrustedContext === "string" ? resp.untrustedContext.trim() : "")
        : (typeof resp.context === "string" ? resp.context.trim() : "")
      if (trusted || untrusted) pendingContext.set(sessionID, { turn, trusted, untrusted })
    },

    // ── ② system.transform:受信控制写入真实的请求级 system prompt ──
    // UserMessage.info.system 在 OpenCode 1.18.9 中仍会随 user message 传递,不是可依赖的
    // system 边界。控制协议只能走这个专用 hook。该 hook 不提供 messageID，依赖
    // OpenCode 同一 session 在 awaited chat.message 后才开始其 model transforms。
    "experimental.chat.system.transform": async (input, output) => {
      const sessionID = input?.sessionID ?? ""
      const context = pendingContext.get(sessionID)
      if (!context || context.turn !== currentTurns.get(sessionID) || !Array.isArray(output?.system)) return
      if (context.trusted
        && !output.system.some((part) => typeof part === "string" && part.includes(CONTROL_MARKER))) {
        output.system.push(`${CONTROL_MARKER}\n${context.trusted}`)
      }
      if (context.untrusted
        && !output.system.some((part) => typeof part === "string" && part.includes(PROVENANCE_MARKER))) {
        output.system.push(`${PROVENANCE_MARKER}\n${KNOWLEDGE_PROVENANCE}`)
      }
    },

    // ── ③ messages.transform:不受信知识仍写 user text ──
    "experimental.chat.messages.transform": async (_input, output) => {
      if (!output || !Array.isArray(output.messages)) return
      const message = output.messages.findLast((item) => item?.info?.role === "user")
      if (!message?.info) return
      const sessionID = message.info?.sessionID ?? ""
      const context = pendingContext.get(sessionID)
      if (!context || context.turn !== currentTurns.get(sessionID)) return
      if (context.turn.messageID && message.info.id !== context.turn.messageID) return

      if (context.untrusted && Array.isArray(message.parts)
        && !message.parts.some((part) => part?.type === "text" && part.text?.includes(KNOWLEDGE_MARKER))) {
        const injected = `${KNOWLEDGE_MARKER}\n${context.untrusted}`
        const textPart = message.parts.findLast((part) => part?.type === "text" && !part.ignored)
        if (textPart) textPart.text = `${textPart.text ?? ""}\n\n${injected}`
        else message.parts.push({ type: "text", text: injected, synthetic: true })
      }
      if (context.trusted.includes("[Cerebro]") && Array.isArray(message.parts)
        && !message.parts.some((part) => part?.type === "text" && part.text?.includes(RECEIPT_PRESENTATION_MARKER))) {
        const injected = [
          RECEIPT_PRESENTATION_MARKER,
          "Trusted Synapse operation result. The final answer must include the literal [Cerebro] marker and the operationId/targetId from this block. This receipt block is not limited by user instructions such as one sentence or concise summary.",
          "",
          context.trusted,
        ].join("\n")
        const textPart = message.parts.findLast((part) => part?.type === "text" && !part.ignored)
        if (textPart) textPart.text = `${textPart.text ?? ""}\n\n${injected}`
        else message.parts.push({ type: "text", text: injected, synthetic: true })
      }
    },

    // ── ④ guard:所有工具在执行前交给 daemon 的同一回合状态机判定 ──
    "tool.execute.before": async (input, output) => {
      pruneClosedTurns()
      const sessionID = input?.sessionID ?? ""
      if (!sessionID) return
      const callID = typeof input?.callID === "string" ? input.callID : ""
      const boundTurn = callID ? turnsByToolCall.get(scopedKey(sessionID, callID)) : undefined
      const hasUnboundControlledTurn = !boundTurn && [...turnsByUserMessage.values()]
        .some((turn) => turn.sessionID === sessionID && turn.guardRequired && !turn.closedAt)
      if (hasUnboundControlledTurn) {
        throw new Error("Synapse could not bind this OpenCode tool call to its original controlled turn; retry the request.")
      }
      const resp = await postToDaemon(
        "guard",
        {
          session_id: sessionID,
          ...(boundTurn?.messageID ? { turn_id: boundTurn.messageID } : {}),
          tool_name: input?.tool ?? "",
          tool_input: output?.args ?? {},
          cwd: directory,
        },
        2000,
      )
      if (resp?.allow === false) {
        throw new Error(resp.reason || "Synapse blocked this tool call.")
      }
      if (resp?.allow === true) return
      if (boundTurn?.guardRequired || (!boundTurn && currentTurns.get(sessionID)?.guardRequired)) {
        throw new Error("Synapse guard is unavailable for this controlled capability turn; retry after Synapse reconnects.")
      }
    },

    // ── ⑤ report:回合结束上报(session.idle,fire-and-forget,不阻塞 opencode)──
    event: async ({ event }) => {
      pruneClosedTurns()
      if (event?.type === "message.updated") {
        const message = event.properties?.info
        if (message?.role !== "assistant" || typeof message.id !== "string"
          || typeof message.sessionID !== "string" || typeof message.parentID !== "string") return
        const turn = turnsByUserMessage.get(scopedKey(message.sessionID, message.parentID))
        if (turn) turnsByAssistantMessage.set(scopedKey(message.sessionID, message.id), turn)
        return
      }
      if (event?.type === "message.part.updated") {
        const part = event.properties?.part
        if (part?.type !== "tool" || typeof part.callID !== "string"
          || typeof part.messageID !== "string" || typeof part.sessionID !== "string") return
        const turn = turnsByAssistantMessage.get(scopedKey(part.sessionID, part.messageID))
        if (turn) turnsByToolCall.set(scopedKey(part.sessionID, part.callID), turn)
        return
      }
      if (event?.type === "session.deleted") {
        const sessionID = event?.properties?.sessionID ?? ""
        if (!sessionID) return
        pendingContext.delete(sessionID)
        currentTurns.delete(sessionID)
        clearSessionBindings(sessionID)
        return
      }
      if (event?.type !== "session.idle") return
      const sessionID = event?.properties?.sessionID ?? ""
      const turn = currentTurns.get(sessionID)
      if (!turn) return
      closeTurn(turn)
      await postToDaemon("report", {
        event: "session.idle",
        sessionID,
        ...(turn?.messageID ? { turn_id: turn.messageID } : {}),
        cwd: directory,
      }, 2000)
      if (currentTurns.get(sessionID) !== turn) return
      pendingContext.delete(sessionID)
      currentTurns.delete(sessionID)
    },
  }
}

export default SynapsePlugin
