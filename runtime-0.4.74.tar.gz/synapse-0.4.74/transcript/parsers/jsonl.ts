/**
 * transcript/parsers/jsonl.ts —— JSONL 会话文件的 torn-read 安全解析(CC / Codex)。
 *
 * 方案 R5/R7:正在被写入的会话文件可能最后一行是半行(torn write)。守卫:
 *   - 逐行解析,**只同步到最后一条完整换行结尾的行**;
 *   - 文件不以 \n 结尾 → 丢弃最后一段(可能是半行),游标只前进到最后一个 \n 之后。
 *
 * 返回:成功解析的记录 + 一个 byteOffset(下次从这里继续,幂等)。
 */
export interface JsonlParseResult {
  /** 成功解析的每行对象 */
  records: unknown[]
  /** 已安全消费到的字节偏移(下次 read 从此处继续) */
  safeOffset: number
  /** 跳过的坏行数(遥测) */
  skipped: number
}

/**
 * @param content 从 startOffset 起读到的文本
 * @param startOffset 本次读取在文件中的起始字节偏移
 */
export function parseJsonlSafe(content: string, startOffset = 0): JsonlParseResult {
  const records: unknown[] = []
  let skipped = 0

  // 找最后一个换行:它之后的内容可能是半行(正在写),丢弃不处理
  const lastNl = content.lastIndexOf("\n")
  if (lastNl === -1) {
    // 整段没有换行 → 全部可能是半行,一条都不消费
    return { records: [], safeOffset: startOffset, skipped: 0 }
  }

  // 只处理到最后一个换行为止的完整部分
  const complete = content.slice(0, lastNl) // 不含最后的 \n
  const lines = complete.split("\n")
  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed) continue // 空行跳过
    try {
      records.push(JSON.parse(trimmed))
    } catch {
      // 单行坏 JSON(极少见,非半行截断)→ 跳过并计数,不 throw
      skipped++
    }
  }

  // 消费到最后一个 \n 之后(含该换行符本身)
  const safeOffset = startOffset + Buffer.byteLength(content.slice(0, lastNl + 1), "utf8")
  return { records, safeOffset, skipped }
}
