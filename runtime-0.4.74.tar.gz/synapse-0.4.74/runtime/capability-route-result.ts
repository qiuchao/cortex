import {
  KnowledgeAgentExecuteRequestSchema,
  KnowledgeAgentExecuteResponseSchema,
} from "@cerebro/wire"
import type { TaskTurnExecutionAuthorization, TaskTurnGuardRegistry } from "../core/task-turn-guard.ts"
import type {
  KnowledgeConfirmationIntake,
  KnowledgeConfirmationPendingResponse,
} from "../core/knowledge-confirmation-intake.ts"
import type { AgentCapabilityBroker, AgentExecutionResult } from "./agent-capability-broker.ts"
import { isCapabilityRouteTerminalResponse } from "./task-route-execution.ts"

export type SettledCapabilityExecutionResult = AgentExecutionResult | { ok: true; response: unknown }

export async function settleCapabilityRouteExecution(input: {
  broker: AgentCapabilityBroker
  confirmationIntake?: KnowledgeConfirmationIntake
  guards?: TaskTurnGuardRegistry
  routeToken?: string
  authorization: TaskTurnExecutionAuthorization
  request: unknown
  result: AgentExecutionResult
}): Promise<SettledCapabilityExecutionResult> {
  if (!input.result.ok) return input.result
  const confirmation = KnowledgeAgentExecuteResponseSchema.safeParse(input.result.response)
  if (confirmation.success && confirmation.data.status === "confirmation_required") {
    const request = KnowledgeAgentExecuteRequestSchema.safeParse(input.request)
    if (!request.success || request.data.confirmation || !input.confirmationIntake) {
      return {
        ok: false,
        reason: "turn_scope_denied",
        message: "Knowledge confirmation could not be bound to a trusted user turn",
        httpStatus: 409,
      }
    }
    const captured = input.confirmationIntake.capture(
      request.data,
      confirmation.data,
      input.authorization.knowledgeUserInput,
    )
    markRouteComplete(input)
    if (!captured.confirmedRequest) return { ok: true, response: captured.publicResponse }

    const confirmed = await input.broker.execute(captured.confirmedRequest)
    if (!confirmed.ok) return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    const repeated = KnowledgeAgentExecuteResponseSchema.safeParse(confirmed.response)
    if (!repeated.success || repeated.data.capability !== request.data.capability) {
      return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    }
    if (repeated.data.status === "confirmation_required") {
      const publicResponse = input.confirmationIntake.updateReceipt(captured.operationId, repeated.data)
      return publicResponse
        ? { ok: true, response: publicResponse }
        : pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    }
    input.confirmationIntake.complete(captured.operationId)
    return { ok: true, response: repeated.data }
  }

  if (isCapabilityRouteTerminalResponse(input.result.response)) markRouteComplete(input)
  return input.result
}

function pendingAfterAutomaticConfirmationFailure(
  response: KnowledgeConfirmationPendingResponse,
): SettledCapabilityExecutionResult {
  return {
    ok: true,
    response: {
      ...response,
      summary: `${response.capability} 尚未确认完成；操作引用已保留，请在新消息中重试“${response.confirmationPrompt}”或取消。`,
    },
  }
}

function markRouteComplete(input: {
  guards?: TaskTurnGuardRegistry
  routeToken?: string
  authorization: TaskTurnExecutionAuthorization
}): void {
  if (input.authorization.tracked && input.authorization.completesRoute
    && input.guards && input.routeToken && input.authorization.command) {
    input.guards.markRouted(input.routeToken, input.authorization.command)
  }
}
