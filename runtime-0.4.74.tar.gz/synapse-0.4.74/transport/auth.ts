/**
 * transport/auth.ts —— 端点鉴权(信任边界的第一道门,Phase 1 起强制)。
 *
 * 方案 D6 / R1 / pre-mortem A:端点手握 KNOWLEDGE_API_KEY + 可触发不可逆 PII 上传。
 * 鉴权按 OS 派生,但**统一在这里判定**,上层 server 只调 authenticate()。
 *
 *  - unix socket(POSIX 默认):目录 0700 + socket 0600 = fs 权限即鉴权。
 *    能连上 socket 本身就证明是同 uid 进程 → 视为已认证。**无需 token。**
 *  - loopback TCP(fallback / Windows 主通路):**强制 bearer token**;
 *    请求必须带 `Authorization: Bearer <token>`,比对 loopbackTokenPath() 里的 0600 文件。
 *    **token-less loopback 一律拒绝**(方案硬红线)。
 *
 * 🔴 token 隔离:本文件的 loopback token 走 loopbackTokenPath(),与 core/token-store 的
 *    machine token(tokenPath(),主脑 Bearer)是两个不同秘密,物理隔离,绝不共用文件。
 */
import { randomBytes } from "node:crypto"
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from "node:fs"
import { dirname } from "node:path"
import type { IncomingMessage } from "node:http"
import { loopbackTokenPath, runtimeDir } from "./discovery.ts"

export type TransportMode = "unix-socket" | "named-pipe" | "loopback-tcp"

/**
 * 生成并落地一个 0600 loopback bearer token(仅 loopback-tcp 传输需要)。返回 token 明文。
 * 🔴 写 loopbackTokenPath(),**不是** machine token 的 tokenPath()——误用会覆盖工作台下发的主脑 token。
 * daemon 每次启动换新 token(自然轮换);薄壳每轮从 runtime.env 现读,天然跟随。
 */
export function ensureToken(env: NodeJS.ProcessEnv = process.env): string {
  const p = loopbackTokenPath(env)
  mkdirSync(dirname(p), { recursive: true, mode: 0o700 })
  const token = randomBytes(32).toString("hex")
  writeFileSync(p, token, { mode: 0o600 })
  chmodSync(p, 0o600) // 显式再收紧(umask 可能放宽)
  return token
}

/** 读取已落地的 loopback token(薄壳/CLI 侧用)。不存在返回 null。 */
export function readToken(env: NodeJS.ProcessEnv = process.env): string | null {
  try {
    return readFileSync(loopbackTokenPath(env), "utf8").trim() || null
  } catch {
    return null
  }
}

export interface AuthContext {
  mode: TransportMode
  /** loopback-tcp 模式下期望的 token(unix-socket 模式忽略)。 */
  expectedToken?: string
}

export interface AuthResult {
  ok: boolean
  /** 拒绝原因(用于 auth-rejection 遥测计数)。 */
  reason?: "missing_token" | "bad_token" | "token_not_configured"
}

/**
 * 判定一个入站请求是否已认证。
 *
 * unix-socket / named-pipe:连上即认证(fs 权限/ACL 已在 OS 层把关)。
 * loopback-tcp:必须 Bearer token 且匹配;缺 token / 不匹配 / 未配置 token 一律拒。
 */
export function authenticate(req: IncomingMessage, ctx: AuthContext): AuthResult {
  if (ctx.mode === "unix-socket" || ctx.mode === "named-pipe") {
    return { ok: true }
  }
  // loopback-tcp:强制 token
  if (!ctx.expectedToken) {
    // 没配置 token 的 loopback TCP = 禁止(token-less loopback 红线)
    return { ok: false, reason: "token_not_configured" }
  }
  const header = req.headers["authorization"]
  const presented =
    typeof header === "string" && header.startsWith("Bearer ")
      ? header.slice("Bearer ".length).trim()
      : ""
  if (!presented) return { ok: false, reason: "missing_token" }
  if (!timingSafeEqualStr(presented, ctx.expectedToken)) {
    return { ok: false, reason: "bad_token" }
  }
  return { ok: true }
}

/** 常数时间字符串比较,避免 token 比对计时侧信道。 */
function timingSafeEqualStr(a: string, b: string): boolean {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}

/** 确保运行时目录存在且为 0700(socket/token 的容器)。 */
export function ensureRuntimeDir(env: NodeJS.ProcessEnv = process.env): string {
  const dir = runtimeDir(env)
  mkdirSync(dir, { recursive: true, mode: 0o700 })
  try {
    chmodSync(dir, 0o700)
  } catch {
    /* best-effort */
  }
  return dir
}
