/**
 * policy/loader.ts —— 能力规范层框架:role→pack 映射 + 生命周期 + 规则同步。
 *
 * 框架职责(spec §99-102,窄):
 *   - 从主脑同步团队规则(单一来源) —— 协议是 daemon 内部细节(out of scope,可逆);
 *     这里留 syncRules() 钩子,默认 no-op(git pack 的分支规则先走 git-rules-loader 本地三层)。
 *   - role → 适用 pack 映射。
 *   - 对一个意图做确定性判定(遍历适用 pack 的 validate)。
 *
 * 新增团队规范 = 主脑加一个 pack(代码)+ 全员 daemon 下次同步获得,无需口头交接。
 * **不设计通用规则 DSL**(反过度抽象)。
 */
import type { PolicyPack, PolicyIntent, PolicyContext, ValidateResult } from "./pack.ts"
import { gitPack } from "./packs/git/index.ts"

export interface PolicyLoaderOptions {
  /** 注册的 pack(默认 git pack)。 */
  packs?: PolicyPack[]
  /** role→packIds 映射(默认:所有角色都挂 git)。 */
  rolePackMap?: Record<string, string[]>
}

export class PolicyLoader {
  private readonly packs: Map<string, PolicyPack>
  private readonly rolePackMap: Record<string, string[]>

  constructor(opts: PolicyLoaderOptions = {}) {
    const packs = opts.packs ?? [gitPack]
    this.packs = new Map(packs.map((p) => [p.id, p]))
    this.rolePackMap = opts.rolePackMap ?? {}
  }

  /** 取某 role 适用的 pack;未在 map 中 = 所有不限定角色的 pack。 */
  packsForRole(role: string | undefined): PolicyPack[] {
    const ids = role ? this.rolePackMap[role] : undefined
    if (ids) {
      return ids.map((id) => this.packs.get(id)).filter((p): p is PolicyPack => !!p)
    }
    // 默认:返回所有"不限定角色 / 适用该角色"的 pack
    return [...this.packs.values()].filter(
      (p) => !p.appliesToRoles || (role ? p.appliesToRoles.includes(role) : true),
    )
  }

  /**
   * 对一个意图做判定:遍历适用 pack,任一 pack 拒绝即拒绝(第一个 deny 短路)。
   * 无适用 pack / 全放行 → ok:true。
   */
  async validate(
    intent: PolicyIntent,
    ctx: PolicyContext,
    role?: string,
  ): Promise<ValidateResult> {
    // 追踪最弱 enforcement:任一 pack 报 unavailable/degraded 都要如实上浮,
    // 否则缺少能力/cwd 时的降级放行会被误报为 enforced。
    let weakest: ValidateResult["enforcement"] = "enforced"
    let weakestReason: string | undefined
    const rank = { enforced: 0, degraded: 1, unavailable: 2 } as const
    for (const pack of this.packsForRole(role)) {
      const r = await pack.validate(intent, ctx)
      if (!r.ok) return r // deny 短路,原样返回(含 reason)
      const e = r.enforcement ?? "enforced"
      if (rank[e] > rank[weakest]) {
        weakest = e
        weakestReason = r.reason
      }
    }
    return { ok: true, enforcement: weakest, reason: weakestReason }
  }

  /**
   * 从主脑同步规则。协议 out of scope(可逆);默认 no-op。
   * git 分支规则当前走本地三层(ported/git-rules-loader),brain 下发接口留待协议落地。
   */
  async syncRules(): Promise<void> {
    // no-op placeholder —— daemon→brain 协议是内部细节,不碰薄壳/verb
  }
}
