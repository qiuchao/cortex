/**
 * core/parsers/opencode.ts —— 运行时侧解析 opencode 的 hook 原始 stdin。
 *
 * opencode 用 plugin 事件(非 CLI hook stdin),但薄壳仍把事件载荷序列化为 JSON 转发:
 *   inject ← chat.message        { sessionID, message:{...}, ... }
 *   report ← event:session.ended { sessionID, ... }
 *
 * ⚠️ opencode 命名习惯用 camelCase `sessionID`(与 CC/Codex 的 session_id 不同)——
 *    这正是 adapter 模式要吸收的差异:统一在 parser 里归一,运行时只见规范字段。
 * 工具前置护栏由 plugin 的 tool.execute.before 直接转发 /guard，不经过本 parser。
 */
import type { InjectRequest, ReportRequest } from "../../transport/contract.ts"
import { str, asObject, parseAttachments, nestedStr, stableTurnAnchor, supportRails, transcriptTail } from "./util.ts"


/** 把一个 parts 数组(opencode Part[])里的 text/content 拼成一段文本。 */
function joinParts(parts: unknown): string {
  if (!Array.isArray(parts)) return ""
  return parts
    .map((p) => (p && typeof p === "object" ? str(p as Record<string, unknown>, "text", "content") : ""))
    .filter(Boolean)
    .join("\n")
}

/**
 * opencode chat.message 里用户文本的位置随 @opencode-ai/plugin 版本而异:
 *   - 顶层 text/prompt/content(旧形态 / 归一后)
 *   - message.content|text
 *   - **顶层 parts[]**(v1.17.x:hook output = { message, parts } 并列,parts 不在 message 内!
 *     plugin.js 按原形转发 → parts 落在**顶层**。漏读它 = user_input 恒空 = inject 恒降级)
 *   - message.parts[](保险:某些版本可能嵌在 message 内)
 * 顺序:直取 → message 文本 → 顶层 parts → message.parts,任一命中即返回。
 */
function extractUserText(o: Record<string, unknown>): string {
  const direct = str(o, "text", "prompt", "content")
  if (direct) return direct
  const msg = asObject(o["message"])
  const mContent = str(msg, "content", "text")
  if (mContent) return mContent
  // 🔴 顶层 parts(opencode v1.17.x 主形态)——真机实测 plugin 把 parts 转发在顶层。
  const topParts = joinParts(o["parts"])
  if (topParts) return topParts
  const msgParts = joinParts(msg["parts"])
  if (msgParts) return msgParts
  return ""
}

export function parseInject(raw: unknown): InjectRequest {
  const o = asObject(raw)
  // chat.message output always supplies the complete current parts array.
  const parsedAttachments = parseAttachments(o, Array.isArray(o["parts"]))
  const user_input = extractUserText(o)
  const session_id = str(o, "sessionID", "session_id", "sessionId")
  const message_id = str(o, "messageID", "message_id", "request_id", "id") || nestedStr(o, "message", "id") || undefined
  const conversation_id = str(o, "conversation_id", "conversationId") || undefined
  const turn_id = stableTurnAnchor(
    o,
    { client: "opencode", sessionId: session_id, messageId: message_id, conversationId: conversation_id, currentText: user_input },
    "turn_id", "messageID", "message_id", "request_id", "id",
  )
  return {
    client: "opencode",
    event: str(o, "event", "type") || "chat.message",
    project: str(o, "cwd", "directory", "worktree") || undefined,
    cwd: str(o, "cwd", "directory", "worktree") || undefined,
    user_input,
    session_id,
    turn_id,
    message_id,
    conversation_id,
    attachments: parsedAttachments.files,
    attachment_observation: parsedAttachments.observation,
    attachment_error: parsedAttachments.error,
    transcript_tail: transcriptTail(o),
    support_rails: supportRails(o),
  }
}

export function parseReport(raw: unknown): ReportRequest {
  const o = asObject(raw)
  return {
    client: "opencode",
    event: str(o, "event", "type") || "session.ended",
    session_id: str(o, "sessionID", "session_id", "sessionId"),
    turn_id: str(o, "turn_id", "messageID") || undefined,
    project: str(o, "cwd", "directory", "worktree") || undefined,
    cwd: str(o, "cwd", "directory", "worktree") || undefined,
  }
}
