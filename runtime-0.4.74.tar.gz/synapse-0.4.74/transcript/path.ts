/** 与 Cerebro normalizeLocalPath 保持一致，供目录清单和扫描过滤共用。 */
export function normalizeDirectoryPath(value: string): string {
  let normalized = value.trim().replace(/\\/g, "/")
  if (/^[A-Za-z]:\//.test(normalized)) normalized = normalized.toLowerCase()
  while (normalized.length > 1 && normalized.endsWith("/")) normalized = normalized.slice(0, -1)
  return normalized
}
