/** Shared registry transport. Registration relies exclusively on the atomic S20 contract. */
export interface RepoContext {
  repoId: string
  repoName: string
  productionId: string
  productionName: string | null
  projectId?: string
}

export interface RepoCloneHttpConfig {
  brainBaseUrl: string
  machineToken: string
  timeoutMs: number
}

export type RepoCloneLookup =
  | { status: "resolved"; context: RepoContext }
  // The server also returns null for an inaccessible binding, not only absence.
  | { status: "unresolved" }
  | { status: "unavailable" }
  | { status: "rejected"; code: string }

export async function lookupRepoCloneContext(
  cfg: RepoCloneHttpConfig,
  cwd: string,
  machineId: string,
  signal?: AbortSignal,
): Promise<RepoCloneLookup> {
  try {
    const response = await fetch(`${cfg.brainBaseUrl}/api/v1/repo-clones/resolve`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.machineToken}` },
      body: JSON.stringify({ cwd: cwd.trim(), machineId: machineId.trim() }),
      signal: signal
        ? AbortSignal.any([AbortSignal.timeout(cfg.timeoutMs), signal])
        : AbortSignal.timeout(cfg.timeoutMs),
    })
    if (!response.ok) return response.status === 401 || response.status === 403
      ? { status: "rejected", code: `http_${response.status}` } : { status: "unavailable" }
    const parsed = await response.json() as { status?: unknown; context?: unknown }
    if (parsed.status !== "ok") return { status: "unavailable" }
    if (parsed.context === null) return { status: "unresolved" }
    if (!parsed.context || typeof parsed.context !== "object") return { status: "unavailable" }
    const value = parsed.context as Record<string, unknown>
    if (typeof value.repoId !== "string" || !value.repoId.trim() || typeof value.repoName !== "string"
      || typeof value.productionId !== "string" || (value.productionName !== null && typeof value.productionName !== "string")) {
      return { status: "unavailable" }
    }
    return {
      status: "resolved",
      context: {
        repoId: value.repoId,
        repoName: value.repoName,
        productionId: value.productionId,
        productionName: value.productionName as string | null,
        ...(typeof value.projectId === "string" && value.projectId.trim() ? { projectId: value.projectId.trim() } : {}),
      },
    }
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? error
    return { status: "unavailable" }
  }
}

export interface RepoCloneRegistrationInput {
  productionId: string
  localPath: string
  cwd: string
  machineId: string
  repoId: string
  repositoryId: string
  candidateRepoIds: string[]
  gitRemote: string
}

export type RepoCloneRegistration =
  | { status: "created" | "unchanged" }
  | { status: "conflict" | "ambiguous" | "rejected" | "unavailable"; code?: string; reason?: string }

/** One atomic attempt; never retry or fall back to a legacy upsert. */
export async function registerRepoClone(
  cfg: RepoCloneHttpConfig, input: RepoCloneRegistrationInput, signal?: AbortSignal,
): Promise<RepoCloneRegistration> {
  try {
    const response = await fetch(`${cfg.brainBaseUrl}/api/v1/repo-clones`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.machineToken}` },
      body: JSON.stringify(input),
      signal: signal ? AbortSignal.any([AbortSignal.timeout(cfg.timeoutMs), signal]) : AbortSignal.timeout(cfg.timeoutMs),
    })
    const body = await response.json() as Record<string, unknown>
    // Only stable identifiers enter diagnostics, never arbitrary server messages/remotes.
    const identifier = (value: unknown) => typeof value === "string" && /^[a-z][a-z0-9_]{0,95}$/.test(value) ? value : undefined
    const code = identifier(body.code) ?? `http_${response.status}`
    const reason = identifier(body.reason)
    if (response.status === 409 && (body.status === "conflict" || body.status === "ambiguous")) {
      return { status: body.status, code, ...(reason ? { reason } : {}) }
    }
    if ((response.status === 201 && body.status === "created") || (response.status === 200 && body.status === "unchanged")) {
      return { status: body.status }
    }
    return { status: response.status >= 400 && response.status < 500 ? "rejected" : "unavailable", code }
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? error
    return { status: "unavailable" }
  }
}
