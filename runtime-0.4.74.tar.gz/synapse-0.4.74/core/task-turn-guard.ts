import { createHash } from "node:crypto"
import { lstatSync, readFileSync, realpathSync } from "node:fs"
import { basename, dirname, isAbsolute, normalize, resolve } from "node:path"
import type { InjectRequest } from "../transport/contract.ts"
import type { GuardResult } from "./guard.ts"
import { parseSafeCommandWords, parseSafeJsonPipeline } from "./safe-json-pipeline.ts"
import { quoteAgentCommandArgForLauncher } from "./agent-command-line.ts"
import { inferAgentCommandShell } from "./agent-command-line.ts"
import { bindTaskTurnEnvelope } from "./task-turn-envelope.ts"
import {
  AGENT_JSON_CHUNK_MAX_BYTES,
  AGENT_JSON_CHUNK_MAX_CHARS,
  AGENT_JSON_TRANSFER_MAX_BYTES,
  AGENT_JSON_TRANSFER_MAX_CHUNKS,
  decodeAgentJsonBase64Url,
} from "../runtime/agent-json-transfer.ts"
import {
  KnowledgeAgentExecuteRequestSchema,
  type KnowledgeCapabilityBoundArgs,
  type KnowledgeCapabilityName,
} from "@cerebro/wire"

export type TaskTurnGuardMode = "task_required" | "knowledge_required" | "answer_only" | "local_artifact_only" | "local_implementation" | "local_diagnostic" | "ordinary"

export interface TaskTurnRoutePolicy {
  kind?: "task"
  launcher: string
  routeToken: string
  draftRequestId: string
  protocolVersion: string
  productionId: string
  allowedCommands: readonly string[]
  completionCommands: readonly string[]
  /** Trusted complete inputs for deterministic commands in this turn. */
  boundInputByCommand?: Readonly<Record<string, Readonly<Record<string, unknown>>>>
  /** Deterministic routes have no reason to inspect a command schema first. */
  allowCommandDescribe?: boolean
  attachmentHandle?: string
  attachmentPolicy?: "bug-upload" | "requirement-empty-check"
  /** A completed create draft must return to the user instead of unlocking unrelated tools. */
  answerOnlyAfterCompletion?: boolean
  /** Hash of Claude Code's exact hook context, used to authorize its spill-file read. */
  injectedContextSha256?: string
}

export interface KnowledgeTurnRoutePolicy {
  kind: "knowledge"
  launcher: string
  routeToken: string
  protocolVersion: string
  client: InjectRequest["client"]
  sessionId: string
  turnId: string
  allowedCommands: readonly string[]
  completionCommands: readonly string[]
  /** Trusted user-message arguments, isolated by the selected capability. */
  boundArgsByCapability?: KnowledgeCapabilityBoundArgs
  answerOnlyAfterCompletion?: boolean
  injectedContextSha256?: string
}

export type CapabilityTurnRoutePolicy = TaskTurnRoutePolicy | KnowledgeTurnRoutePolicy

interface TaskTurnGuardPolicyBase {
  reason: string
}

export type TaskTurnGuardPolicy =
  | (TaskTurnGuardPolicyBase & { mode: "task_required"; route: TaskTurnRoutePolicy })
  | (TaskTurnGuardPolicyBase & { mode: "knowledge_required"; route: KnowledgeTurnRoutePolicy })
  | (TaskTurnGuardPolicyBase & {
      mode: Exclude<TaskTurnGuardMode, "task_required" | "knowledge_required">
      route?: undefined
    })

export interface TaskTurnGuardRegistryOptions {
  now?: () => number
  ttlMs?: number
  maxEntries?: number
}

export interface TaskTurnExecutionAuthorization {
  tracked: boolean
  allowed: boolean
  reason?: string
  request?: unknown
  command?: string
  completesRoute?: boolean
  /** Exact user text bound to a Knowledge route; never accepted from the model envelope. */
  knowledgeUserInput?: string
  attachmentPreparation?: {
    handle: string
    policy: "bug-upload" | "requirement-empty-check"
  }
}

export interface TaskTurnActivation {
  sessionKey: string
  turnKey: string
  generation: number
}

export interface TaskTurnGuardRegistry {
  beginTurn(request: InjectRequest): TaskTurnActivation | undefined
  register(request: InjectRequest, policy: TaskTurnGuardPolicy, activation?: TaskTurnActivation): void
  evaluate(client: string, raw: unknown): GuardResult | undefined
  authorizeExecution(routeToken: string | undefined, raw: unknown): TaskTurnExecutionAuthorization
  markAttachmentsPrepared(attachmentHandle: string, attachmentTokens: readonly string[]): boolean
  markRouted(routeToken: string, command: string): boolean
}

type TaskTurnGuardState = TaskTurnGuardPolicy & {
  key: string
  sessionId: string
  expiresAt: number
  routed: boolean
  userInput: string
  preparedAttachmentTokens?: string[]
}

interface ActiveTaskTurn {
  turnKey: string
  generation: number
  expiresAt: number
}

const DEFAULT_TTL_MS = 10 * 60_000
const DEFAULT_MAX_ENTRIES = 1_024

export function createTaskTurnGuardRegistry(
  options: TaskTurnGuardRegistryOptions = {},
): TaskTurnGuardRegistry {
  const now = options.now ?? Date.now
  const ttlMs = options.ttlMs ?? DEFAULT_TTL_MS
  const maxEntries = options.maxEntries ?? DEFAULT_MAX_ENTRIES
  const states = new Map<string, TaskTurnGuardState>()
  const tokenKeys = new Map<string, string>()
  const attachmentKeys = new Map<string, string>()
  const activeTurns = new Map<string, ActiveTaskTurn>()
  const revokedTurns = new Map<string, number>()
  const revokedActiveTurns = new Map<string, { turnKey: string; expiresAt: number }>()
  let generation = 0

  const remove = (key: string): void => {
    const state = states.get(key)
    if (state?.route?.routeToken) tokenKeys.delete(state.route.routeToken)
    if (isTaskRoute(state?.route) && state.route.attachmentHandle) {
      attachmentKeys.delete(state.route.attachmentHandle)
    }
    states.delete(key)
  }
  const forgetRevoked = (key: string): void => {
    revokedTurns.delete(key)
    for (const [sessionKey, revoked] of revokedActiveTurns) {
      if (revoked.turnKey === key) revokedActiveTurns.delete(sessionKey)
    }
  }
  const revoke = (key: string, current: number): void => {
    if (!states.has(key)) return
    remove(key)
    forgetRevoked(key)
    revokedTurns.set(key, current + ttlMs)
    while (revokedTurns.size > maxEntries) {
      forgetRevoked(revokedTurns.keys().next().value as string)
    }
  }
  const prune = (current: number): void => {
    for (const [key, state] of states) if (state.expiresAt <= current) remove(key)
    for (const [key, active] of activeTurns) if (active.expiresAt <= current) activeTurns.delete(key)
    for (const [key, expiresAt] of revokedTurns) if (expiresAt <= current) forgetRevoked(key)
    for (const [key, revoked] of revokedActiveTurns) {
      if (revoked.expiresAt <= current) revokedActiveTurns.delete(key)
    }
  }
  const stateForToken = (routeToken: string): TaskTurnGuardState | undefined => {
    const key = tokenKeys.get(routeToken)
    if (!key) return undefined
    return states.get(key)
  }

  return {
    beginTurn(request) {
      const current = now()
      prune(current)
      const sessionKey = taskSessionKey(request.client, request.session_id)
      const key = turnKey(request.client, request.session_id, request.turn_id)
      if (!sessionKey || !key) return undefined
      revokedActiveTurns.delete(sessionKey)
      const previous = activeTurns.get(sessionKey)
      if (previous?.turnKey === key) {
        remove(key)
        forgetRevoked(key)
      } else if (previous) {
        revoke(previous.turnKey, current)
      }
      const activation = { sessionKey, turnKey: key, generation: ++generation }
      activeTurns.set(sessionKey, { ...activation, expiresAt: current + ttlMs })
      while (activeTurns.size > maxEntries) {
        const oldestSession = activeTurns.keys().next().value as string
        const oldestTurn = activeTurns.get(oldestSession)
        if (oldestTurn) {
          revoke(oldestTurn.turnKey, current)
          const expiresAt = revokedTurns.get(oldestTurn.turnKey)
          if (expiresAt !== undefined) {
            revokedActiveTurns.set(oldestSession, { turnKey: oldestTurn.turnKey, expiresAt })
          }
        }
        activeTurns.delete(oldestSession)
      }
      return activation
    },
    register(request, policy, activation) {
      const current = now()
      prune(current)
      const currentActivation = activation ?? this.beginTurn(request)
      if (!currentActivation) return
      const active = activeTurns.get(currentActivation.sessionKey)
      if (!active
        || active.turnKey !== currentActivation.turnKey
        || active.generation !== currentActivation.generation) return
      const key = turnKey(request.client, request.session_id, request.turn_id)
      if (!key || key !== currentActivation.turnKey) return
      remove(key)
      forgetRevoked(key)
      const route = policy.route
      if ((policy.mode === "task_required" || policy.mode === "knowledge_required")
        && !validRoutePolicy(policy.mode, route)) {
        policy = {
          mode: "answer_only",
          reason: "本轮 capability 路由凭据不完整，不得调用本地、外部协议、浏览器或桌面 UI 工具。",
        }
      }
      const state: TaskTurnGuardState = {
        ...policy,
        key,
        sessionId: request.session_id!,
        userInput: request.user_input,
        expiresAt: current + ttlMs,
        routed: false,
      }
      states.set(key, state)
      active.expiresAt = state.expiresAt
      if (state.route) tokenKeys.set(state.route.routeToken, key)
      if (isTaskRoute(state.route) && state.route.attachmentHandle) {
        attachmentKeys.set(state.route.attachmentHandle, key)
      }
      while (states.size > maxEntries) revoke(states.keys().next().value as string, current)
    },
    evaluate(client, raw) {
      prune(now())
      const identity = hookTurnIdentity(raw)
      const sessionKey = taskSessionKey(client, identity.sessionId)
      if (!sessionKey) return undefined
      const key = turnKey(client, identity.sessionId, identity.turnId)
        ?? activeTurns.get(sessionKey)?.turnKey
        ?? revokedActiveTurns.get(sessionKey)?.turnKey
      if (!key) return undefined
      const state = states.get(key)
      if (!state) {
        return revokedTurns.has(key)
          ? deny("该 Task 回合已被后续用户回合取代，拒绝执行迟到的工具调用。")
          : undefined
      }
      if (state.mode === "ordinary") {
        const ordinaryCommand = hookCommand(raw)
        return ordinaryCommand && isAgentExecuteCommand(ordinaryCommand)
          ? deny("普通回合没有获得 Cerebro capability 授权；拒绝执行历史上下文中的 agent execute。")
          : undefined
      }
      if (state.mode === "answer_only") return deny(state.reason)
      if (state.mode === "local_artifact_only") {
        return isLocalArtifactTool(raw) ? undefined : deny(state.reason)
      }
      if (state.mode === "local_implementation" || state.mode === "local_diagnostic") {
        return isLocalImplementationTool(raw) ? undefined : deny(state.reason)
      }
      if (state.routed) {
        if (state.route?.answerOnlyAfterCompletion) {
          return deny("Synapse 已生成本轮待确认操作；不得再次调用工具、重复生成草稿或改用浏览器/桌面 UI。")
        }
        // A read may legitimately require more than one typed Task call (for
        // example list followed by detail). Keep the exact route available,
        // but never unlock unrelated local, browser, desktop, or MCP tools.
      }

      // Claude Code persists oversized UserPromptSubmit additionalContext to a
      // session-local file and asks the model to Read it. This is transport,
      // not repository exploration: authorize only the exact hashed payload
      // that Synapse injected for this controlled turn.
      if (client === "claude-code" && state.route
        && isAuthorizedClaudeContextRead(raw, state.sessionId, state.route.injectedContextSha256)) {
        return undefined
      }

      const command = hookCommand(raw)
      if (command && state.route) {
        const pipeline = validateAuthorizedExecutePipeline(command, state.route, state.preparedAttachmentTokens)
        if (pipeline.matched) {
          // PreToolUse only authorizes this exact call. The daemon marks the turn
          // routed after the typed broker has returned success.
          return pipeline.allowed ? undefined : deny(pipeline.reason)
        }
      }
      if (command && isTaskRoute(state.route) && state.route.allowCommandDescribe !== false
        && isAuthorizedTaskDescribeCommand(command, state.route)) return undefined
      return deny(
        state.mode === "knowledge_required"
          ? "本轮是明确的 Knowledge 操作。首个业务工具必须是注入中携带本轮令牌的完整 Synapse capability 管道；不得先浏览仓库、调用其他外部协议、操作浏览器/主脑桌面客户端或用 UI 自动化模拟人工操作。"
          : "本轮是可执行的需求/Bug/迭代操作。首个业务工具必须是注入中携带本轮令牌的完整 Synapse Task 管道；不得先浏览仓库、调用外部协议、操作浏览器/主脑桌面客户端或用 UI 自动化模拟人工操作。",
      )
    },
    authorizeExecution(routeToken, raw) {
      prune(now())
      if (!routeToken) {
        const identity = knowledgeExecutionIdentity(raw)
        const exactKey = identity
          ? turnKey(identity.client, identity.sessionId, identity.turnId)
          : undefined
        const sessionKey = identity
          ? taskSessionKey(identity.client, identity.sessionId)
          : undefined
        const activeKey = sessionKey
          ? activeTurns.get(sessionKey)?.turnKey ?? revokedActiveTurns.get(sessionKey)?.turnKey
          : undefined
        const key = exactKey ?? activeKey
        const state = key ? states.get(key) : undefined
        if (state || key && revokedTurns.has(key) || activeKey) {
          return { tracked: true, allowed: false, reason: "turn-scoped capability execution requires the active turn token" }
        }
        return { tracked: false, allowed: true }
      }
      const token = routeToken.trim()
      const state = stateForToken(token)
      if (!state || !state.route || (state.mode !== "task_required" && state.mode !== "knowledge_required")) {
        return { tracked: true, allowed: false, reason: "capability turn token is invalid or expired" }
      }
      if (state.routed && state.route.answerOnlyAfterCompletion) {
        return { tracked: true, allowed: false, reason: "Task turn already completed its pending operation" }
      }
      const taskRoute = isTaskRoute(state.route) ? state.route : undefined
      const knowledgeRoute = isKnowledgeRoute(state.route) ? state.route : undefined
      if (!taskRoute && !knowledgeRoute) {
        return { tracked: true, allowed: false, reason: "capability turn route type does not match its policy" }
      }
      const validated = taskRoute
        ? validateTaskEnvelope(raw, taskRoute, state.preparedAttachmentTokens)
        : validateKnowledgeEnvelope(raw, knowledgeRoute!)
      return validated.ok
        ? {
            tracked: true,
            allowed: true,
            request: validated.request,
            command: validated.command,
            completesRoute: validated.completesRoute,
            ...(knowledgeRoute ? { knowledgeUserInput: state.userInput } : {}),
            ...(validated.needsAttachmentPreparation && taskRoute?.attachmentHandle && taskRoute.attachmentPolicy
              ? {
                  attachmentPreparation: {
                    handle: taskRoute.attachmentHandle,
                    policy: taskRoute.attachmentPolicy,
                  },
                }
              : {}),
          }
        : { tracked: true, allowed: false, reason: validated.reason }
    },
    markAttachmentsPrepared(attachmentHandle, attachmentTokens) {
      prune(now())
      const key = attachmentKeys.get(attachmentHandle.trim())
      const state = key ? states.get(key) : undefined
      const route = state?.route
      if (!state || state.mode !== "task_required" || !isTaskRoute(route)
        || route.attachmentHandle !== attachmentHandle.trim()) return false
      const tokens = [...attachmentTokens]
      if (!tokens.every((token) => typeof token === "string" && token.trim() && token.length <= 512)
        || new Set(tokens).size !== tokens.length) return false
      if (route.attachmentPolicy === "requirement-empty-check" && tokens.length > 0) return false
      if (state.preparedAttachmentTokens
        && !sameStringArray(state.preparedAttachmentTokens, tokens)) return false
      state.preparedAttachmentTokens = tokens
      return true
    },
    markRouted(routeToken, command) {
      prune(now())
      const state = stateForToken(routeToken.trim())
      if (!state || (state.mode !== "task_required" && state.mode !== "knowledge_required")
        || !state.route?.completionCommands.includes(command)) return false
      state.routed = true
      return true
    },
  }
}

function validRoutePolicy(
  mode: "task_required" | "knowledge_required",
  route: CapabilityTurnRoutePolicy | undefined,
): route is CapabilityTurnRoutePolicy {
  if (mode === "knowledge_required") {
    return Boolean(
      isKnowledgeRoute(route)
        && route.launcher.trim()
        && route.routeToken.trim()
        && route.protocolVersion.trim()
        && route.client
        && route.sessionId.trim()
        && route.turnId.trim()
        && route.allowedCommands.length > 0
        && route.completionCommands.length > 0
        && route.completionCommands.every((command) => route.allowedCommands.includes(command))
        && validKnowledgeBoundArgs(route),
    )
  }
  return Boolean(
    isTaskRoute(route)
      && route.launcher.trim()
      && route.routeToken.trim()
      && route.draftRequestId.trim()
      && route.protocolVersion.trim()
      && route.productionId.trim()
      && route.allowedCommands.length > 0
      && route.completionCommands.length > 0
      && route.completionCommands.every((command) => route.allowedCommands.includes(command))
      && validTaskBoundInputs(route)
      && Boolean(route.attachmentHandle) === Boolean(route.attachmentPolicy)
      && (route.attachmentPolicy !== "bug-upload" || route.allowedCommands.includes("bug.create"))
      && (route.attachmentPolicy !== "requirement-empty-check" || route.allowedCommands.includes("requirement.create")),
  )
}

export function hashTaskInjectedContext(context: string): string {
  return createHash("sha256").update(context.trim()).digest("hex")
}

function turnKey(client: string, sessionId?: string, turnId?: string): string | undefined {
  const session = sessionId?.trim()
  const turn = turnId?.trim()
  return client && session && turn ? `${client}\n${session}\n${turn}` : undefined
}

function taskSessionKey(client: string, sessionId?: string): string | undefined {
  const session = sessionId?.trim()
  return client && session ? `${client}\n${session}` : undefined
}

function isKnowledgeRoute(
  route: CapabilityTurnRoutePolicy | undefined,
): route is KnowledgeTurnRoutePolicy {
  return route?.kind === "knowledge"
}

function isTaskRoute(
  route: CapabilityTurnRoutePolicy | undefined,
): route is TaskTurnRoutePolicy {
  return Boolean(route && route.kind !== "knowledge")
}

function hookTurnIdentity(raw: unknown): { sessionId?: string; turnId?: string } {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {}
  const record = raw as Record<string, unknown>
  return {
    sessionId: stringField(record, "session_id", "sessionId"),
    turnId: stringField(record, "turn_id", "turnId"),
  }
}

function hookCommand(raw: unknown): string {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return ""
  const record = raw as Record<string, unknown>
  const direct = coerceCommand(record["command"])
  if (direct) return direct
  for (const field of ["tool_input", "input"] as const) {
    const value = record[field]
    if (!value || typeof value !== "object" || Array.isArray(value)) continue
    const command = coerceCommand((value as Record<string, unknown>)["command"])
    if (command) return command
  }
  return ""
}

function isAgentExecuteCommand(command: string): boolean {
  const pipeline = parseSafeJsonPipeline(command)
  const candidates = pipeline ? [pipeline.receiver] : [command]
  return candidates.some((candidate) => {
    const words = parseSafeCommandWords(
      candidate,
      inferAgentCommandShell(candidate) === "powershell",
    )
    if (words) {
      return words.some((word, index) => (
        word === "agent" && words[index + 1] === "execute"
      ))
    }
    // Ordinary turns should never invoke the broker. Keep malformed historical
    // variants fail-closed even when they are not safe enough to tokenize.
    return /(?:^|\s)agent\s+execute(?:\s|$)/i.test(candidate)
  })
}

function hookToolName(raw: unknown): string {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return ""
  return stringField(raw as Record<string, unknown>, "tool_name", "toolName") ?? ""
}

function isLocalImplementationTool(raw: unknown): boolean {
  const toolName = hookToolName(raw)
  if (!/^(?:apply_patch|patch|Edit|Write|MultiEdit|NotebookEdit|Read|Glob|Grep|Bash|exec_command|shell_command|run_shell_command|view_image|list_directory|read_file|write_file|grep_search|replace)$/i.test(toolName)) {
    return false
  }
  const command = hookCommand(raw)
  return !command || !isAgentCapabilityCommand(command) && !isExternalOrUiCommand(command)
}

function isLocalArtifactTool(raw: unknown): boolean {
  return /^(?:apply_patch|patch|Edit|Write|MultiEdit|NotebookEdit|write_file|replace)$/i.test(hookToolName(raw))
}

function isAgentCapabilityCommand(command: string): boolean {
  const pipeline = parseSafeJsonPipeline(command)
  const candidates = pipeline ? [pipeline.receiver] : [command]
  return candidates.some((candidate) => {
    const words = parseSafeCommandWords(
      candidate,
      inferAgentCommandShell(candidate) === "powershell",
    )
    if (words) {
      return words.some((word, index) => (
        word === "agent" && /^(?:describe|execute|attachments)$/.test(words[index + 1] ?? "")
      ))
    }
    return /(?:^|\s)agent\s+(?:describe|execute|attachments)(?:\s|$)/i.test(candidate)
  })
}

function isExternalOrUiCommand(command: string): boolean {
  const executable = String.raw`(?:[^\s;&|()]+[/\\])?(?:curl|wget|http|https|ftp|sftp|ssh|scp|nc|ncat|netcat|telnet|websocat|playwright|selenium|chromium|chromium-browser|google-chrome|chrome|firefox|msedge|open|xdg-open|gio|osascript|xdotool|wmctrl|cliclick|cerebro)(?:\.exe)?`
  const commandBoundary = String.raw`(?:^|[;&|()\r\n]\s*|\b(?:then|do)\s+)`
  const wrappers = String.raw`(?:(?:sudo|env|command|exec|nohup)\s+)*`
  if (new RegExp(`${commandBoundary}${wrappers}${executable}(?:\\s|$)`, "i").test(command)) return true
  if (new RegExp(`${commandBoundary}${wrappers}(?:npx|bunx|pnpm\\s+dlx|yarn\\s+dlx)\\s+(?:--yes\\s+)?(?:@[^\\s]+/)?(?:playwright|selenium)(?:\\s|$)`, "i").test(command)) return true
  if (new RegExp(`${commandBoundary}${wrappers}(?:powershell|pwsh)(?:\\.exe)?\\b[^;\\r\\n]{0,160}\\b(?:Invoke-WebRequest|Invoke-RestMethod|Start-Process)\\b`, "i").test(command)) return true
  if (new RegExp(`${commandBoundary}${wrappers}(?:Invoke-WebRequest|Invoke-RestMethod|Start-Process|iwr|irm)(?:\\s|$)`, "i").test(command)) return true
  if (new RegExp(`${commandBoundary}${wrappers}git\\s+(?:clone|fetch|pull|push|ls-remote)(?:\\s|$)`, "i").test(command)) return true
  if (new RegExp(`${commandBoundary}${wrappers}(?:node|nodejs|bun|deno)(?:\\.exe)?\\s+(?:--eval|-e)\\b[^;\\r\\n]{0,320}(?:https?://|\\bfetch\\s*\\(|\\b(?:https?|net)\\s*\\.|require\\s*\\(\\s*['\"](?:node:)?(?:https?|net)|from\\s+['\"](?:node:)?(?:https?|net))`, "i").test(command)) return true
  return new RegExp(`${commandBoundary}${wrappers}(?:python|python3|py)(?:\\.exe)?\\s+(?:-c|/c)\\b[^;\\r\\n]{0,320}(?:https?://|urllib|requests|httpx|aiohttp|socket)`, "i").test(command)
}

function isAuthorizedClaudeContextRead(
  raw: unknown,
  sessionId: string,
  expectedHash?: string,
): boolean {
  if (!expectedHash || hookToolName(raw) !== "Read") return false
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return false
  const record = raw as Record<string, unknown>
  const input = record["tool_input"]
  if (!input || typeof input !== "object" || Array.isArray(input)) return false
  const fields = input as Record<string, unknown>
  if (Object.keys(fields).some((key) => !["file_path", "offset", "limit"].includes(key))) return false
  const filePath = fields["file_path"]
  if (typeof filePath !== "string" || !isAbsolute(filePath)) return false
  if (fields["offset"] !== undefined && (!Number.isInteger(fields["offset"]) || Number(fields["offset"]) < 0)) return false
  if (fields["limit"] !== undefined && (!Number.isInteger(fields["limit"]) || Number(fields["limit"]) < 1)) return false

  const normalized = normalize(filePath)
  if (basename(dirname(normalized)) !== "tool-results") return false
  if (basename(dirname(dirname(normalized))) !== sessionId) return false
  if (!/^hook-[a-f0-9-]+-\d+-additionalContext\.txt$/i.test(basename(normalized))) return false
  try {
    const stat = lstatSync(normalized)
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 2 * 1024 * 1024) return false
    if (realpathSync(normalized) !== resolve(normalized)) return false
    return hashTaskInjectedContext(readFileSync(normalized, "utf8")) === expectedHash
  } catch {
    return false
  }
}

function coerceCommand(value: unknown): string {
  if (typeof value === "string") return value.trim()
  if (Array.isArray(value) && value.every((part) => typeof part === "string")) return value.join(" ").trim()
  return ""
}

function stringField(record: Record<string, unknown>, ...names: string[]): string | undefined {
  for (const name of names) {
    const value = record[name]
    if (typeof value === "string" && value.trim()) return value.trim()
  }
  return undefined
}

function validateAuthorizedExecutePipeline(
  command: string,
  route: CapabilityTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  return isTaskRoute(route)
    ? validateTaskExecutePipeline(command, route, preparedAttachmentTokens)
    : validateKnowledgeExecutePipeline(command, route)
}

function validateTaskExecutePipeline(
  command: string,
  route: TaskTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  const pipeline = parseJsonPipeline(command)
  const payload: AgentJsonArgvPayload = pipeline && sameSafeCommand(pipeline.receiver, taskExecuteReceiver(route), route.launcher)
    ? { matched: true, ready: true, value: pipeline.payload }
    : parseAgentJsonArgvExecute(command, route)
  if (!payload.matched) return { matched: false }
  if (!payload.ready) {
    return payload.valid
      ? { matched: true, allowed: true }
      : { matched: true, allowed: false, reason: payload.reason }
  }
  const validated = validateTaskEnvelope(payload.value, route, preparedAttachmentTokens)
  return validated.ok
    ? { matched: true, allowed: true }
    : { matched: true, allowed: false, reason: validated.reason }
}

function validateKnowledgeExecutePipeline(
  command: string,
  route: KnowledgeTurnRoutePolicy,
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  const pipeline = parseJsonPipeline(command)
  const payload: AgentJsonArgvPayload = pipeline && sameSafeCommand(pipeline.receiver, agentExecuteReceiver(route), route.launcher)
    ? { matched: true, ready: true, value: pipeline.payload }
    : parseAgentJsonArgvExecute(command, route)
  if (!payload.matched) return { matched: false }
  if (!payload.ready) {
    return payload.valid
      ? { matched: true, allowed: true }
      : { matched: true, allowed: false, reason: payload.reason }
  }
  const validated = validateKnowledgeEnvelope(payload.value, route)
  return validated.ok
    ? { matched: true, allowed: true }
    : { matched: true, allowed: false, reason: validated.reason }
}

function knowledgeExecutionIdentity(raw: unknown): {
  client: string
  sessionId: string
  turnId: string
} | undefined {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return undefined
  const record = raw as Record<string, unknown>
  const client = stringField(record, "client")
  const sessionId = stringField(record, "sessionId")
  const turnId = stringField(record, "turnId")
  return client && sessionId && turnId
    ? { client, sessionId, turnId }
    : undefined
}

function validateKnowledgeEnvelope(
  raw: unknown,
  route: KnowledgeTurnRoutePolicy,
): {
  ok: true
  request: unknown
  command: string
  completesRoute: boolean
  needsAttachmentPreparation: false
} | { ok: false; reason: string } {
  const parsed = KnowledgeAgentExecuteRequestSchema.safeParse(bindKnowledgeRouteArgs(raw, route))
  if (!parsed.success) {
    const issues = parsed.error.issues
      .slice(0, 6)
      .map((issue) => `${issue.path.join(".") || "request"}: ${issue.message}`)
      .join("; ")
    return { ok: false, reason: `Knowledge envelope schema validation failed: ${issues}` }
  }
  const request = parsed.data
  if (request.confirmation) {
    return { ok: false, reason: "Knowledge confirmation is accepted only from a new explicit user turn" }
  }
  if (request.protocolVersion !== route.protocolVersion) {
    return { ok: false, reason: "Knowledge envelope protocolVersion does not match this turn" }
  }
  if (request.client !== route.client
    || request.sessionId !== route.sessionId
    || request.turnId !== route.turnId) {
    return { ok: false, reason: "Knowledge envelope identity does not match this turn" }
  }
  if (!route.allowedCommands.includes(request.capability)) {
    return { ok: false, reason: "Knowledge envelope capability is unavailable in this turn" }
  }
  return {
    ok: true,
    request,
    command: request.capability,
    completesRoute: route.completionCommands.includes(request.capability),
    needsAttachmentPreparation: false,
  }
}

function bindKnowledgeRouteArgs(raw: unknown, route: KnowledgeTurnRoutePolicy): unknown {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return raw
  const request = raw as Record<string, unknown>
  const capability = request["capability"]
  if (typeof capability !== "string") return raw
  const boundArgs = route.boundArgsByCapability?.[capability as KnowledgeCapabilityName]
  if (!boundArgs || Object.keys(boundArgs).length === 0) return raw
  const modelArgs = request["args"] && typeof request["args"] === "object" && !Array.isArray(request["args"])
    ? request["args"] as Record<string, unknown>
    : {}
  return { ...request, args: { ...modelArgs, ...boundArgs } }
}

function validKnowledgeBoundArgs(route: KnowledgeTurnRoutePolicy): boolean {
  return Object.entries(route.boundArgsByCapability ?? {}).every(([capability, args]) => (
    route.allowedCommands.includes(capability)
      && args !== null
      && typeof args === "object"
      && !Array.isArray(args)
  ))
}

function validateTaskEnvelope(
  raw: unknown,
  route: TaskTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): {
  ok: true
  request: unknown
  command: string
  completesRoute: boolean
  needsAttachmentPreparation: boolean
} | { ok: false; reason: string } {
  const bound = bindTaskTurnEnvelope(bindTaskRouteInput(raw, route), {
    draftRequestId: route.draftRequestId,
    allowMatchingRequestId: true,
  })
  if (!bound.ok) return bound
  if (bound.request.protocolVersion !== route.protocolVersion) {
    return { ok: false, reason: "Task envelope protocolVersion does not match this turn" }
  }
  if (bound.request.productionId !== route.productionId) {
    return { ok: false, reason: "Task envelope productionId does not match this turn" }
  }
  if (!route.allowedCommands.includes(bound.command)) {
    return { ok: false, reason: "Task envelope command is unavailable in this turn" }
  }
  let trustedRequest: unknown = bound.request
  let needsAttachmentPreparation = false
  if (bound.command === "bug.create" && route.attachmentPolicy === "bug-upload") {
    const input = bound.request.input as Record<string, unknown>
    const supplied = input["attachmentTokens"]
    if (supplied !== undefined) {
      return { ok: false, reason: "bug.create attachmentTokens must be omitted and bound by Synapse for this turn" }
    }
    if (!preparedAttachmentTokens) {
      needsAttachmentPreparation = true
    } else {
      trustedRequest = {
        ...bound.request,
        input: { ...input, attachmentTokens: [...preparedAttachmentTokens] },
      }
    }
  }
  if (bound.command === "requirement.create" && route.attachmentPolicy === "requirement-empty-check") {
    const input = bound.request.input as Record<string, unknown>
    if (input["attachmentTokens"] !== undefined) {
      return { ok: false, reason: "requirement.create does not accept attachmentTokens" }
    }
    if (!preparedAttachmentTokens) {
      needsAttachmentPreparation = true
    }
    if (preparedAttachmentTokens && preparedAttachmentTokens.length > 0) {
      return { ok: false, reason: "requirement.create does not support current-turn attachments" }
    }
  }
  return {
    ok: true,
    request: trustedRequest,
    command: bound.command,
    completesRoute: route.completionCommands.includes(bound.command),
    needsAttachmentPreparation,
  }
}

function bindTaskRouteInput(raw: unknown, route: TaskTurnRoutePolicy): unknown {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return raw
  const request = raw as Record<string, unknown>
  const command = request["command"]
  if (typeof command !== "string") return raw
  const input = route.boundInputByCommand?.[command]
  return input ? { ...request, input: { ...input } } : raw
}

function validTaskBoundInputs(route: TaskTurnRoutePolicy): boolean {
  return Object.entries(route.boundInputByCommand ?? {}).every(([command, input]) => (
    route.allowedCommands.includes(command)
      && input !== null
      && typeof input === "object"
      && !Array.isArray(input)
  ))
}

function sameStringArray(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index])
}

function agentExecuteReceiver(route: CapabilityTurnRoutePolicy): string {
  return `${route.launcher} agent execute --stdin --turn-token ${quoteAgentCommandArgForLauncher(route.routeToken, route.launcher)}`
}

function taskExecuteReceiver(route: TaskTurnRoutePolicy): string {
  return agentExecuteReceiver(route)
}

function isAuthorizedTaskDescribeCommand(command: string, route: TaskTurnRoutePolicy): boolean {
  const value = command.trim()
  if (!value) return false
  return route.allowedCommands.some((capability) => sameSafeCommand(value, [
    route.launcher,
    "agent describe --task-only --json --production-id",
    quoteAgentCommandArgForLauncher(route.productionId, route.launcher),
    "--capability",
    quoteAgentCommandArgForLauncher(capability, route.launcher),
  ].join(" "), route.launcher))
}

function sameSafeCommand(actual: string, expected: string, launcher: string): boolean {
  const powershell = inferAgentCommandShell(launcher) === "powershell"
  const actualWords = parseSafeCommandWords(actual, powershell)
  const expectedWords = parseSafeCommandWords(expected, powershell)
  return Boolean(
    actualWords
      && expectedWords
      && actualWords.length === expectedWords.length
      && actualWords.every((word, index) => word === expectedWords[index]),
  )
}

function parseJsonPipeline(command: string): { payload: unknown; receiver: string } | undefined {
  return parseSafeJsonPipeline(command)
}

type AgentJsonArgvPayload =
  | { matched: false }
  | { matched: true; ready: true; value: unknown }
  | { matched: true; ready: false; valid: true }
  | { matched: true; ready: false; valid: false; reason: string }

function parseAgentJsonArgvExecute(
  command: string,
  route: CapabilityTurnRoutePolicy,
): AgentJsonArgvPayload {
  const powershell = inferAgentCommandShell(route.launcher) === "powershell"
  const words = parseSafeCommandWords(command, powershell)
  const launcherWords = parseSafeCommandWords(route.launcher, powershell)
  if (!words || !launcherWords || !startsWithWords(words, launcherWords)) return { matched: false }
  const args = words.slice(launcherWords.length)
  if (args[0] !== "agent" || args[1] !== "execute") return { matched: false }

  const fail = (reason: string): AgentJsonArgvPayload => ({
    matched: true,
    ready: false,
    valid: false,
    reason,
  })
  const token = args.at(-2) === "--turn-token" ? args.at(-1) : undefined
  if (token !== route.routeToken) return fail("agent execute argv transport has an invalid or missing turn token")
  const transport = args.slice(2, -2)

  if (transport.length === 2 && transport[0] === "--json-base64url") {
    try {
      const value = JSON.parse(decodeAgentJsonBase64Url(transport[1])) as unknown
      if (!value || typeof value !== "object" || Array.isArray(value)) {
        return fail("agent execute --json-base64url must contain one JSON object")
      }
      return { matched: true, ready: true, value }
    } catch (error) {
      return fail(`agent execute --json-base64url is invalid: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  if (transport[0] === "--json-chunk") {
    if (transport.length !== 8
      || transport[2] !== "--transfer-id"
      || transport[4] !== "--chunk-index"
      || transport[6] !== "--chunk-count") {
      return fail("agent execute --json-chunk transport shape is invalid")
    }
    const chunkCount = parseCanonicalNonNegativeInteger(transport[7])
    const chunkIndex = parseCanonicalNonNegativeInteger(transport[5])
    if (!validTransferId(transport[3])
      || chunkCount === undefined || chunkCount < 1 || chunkCount > AGENT_JSON_TRANSFER_MAX_CHUNKS
      || chunkIndex === undefined || chunkIndex >= chunkCount) {
      return fail("agent execute --json-chunk metadata is invalid")
    }
    const maxChunkBytes = Math.min(
      AGENT_JSON_CHUNK_MAX_BYTES,
      Math.floor(AGENT_JSON_TRANSFER_MAX_BYTES / chunkCount),
    )
    if (!validCanonicalBase64UrlChunk(transport[1], maxChunkBytes)) {
      return fail("agent execute --json-chunk payload is invalid")
    }
    return { matched: true, ready: false, valid: true }
  }

  if (transport[0] === "--json-finalize") {
    if (transport.length !== 5
      || transport[1] !== "--transfer-id"
      || transport[3] !== "--chunk-count") {
      return fail("agent execute --json-finalize transport shape is invalid")
    }
    const chunkCount = parseCanonicalNonNegativeInteger(transport[4])
    if (!validTransferId(transport[2])
      || chunkCount === undefined || chunkCount < 1 || chunkCount > AGENT_JSON_TRANSFER_MAX_CHUNKS) {
      return fail("agent execute --json-finalize metadata is invalid")
    }
    return { matched: true, ready: false, valid: true }
  }

  return fail("agent execute argv transport mode is invalid")
}

function startsWithWords(words: readonly string[], prefix: readonly string[]): boolean {
  return words.length >= prefix.length
    && prefix.every((word, index) => words[index] === word)
}

function parseCanonicalNonNegativeInteger(value: string | undefined): number | undefined {
  if (!value || !/^(?:0|[1-9]\d*)$/.test(value)) return undefined
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) ? parsed : undefined
}

function validTransferId(value: string | undefined): boolean {
  return Boolean(value && /^[A-Za-z0-9_-]{16,128}$/.test(value))
}

function validCanonicalBase64UrlChunk(value: string | undefined, maxBytes: number): boolean {
  if (!value || value.length > AGENT_JSON_CHUNK_MAX_CHARS || !/^[A-Za-z0-9_-]+$/.test(value)) return false
  const decoded = Buffer.from(value, "base64url")
  return decoded.length > 0
    && decoded.length <= maxBytes
    && decoded.toString("base64url") === value
}

function deny(reason: string): GuardResult {
  return { allow: false, reason, enforcement: "enforced" }
}
