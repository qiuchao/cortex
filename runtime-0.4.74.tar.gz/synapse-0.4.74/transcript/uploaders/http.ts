/**
 * transcript/uploaders/http.ts —— 真实 HTTP uploader。
 *
 * 实现 TranscriptUploader 接口，将 TranscriptRecord[] 映射为
 * POST /brain/transcripts 的 raw + 边界请求体，由主脑归一层处理。
 *
 * 关键设计约束（corpus-contract.md 红线）：
 *   · 只传 raw + 边界(sessions/messages)，不传 role/content/textPreview/model。
 *     title 是客户端提供的 session 边界元数据，不属于消息归一结果。
 *   · source_message_id 必须稳定、跨轮一致（幂等键第四列）。
 *     对于没有原生 id 的消息，派生规则：
 *       {source_session_id}:{seqBase + chunkIndex}
 *     其中 seqBase = scanner 记录的文件绝对行序号（cursor.recordCount），
 *     chunkIndex = 本批次内的 0-based 下标。
 *     JSONL 客户端每轮只读新字节，seqBase 保证跨轮不重置，杜绝 id 碰撞。
 *   · 失败绝不 throw（保持 loop.ts 的游标重试语义）。
 *   · 按 session 边界分批，且单条 record 内 messages 超限时子拆分：
 *     单批 messages ≤ 500 条 或 ≤ 8MB（取先达到者）。
 */

import type { TranscriptRecord } from '../scanner.ts'
import type { TranscriptUploader } from '../upload.ts'
import type { CorpusSessionBoundary, CorpusMessageRaw, UploadTranscriptsRequest } from '@cerebro/wire'
import { getBrainConfig } from '../../transport/brain-config.ts'

const MAX_MESSAGES_PER_BATCH = 500
const MAX_BYTES_PER_BATCH = 8 * 1024 * 1024 // 8 MB

/**
 * 判断字符串是否为合法 ISO8601 datetime（主脑 z.string().datetime() 要求）。
 * 非法字符串透传会导致主脑校验 400 整批失败 → 游标永久卡住，故在此守门。
 */
function isIsoDatetime(s: string): boolean {
  // 简单守门：可被 Date.parse 解析 + 包含 T 分隔符（排除纯日期 "2026-07-17"）
  if (!s.includes('T')) return false
  const ms = Date.parse(s)
  return !Number.isNaN(ms)
}

/**
 * 把一个 raw 对象中的时间戳字段转成安全的 ISO8601 字符串。
 * - 数字（ms epoch）→ toISOString()，始终合法。
 * - 字符串 → 仅当通过 isIsoDatetime 校验时返回，否则 undefined（省略字段）。
 */
function extractSourceTs(raw: unknown): string | undefined {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) return undefined
  const r = raw as Record<string, unknown>
  const ts = r['timestamp'] ?? r['source_ts'] ?? r['created_at'] ?? r['createdAt']
  if (typeof ts === 'number') {
    return new Date(ts).toISOString()
  }
  if (typeof ts === 'string' && isIsoDatetime(ts)) {
    return ts
  }
  return undefined
}

/**
 * 把一个 TranscriptRecord 拆成 (session boundary, messages[])。
 *
 * source_message_id 稳定派生规则（CRIT fix）：
 *   · 原始 raw 对象有顶层 id / requestId / messageId / uuid → 优先使用原生值。
 *   · 无原生 id → `{session_id}:{seqBase + chunkIndex}`。
 *     seqBase 来自 scanner 的 cursor.recordCount（文件绝对累计行号），
 *     chunkIndex 是本 record.messages 内的 0-based 下标。
 *     JSONL 客户端每轮只读新字节，但 seqBase 跨轮单调递增，id 不会重置碰撞。
 */
function recordToCorpus(
  record: TranscriptRecord,
): { session: CorpusSessionBoundary; messages: CorpusMessageRaw[] } {
  const session: CorpusSessionBoundary = {
    source_client: record.client as CorpusSessionBoundary['source_client'],
    source_session_id: record.session_id,
    source_ts: record.timestamp,
    // 只传会话原始记录中可验证的实际绝对 cwd/project_path。
    // 不使用 scanner 的 fileToProject 存储目录标签（如 Claude 编码目录名），否则无法匹配 repo_clones。
    project_path: record.project_path,
    title: record.title,
  }

  const seqBase = record.seqBase ?? 0

  const messages: CorpusMessageRaw[] = record.messages.map((raw, chunkIndex) => {
    // 尝试从 raw 对象中取原生稳定 id；若无则用文件绝对 seq 派生
    let source_message_id: string
    if (raw !== null && typeof raw === 'object' && !Array.isArray(raw)) {
      const r = raw as Record<string, unknown>
      const native = r['id'] ?? r['requestId'] ?? r['messageId'] ?? r['uuid']
      if (typeof native === 'string' && native.trim()) {
        source_message_id = native.trim()
      } else {
        source_message_id = `${record.session_id}:${seqBase + chunkIndex}`
      }
    } else {
      source_message_id = `${record.session_id}:${seqBase + chunkIndex}`
    }

    const source_ts = extractSourceTs(raw)

    return {
      source_client: record.client as CorpusMessageRaw['source_client'],
      source_session_id: record.session_id,
      source_message_id,
      seq: seqBase + chunkIndex,
      raw,
      ...(source_ts ? { source_ts } : {}),
    }
  })

  return { session, messages }
}

/**
 * 将 records 分批，每批不超过 MAX_MESSAGES_PER_BATCH 条 / MAX_BYTES_PER_BATCH 字节。
 *
 * MED fix（单 record 超限子拆分）：单条 record 的 messages 超过上限时，
 * 在 record 内部切分为多个子批，每子批重复 session boundary（主脑幂等键去重）。
 * 这保证即使单个 session 有数千条消息，也不会违反契约 cap 或触发 8s 超时。
 */
function buildBatches(
  records: TranscriptRecord[],
): UploadTranscriptsRequest[] {
  const batches: UploadTranscriptsRequest[] = []
  let currentSessions: CorpusSessionBoundary[] = []
  let currentMessages: CorpusMessageRaw[] = []
  let currentBytes = 0

  function flush() {
    if (currentSessions.length > 0) {
      batches.push({ sessions: currentSessions, messages: currentMessages })
      currentSessions = []
      currentMessages = []
      currentBytes = 0
    }
  }

  for (const record of records) {
    const { session, messages } = recordToCorpus(record)

    // 单 record 内子拆分：将 messages 切成不超过 MAX_MESSAGES_PER_BATCH 的块
    let i = 0
    while (i < messages.length) {
      const chunk: CorpusMessageRaw[] = []
      let chunkBytes = 0

      while (i < messages.length) {
        const msgBytes = Buffer.byteLength(JSON.stringify(messages[i]), 'utf8')
        // 若当前 chunk 已有内容且追加后超限 → 停止，下次循环继续
        if (
          chunk.length > 0 &&
          (chunk.length + 1 > MAX_MESSAGES_PER_BATCH ||
            chunkBytes + msgBytes > MAX_BYTES_PER_BATCH)
        ) {
          break
        }
        chunk.push(messages[i]!)
        chunkBytes += msgBytes
        i++
      }

      // 把这个 chunk 追加到当前批次；若追加后超限，先 flush 当前批次
      if (
        currentMessages.length > 0 &&
        (currentMessages.length + chunk.length > MAX_MESSAGES_PER_BATCH ||
          currentBytes + chunkBytes > MAX_BYTES_PER_BATCH)
      ) {
        flush()
      }

      currentSessions.push(session) // session 可重复（主脑 onConflictDoNothing）
      currentMessages.push(...chunk)
      currentBytes += chunkBytes
    }
  }

  flush()
  return batches
}

/**
 * 向 POST {brainBaseUrl}/brain/transcripts 上传一批语料。
 * 非 2xx 或网络错误 → { ok: false, uploaded: 0 }，绝不 throw。
 */
async function uploadBatch(
  batch: UploadTranscriptsRequest,
  brainBaseUrl: string,
  machineToken: string,
  timeoutMs: number,
): Promise<{ ok: boolean; accepted: number }> {
  const url = `${brainBaseUrl}/brain/transcripts`
  let resp: Response
  try {
    resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${machineToken}`,
      },
      body: JSON.stringify(batch),
      signal: AbortSignal.timeout(timeoutMs),
    })
  } catch {
    // 网络错误 / 超时
    return { ok: false, accepted: 0 }
  }

  if (!resp.ok) {
    return { ok: false, accepted: 0 }
  }

  let parsed: { accepted?: unknown; skipped_duplicates?: unknown }
  try {
    parsed = (await resp.json()) as { accepted?: unknown; skipped_duplicates?: unknown }
  } catch {
    return { ok: false, accepted: 0 }
  }

  if (
    typeof parsed.accepted !== 'number' ||
    !Number.isInteger(parsed.accepted) ||
    parsed.accepted < 0 ||
    typeof parsed.skipped_duplicates !== 'number' ||
    !Number.isInteger(parsed.skipped_duplicates) ||
    parsed.skipped_duplicates < 0
  ) {
    return { ok: false, accepted: 0 }
  }
  return { ok: true, accepted: parsed.accepted }
}

/**
 * 创建基于 HTTP 的 TranscriptUploader。
 *
 * brain config 缺失（CEREBRO_BRAIN_URL / token 未配置）→ 降级返回 ok:false，
 * loop.ts 收到 ok:false 后保守不推进游标（下轮重试），符合「未配置不丢数据」语义。
 *
 * @param env 环境变量注入（便于测试 mock，默认 process.env）
 */
export function createHttpUploader(
  env: NodeJS.ProcessEnv = process.env,
  options: { onBatchComplete?: () => void } = {},
): TranscriptUploader {
  return async (records) => {
    if (records.length === 0) return { ok: true, uploaded: 0 }

    const cfg = getBrainConfig(env)
    if (!cfg || !cfg.machineToken) {
      // brain 未配置 → 静默降级（不 throw，不打日志；loop 保守处理）
      return { ok: false, uploaded: 0 }
    }

    const batches = buildBatches(records)
    let totalAccepted = 0

    for (const batch of batches) {
      const result = await uploadBatch(
        batch,
        cfg.brainBaseUrl,
        cfg.machineToken,
        cfg.timeoutMs,
      )
      if (!result.ok) {
        // 任一批次失败 → 整体 ok:false（loop.ts 回退游标，下轮重试全部）
        return { ok: false, uploaded: 0 }
      }
      totalAccepted += result.accepted
      options.onBatchComplete?.()
    }

    return { ok: true, uploaded: totalAccepted }
  }
}
