/**
 * core/formatters/index.ts —— 运行时侧 per-client **出站**格式化(与 core/parsers/ 对称)。
 *
 * parsers 把各客户端 hook 原始 stdin → 规范 Inject/ReportRequest(入站);
 * formatters 把规范响应(InjectResponse / GuardResult / ReportResponse)→ **各客户端 hook
 * 契约**(出站)。薄壳零业务逻辑 —— 原样回显 daemon 返回的 body,契约翻译全在这里。
 *
 * ## 为什么必须有这层(真机 CC 验收踩的坑)
 * Claude Code(v2.1.90 起)/ Codex(ClaudeHooksEngine)/ Gemini CLI 的 hook 都**不认**
 * 通用的 `{"allow":false}` / `{"context":"..."}`,各有自己的 stdout JSON 契约:
 *   - PreToolUse 拒绝 = `hookSpecificOutput.permissionDecision:"deny"` + reason(exit 0);
 *     `{"allow":false}` 与旧 exit 2 都被忽略 → 护栏形同虚设。
 *   - Claude UserPromptSubmit 用 `hookSpecificOutput.additionalContext`；Codex 0.144.x 用其
 *     官方 raw-text stdout 兼容通道；Gemini 用 BeforeAgent additionalContext 改 prompt。
 * 之前 WSL「验收」用 CLI 喂 stdin,从没走真实 hook 通道验 daemon 输出是否被 honor → 漏掉。
 *
 * ## 契约来源(均官方文档 / 源码核实)
 *   - claude-code:code.claude.com/docs/en/hooks(hookSpecificOutput + permissionDecision)。
 *   - codex:openai/codex rust-v0.144.4 hooks/events/user_prompt_submit.rs 的 plain-text 分支。
 *   - gemini-cli:v0.49.0 hooks BeforeAgent additionalContext prompt 改写。
 *   - opencode:走 plugin.js(非 shim),plugin 直接读 canonical response 的分层 context
 *     → **identity**,原样回。
 *
 * ## 纪律
 *   - inject 空/降级 → `{}`(无决策),绝不回带噪声的壳。
 *   - guard allow → `{}`(= exit 0 无决策 = 走客户端正常权限流,**不**自动批准)。
 *   - report → `{}`(Stop/SessionEnd 纯副作用;回 additionalContext 会让 CC「继续对话」)。
 */
import type { InjectResponse, ReportResponse } from "../../transport/contract.ts"
import type { GuardResult } from "../guard.ts"

/** 每客户端出站格式化器。返回值是**将被 JSON.stringify 回给薄壳**的对象。 */
export interface ClientFormatter {
  supportsAnswerValidation?: boolean
  formatInject: (r: InjectResponse, rawInput?: unknown) => unknown
  formatGuard: (r: GuardResult) => unknown
  formatReport: (r: ReportResponse, authoritativeReceipt?: string) => unknown
}

// ─────────────────────────────────────────────────────────────────────────────
// claude-code:hookSpecificOutput + permissionDecision
// ─────────────────────────────────────────────────────────────────────────────

/**
 * CC / Codex 同族契约。inject 用 UserPromptSubmit,guard 用 PreToolUse。
 * hookEventName 必填(CC 官方 schema 要求),故这里带上。
 */
const claudeCode: ClientFormatter = {
  formatInject(r) {
    const ctx = (r.context ?? "").trim()
    // 空/降级 → 无决策(不塞空壳);非空 → additionalContext。
    if (!ctx) return {}
    return {
      hookSpecificOutput: {
        hookEventName: "UserPromptSubmit",
        additionalContext: ctx,
      },
    }
  },
  formatGuard(r) {
    // allow(或无判定)→ {}:exit 0 无决策 = 走客户端正常权限流(不自动批准)。
    if (r.allow) return {}
    // deny → permissionDecision:deny + reason(CC/Codex 硬拦的唯一被认形态)。
    return {
      hookSpecificOutput: {
        hookEventName: "PreToolUse",
        permissionDecision: "deny",
        permissionDecisionReason: r.reason ?? "blocked by Synapse policy",
      },
    }
  },
  formatReport() {
    // Stop/SessionEnd 纯副作用:不回 additionalContext(否则 CC 视为「继续对话」)。
    return {}
  },
}

// Codex 0.144.x 明确把 exit 0 的非 JSON stdout 直接作为 additional context。使用这条
// 原生文本通道可避开严格 deny_unknown_fields JSON schema，也不会被同组其他 hook 的
// JSON 解析状态污染。guard 仍沿用 ClaudeHooksEngine 的 PreToolUse JSON 契约。
const codex: ClientFormatter = {
  supportsAnswerValidation: true,
  formatInject(r) {
    const ctx = (r.context ?? "").trim()
    if (!ctx) return ""
    // Codex treats stdout beginning with `{` or `[` as JSON. Synapse contexts begin with
    // `[Synapse ...]`, so emitting the context verbatim makes valid plain text fail JSON parsing.
    return `Synapse additional context:\n${ctx}`
  },
  formatGuard: claudeCode.formatGuard,
  formatReport(r, authoritativeReceipt) {
    if (r.answerValidation?.status === "correct") return { decision: "block", reason: r.answerValidation.reason }
    if (r.answerValidation?.notificationPrompt) return { decision: "block", reason: r.answerValidation.notificationPrompt }
    if (r.answerValidation?.status === "failed") return { continue: false, stopReason: r.answerValidation.reason, systemMessage: r.answerValidation.reason }
    return authoritativeReceipt ? { systemMessage: authoritativeReceipt } : {}
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// gemini-cli:BeforeAgent additionalContext;guard decision:"deny"
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Gemini 0.49.0 的 BeforeModel llm_request translator 会过滤 function parts，改写后可能在
 * 并行工具 continuation 中重复 functionResponse。BeforeAgent additionalContext 直接追加到
 * 当前 prompt，不重建模型 history，因此是知识与控制上下文的安全注入点。
 *   - 拒绝 = 顶层 decision:"deny" + reason(gemini 未装 guard,留作完整性)。
 *   - SessionEnd = {}(副作用)。
 */
const geminiCli: ClientFormatter = {
  formatInject(r, rawInput) {
    const ctx = (r.context ?? "").trim()
    if (!ctx) return {}
    if (!rawInput || typeof rawInput !== "object") return {}
    const raw = rawInput as Record<string, unknown>
    if (raw["hook_event_name"] !== "BeforeAgent" || typeof raw["prompt"] !== "string") return {}
    return {
      hookSpecificOutput: {
        hookEventName: "BeforeAgent",
        additionalContext: ctx,
      },
    }
  },
  formatGuard(r) {
    if (r.allow) return {}
    return { decision: "deny", reason: r.reason ?? "blocked by Synapse policy" }
  },
  formatReport() {
    return {}
  },
}

// Kimi UserPromptSubmit consumes successful stdout as additional context. Keep
// it plain text; JSON-shaped stdout is interpreted as hook control metadata.
const kimiCode: ClientFormatter = {
  formatInject(r) {
    const ctx = (r.context ?? "").trim()
    return ctx ? `Synapse additional context:\n${ctx}` : ""
  },
  formatGuard: claudeCode.formatGuard,
  formatReport: claudeCode.formatReport,
}

// ─────────────────────────────────────────────────────────────────────────────
// opencode:identity —— plugin.js 直接读 canonical response(包括分层 context / allow)
// ─────────────────────────────────────────────────────────────────────────────

const opencode: ClientFormatter = {
  formatInject: (r) => r,
  formatGuard: (r) => r,
  formatReport: (r) => r,
}

// ─────────────────────────────────────────────────────────────────────────────
// registry(镜像 parsers/index.ts)
// ─────────────────────────────────────────────────────────────────────────────

const FORMATTERS: Record<string, ClientFormatter> = {
  "claude-code": claudeCode,
  codex,
  "gemini-cli": geminiCli,
  "kimi-code": kimiCode,
  opencode,
}

/**
 * 取某 client 的出站格式化器。未知 client → 回落 opencode(identity),
 * 保证「即使加了新 client 忘了注册」也只是不翻译、不至于崩(向后兼容 canonical)。
 */
export function getFormatter(client: string): ClientFormatter {
  return FORMATTERS[client] ?? opencode
}
