/**
 * transcript/directories.ts —— conversation-corpus 目录清单与上传开关同步。
 *
 * 只上报元数据(project_path/client/conversation_count/last_activity/machineId)，不读取/上传内容正文。
 * manifest 每轮枚举现存会话文件，不使用增量 cursor；稳态内容扫描再按 GET toggles 的
 * enabled=true project_path 过滤，失败时 fail-closed（不上内容）但不阻断 daemon 生命周期。
 */
import { readFileSync, statSync } from "node:fs"
import { dirname, join } from "node:path"
import type {
  DirectoriesManifestRequest,
  DirectoriesManifestResponse,
  DirectoryManifestItem,
  DirectoryTogglesResponse,
} from "@cerebro/wire"
import {
  collectFiles,
  defaultScanConfigs,
  extractProjectPath,
  extractProjectPathFromJsonlPrefix,
  fileToSessionId,
  type ClientScanConfig,
} from "./scanner.ts"
import { parseWholeJsonSafe } from "./parsers/json.ts"
import { parseCopilotFile } from "./parsers/copilot.ts"
import { getBrainConfig } from "../transport/brain-config.ts"
import { probeConfiguredRepoClones } from "./repo-clone-probe.ts"
import { normalizeDirectoryPath } from "./path.ts"
import { parseGeminiSessionFile } from "./adapters/gemini.ts"
import { listOpenCodeSessions } from "./adapters/opencode.ts"
import { listCursorSessions } from "./adapters/cursor.ts"
import { isKimiMainWire, readKimiSessionMetadata } from "./adapters/kimi-code.ts"

export { normalizeDirectoryPath } from "./path.ts"

export interface BuildDirectoryManifestOptions {
  configs?: ClientScanConfig[]
  machineId: string | undefined
}

export interface DirectoryManifestBuildResult {
  request: DirectoriesManifestRequest | null
  skippedNoMachineId: boolean
  skippedNoProjectPath: number
  /** 本轮 manifest 解析出的文件路径缓存，供 scanner 复用，避免同 tick 重复读 JSONL 前缀。 */
  projectPathByFile: Map<string, string>
}

interface AggregateItem {
  project_path: string
  client: DirectoryManifestItem["client"]
  conversation_count: number
  last_activity?: string
  machineId: string
}

/** manifest 只依赖现存文件，不读/写 CursorStore。 */
export function buildDirectoryManifest(opts: BuildDirectoryManifestOptions): DirectoryManifestBuildResult {
  if (!opts.machineId) {
    return { request: null, skippedNoMachineId: true, skippedNoProjectPath: 0, projectPathByFile: new Map() }
  }

  const configs = opts.configs ?? defaultScanConfigs()
  const aggregate = new Map<string, AggregateItem>()
  const projectPathByFile = new Map<string, string>()
  let skippedNoProjectPath = 0

  function add(client: string, rawPath: string | undefined, last: string, file?: string): void {
    if (!rawPath) {
      skippedNoProjectPath++
      return
    }
    const project_path = normalizeDirectoryPath(rawPath)
    if (file) projectPathByFile.set(file, project_path)
    const key = `${client}\0${project_path}`
    const prev = aggregate.get(key)
    if (!prev) {
      aggregate.set(key, {
        project_path,
        client: client as DirectoryManifestItem["client"],
        conversation_count: 1,
        last_activity: last,
        machineId: opts.machineId!,
      })
    } else {
      prev.conversation_count += 1
      if (!prev.last_activity || last > prev.last_activity) prev.last_activity = last
    }
  }

  for (const cfg of configs) {
    for (const root of cfg.roots) {
      for (const file of collectFiles(root, cfg.ext)) {
        if (cfg.format === "kimi-code") {
          if (!isKimiMainWire(file)) continue
          const metadata = readKimiSessionMetadata(file)
          let mtimeMs = 0
          try {
            mtimeMs = statSync(file).mtimeMs
          } catch {
            continue
          }
          add(cfg.client, metadata.projectPath, new Date(mtimeMs).toISOString(), file)
          continue
        }
        if (cfg.format === "opencode-sqlite" || cfg.format === "cursor-sqlite") {
          const sessions = cfg.format === "opencode-sqlite"
            ? listOpenCodeSessions(file)
            : listCursorSessions(file)
          for (const session of sessions) {
            add(
              cfg.client,
              session.projectPath,
              new Date(session.updatedAtMs || session.createdAtMs).toISOString(),
            )
          }
          continue
        }
        const extractedProjectPath = extractProjectPathFromFile(cfg, file)
        let mtimeMs = 0
        try {
          mtimeMs = statSync(file).mtimeMs
        } catch {
          continue
        }
        const last = new Date(mtimeMs).toISOString()
        add(cfg.client, extractedProjectPath, last, file)
      }
    }
  }

  const directories = [...aggregate.values()].sort((a, b) => {
    const c = a.client.localeCompare(b.client)
    return c !== 0 ? c : a.project_path.localeCompare(b.project_path)
  })
  return {
    request: directories.length > 0 ? { directories } : null,
    skippedNoMachineId: false,
    skippedNoProjectPath,
    projectPathByFile,
  }
}

function extractProjectPathFromFile(cfg: ClientScanConfig, file: string): string | undefined {
  if (cfg.format === "jsonl") {
    return extractProjectPathFromJsonlPrefix(file)
  }

  let content: string
  try {
    content = readFileSync(file, "utf8")
  } catch {
    return undefined
  }

  if (cfg.format === "copilot") {
    const parsed = parseCopilotFile(content, fileToSessionId(file))
    return parsed.ok ? extractProjectPath(parsed.requests) ?? readWorkspacePath(file) : undefined
  }
  if (cfg.format === "gemini") {
    return parseGeminiSessionFile(file, content)?.projectPath
  }
  const parsed = parseWholeJsonSafe(content)
  if (!parsed.ok) return undefined
  return extractProjectPath(Array.isArray(parsed.value) ? parsed.value : [parsed.value])
}

function readWorkspacePath(sessionFile: string): string | undefined {
  try {
    const value = JSON.parse(readFileSync(join(dirname(dirname(sessionFile)), "workspace.json"), "utf8")) as Record<string, unknown>
    const raw = typeof value["folder"] === "string"
      ? value["folder"]
      : typeof value["workspace"] === "string" ? value["workspace"] : ""
    if (!raw) return undefined
    if (!raw.startsWith("file://")) return raw
    let path = decodeURIComponent(new URL(raw).pathname)
    if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1)
    return path
  } catch {
    return undefined
  }
}

export interface DirectorySyncClient {
  sync: (manifest: DirectoriesManifestRequest | null, machineId: string) => Promise<Set<string>>
}

/** HTTP POST /brain/directories + GET /brain/directories/toggles。失败降级为空 allowlist。 */
export function createHttpDirectorySync(env: NodeJS.ProcessEnv = process.env): DirectorySyncClient {
  return {
    sync: async (manifest, machineId) => {
      const cfg = getBrainConfig(env)
      if (!cfg || !cfg.machineToken) return new Set<string>()

      const headers = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.machineToken}`,
      }

      try {
        if (manifest && manifest.directories.length > 0) {
          const post = await fetch(`${cfg.brainBaseUrl}/brain/directories`, {
            method: "POST",
            headers,
            body: JSON.stringify(manifest),
            signal: AbortSignal.timeout(cfg.timeoutMs),
          })
          if (!post.ok) return new Set<string>()
          let parsedPost: DirectoriesManifestResponse
          try {
            parsedPost = (await post.json()) as DirectoriesManifestResponse
          } catch {
            return new Set<string>()
          }
          if (
            typeof parsedPost !== "object" ||
            parsedPost === null ||
            !Number.isInteger((parsedPost as { processed?: unknown }).processed) ||
            (parsedPost as { processed: number }).processed < 0
          ) {
            return new Set<string>()
          }
        }

        const get = await fetch(`${cfg.brainBaseUrl}/brain/directories/toggles`, {
          method: "GET",
          headers,
          signal: AbortSignal.timeout(cfg.timeoutMs),
        })
        if (!get.ok) return new Set<string>()
        const parsed = (await get.json()) as DirectoryTogglesResponse
        const enabled = new Set<string>()
        for (const item of Array.isArray(parsed.items) ? parsed.items : []) {
          if (item.machineId === machineId && item.enabled === true && typeof item.project_path === "string") {
            enabled.add(normalizeDirectoryPath(item.project_path))
          }
        }
        try {
          const probe = await probeConfiguredRepoClones({ cfg: { ...cfg, machineToken: cfg.machineToken }, machineId })
          if (probe.status !== "ok") {
            // Keep ambiguity actionable in daemon logs; remote URLs may contain credentials.
            process.stderr.write(`${JSON.stringify({
              event: "repo_clone_probe",
              machineId,
              status: probe.status,
              code: probe.code,
              bindings: probe.bindings.map(({ localPath, candidateRepoIds, existingRepoId, status, code, reason }) => ({
                localPath, candidateRepoIds, existingRepoId, status, code, reason,
              })),
            })}\n`)
          }
        } catch {
          /* clone 探测失败不影响目录开关同步 */
        }
        return enabled
      } catch {
        return new Set<string>()
      }
    },
  }
}
