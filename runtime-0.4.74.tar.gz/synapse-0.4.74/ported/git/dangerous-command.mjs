/** Import-safe dangerous git command matcher shared by the daemon and CLI gateway. */
export const DANGEROUS_COMMAND_PATTERNS = [
  "reset\\s+--hard",
  "push\\s+--force",
  "push\\s+-f\\s",
  "push\\s+-f$",
  "branch\\s+-D\\s",
  "branch\\s+--delete\\s",
  "clean\\s+-f",
  "clean\\s+-d",
  "clean\\s+-x",
  "rebase\\s+main",
  "rebase\\s+master",
  "push\\s+origin\\s+--delete",
  "push\\s+.*:refs",
  "push\\s+--force-with-lease",
  "\\brm\\s+.*-r.*\\.git(?:[/\\s]|$)",
  "\\brm\\s+.*\\.git\\s*(?:--recursive|$)",
]

/**
 * @param {string | undefined | null} command
 * @returns {{ pattern: string } | undefined}
 */
export function matchDangerousCommand(command) {
  if (!command) return undefined
  for (const pattern of DANGEROUS_COMMAND_PATTERNS) {
    try {
      if (new RegExp(pattern, "i").test(command)) return { pattern }
    } catch {
      // A bad policy pattern must not crash the resident guard.
    }
  }
  return undefined
}
