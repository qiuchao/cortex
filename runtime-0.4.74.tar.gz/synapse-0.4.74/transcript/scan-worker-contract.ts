import type { FileCursor } from "./cursor.ts"
import type { ClientScanConfig, ScanResult } from "./scanner.ts"
import type { DirectoryManifestBuildResult } from "./directories.ts"

export interface SerializableScanOptions {
  configs?: ClientScanConfig[]
  cursors: Record<string, FileCursor>
  userId: string | null
  minAgeMs?: number
  allowlist?: string[]
  enabledProjectPaths?: string[]
  projectPathByFile?: Array<[string, string]>
  stageCursorUpdates?: boolean
  nowMs: number
}

export interface SerializableManifestOptions {
  configs?: ClientScanConfig[]
  machineId: string | undefined
}

export interface SerializableManifestResult
  extends Omit<DirectoryManifestBuildResult, "projectPathByFile"> {
  projectPathByFile: Array<[string, string]>
}

export interface SerializableScanUploadResult {
  scanned: number
  cursorUpdates: ScanResult["cursorUpdates"]
  upload: { ok: boolean; uploaded: number }
}

export type ScanWorkerRequest =
  | { id: number; kind: "scan"; payload: SerializableScanOptions }
  | { id: number; kind: "scan-upload"; payload: SerializableScanOptions & { env: NodeJS.ProcessEnv } }
  | { id: number; kind: "manifest"; payload: SerializableManifestOptions }

export type ScanWorkerResponse =
  | { id: number; ok: true; kind: "scan"; result: ScanResult }
  | { id: number; ok: true; kind: "scan-upload"; result: SerializableScanUploadResult }
  | { id: number; ok: true; kind: "manifest"; result: SerializableManifestResult }
  | { id: number; ok: false; error: string }

export type ScanWorkerMessage =
  | ScanWorkerResponse
  | { id: number; kind: "progress" }
