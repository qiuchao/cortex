import { BugPublicIdSchema } from "@cerebro/wire"
import { z } from "zod"
import { collectBugEvidenceScopes, unavailableBugEvidence, type ReadBugEvidence } from "../core/work-item-bug-context.ts"
import type { BugEvidenceScope, WorkItemBugEvidence } from "../transport/work-item-bug-evidence.ts"
import type { OperationTurnBridgeResult } from "./operation-turn-bridge.ts"

const CACHE_TTL_MS = 10 * 60_000
const CACHE_MAX_ENTRIES = 128
const LOAD_TIMEOUT_MS = 18_000
const DETAIL_MAX_CHARS = 80_000
const UuidSchema = z.string().uuid()

export type OperationBugEvidenceLoader = (key: string, result: OperationTurnBridgeResult, signal?: AbortSignal, remainingMs?: number) => Promise<WorkItemBugEvidence[]>
interface TrustedBugDetail { scope: BugEvidenceScope; result: Record<string, unknown>; bug: Record<string, unknown> }
interface Entry {
  controller: AbortController
  promise: Promise<WorkItemBugEvidence[]>
  waiters: number
  settled: boolean
  expiresAt: number
}

/** One factory belongs to one runtime. A receipt stays usable even when its
 * optional evidence fails, expires, or is cancelled. */
export function createOperationBugEvidenceLoader(read: ReadBugEvidence | undefined): OperationBugEvidenceLoader {
  const cache = new Map<string, Entry>()
  return async (key, result, signal, remainingMs = LOAD_TIMEOUT_MS) => {
    const scopes = trustedBugDetails(result).map((detail) => detail.scope)
    if (scopes.length === 0) return []
    if (signal?.aborted) return unavailable(scopes, "ABORTED")
    const timeoutMs = Number.isFinite(remainingMs) ? Math.max(0, Math.min(LOAD_TIMEOUT_MS, remainingMs)) : 0
    if (timeoutMs === 0) return unavailable(scopes, "TIMEOUT")
    const cacheKey = JSON.stringify([key, scopes])
    for (const [entryKey, entry] of cache) {
      if (entry.settled && entry.expiresAt <= Date.now()) cache.delete(entryKey)
    }
    let entry = cache.get(cacheKey)
    if (!entry) {
      while (cache.size >= CACHE_MAX_ENTRIES) {
        const oldest = [...cache.entries()].find(([, value]) => value.settled) ?? cache.entries().next().value!
        cache.delete(oldest[0])
        if (!oldest[1].settled) oldest[1].controller.abort()
      }
      entry = { controller: new AbortController(), promise: Promise.resolve([]), waiters: 0, settled: false, expiresAt: 0 }
      cache.set(cacheKey, entry)
      const current = entry
      let timedOut = false
      const timer = setTimeout(() => { timedOut = true; current.controller.abort() }, timeoutMs)
      timer.unref()
      const cancelled = new Promise<WorkItemBugEvidence[]>((resolve) => {
        current.controller.signal.addEventListener("abort", () => resolve(unavailable(scopes, timedOut ? "TIMEOUT" : "ABORTED")), { once: true })
      })
      current.promise = Promise.race([
        collectBugEvidenceScopes(scopes, read, 24_000, current.controller.signal).catch(() => unavailable(scopes, timedOut ? "TIMEOUT" : current.controller.signal.aborted ? "ABORTED" : "UNAVAILABLE")),
        cancelled,
      ]).then((evidence) => {
        current.settled = true
        current.expiresAt = Date.now() + CACHE_TTL_MS
        if (current.controller.signal.aborted && !timedOut && cache.get(cacheKey) === current) cache.delete(cacheKey)
        return evidence
      }).finally(() => clearTimeout(timer))
    }
    const current = entry
    current.waiters++
    return new Promise<WorkItemBugEvidence[]>((resolve) => {
      let done = false
      const waiterTimer = setTimeout(() => finish(unavailable(scopes, "TIMEOUT"), true), timeoutMs)
      waiterTimer.unref()
      const finish = (evidence: WorkItemBugEvidence[], cancelled: boolean) => {
        if (done) return
        done = true
        clearTimeout(waiterTimer)
        signal?.removeEventListener("abort", onAbort)
        current.waiters--
        if (cancelled && current.waiters === 0 && !current.settled) {
          if (cache.get(cacheKey) === current) cache.delete(cacheKey)
          current.controller.abort()
        }
        resolve(evidence)
      }
      const onAbort = () => finish(unavailable(scopes, "ABORTED"), true)
      signal?.addEventListener("abort", onAbort, { once: true })
      if (signal?.aborted) onAbort()
      void current.promise.then((evidence) => finish(evidence, false))
    })
  }
}

/** Business evidence only: callers must place these strings in their untrusted
 * data region, never the trusted tool-control instructions. */
export function operationBugDetailEvidence(result: OperationTurnBridgeResult): string[] {
  const details = trustedBugDetails(result)
  const facts: string[] = []
  let remaining = DETAIL_MAX_CHARS
  for (const [index, detail] of details.entries()) {
    if (remaining < 512) {
      facts.push(JSON.stringify({ complete: false, truncated: true, unreadBugCount: details.length - index }))
      break
    }
    const sourceComments = Array.isArray(detail.result.comments)
      ? detail.result.comments
      : record(detail.result.comments)?.items
    const commentsAvailable = Array.isArray(sourceComments)
    const comments = commentsAvailable ? sourceComments.map((value: unknown) => {
      const item = record(value)
      return item ? { id: item.id, authorName: item.authorName, body: item.body, createdAt: item.createdAt, deletedAt: item.deletedAt } : null
    }) : []
    const originalDescription = typeof detail.bug.description === "string" ? detail.bug.description : ""
    const originalTitle = typeof detail.bug.title === "string" ? detail.bug.title : ""
    const fact = {
      ...detail.scope,
      bug: { ...detail.bug, publicId: detail.scope.publicId, title: originalTitle.slice(0, 512), description: originalDescription },
      comments,
      descriptionComplete: true,
      commentsComplete: commentsAvailable && comments.every((comment) => comment !== null),
      unreadCommentCount: 0,
      complete: commentsAvailable && comments.every((comment) => comment !== null) && originalTitle.length <= 512,
      truncated: originalTitle.length > 512,
    }
    // Divide the total budget so one long Bug cannot erase subsequent details.
    const budget = Math.min(remaining - 128, Math.max(512, Math.floor((remaining - 128) / (details.length - index))))
    const serialize = () => JSON.stringify(fact)
    if (serialize().length > budget) {
      fact.truncated = true
      fact.complete = false
      if (fact.comments.length > 0) {
        const originalComments = fact.comments
        fact.commentsComplete = false
        let low = 0
        let high = originalComments.length
        while (low < high) {
          const middle = Math.ceil((low + high) / 2)
          fact.comments = originalComments.slice(0, middle)
          fact.unreadCommentCount = originalComments.length - middle
          if (serialize().length <= budget) low = middle
          else high = middle - 1
        }
        fact.comments = originalComments.slice(0, low)
        fact.unreadCommentCount = originalComments.length - low
      }
      if (serialize().length > budget) {
        fact.descriptionComplete = false
        let low = 0
        let high = originalDescription.length
        while (low < high) {
          const middle = Math.ceil((low + high) / 2)
          fact.bug.description = originalDescription.slice(0, middle)
          if (serialize().length <= budget) low = middle
          else high = middle - 1
        }
        fact.bug.description = originalDescription.slice(0, low)
      }
    }
    const rendered = serialize()
    if (rendered.length > remaining - 128) {
      facts.push(JSON.stringify({ complete: false, truncated: true, unreadBugCount: details.length - index }))
      break
    }
    facts.push(rendered)
    remaining -= rendered.length
  }
  return facts
}

function trustedBugDetails(result: OperationTurnBridgeResult): TrustedBugDetail[] {
  if (!result.available || (result.response.decision !== "operation" && result.response.decision !== "mixed")) return []
  const details: TrustedBugDetail[] = []
  const seen = new Set<string>()
  for (const operation of result.response.operations ?? []) {
    if (operation.resource !== "bug" || operation.action !== "query" || operation.status !== "executed") continue
    const value = record(operation.result)
    const bug = record(value?.bug)
    if (!value || !bug || Array.isArray(value.items)) continue
    const publicId = BugPublicIdSchema.safeParse(bug.publicId)
    if (!publicId.success || typeof bug.productionId !== "string" || !bug.productionId.trim() || bug.productionId.length > 128) continue
    const input = record(operation.input)
    const targets = [operation.targetId, input?.targetId, input?.bugId].filter((target) => target !== undefined)
    if (targets.some((target) => {
      const parsed = BugPublicIdSchema.safeParse(target)
      return !(parsed.success && parsed.data === publicId.data) && !(target === bug.id && UuidSchema.safeParse(target).success)
    })) continue
    const scope = { publicId: publicId.data, productionId: bug.productionId.trim() }
    const fingerprint = JSON.stringify(scope)
    if (seen.has(fingerprint)) continue
    seen.add(fingerprint)
    details.push({ scope, result: value, bug })
  }
  return details
}

function unavailable(scopes: BugEvidenceScope[], code: "UNAVAILABLE" | "ABORTED" | "TIMEOUT"): WorkItemBugEvidence[] {
  return scopes.map((scope) => ({
    ...unavailableBugEvidence(scope),
    errors: [
      { scope: "activities", code, message: "Bug 活动记录未能加载；主操作回执仍有效，请单独重试证据读取。" },
      { scope: "attachments", code, message: "Bug 截图未能加载；尚未查看图片内容，请单独重试证据读取。" },
    ],
  }))
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}
