export type AgentCommandShell = "default" | "powershell"

export function agentCommandShell(
  platform: NodeJS.Platform,
  client?: string,
): AgentCommandShell {
  return platform === "win32" && client === "codex" ? "powershell" : "default"
}

export function inferAgentCommandShell(launcher: string): AgentCommandShell {
  return /^\s*&(?:\s|$)/.test(launcher) ? "powershell" : "default"
}

export function quoteAgentCommandArg(
  value: string,
  shell: AgentCommandShell,
  platform: NodeJS.Platform = process.platform,
): string {
  if (shell === "powershell") {
    return `'${value.replace(/'/g, "''")}'`
  }
  if (platform === "win32") {
    return `"${value.replace(/"/g, '""')}"`
  }
  return `'${value.replace(/'/g, `'"'"'`)}'`
}

export function quoteAgentCommandArgForLauncher(
  value: string,
  launcher: string,
  platform: NodeJS.Platform = process.platform,
): string {
  return quoteAgentCommandArg(value, inferAgentCommandShell(launcher), platform)
}

export function renderAgentLauncher(
  command: string,
  args: readonly string[],
  shell: AgentCommandShell,
  platform: NodeJS.Platform = process.platform,
): string {
  const invocation = [command, ...args]
    .map((value) => quoteAgentCommandArg(value, shell, platform))
    .join(" ")
  return shell === "powershell" ? `& ${invocation}` : invocation
}
