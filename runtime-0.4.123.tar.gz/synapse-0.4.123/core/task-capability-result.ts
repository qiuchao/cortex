import {
  buildBugWorkflowReadRequest,
  parseBugWorkflowReadResponse,
  buildRequirementBugReadRequest,
  parseRequirementBugReadResponse,
  TaskCapabilityExecuteResponseSchema,
  type TaskCapabilityExecuteRequest,
} from "@cerebro/wire"

/** Negotiate canonical reads once for all consumer paths. */
export function negotiateTaskRead(request: TaskCapabilityExecuteRequest): TaskCapabilityExecuteRequest {
  if (request.command === "bug.workflow.list") return buildBugWorkflowReadRequest(request.productionId, request.input)
  return request.command === "requirement.bug.list"
    ? buildRequirementBugReadRequest(request.productionId, request.input)
    : request
}

/** Shared by HTTP transport, injected broker ports and final turn settlement. */
export function parseTaskCapabilityResponse(request: TaskCapabilityExecuteRequest, value: unknown) {
  if (request.command === "bug.workflow.list") {
    return parseBugWorkflowReadResponse(value, request.productionId, request.input)
  }
  if (request.command === "requirement.bug.list") {
    return parseRequirementBugReadResponse(value, request.productionId, request.input)
  }
  const response = TaskCapabilityExecuteResponseSchema.parse(value)
  if (response.command !== request.command) throw new TypeError("task capability response command does not match the request")
  return response
}
