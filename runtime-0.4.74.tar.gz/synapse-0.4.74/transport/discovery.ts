/**
 * transport/discovery.ts —— 运行时发现:socket 路径 + 发现文件 + bearer token 路径。
 *
 * 方案 R4b:socket 路径优先 $XDG_RUNTIME_DIR,回落 ~/.synapse/run;
 *          发现文件 ~/.cache/synapse/runtime.json {socket_path, pid, started_at};
 *          薄壳按固定路径找 socket。
 *
 * POSIX-first(方案 D6:target WSL2/Linux/mac;Windows named-pipe 待 box A)。
 * Windows 派生在 socketPath() 里留了分支占位,具体 ACL 鉴权 Phase 后续/box A 落地。
 */
import { homedir, tmpdir } from "node:os"
import { join } from "node:path"
import { mkdtempSync } from "node:fs"

const APP = "synapse"

/** 运行时目录(存 socket / token)。0700。 */
export function runtimeDir(env: NodeJS.ProcessEnv = process.env): string {
  const xdg = env["XDG_RUNTIME_DIR"]
  if (xdg && xdg.trim()) return join(xdg, APP)
  return join(homedir(), `.${APP}`, "run")
}

/** 缓存目录(存发现文件)。 */
export function cacheDir(env: NodeJS.ProcessEnv = process.env): string {
  const xdg = env["XDG_CACHE_HOME"]
  const base = xdg && xdg.trim() ? xdg : join(homedir(), ".cache")
  return join(base, APP)
}

/** unix socket 路径(POSIX)。Windows 走 named pipe(占位,box A 落地)。 */
export function socketPath(env: NodeJS.ProcessEnv = process.env): string {
  if (process.platform === "win32") {
    // named pipe 命名空间;ACL 鉴权派生 = per-OS TODO(方案 D6 / R1)
    return `\\\\.\\pipe\\${APP}`
  }
  return join(runtimeDir(env), "synapse.sock")
}

/**
 * 是否走 loopback TCP 传输(而非 unix socket)。
 *
 * - win32:默认 true —— named pipe 的 ACL 鉴权是未完工 TODO,且 sh/cmd 薄壳的 curl
 *   连不上 named pipe(curl --unix-socket 不支持 Windows pipe);loopback TCP + 0600 token
 *   是 Windows 当前唯一可跑通的通路。
 * - POSIX:默认 false —— unix socket 的 fs 权限即免费鉴权,是首选。
 * - 显式覆盖:env SYNAPSE_TRANSPORT=loopback-tcp 强制开(便于在 Linux 上真验 TCP 路径),
 *   =unix-socket 强制关。
 */
export function shouldUseLoopbackTcp(env: NodeJS.ProcessEnv = process.env): boolean {
  const forced = env["SYNAPSE_TRANSPORT"]?.trim().toLowerCase()
  if (forced === "loopback-tcp") return true
  if (forced === "unix-socket") return false
  return process.platform === "win32"
}

/**
 * machine token 文件路径(主脑 Bearer,per-user 绑 users.id)。0600。
 * 🔴 与 loopbackTokenPath() 物理隔离:machine token 是主脑鉴权,loopback token 是本地 IPC 鉴权,
 *    两者语义/生命周期不同,绝不能共用一个文件(否则互相覆盖)。
 * 命名注意:历史上此文件名就叫 "token"(core/token-store + brain-config 依赖),保持不变。
 */
export function tokenPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(runtimeDir(env), "token")
}

/**
 * loopback TCP 鉴权 token 文件路径(仅 loopback-tcp 传输用;unix socket 靠 fs 权限鉴权)。0600。
 * 独立于 tokenPath():见上「物理隔离」。
 */
export function loopbackTokenPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(runtimeDir(env), "loopback-token")
}

/** 发现文件路径。薄壳/CLI 读它拿到 socket_path/pid/port。 */
export function discoveryPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "runtime.json")
}

/**
 * sh 薄壳友好的运行时发现文件(纯 KEY=VALUE,可 `.` source)。
 * daemon 写,sh 薄壳 source 后据 SYNAPSE_PORT 有无选 TCP/unix 通路。
 * 薄壳「绝不用 Node」→ 不解析 JSON,读这个纯文本即可。
 */
export function runtimeEnvPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "runtime.env")
}

/** Agent CLI 在客户端网络沙箱内无法连接 socket/TCP 时使用的同 UID 文件 IPC。 */
export function agentSpoolDir(env: NodeJS.ProcessEnv = process.env): string {
  const configured = env["SYNAPSE_AGENT_SPOOL_DIR"]?.trim()
  if (configured) return configured
  const identity = typeof process.getuid === "function" ? String(process.getuid()) : "user"
  return join(tmpdir(), `${APP}-agent-${identity}`)
}

/** Allocate a non-predictable spool path for one daemon lifetime. */
export function createAgentSpoolDir(env: NodeJS.ProcessEnv = process.env): string {
  const configured = env["SYNAPSE_AGENT_SPOOL_DIR"]?.trim()
  if (configured) return configured
  const identity = typeof process.getuid === "function" ? String(process.getuid()) : "user"
  return mkdtempSync(join(tmpdir(), `${APP}-agent-${identity}-`))
}

/** pidfile / lockfile 路径(单实例保证)。 */
export function pidfilePath(env: NodeJS.ProcessEnv = process.env): string {
  return join(runtimeDir(env), "synapse.pid")
}

/**
 * machine-id 文件路径(Cortex 生成的独立 machineId,per-device 永久持久化)。0600。
 *
 * 与 tokenPath() 物理隔离:
 *   · tokenPath()      = 主脑鉴权(per-user 跨机共享)
 *   · machineIdPath()  = 机器标识(per-device,与 user 正交)
 * 两者绝不能共用一个文件。文件名 "machine-id" 与 "token" 保持语义区分。
 */
export function machineIdPath(env: NodeJS.ProcessEnv = process.env): string {
  const home = env["USERPROFILE"]?.trim() || env["HOME"]?.trim() || homedir()
  return join(home, `.${APP}`, "run", "machine-id")
}

/** 稳定上下文本地缓存正文路径(周期同步下行写入,会话级注入读取)。 */
export function stableContextCachePath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "stable-context.md")
}

/** 稳定上下文 etag 记录路径(304 条件请求用)。 */
export function stableContextEtagPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "stable-context.etag")
}

/** 当前客户端 session 内尚未确认提交的需求草稿。 */
export function requirementIntakePath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "requirement-intake.json")
}

export function bugIntakePath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "bug-intake.json")
}

/** Minimal references for task drafts created through the generic agent broker. */
export function taskCapabilityDraftPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "task-capability-drafts.json")
}

/** Short-lived Knowledge confirmation receipts held by the local daemon. */
export function knowledgeConfirmationPath(env: NodeJS.ProcessEnv = process.env): string {
  return join(cacheDir(env), "knowledge-confirmations.json")
}

export interface DiscoveryInfo {
  socket_path: string
  pid: number
  started_at: string
  version: string
  /** loopback-tcp 传输时监听的环回端口(unix-socket 传输时 undefined)。 */
  port?: number
  /** 传输类型;缺省视为 unix-socket(向后兼容旧发现文件)。 */
  transport?: "unix-socket" | "named-pipe" | "loopback-tcp"
  /** 网络/Unix socket 被客户端沙箱禁用时的文件 IPC 目录。 */
  agent_spool_path?: string
  /** daemon 启动时固化的 Git 硬护栏状态。 */
  git_guard_enabled?: boolean
}

/** 临时目录兜底(极端情况 homedir 不可写时,仅测试/诊断用)。 */
export function fallbackTmpDir(): string {
  return join(tmpdir(), APP)
}
