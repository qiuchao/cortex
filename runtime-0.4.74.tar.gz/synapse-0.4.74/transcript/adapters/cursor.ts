import { existsSync, readFileSync, readdirSync } from "node:fs"
import { dirname, join } from "node:path"
import { DatabaseSync } from "node:sqlite"

export interface CursorSessionMeta {
  id: string
  projectPath?: string
  title?: string
  createdAtMs: number
  updatedAtMs: number
}

interface SqlRow { [key: string]: unknown }

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function parseJson(value: unknown): Record<string, unknown> | undefined {
  if (value instanceof Uint8Array) value = Buffer.from(value).toString("utf8")
  if (typeof value !== "string") return undefined
  try {
    return asRecord(JSON.parse(value))
  } catch {
    return undefined
  }
}

function parseJsonValue(value: unknown): unknown {
  if (typeof value !== "string") return value
  try {
    return JSON.parse(value) as unknown
  } catch {
    return value
  }
}

function text(value: unknown): string {
  return typeof value === "string" ? value : ""
}

function millis(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value
  if (typeof value !== "string" || !value.trim()) return 0
  const numeric = Number(value)
  if (Number.isFinite(numeric)) return numeric
  const parsed = Date.parse(value)
  return Number.isFinite(parsed) ? parsed : 0
}

function workspacePathFromComposer(composer: Record<string, unknown>): string | undefined {
  const identifier = asRecord(composer["workspaceIdentifier"])
  const uri = asRecord(identifier?.["uri"])
  const fsPath = text(uri?.["fsPath"]).trim()
  return fsPath || undefined
}

function pathFromUri(raw: string): string | undefined {
  if (!raw.startsWith("file://")) return undefined
  try {
    const url = new URL(raw)
    let path = decodeURIComponent(url.pathname)
    if (url.hostname) path = `//${url.hostname}${path}`
    if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1)
    return path
  } catch {
    return undefined
  }
}

function workspacePathFromBubble(bubble: Record<string, unknown> | undefined): string | undefined {
  if (!bubble) return undefined
  const direct = text(bubble["workspaceProjectDir"]).trim()
  if (direct) return direct
  const uris = bubble["workspaceUris"]
  if (!Array.isArray(uris)) return undefined
  for (const value of uris) {
    if (typeof value !== "string") continue
    const path = pathFromUri(value)
    if (path) return path
  }
  return undefined
}

function pathFromWorkspaceJson(workspaceDir: string): string | undefined {
  try {
    const parsed = JSON.parse(readFileSync(join(workspaceDir, "workspace.json"), "utf8")) as Record<string, unknown>
    const raw = text(parsed["folder"] ?? parsed["workspace"])
    if (!raw) return undefined
    return pathFromUri(raw) ?? raw
  } catch {
    return undefined
  }
}

function workspaceComposerIds(dbPath: string): string[] {
  if (!existsSync(dbPath)) return []
  const db = new DatabaseSync(dbPath, { readOnly: true })
  try {
    const ids = new Set<string>()
    const row = db.prepare("SELECT value FROM ItemTable WHERE key = 'composer.composerData'").get() as SqlRow | undefined
    const refs = parseJson(row?.["value"])
    if (Array.isArray(refs?.["allComposers"])) {
      for (const item of refs["allComposers"]) {
        const id = text(asRecord(item)?.["composerId"])
        if (id) ids.add(id)
      }
    }
    if (Array.isArray(refs?.["selectedComposerIds"])) {
      for (const id of refs["selectedComposerIds"]) if (typeof id === "string" && id) ids.add(id)
    }
    const panels = db.prepare(
      `SELECT value FROM ItemTable
       WHERE key = 'workbench.panel.composerChatViewPane'
          OR (key LIKE 'workbench.panel.composerChatViewPane.%' AND key NOT LIKE '%.hidden')`,
    ).all() as SqlRow[]
    for (const panel of panels) {
      const data = parseJson(panel["value"])
      for (const key of Object.keys(data ?? {})) {
        const prefix = "workbench.panel.aichat.view."
        if (key.startsWith(prefix)) ids.add(key.slice(prefix.length))
      }
    }
    return [...ids]
  } finally {
    db.close()
  }
}

function legacyWorkspaceMap(globalDbPath: string): Map<string, string> {
  const result = new Map<string, string>()
  const workspaceRoot = join(dirname(dirname(globalDbPath)), "workspaceStorage")
  if (!existsSync(workspaceRoot)) return result
  for (const name of readdirSync(workspaceRoot)) {
    const dir = join(workspaceRoot, name)
    const projectPath = pathFromWorkspaceJson(dir)
    if (!projectPath) continue
    for (const id of workspaceComposerIds(join(dir, "state.vscdb"))) result.set(id, projectPath)
  }
  return result
}

export function listCursorSessions(globalDbPath: string): CursorSessionMeta[] {
  const legacyPaths = legacyWorkspaceMap(globalDbPath)
  const db = new DatabaseSync(globalDbPath, { readOnly: true })
  try {
    const rows = db.prepare(
      "SELECT key, value FROM cursorDiskKV WHERE key LIKE 'composerData:%' AND value IS NOT NULL",
    ).all() as SqlRow[]
    return rows.flatMap((row) => {
      const key = text(row["key"])
      const composer = parseJson(row["value"])
      if (!composer) return []
      const id = text(composer["composerId"]) || key.slice("composerData:".length)
      if (!id) return []
      const title = text(composer["name"]).trim()
      const headers = Array.isArray(composer["fullConversationHeadersOnly"])
        ? composer["fullConversationHeadersOnly"] as unknown[]
        : []
      const firstBubbleId = text(asRecord(headers[0])?.["bubbleId"])
      const firstBubbleRow = firstBubbleId
        ? db.prepare("SELECT value FROM cursorDiskKV WHERE key = ?").get(`bubbleId:${id}:${firstBubbleId}`) as SqlRow | undefined
        : undefined
      const inline = Array.isArray(composer["conversation"]) ? composer["conversation"] as unknown[] : []
      const projectPath = workspacePathFromComposer(composer)
        ?? legacyPaths.get(id)
        ?? workspacePathFromBubble(parseJson(firstBubbleRow?.["value"]) ?? asRecord(inline[0]))
      return [{
        id,
        projectPath,
        ...(title ? { title } : {}),
        createdAtMs: millis(composer["createdAt"]),
        updatedAtMs: millis(composer["lastUpdatedAt"]) || millis(composer["createdAt"]),
      }]
    })
  } finally {
    db.close()
  }
}

export function loadCursorMessages(globalDbPath: string, composerId: string): unknown[] {
  const db = new DatabaseSync(globalDbPath, { readOnly: true })
  try {
    const composerRow = db.prepare("SELECT value FROM cursorDiskKV WHERE key = ?").get(
      `composerData:${composerId}`,
    ) as SqlRow | undefined
    const composer = parseJson(composerRow?.["value"]) ?? {}
    const rows = db.prepare(
      "SELECT key, value FROM cursorDiskKV WHERE key LIKE ? AND value IS NOT NULL",
    ).all(`bubbleId:${composerId}:%`) as SqlRow[]
    const bubbles = new Map<string, Record<string, unknown>>()
    for (const row of rows) {
      const bubble = parseJson(row["value"])
      if (!bubble) continue
      const id = text(bubble["bubbleId"]) || text(row["key"]).split(":").slice(2).join(":")
      if (id) bubbles.set(id, bubble)
    }

    const inline = Array.isArray(composer["conversation"]) ? composer["conversation"] as unknown[] : []
    for (const item of inline) {
      const bubble = asRecord(item)
      const id = text(bubble?.["bubbleId"])
      if (id && !bubbles.has(id) && bubble) bubbles.set(id, bubble)
    }
    const headers = Array.isArray(composer["fullConversationHeadersOnly"])
      ? composer["fullConversationHeadersOnly"] as unknown[]
      : []
    const orderedIds = headers.map((header) => text(asRecord(header)?.["bubbleId"])).filter(Boolean)
    const ordered = orderedIds.length > 0
      ? orderedIds.flatMap((id) => bubbles.get(id) ? [bubbles.get(id)!] : [])
      : [...bubbles.values()].sort((a, b) => {
        const left = millis(asRecord(a["timingInfo"])?.["clientStartTime"])
        const right = millis(asRecord(b["timingInfo"])?.["clientStartTime"])
        return left - right
      })

    return ordered.flatMap((bubble, index) => {
      const content = text(bubble["text"])
      const thinking = text(asRecord(bubble["thinking"])?.["text"])
      const tool = asRecord(bubble["toolFormerData"])
      const toolName = text(tool?.["name"])
      const toolCallId = text(tool?.["toolCallId"]) || text(bubble["bubbleId"])
      const toolInput = parseJsonValue(tool?.["params"] ?? tool?.["rawArgs"])
      const toolOutput = tool?.["result"] ?? tool?.["error"]
      const toolParts = millis(bubble["capabilityType"]) === 15 && toolName
        ? [
            { type: "tool_use", id: toolCallId, name: toolName, input: toolInput },
            ...(toolOutput !== undefined
              ? [{ type: "tool_result", tool_use_id: toolCallId, content: toolOutput }]
              : []),
          ]
        : []
      if (!content && !thinking && toolParts.length === 0) return []
      const type = millis(bubble["type"])
      const timing = asRecord(bubble["timingInfo"])
      const timestamp = millis(timing?.["clientStartTime"]) || millis(bubble["createdAt"])
      return [{
        id: text(bubble["bubbleId"]) || `${composerId}:${index}`,
        _corpus_role: type === 1 ? "user" : "assistant",
        content: [
          ...(thinking ? [{ type: "thinking", text: thinking }] : []),
          ...(content ? [{ type: "text", text: content }] : []),
          ...toolParts,
        ],
        ...(timestamp ? { timestamp } : {}),
      }]
    })
  } finally {
    db.close()
  }
}
