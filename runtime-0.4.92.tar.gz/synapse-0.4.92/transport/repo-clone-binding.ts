/**
 * transcript/repo-clone-probe.ts —— 配置仓库 clone 探测。
 *
 * directory sync tick 的附属 best-effort 步骤：从 Cerebro 拉当前用户可见 repo 配置，
 * 只检查配置给出的 suggestedInstallDir 及其 <suggested>/<repoBaseName> 兼容路径，
 * 验证真实 git 根目录与 remote，汇总候选并通过原子接口确认绑定。
 *
 * 安全边界：不扫描任意目录、不 shell 拼命令、失败不阻断同步主流程。
 */
import { execFile } from "node:child_process"
import { statSync } from "node:fs"
import { resolve } from "node:path"
import { normalizeDirectoryPath } from "../transcript/path.ts"
import { lookupRepoCloneContext, registerRepoClone, type RepoCloneHttpConfig, type RepoContext } from "./repo-clone-registry.ts"
import { promisify } from "node:util"

const execFileAsync = promisify(execFile)
const GIT_REMOTE_TIMEOUT_MS = 3_000

export interface ConfigRepo {
  id: string
  productionId?: string | null
  gitUrl?: string | null
  suggestedInstallDir?: string | null
}

export type ProbeHttpConfig = RepoCloneHttpConfig

export interface ProbeRepoClonesOptions {
  cfg: ProbeHttpConfig
  machineId: string
  signal?: AbortSignal
  execGitRemote?: (localPath: string) => Promise<string>
}

interface OrgReposResponse {
  repos?: unknown
}

interface NormalizeResponse {
  status?: unknown
  normalized?: unknown
}

/** 从 git URL 提取仓库目录基名；仅用于候选路径拼接，不参与 remote 等价判断。 */
export function repoBaseName(gitUrl: string): string {
  const trimmed = gitUrl.trim().replace(/[\\/]+$/, "")
  const last = trimmed.split(/[\\/:]/).filter(Boolean).pop() ?? trimmed
  return last.endsWith(".git") ? last.slice(0, -4) : last
}

/** 跨 POSIX/Windows 字符串拼接；不 resolve、不枚举父目录，避免扩大探测范围。 */
export function joinConfiguredPath(parent: string, child: string): string {
  const rawBase = parent.trim()
  const isPosixRoot = /^\/+$/u.test(rawBase)
  const isWindowsDriveRoot = /^[A-Za-z]:[\\/]*$/u.test(rawBase)
  const base = isPosixRoot
    ? "/"
    : isWindowsDriveRoot
      ? `${rawBase.slice(0, 2)}${rawBase.includes("\\") ? "\\" : "/"}`
      : rawBase.replace(/[\\/]+$/, "")
  const part = child.trim().replace(/^[\\/]+/, "")
  if (!base) return part
  if (!part) return base
  if (base === "/") return `/${part}`
  if (/^[A-Za-z]:[\\/]$/u.test(base)) return `${base}${part}`
  const sep = base.includes("\\") && !base.includes("/") ? "\\" : "/"
  return `${base}${sep}${part}`
}

/** 候选严格来自配置：suggestedInstallDir 本身优先，其次兼容 <suggested>/<repoBaseName>。 */
export function buildConfiguredCloneCandidates(repo: Pick<ConfigRepo, "gitUrl" | "suggestedInstallDir">): string[] {
  const suggested = repo.suggestedInstallDir?.trim()
  const gitUrl = repo.gitUrl?.trim()
  if (!suggested || !gitUrl) return []
  const nested = joinConfiguredPath(suggested, repoBaseName(gitUrl))
  return suggested === nested ? [suggested] : [suggested, nested]
}

export interface CloneBindingProbe {
  localPath: string
  gitRemote: string
  normalizedRemote: string
  candidateRepoIds: string[]
  existingRepoId?: string
  productionId?: string
  status: "created" | "unchanged" | "ambiguous" | "conflict" | "rejected" | "unavailable"
  code?: string
  reason?: string
}

export interface ProbeRepoClonesResult {
  registered: number
  status: "ok" | "clarify" | "unavailable"
  bindings: CloneBindingProbe[]
  code?: string
}

export async function probeConfiguredRepoClones(opts: ProbeRepoClonesOptions): Promise<ProbeRepoClonesResult> {
  return probeBindings(opts)
}

async function probeBindings(opts: ProbeRepoClonesOptions, cwdRoot?: string): Promise<ProbeRepoClonesResult> {
  try {
    const headers = authJsonHeaders(opts.cfg.machineToken)
    // The strict resolver already computed the exact git root. Start reading
    // its remote while the catalogue request is in flight so the two network/
    // process waits do not add to the hook's critical path.
    const cwdRemotePromise = cwdRoot
      ? readGitRemote(cwdRoot, opts.execGitRemote, opts.signal)
      : undefined
    const repos = await fetchConfiguredRepos(opts.cfg, headers, opts.signal)
    const groups = new Map<string, CloneBindingProbe>()
    const localRemotes = new Map<string, Promise<string | null>>()
    if (cwdRoot && cwdRemotePromise) localRemotes.set(normalizeDirectoryPath(resolve(cwdRoot)), cwdRemotePromise)
    const remotes = new Map<string, Promise<string | null>>()
    const normalize = (remote: string) => {
      if (!remotes.has(remote)) remotes.set(remote, normalizeRemote(opts.cfg, headers, remote, opts.signal))
      return remotes.get(remote)!
    }
    let unavailable = false

    const normalizedRepos = new Map<string, string>()
    // Normalize configured remotes concurrently with a small fixed fan-out.
    // The result is collected before matching so failures remain fail-closed.
    const configRemotes = await mapBounded(repos, 4, async (repo) => {
      const gitUrl = repo.gitUrl?.trim()
      return repo.id && gitUrl ? [repo, await normalize(gitUrl)] as const : [repo, null] as const
    })
    // Collect every matching candidate before deciding: iteration order is never identity.
    for (const [repo, normalizedConfig] of configRemotes) {
      if (!repo.id || !normalizedConfig) {
        if (repo.id && repo.gitUrl?.trim()) unavailable = true
        continue
      }
      normalizedRepos.set(repo.id, normalizedConfig)
      for (const candidate of cwdRoot ? [cwdRoot] : buildConfiguredCloneCandidates(repo)) {
        if (!isDirectory(candidate)) continue
        const localPath = normalizeDirectoryPath(resolve(candidate))
        if (!localRemotes.has(localPath)) localRemotes.set(localPath, readGitRemote(localPath, opts.execGitRemote, opts.signal))
        const gitRemote = await localRemotes.get(localPath)!
        if (!gitRemote) continue
        const normalizedLocal = await normalize(gitRemote)
        if (!normalizedLocal) { unavailable = true; continue }
        if (normalizedLocal !== normalizedConfig) continue
        const group = groups.get(localPath) ?? {
          localPath, gitRemote, normalizedRemote: normalizedLocal,
          candidateRepoIds: [], status: "unavailable" as const,
        }
        if (!group.candidateRepoIds.includes(repo.id)) group.candidateRepoIds.push(repo.id)
        groups.set(localPath, group)
        break
      }
    }

    let registered = 0
    for (const binding of groups.values()) {
      // All visible repositories sharing this remote compete, even if their
      // suggested installation paths differ. A path suggestion is not ownership.
      binding.candidateRepoIds = [...normalizedRepos].filter(([, remote]) => remote === binding.normalizedRemote)
        .map(([id]) => id).sort()
      const candidate = repos.find((repo) => repo.id === binding.candidateRepoIds[0])
      const existing = await lookupRepoCloneContext(opts.cfg, binding.localPath, opts.machineId, opts.signal)
      if (existing.status === "resolved") binding.existingRepoId = existing.context.repoId
      if (existing.status === "rejected") {
        binding.status = "rejected"
        binding.code = existing.code
      } else if (existing.status === "unavailable" || unavailable) {
        binding.status = "unavailable"
      } else if (binding.candidateRepoIds.length > 1) {
        binding.status = "ambiguous"
      } else if (existing.status === "resolved" && existing.context.repoId !== binding.candidateRepoIds[0]) {
        binding.status = "conflict"
      } else if (!candidate?.productionId?.trim()) {
        binding.status = "rejected"
        binding.code = "production_context_missing"
      } else {
        const result = await registerRepoClone(opts.cfg, {
          localPath: binding.localPath, cwd: binding.localPath,
          repoId: binding.candidateRepoIds[0]!, repositoryId: binding.candidateRepoIds[0]!,
          candidateRepoIds: binding.candidateRepoIds, productionId: candidate.productionId,
          machineId: opts.machineId, gitRemote: binding.gitRemote,
        }, opts.signal)
        binding.status = result.status
        if ("code" in result) binding.code = result.code
        if ("reason" in result) binding.reason = result.reason
        if (result.status === "created") registered++
        if (result.status === "created" || result.status === "unchanged") {
          const verified = await lookupRepoCloneContext(opts.cfg, binding.localPath, opts.machineId, opts.signal)
          if (verified.status === "rejected") {
            binding.status = "rejected"
            binding.code = verified.code
          } else if (verified.status !== "resolved") {
            binding.status = "unavailable"
            binding.code = "registration_not_resolved"
          } else if (verified.context.repoId !== binding.candidateRepoIds[0] || verified.context.productionId !== candidate.productionId) {
            binding.status = "conflict"
            binding.code = "registration_context_mismatch"
          } else {
            binding.productionId = verified.context.productionId
          }
        }
      }
    }

    const bindings = [...groups.values()]
    return {
      registered,
      status: unavailable || bindings.some((binding) => binding.status === "unavailable")
        ? "unavailable"
        : bindings.some((binding) => binding.status !== "unchanged" && binding.status !== "created") ? "clarify" : "ok",
      bindings,
    }
  } catch (error) {
    if (opts.signal?.aborted) throw opts.signal.reason ?? error
    if (error instanceof RepositoryAccessError) return { registered: 0, status: "clarify", code: error.code, bindings: [] }
    return { registered: 0, status: "unavailable", bindings: [] }
  }
}

function authJsonHeaders(machineToken: string): Record<string, string> {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${machineToken}`,
  }
}

class RepositoryAccessError extends Error {
  code: string
  constructor(status: number) {
    super("Repository access rejected")
    this.code = `http_${status}`
  }
}

async function fetchConfiguredRepos(cfg: ProbeHttpConfig, headers: Record<string, string>, signal?: AbortSignal): Promise<ConfigRepo[]> {
  const res = await fetch(`${cfg.brainBaseUrl}/api/v1/org/repos`, {
    method: "GET",
    headers,
    signal: signal ? AbortSignal.any([AbortSignal.timeout(cfg.timeoutMs), signal]) : AbortSignal.timeout(cfg.timeoutMs),
  })
  if (res.status === 401 || res.status === 403) throw new RepositoryAccessError(res.status)
  if (!res.ok) throw new Error("Repository catalogue unavailable")
  const parsed = (await res.json()) as OrgReposResponse
  if (!Array.isArray(parsed.repos)) throw new Error("Invalid repository catalogue")
  const rawRepos = parsed.repos
  return rawRepos.flatMap((raw): ConfigRepo[] => {
    if (typeof raw !== "object" || raw === null) throw new Error("Invalid repository entry")
    const r = raw as { id?: unknown; productionId?: unknown; gitUrl?: unknown; suggestedInstallDir?: unknown }
    if (typeof r.id !== "string" || !r.id.trim()
      || (r.productionId != null && typeof r.productionId !== "string")
      || (r.gitUrl != null && typeof r.gitUrl !== "string")
      || (r.suggestedInstallDir != null && typeof r.suggestedInstallDir !== "string")) {
      throw new Error("Invalid repository entry")
    }
    return [{
      id: r.id,
      productionId: typeof r.productionId === "string" ? r.productionId : null,
      gitUrl: typeof r.gitUrl === "string" ? r.gitUrl : null,
      suggestedInstallDir: typeof r.suggestedInstallDir === "string" ? r.suggestedInstallDir : null,
    }]
  })
}

async function normalizeRemote(
  cfg: ProbeHttpConfig,
  headers: Record<string, string>,
  url: string,
  signal?: AbortSignal,
): Promise<string | null> {
  try {
    const res = await fetch(`${cfg.brainBaseUrl}/api/v1/utils/normalize-git-remote`, {
      method: "POST",
      headers,
      body: JSON.stringify({ url }),
      signal: signal ? AbortSignal.any([AbortSignal.timeout(cfg.timeoutMs), signal]) : AbortSignal.timeout(cfg.timeoutMs),
    })
    if (res.status === 401 || res.status === 403) throw new RepositoryAccessError(res.status)
    if (!res.ok) return null
    const parsed = (await res.json()) as NormalizeResponse
    return parsed.status === "ok" && typeof parsed.normalized === "string" && parsed.normalized.trim()
      ? parsed.normalized : null
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? error
    if (error instanceof RepositoryAccessError) throw error
    return null
  }
}

async function mapBounded<T, R>(values: readonly T[], limit: number, fn: (value: T) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(values.length)
  let next = 0
  const worker = async (): Promise<void> => {
    while (true) {
      const index = next++
      if (index >= values.length) return
      results[index] = await fn(values[index]!)
    }
  }
  await Promise.all(Array.from({ length: Math.min(Math.max(limit, 1), values.length) }, worker))
  return results
}

function isDirectory(path: string): boolean {
  try {
    return statSync(path).isDirectory()
  } catch {
    return false
  }
}

async function readGitRemote(
  localPath: string,
  injected?: (localPath: string) => Promise<string>,
  signal?: AbortSignal,
): Promise<string | null> {
  try {
    if (injected) return (await injected(localPath)).trim() || null
    // git remote alone also succeeds in arbitrary children of a repository.
    const { stdout: root } = await execFileAsync("git", ["-C", localPath, "rev-parse", "--show-toplevel"], {
      shell: false, timeout: GIT_REMOTE_TIMEOUT_MS, maxBuffer: 64 * 1024, windowsHide: true, signal,
    })
    if (normalizeDirectoryPath(resolve(root.trim())) !== normalizeDirectoryPath(resolve(localPath))) return null
    const { stdout } = await execFileAsync("git", ["-C", localPath, "remote", "get-url", "origin"], {
      shell: false,
      timeout: GIT_REMOTE_TIMEOUT_MS,
      maxBuffer: 64 * 1024,
      windowsHide: true,
      signal,
    })
    return String(stdout).trim() || null
  } catch {
    return null
  }
}

/** Recheck each cwd; never reuse a previous turn's product or trust a legacy row alone. */
export async function resolveTrustedRepoCloneContext(
  cfg: RepoCloneHttpConfig, cwd: string, machineId: string, signal?: AbortSignal,
): Promise<RepoContext | null> {
  const initial = await lookupRepoCloneContext(cfg, cwd, machineId, signal)
  if (initial.status !== "resolved") return null
  try {
    const { stdout } = await execFileAsync("git", ["-C", cwd, "rev-parse", "--show-toplevel"], {
      shell: false, timeout: GIT_REMOTE_TIMEOUT_MS, maxBuffer: 64 * 1024, windowsHide: true, signal,
    })
    const root = normalizeDirectoryPath(resolve(stdout.trim()))
    const result = await probeBindings({ cfg, machineId, signal }, root)
    const binding = result.bindings.find((entry) => entry.localPath === root)
    if (signal?.aborted) throw signal.reason
    if (result.status !== "ok" || !binding || !["created", "unchanged"].includes(binding.status)) return null
    const verified = await lookupRepoCloneContext(cfg, cwd, machineId, signal)
    return verified.status === "resolved" && verified.context.repoId === binding.candidateRepoIds[0]
      && verified.context.productionId === binding.productionId ? verified.context : null
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? error
    return null
  }
}
