/**
 * core/task-query.ts —— 任务查询(按需,复用 inject 意图识别;spec §89)。
 *
 * 任务**不每轮注入、不本地缓存、无本地队列**(方案纯减法)。用户主动问("我有什么任务")
 * → inject 识别这是任务查询意图 → 运行时当场转发主脑 → 注入答案。任务只在主脑。
 *
 * 这里只做**意图识别 + 转发端口**;实际查询走可注入的 taskFetcher(brain 协议 out of scope)。
 */

/** 便宜的意图识别:用户这轮输入是否在问任务。中英启发式,宁可漏判不误触发。 */
export function isTaskQueryIntent(userInput: string): boolean {
  const t = (userInput ?? "").trim().toLowerCase()
  if (!t) return false
  return (
    /(我有什么任务|我的任务|有什么任务|待办|接下来做什么|下一步做什么|分配给我|我该做什么|任务系统.*(?:需求|任务)|(?:当前|现有|查看).*(?:需求池|需求)|需求池.*(?:有什么|列表|查看))/.test(userInput) ||
    /\b(my tasks?|what.*tasks?|assigned to me|what should i (do|work on)|to-?do list)\b/.test(t)
  )
}

export type TaskQueryKind = "my_tasks" | "requirements"
export interface TaskQueryContext {
  userId: string | null
  kind: TaskQueryKind
  cwd?: string
  machineId?: string
}
export type TaskFetcher = (context: TaskQueryContext) => Promise<string>

/**
 * 若是任务查询意图 → 当场查主脑并返回可注入文本;否则返回 null(交回普通 KH 检索)。
 * **不缓存**:每次都现查主脑。
 */
export async function maybeAnswerTaskQuery(
  userInput: string,
  context: Omit<TaskQueryContext, "kind">,
  fetcher: TaskFetcher,
): Promise<string | null> {
  if (!isTaskQueryIntent(userInput)) return null
  try {
    const kind: TaskQueryKind = /需求|需求池/.test(userInput) ? "requirements" : "my_tasks"
    const answer = await fetcher({ ...context, kind })
    return answer || (kind === "requirements"
      ? "[Synapse] 当前需求池为空。"
      : "[Synapse] 主脑当前无分配给你的任务。")
  } catch {
    // 任务查询失败也不阻断这一轮(降级为无答案)
    return "[Synapse] 任务查询暂时不可用(主脑不可达)。"
  }
}
