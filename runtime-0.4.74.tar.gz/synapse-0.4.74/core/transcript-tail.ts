/**
 * Resolve the latest completed user/assistant turn from each client's native
 * transcript store. The report hook intentionally carries no conversation text,
 * so this module must use the same client-specific formats as the corpus scanner.
 */
import { existsSync, lstatSync, readFileSync, readdirSync, statSync } from "node:fs"
import { extname, join } from "node:path"
import { homedir } from "node:os"
import { parseJsonlSafe } from "../transcript/parsers/jsonl.ts"
import { parseWholeJsonSafe } from "../transcript/parsers/json.ts"
import { listOpenCodeSessions, loadOpenCodeMessages } from "../transcript/adapters/opencode.ts"
import { parseGeminiSessionFile } from "../transcript/adapters/gemini.ts"
import { parseKimiWireRecords } from "../transcript/parsers/kimi-code.ts"
import { isKimiMainWire, readKimiSessionMetadata } from "../transcript/adapters/kimi-code.ts"
import { defaultScanConfigs, type ClientScanConfig } from "../transcript/scanner.ts"

export interface ExtractTurnTextInput {
  client: string
  session_id: string
  cwd?: string
}

export interface ExtractTurnTextOpts {
  configs?: ClientScanConfig[]
  home?: string
}

interface NormalizedMessage {
  role: "user" | "assistant"
  text: string
}

export function extractTurnText(
  input: ExtractTurnTextInput,
  opts?: ExtractTurnTextOpts,
): string | undefined {
  try {
    if (!input.session_id) return undefined
    const configs = opts?.configs ?? defaultScanConfigs(opts?.home ?? homedir())
    const cfg = configs.find((candidate) => candidate.client === input.client)
    if (!cfg) return undefined

    if (cfg.format === "opencode-sqlite") {
      return extractOpenCodeTurn(cfg, input.session_id)
    }
    if (cfg.format === "gemini") {
      return extractGeminiTurn(cfg, input.session_id)
    }
    if (cfg.format === "kimi-code") {
      return extractKimiTurn(cfg, input.session_id)
    }

    const file = locateSessionFile(cfg, input.session_id, input.client)
    if (!file) return undefined
    if (cfg.format === "jsonl") {
      const parsed = parseJsonlSafe(ensureTrailingNewline(readFileSync(file, "utf8")), 0)
      return renderLatestCompletedTurn(normalizeRecords(input.client, parsed.records))
    }
    return extractLegacyJsonTurn(file, input.client)
  } catch {
    return undefined
  }
}

function extractOpenCodeTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  for (const database of cfg.roots) {
    if (!existsSync(database)) continue
    const session = listOpenCodeSessions(database).find((candidate) => candidate.id === sessionId)
    if (!session) continue
    return renderLatestCompletedTurn(normalizeRecords("opencode", loadOpenCodeMessages(database, sessionId)))
  }
  return undefined
}

function extractGeminiTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  const candidates = collectFiles(cfg)
  for (const file of newestFirst(candidates)) {
    const snapshot = parseGeminiSessionFile(file, readFileSync(file, "utf8"))
    if (snapshot?.sessionId !== sessionId) continue
    return renderLatestCompletedTurn(normalizeRecords("gemini-cli", snapshot.messages))
  }
  return undefined
}

function extractKimiTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  const candidates = collectFiles(cfg)
    .filter((file) => isKimiMainWire(file) && readKimiSessionMetadata(file).sessionId === sessionId)
  for (const file of newestFirst(candidates)) {
    const parsed = parseJsonlSafe(ensureTrailingNewline(readFileSync(file, "utf8")), 0)
    return renderLatestCompletedTurn(normalizeRecords("kimi-code", parseKimiWireRecords(parsed.records)))
  }
  return undefined
}

function extractLegacyJsonTurn(file: string, client: string): string | undefined {
  const parsed = parseWholeJsonSafe(readFileSync(file, "utf8"))
  if (!parsed.ok) return undefined
  const value = parsed.value
  const records = Array.isArray(value)
    ? value
    : isRecord(value) && Array.isArray(value["messages"])
      ? value["messages"]
      : [value]
  return renderLatestCompletedTurn(normalizeRecords(client, records))
}

function locateSessionFile(cfg: ClientScanConfig, sessionId: string, client: string): string | undefined {
  const files = newestFirst(collectFiles(cfg))
  const filenameMatch = files.find((file) => {
    const name = file.split(/[/\\]/).pop() ?? ""
    return name.replace(/\.[^.]+$/, "") === sessionId || name.includes(sessionId)
  })
  if (filenameMatch) return filenameMatch

  // Resumed Codex threads can expose payload.session_id while the rollout file is
  // named after payload.id. Inspect bounded metadata instead of assuming equality.
  return files.find((file) => transcriptDeclaresSession(file, sessionId, client))
}

function transcriptDeclaresSession(file: string, sessionId: string, client: string): boolean {
  if (extname(file) !== ".jsonl") return false
  const prefix = readFileSync(file, "utf8").slice(0, 256 * 1024)
  const parsed = parseJsonlSafe(ensureTrailingNewline(prefix), 0)
  return parsed.records.slice(0, 32).some((value) => {
    const record = asRecord(value)
    const payload = asRecord(record["payload"])
    if (client === "codex") {
      return [payload["id"], payload["session_id"], record["session_id"]].includes(sessionId)
    }
    return [record["sessionId"], record["session_id"]].includes(sessionId)
  })
}

function collectFiles(cfg: ClientScanConfig): string[] {
  const found = new Set<string>()
  for (const root of cfg.roots) collect(root, cfg.ext, found)
  return [...found]
}

function collect(path: string, extensions: string[], found: Set<string>): void {
  if (!existsSync(path)) return
  const stat = lstatSync(path)
  if (stat.isSymbolicLink()) return
  if (stat.isFile()) {
    if (extensions.includes(extname(path))) found.add(path)
    return
  }
  for (const entry of readdirSync(path)) collect(join(path, entry), extensions, found)
}

function newestFirst(files: string[]): string[] {
  return files.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)
}

function normalizeRecords(client: string, records: unknown[]): NormalizedMessage[] {
  const messages: NormalizedMessage[] = []
  for (const value of records) {
    const record = asRecord(value)
    let message = record

    if (client === "codex") {
      if (record["type"] !== "response_item") continue
      const payload = asRecord(record["payload"])
      if (payload["type"] !== "message") continue
      message = payload
    } else if (client === "claude-code") {
      if (record["isMeta"] === true || record["isSidechain"] === true) continue
      const nested = asRecord(record["message"])
      if (Object.keys(nested).length > 0) message = nested
    }

    const role = normalizeRole(message["role"] ?? record["type"])
    if (!role) continue
    const rawContent = message["content"] ?? message["text"] ?? message["displayContent"]
    const extracted = textFromValue(rawContent, { textPartsOnly: client === "opencode" || client === "kimi-code" })
    const text = role === "user" ? stripInjectedUserContext(extracted) : extracted
    if (text) messages.push({ role, text })
  }
  return messages
}

function renderLatestCompletedTurn(messages: NormalizedMessage[]): string | undefined {
  let assistant = messages.length - 1
  while (assistant >= 0 && messages[assistant]?.role !== "assistant") assistant--
  if (assistant < 0) return undefined

  let user = assistant - 1
  while (user >= 0 && messages[user]?.role !== "user") user--
  const selected = messages.slice(user >= 0 ? user : assistant, assistant + 1)
  if (selected.length === 0) return undefined
  return selected.map((message) => `[${message.role}] ${message.text}`).join("\n\n")
}

function normalizeRole(value: unknown): NormalizedMessage["role"] | undefined {
  if (value === "user") return "user"
  if (value === "assistant" || value === "gemini") return "assistant"
  return undefined
}

function textFromValue(value: unknown, opts: { textPartsOnly?: boolean } = {}): string {
  if (typeof value === "string") return value.trim()
  if (Array.isArray(value)) {
    return value.map((item) => textFromValue(item, opts)).filter(Boolean).join(" ").trim()
  }
  if (!isRecord(value)) return ""
  const record = asRecord(value)
  const type = typeof record["type"] === "string" ? record["type"] : ""
  if ([
    "tool_use",
    "tool_result",
    "functionCall",
    "functionResponse",
    "function_call",
    "function_response",
  ].includes(type)) return ""
  if (opts.textPartsOnly && type && type !== "text") return ""
  for (const key of ["text", "content", "parts"]) {
    const text = textFromValue(record[key], opts)
    if (text) return text
  }
  return ""
}

const INJECTED_USER_CONTEXT_MARKERS = [
  "<hook_context>",
  "Synapse additional context:",
  "[Synapse additional context]",
  "[Synapse control]",
]

/** Prevent Synapse's own injected knowledge from being re-sedimented as user input. */
function stripInjectedUserContext(value: string): string {
  let end = value.length
  for (const marker of INJECTED_USER_CONTEXT_MARKERS) {
    const index = value.indexOf(marker)
    if (index >= 0 && index < end) end = index
  }
  return value.slice(0, end).trim()
}

function asRecord(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {}
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

function ensureTrailingNewline(value: string): string {
  return value.endsWith("\n") ? value : `${value}\n`
}
