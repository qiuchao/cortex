import type { z } from "zod"
/**
 * Thin consumer for Cerebro's deterministic legacy-task-admission.v2 route.
 *
 * This module deliberately owns transport and correlation validation only.
 * Task intent, product resolution and read execution belong to
 * Cerebro; Synapse must never recreate those decisions locally.
 */
import { stableUuidV4 } from "../core/stable-uuid.ts"
import { resolveUserId } from "../core/user-id.ts"
import { withControlDeadline } from "../core/control-deadline.ts"
import { getBrainConfig } from "../transport/brain-config.ts"
import {
  LEGACY_TASK_ADMISSION_V2_CONTRACT,
  LEGACY_TASK_ADMISSION_V2_PROTOCOL_VERSION,
  LEGACY_ITERATION_LIST_SLICE,
  LegacyTaskAdmissionReferenceSchema,
  LegacyTaskAdmissionV2RequestSchema,
  parseLegacyTaskAdmissionV2Response,
  type LegacyTaskAdmissionV2NegotiatedResponse,
  type LegacyTaskAdmissionV2NegotiatedResult,
  type LegacyTaskAdmissionReference,
  type LegacyTaskAdmissionV2Request,
  type IterationListFilterInput,
  type LegacyTaskAdmissionV3ReferenceSchema,
} from "@cerebro/wire"

export const LEGACY_TASK_ADMISSION_PATH = "/brain/legacy-task-admission" as const
export const LEGACY_TASK_ADMISSION_CONTRACT = LEGACY_TASK_ADMISSION_V2_CONTRACT
export const LEGACY_TASK_ADMISSION_PROTOCOL_VERSION = LEGACY_TASK_ADMISSION_V2_PROTOCOL_VERSION
export const LEGACY_TASK_ADMISSION_TIMEOUT_MS = 3_500
/** Protocol capabilities are fixed for this client, independent of user intent. */
export const LEGACY_TASK_SUPPORTED_SLICES = Object.freeze([LEGACY_ITERATION_LIST_SLICE])

export interface LegacyTaskAdmissionInput {
  client: string
  sessionId: string
  turnId: string
  userInput: string
  messageId?: string
  productionContext?: {
    productionId?: string
    projectId?: string
    repositoryId?: string
  }
  references?: readonly LegacyTaskAdmissionReference[]
  typedRead?: { command: "iteration.list"; input: IterationListFilterInput }
  signal?: AbortSignal
  env?: NodeJS.ProcessEnv
}

export interface LegacyTaskAdmissionBridgeSuccess {
  available: true
  request: LegacyTaskAdmissionV2Request
  response: LegacyTaskAdmissionV2NegotiatedResponse | LegacyTaskAdmissionV2NegotiatedResult | z.infer<typeof LegacyTaskAdmissionV3ReferenceSchema>
  resultContext?: string
}

export interface LegacyTaskAdmissionBridgeUnavailable {
  available: false
  request?: LegacyTaskAdmissionV2Request
  response?: LegacyTaskAdmissionV2NegotiatedResponse | LegacyTaskAdmissionV2NegotiatedResult
  reason: string
  errorCode?: "UNAVAILABLE" | "BAD_CORRELATION" | "CANCELLED"
}

export type LegacyTaskAdmissionBridgeResult =
  | LegacyTaskAdmissionBridgeSuccess
  | LegacyTaskAdmissionBridgeUnavailable

export function isLegacyTaskAdmissionOutside(
  response: LegacyTaskAdmissionBridgeSuccess["response"],
): boolean {
  return "slice" in response && response.slice === "outside_slice" && response.allowLegacy === true
}

export function isLegacyTaskAdmissionUnified(
  response: LegacyTaskAdmissionBridgeSuccess["response"],
): boolean {
  return "slice" in response && response.slice === "outside_slice" && response.allowLegacy === false
}

export interface LegacyTaskAdmissionBridgeOptions {
  timeoutMs?: number
  fetchImpl?: typeof fetch
}

/** Bind transport identities to the current trusted configuration, never to model output. */
export function legacyTaskAdmissionScope(env: NodeJS.ProcessEnv = process.env) {
  const config = getBrainConfig(env)
  return {
    actorScope: resolveUserId({ env }) ?? "",
    brainScope: config?.brainBaseUrl ?? env.CEREBRO_BRAIN_URL?.trim() ?? "",
    authScope: config?.machineToken ?? env.CEREBRO_MACHINE_TOKEN?.trim() ?? "",
  }
}

export function buildLegacyTaskAdmissionRequest(
  input: LegacyTaskAdmissionInput,
  actorUserId = resolveUserId({ env: input.env }),
): LegacyTaskAdmissionV2Request {
  const sessionId = required(input.sessionId, "sessionId")
  const turnId = required(input.turnId, "turnId")
  const message = input.userInput
  if (!message?.trim()) throw new TypeError("message must not be empty")
  if (!actorUserId?.trim()) throw new TypeError("trusted actorUserId is unavailable")
  const references = (input.references ?? []).map((reference) => LegacyTaskAdmissionReferenceSchema.parse(reference))
  const requestId = stableUuidV4(`cerebro.${LEGACY_TASK_ADMISSION_CONTRACT}`, JSON.stringify({
    ...legacyTaskAdmissionScope(input.env), actorScope: actorUserId.trim(),
    client: input.client, sessionId, turnId, messageId: input.messageId?.trim() ?? null, message,
    productionContext: input.productionContext ?? null, references, acceptedSlices: LEGACY_TASK_SUPPORTED_SLICES,
    typedRead: input.typedRead ?? null,
  }))
  return LegacyTaskAdmissionV2RequestSchema.parse({
    contract: LEGACY_TASK_ADMISSION_CONTRACT,
    protocolVersion: LEGACY_TASK_ADMISSION_PROTOCOL_VERSION,
    requestId,
    sessionId,
    turnId,
    actorUserId: actorUserId.trim(),
    client: required(input.client, "client"),
    message,
    ...(input.productionContext ? { productionContext: { ...input.productionContext } } : {}),
    references,
    acceptedSlices: [...LEGACY_TASK_SUPPORTED_SLICES],
    ...(input.typedRead ? { typedRead: input.typedRead } : {}),
  })
}

export async function submitLegacyTaskAdmission(
  input: LegacyTaskAdmissionInput,
  options: LegacyTaskAdmissionBridgeOptions = {},
): Promise<LegacyTaskAdmissionBridgeResult> {
  let request: LegacyTaskAdmissionV2Request
  try {
    request = buildLegacyTaskAdmissionRequest(input)
  } catch (error) {
    return { available: false, reason: error instanceof Error ? error.message : String(error), errorCode: "UNAVAILABLE" }
  }
  const cfg = getBrainConfig(input.env ?? process.env)
  if (!cfg?.machineToken) return { available: false, request, reason: "Cerebro legacy task admission is not configured", errorCode: "UNAVAILABLE" }
  try {
    return await withControlDeadline(async (signal): Promise<LegacyTaskAdmissionBridgeResult> => {
      signal.throwIfAborted()
      const response = await (options.fetchImpl ?? fetch)(`${cfg.brainBaseUrl}${LEGACY_TASK_ADMISSION_PATH}`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${cfg.machineToken}`,
        },
        body: JSON.stringify(request),
        signal,
      })
      const payload = await response.json().catch(() => undefined)
      signal.throwIfAborted()
      let parsed: LegacyTaskAdmissionV2NegotiatedResponse | LegacyTaskAdmissionV2NegotiatedResult
      try {
        parsed = parseLegacyTaskAdmissionV2Response(payload, request, request.productionContext?.productionId)
      } catch (error) {
        const correlation = typeof error === "object" && error !== null && "code" in error && error.code === "BAD_CORRELATION"
        return { available: false, request, reason: correlation ? "legacy task admission response correlation mismatch" : "legacy task admission response failed shared wire schema validation", errorCode: correlation ? "BAD_CORRELATION" : "UNAVAILABLE" }
      }
      if ("productionId" in parsed && request.productionContext?.productionId && parsed.productionId !== request.productionContext.productionId) {
        return { available: false, request, response: parsed, reason: "legacy task admission response production mismatch", errorCode: "BAD_CORRELATION" }
      }
      if (parsed.decision === "read") {
        return { available: false, request, reason: "legacy task admission execution returned an unexecuted binding", errorCode: "UNAVAILABLE" }
      }
      const outside = isLegacyTaskAdmissionOutside(parsed)
      const unified = isLegacyTaskAdmissionUnified(parsed)
      const inSlice = (parsed.slice === "legacy_requirement_read" || parsed.slice === "legacy_bug_list" || parsed.slice === "legacy_iteration_list") && parsed.allowLegacy === false
      if (!outside && !unified && !inSlice) {
        return { available: false, request, response: parsed, reason: "legacy task admission response slice binding is invalid", errorCode: "BAD_CORRELATION" }
      }
      const notFound = response.status === 404 && parsed.decision === "result" && "errorCode" in parsed && parsed.errorCode === "NOT_FOUND"
      if (parsed.decision === "unavailable" || (!response.ok && !notFound)) {
        const errorCode = "errorCode" in parsed ? parsed.errorCode : undefined
        return { available: false, request, response: parsed, reason: parsed.decision === "unavailable" ? parsed.reason : `Cerebro returned HTTP ${response.status}`, errorCode: errorCode === "CANCELLED" ? "CANCELLED" : "UNAVAILABLE" }
      }
      return { available: true, request, response: parsed }
    }, options.timeoutMs ?? LEGACY_TASK_ADMISSION_TIMEOUT_MS, input.signal)
  } catch {
    const cancelled = input.signal?.aborted
    return { available: false, request, reason: cancelled ? "legacy task admission request cancelled" : "legacy task admission unavailable", errorCode: cancelled ? "CANCELLED" : "UNAVAILABLE" }
  }
}

function required(value: string | undefined, field: string): string {
  const normalized = value?.trim() ?? ""
  if (!normalized) throw new TypeError(`${field} must not be empty`)
  return normalized
}
