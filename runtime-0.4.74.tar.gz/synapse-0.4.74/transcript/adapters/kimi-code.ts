import { readFileSync } from "node:fs"
import { basename, dirname, join } from "node:path"
import { parseWholeJsonSafe } from "../parsers/json.ts"
import { normalizeSessionTitle } from "../title.ts"

export interface KimiSessionMetadata {
  sessionId: string
  projectPath?: string
  title?: string
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

export function isKimiMainWire(path: string): boolean {
  const parts = path.split(/[\\/]/)
  return parts.length >= 4
    && parts.at(-1) === "wire.jsonl"
    && parts.at(-2) === "main"
    && parts.at(-3) === "agents"
}

export function kimiSessionDirectory(wirePath: string): string {
  return dirname(dirname(dirname(wirePath)))
}

/** Read the v2 state.json shape while retaining compatibility with the original adapter. */
export function readKimiSessionMetadata(wirePath: string): KimiSessionMetadata {
  const sessionDirectory = kimiSessionDirectory(wirePath)
  const fallbackSessionId = basename(sessionDirectory)
  try {
    const parsed = parseWholeJsonSafe(readFileSync(join(sessionDirectory, "state.json"), "utf8"))
    const state = parsed.ok ? asRecord(parsed.value) : undefined
    if (!state) return { sessionId: fallbackSessionId }
    const custom = asRecord(state["custom"])
    const sessionId = typeof state["id"] === "string"
      ? state["id"]
      : typeof state["sessionId"] === "string" ? state["sessionId"] : fallbackSessionId
    const projectPath = typeof state["cwd"] === "string"
      ? state["cwd"]
      : typeof state["workDir"] === "string" ? state["workDir"] : undefined
    const title = normalizeSessionTitle(
      state["title"] ?? state["customTitle"] ?? custom?.["title"] ?? custom?.["customTitle"],
    )
    return {
      sessionId,
      ...(projectPath ? { projectPath } : {}),
      ...(title ? { title } : {}),
    }
  } catch {
    return { sessionId: fallbackSessionId }
  }
}
