# ported/ — 隔离的安全与兼容模块

> 这里保存需要严格控制进程边界的模块。含 `process.exit` 的脚本只能作为子进程执行；纯模块可由 Synapse daemon 直接导入。

## 🔴 唯一铁律:含 `process.exit` 的模块禁止进程内 import,只能子进程 spawn

常驻运行时是长寿进程。任何在模块顶层或函数里调用 `process.exit()` 的模块一旦被 `import` 进运行时,它第一次执行(例如第一个 git 受保护主干检查)就会**把整个 daemon 杀掉**,所有客户端的 inject/report/guard 静默失效。

因此按 **exit 行为** 严格分两组:

### A. 子进程组(含 `process.exit`,**只能 spawn**,放 `ported/git/`)

| 文件 | exit 数 | 调用方式 |
|---|---|---|
| `git/git-safety-gateway.mjs` | 34 | `node ported/git/git-safety-gateway.mjs <subcommand>`,读退出码 |
| `git/branch-parent-helper.mjs` | 5 | 子进程 |
| `git/recovery-helpers.mjs` | 2 | 子进程 |
| `git/commit-sync-helpers.mjs` | 1 | 子进程 |
| `git/read-git-rules.mjs` | 1 | 子进程 |
| `git/conflict-parser.mjs` | 0(纯) | 归此目录,仍按子进程调用以防未来加 exit |
| `git/repo-hash.mjs` | 0(纯) | 网关的传递依赖(`computeRepoHash`);随网关子进程运行,不单独 import |
| `capability-detect.mjs`(在 `ported/` 根) | 3 | 子进程,作 install/doctor 的 per-client probe |

### B. import 安全组(0 exit,依赖干净,**可进程内 import**)

| 文件 | 依赖 | 说明 |
|---|---|---|
| `git-rules-loader.ts` | 仅 node 内建 | 三层加载 git-rules.json(项目 → 全局 → 内置默认) |
| `git-safety-runtime-helpers.ts` | 仅 node 内建(内部 spawnSync 调 git) | 纯 helpers:`parseGitCommand` / `buildBlockMessage` / `tokenizeCommand` 等 |

> **已删除(2026-07-14,MCP 退役)**:`kh-client.ts` + `kh-client-stdio.ts` + `global-config.ts`。
> inject 检索 / report 沉淀当前走 Cerebro REST(`transport/brain-contract-align.ts` 的 `searchKnowledge` / `sedimentInsight`,
> 对应 `/api/v1/knowledge/search` 与 `/api/v1/knowledge/sediment` + machine token)。检索结果类型见 `transport/kh-types.ts`。

## git-safety-gateway.mjs 退出码契约(源码 header 为准)

> ⚠️ 方案文档 §3/§1 曾把"受保护主干"写成 exit 2,**以源码为准是 exit 3**。

| code | 含义 |
|---|---|
| 0 | 通过 |
| 1 | 敏感信息检测命中 |
| 2 | 大文件超阈值(建议走 LFS) |
| **3** | **main/受保护分支直接提交(阻止)** |
| 4 | 高危命令(reset --hard / push --force / branch -D / clean -fd 等) |
| 5 | commit-required 模式下环境层失败 |
| 11 | 大文件未走 LFS |

子命令:`check-sensitive` / `check-large-files` / `check-branch`(exit 0/3) / `check-dangerous <cmd>`(exit 0/4) / `check-push-status` / `repo-hash` / `all`。
