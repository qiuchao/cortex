/**
 * Resolve the latest completed user/assistant turn from each client's native
 * transcript store. The report hook intentionally carries no conversation text,
 * so this module must use the same client-specific formats as the corpus scanner.
 */
import { existsSync, lstatSync, readFileSync, readdirSync, realpathSync, statSync } from "node:fs"
import { extname, isAbsolute, join, relative, sep } from "node:path"
import { homedir } from "node:os"
import { parseJsonlSafe } from "../transcript/parsers/jsonl.ts"
import { readJsonlPrefix, scanJsonlTail } from "./parsers/transcript-jsonl.ts"
import { parseWholeJsonSafe } from "../transcript/parsers/json.ts"
import { listOpenCodeSessions, loadOpenCodeMessages } from "../transcript/adapters/opencode.ts"
import { parseGeminiSessionFile } from "../transcript/adapters/gemini.ts"
import { parseKimiWireRecords } from "../transcript/parsers/kimi-code.ts"
import { isKimiMainWire, readKimiSessionMetadata } from "../transcript/adapters/kimi-code.ts"
import { defaultScanConfigs, type ClientScanConfig } from "../transcript/scanner.ts"

const JSONL_SESSION_PREFIX_BYTES = 256 * 1024
const JSONL_TAIL_INITIAL_BYTES = 512 * 1024
const JSONL_TAIL_MAX_BYTES = 8 * 1024 * 1024

export interface ExtractTurnTextInput {
  client: string
  session_id: string
  cwd?: string
  turn_id?: string
  transcript_path?: string
}

export interface ExtractTurnTextOpts {
  configs?: ClientScanConfig[]
  home?: string
  codexHome?: string
  xdgDataHome?: string
}

interface NormalizedMessage {
  role: "user" | "assistant"
  text: string
  turnId?: string
  source?: "transcript" | "cerebro_receipt"
  operationIds?: readonly string[]
}

export interface ExtractRecentContextEntry {
  turnId?: string
  role: "user" | "assistant"
  source: "transcript" | "cerebro_receipt"
  content: string
  operationIds?: readonly string[]
}

export function extractTurnText(
  input: ExtractTurnTextInput,
  opts?: ExtractTurnTextOpts,
): string | undefined {
  try {
    if (!input.session_id) return undefined
    const configs = opts?.configs ?? defaultScanConfigs(opts?.home ?? homedir(), {
      codexHome: opts?.codexHome,
      xdgDataHome: opts?.xdgDataHome,
    })
    const cfg = configs.find((candidate) => candidate.client === input.client)
    if (!cfg) return undefined

    if (cfg.format === "opencode-sqlite") {
      return extractOpenCodeTurn(cfg, input.session_id)
    }
    if (cfg.format === "gemini") {
      return extractGeminiTurn(cfg, input.session_id)
    }
    if (cfg.format === "kimi-code") {
      return extractKimiTurn(cfg, input.session_id)
    }

    const file = input.transcript_path
      ? locateExplicitTranscriptFile(cfg, input.transcript_path, input.session_id, input.client, input.cwd)
      : locateSessionFile(cfg, input.session_id, input.client, input.cwd)
    if (!file) return undefined
    if (cfg.format === "jsonl") {
      return extractJsonlTurn(file, input)
    }
    return extractLegacyJsonTurn(file, input.client, { includeCerebroReceipts: true })
  } catch {
    return undefined
  }
}

export function extractRecentContext(
  input: ExtractTurnTextInput,
  opts?: ExtractTurnTextOpts,
): ExtractRecentContextEntry[] | undefined {
  try {
    if (!input.session_id) return undefined
    const configs = opts?.configs ?? defaultScanConfigs(opts?.home ?? homedir(), {
      codexHome: opts?.codexHome,
      xdgDataHome: opts?.xdgDataHome,
    })
    const cfg = configs.find((candidate) => candidate.client === input.client)
    if (!cfg) return undefined

    let messages: NormalizedMessage[] | undefined
    if (cfg.format === "opencode-sqlite") {
      messages = normalizeRecords("opencode", loadOpenCodeMessagesFromConfig(cfg, input.session_id), { includeCerebroReceipts: true })
    } else if (cfg.format === "gemini") {
      messages = normalizeGeminiRecentContext(cfg, input.session_id)
    } else if (cfg.format === "kimi-code") {
      messages = normalizeKimiRecentContext(cfg, input.session_id)
    } else {
      const file = input.transcript_path
        ? locateExplicitTranscriptFile(cfg, input.transcript_path, input.session_id, input.client, input.cwd)
        : locateSessionFile(cfg, input.session_id, input.client, input.cwd)
      if (!file) return undefined
      if (cfg.format === "jsonl") {
        messages = scanJsonlTail(file, {
          initialBytes: JSONL_TAIL_INITIAL_BYTES,
          maxBytes: JSONL_TAIL_MAX_BYTES,
        }, (records) => normalizeRecords(input.client, records, { includeCerebroReceipts: true }))
      } else {
        messages = normalizeLegacyJsonRecentContext(file, input.client, { includeCerebroReceipts: true })
      }
    }
    const selected = renderLatestCompletedRecentContext(messages ?? [], input.turn_id)
    return selected.length ? selected : undefined
  } catch {
    return undefined
  }
}

function extractJsonlTurn(file: string, input: ExtractTurnTextInput): string | undefined {
  return scanJsonlTail(file, {
    initialBytes: JSONL_TAIL_INITIAL_BYTES,
    maxBytes: JSONL_TAIL_MAX_BYTES,
  }, (records) => renderLatestCompletedTurn(normalizeRecords(input.client, records, { includeCerebroReceipts: true }), input.turn_id))
}

function locateExplicitTranscriptFile(
  cfg: ClientScanConfig,
  transcriptPath: string,
  sessionId: string,
  client: string,
  cwd?: string,
): string | undefined {
  const normalizedPath = transcriptPath.trim()
  if (!normalizedPath || !isAbsolute(normalizedPath) || extname(normalizedPath) !== ".jsonl") return undefined
  if (!existsSync(normalizedPath)) return undefined
  let realTranscriptPath: string
  try {
    realTranscriptPath = realpathSync(normalizedPath)
  } catch {
    return undefined
  }
  const allowed = cfg.roots.some((root) => {
    let realRoot: string
    try {
      realRoot = realpathSync(root)
    } catch {
      return false
    }
    const relativePath = relative(realRoot, realTranscriptPath)
    return relativePath === "" || (relativePath !== ".." && !relativePath.startsWith(`..${sep}`) && !isAbsolute(relativePath))
  })
  if (!allowed) return undefined
  return transcriptDeclaresSession(realTranscriptPath, sessionId, client, cwd) ? realTranscriptPath : undefined
}

function extractOpenCodeTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  for (const database of cfg.roots) {
    if (!existsSync(database)) continue
    const session = listOpenCodeSessions(database).find((candidate) => candidate.id === sessionId)
    if (!session) continue
    return renderLatestCompletedTurn(normalizeRecords("opencode", loadOpenCodeMessages(database, sessionId), { includeCerebroReceipts: true }))
  }
  return undefined
}

function loadOpenCodeMessagesFromConfig(cfg: ClientScanConfig, sessionId: string): unknown[] {
  for (const database of cfg.roots) {
    if (!existsSync(database)) continue
    const session = listOpenCodeSessions(database).find((candidate) => candidate.id === sessionId)
    if (!session) continue
    return loadOpenCodeMessages(database, sessionId)
  }
  return []
}

function extractGeminiTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  const candidates = collectFiles(cfg)
  for (const file of newestFirst(candidates)) {
    const snapshot = parseGeminiSessionFile(file, readFileSync(file, "utf8"))
    if (snapshot?.sessionId !== sessionId) continue
    return renderLatestCompletedTurn(normalizeRecords("gemini-cli", snapshot.messages))
  }
  return undefined
}

function normalizeGeminiRecentContext(cfg: ClientScanConfig, sessionId: string): NormalizedMessage[] | undefined {
  const candidates = collectFiles(cfg)
  for (const file of newestFirst(candidates)) {
    const snapshot = parseGeminiSessionFile(file, readFileSync(file, "utf8"))
    if (snapshot?.sessionId !== sessionId) continue
    return normalizeRecords("gemini-cli", snapshot.messages)
  }
  return undefined
}

function extractKimiTurn(cfg: ClientScanConfig, sessionId: string): string | undefined {
  const candidates = collectFiles(cfg)
    .filter((file) => isKimiMainWire(file) && readKimiSessionMetadata(file).sessionId === sessionId)
  for (const file of newestFirst(candidates)) {
    const parsed = parseJsonlSafe(ensureTrailingNewline(readFileSync(file, "utf8")), 0)
    return renderLatestCompletedTurn(normalizeRecords("kimi-code", parseKimiWireRecords(parsed.records)))
  }
  return undefined
}

function normalizeKimiRecentContext(cfg: ClientScanConfig, sessionId: string): NormalizedMessage[] | undefined {
  const candidates = collectFiles(cfg)
    .filter((file) => isKimiMainWire(file) && readKimiSessionMetadata(file).sessionId === sessionId)
  for (const file of newestFirst(candidates)) {
    const parsed = parseJsonlSafe(ensureTrailingNewline(readFileSync(file, "utf8")), 0)
    return normalizeRecords("kimi-code", parseKimiWireRecords(parsed.records))
  }
  return undefined
}

function extractLegacyJsonTurn(
  file: string,
  client: string,
  opts: { includeCerebroReceipts?: boolean } = {},
): string | undefined {
  const parsed = parseWholeJsonSafe(readFileSync(file, "utf8"))
  if (!parsed.ok) return undefined
  const value = parsed.value
  const records = Array.isArray(value)
    ? value
    : isRecord(value) && Array.isArray(value["messages"])
      ? value["messages"]
    : [value]
  return renderLatestCompletedTurn(normalizeRecords(client, records, opts))
}

function normalizeLegacyJsonRecentContext(
  file: string,
  client: string,
  opts: { includeCerebroReceipts?: boolean } = {},
): NormalizedMessage[] | undefined {
  const parsed = parseWholeJsonSafe(readFileSync(file, "utf8"))
  if (!parsed.ok) return undefined
  const value = parsed.value
  const records = Array.isArray(value)
    ? value
    : isRecord(value) && Array.isArray(value["messages"])
      ? value["messages"]
      : [value]
  return normalizeRecords(client, records, opts)
}

function locateSessionFile(cfg: ClientScanConfig, sessionId: string, client: string, cwd?: string): string | undefined {
  const files = newestFirst(collectFiles(cfg))
  const filenameMatch = files.find((file) => {
    const name = file.split(/[/\\]/).pop() ?? ""
    const matchesName = name.replace(/\.[^.]+$/, "") === sessionId || name.includes(sessionId)
    return matchesName && (client !== "codex" || transcriptDeclaresSession(file, sessionId, client, cwd))
  })
  if (filenameMatch) return filenameMatch

  // Resumed Codex threads can expose payload.session_id while the rollout file is
  // named after payload.id. Inspect bounded metadata instead of assuming equality.
  return files.find((file) => transcriptDeclaresSession(file, sessionId, client, cwd))
}

function transcriptDeclaresSession(
  file: string,
  sessionId: string,
  client: string,
  cwd?: string,
): boolean {
  if (extname(file) !== ".jsonl") return false
  const records = readJsonlPrefix(file, JSONL_SESSION_PREFIX_BYTES)
  return Boolean(records?.slice(0, 32).some((value) => {
    const record = asRecord(value)
    const payload = asRecord(record["payload"])
    if (client === "codex") {
      if (record["type"] !== "session_meta") return false
      if (!isCodexMainThreadSessionMeta(payload)) return false
      const canonicalSessionId = stringValue(payload["session_id"])
      const sessionMatches = "session_id" in payload
        ? Boolean(canonicalSessionId && canonicalSessionId === sessionId)
        : stringValue(payload["id"], record["session_id"]) === sessionId
      if (!sessionMatches || !cwd) return sessionMatches
      return typeof payload["cwd"] === "string" && samePath(payload["cwd"], cwd)
    }
    return [record["sessionId"], record["session_id"]].includes(sessionId)
  }))
}

function collectFiles(cfg: ClientScanConfig): string[] {
  const found = new Set<string>()
  for (const root of cfg.roots) collect(root, cfg.ext, found)
  return [...found]
}

function collect(path: string, extensions: string[], found: Set<string>): void {
  if (!existsSync(path)) return
  const stat = lstatSync(path)
  if (stat.isSymbolicLink()) return
  if (stat.isFile()) {
    if (extensions.includes(extname(path))) found.add(path)
    return
  }
  for (const entry of readdirSync(path)) collect(join(path, entry), extensions, found)
}

function newestFirst(files: string[]): string[] {
  return files.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)
}

function normalizeRecords(
  client: string,
  records: unknown[],
  opts: { includeCerebroReceipts?: boolean } = {},
): NormalizedMessage[] {
  const messages: NormalizedMessage[] = []
  let contextTurnId: string | undefined
  let activeUserTurnId: string | undefined
  for (const value of records) {
    const record = asRecord(value)
    if (client === "codex") {
      const payload = asRecord(record["payload"])
      const directTurnId = codexTurnId(record, payload)
      if (record["type"] !== "response_item" && directTurnId) {
        if (directTurnId !== contextTurnId) {
          activeUserTurnId = undefined
        }
        contextTurnId = directTurnId
      }
    }
    let message = record

    if (client === "codex") {
      if (record["type"] !== "response_item") continue
      const payload = asRecord(record["payload"])
      if (payload["type"] !== "message") continue
      message = payload
      const messageTurnId = codexTurnId(record, payload)
      const nativeRole = message["role"] ?? record["type"]
      const receipt = opts.includeCerebroReceipts && nativeRole === "developer"
        ? trustedCerebroReceipt(textFromValue(message["content"] ?? message["text"] ?? message["displayContent"]))
        : undefined
      if (receipt) {
        messages.push({
          role: "assistant",
          text: receipt.text,
          source: "cerebro_receipt",
          operationIds: receipt.operationIds,
          ...(messageTurnId ?? activeUserTurnId ?? contextTurnId ? { turnId: messageTurnId ?? activeUserTurnId ?? contextTurnId } : {}),
        })
        continue
      }
      const role = normalizeRole(nativeRole)
      if (role === "user") {
        activeUserTurnId = messageTurnId ?? contextTurnId
      }
      const logicalTurnId = role === "assistant"
        ? activeUserTurnId ?? messageTurnId ?? contextTurnId
        : messageTurnId ?? contextTurnId
      const rawContent = message["content"] ?? message["text"] ?? message["displayContent"]
      const extracted = textFromValue(rawContent)
      const text = role === "user" ? stripInjectedUserContext(extracted) : extracted
      if (role && text) messages.push({ role, text, source: "transcript", ...(logicalTurnId ? { turnId: logicalTurnId } : {}) })
      continue
    } else if (client === "claude-code") {
      if (record["isMeta"] === true || record["isSidechain"] === true) continue
      const nested = asRecord(record["message"])
      if (Object.keys(nested).length > 0) message = nested
    }

    const receipt = opts.includeCerebroReceipts
      ? trustedCerebroReceipt(textFromValue(message["content"] ?? message["text"] ?? message["displayContent"] ?? record["attachment"]))
      : undefined
    if (receipt) {
      messages.push({
        role: "assistant",
        text: receipt.text,
        source: "cerebro_receipt",
        operationIds: receipt.operationIds,
      })
      continue
    }

    const role = normalizeRole(message["role"] ?? record["type"])
    if (!role) continue
    const rawContent = message["content"] ?? message["text"] ?? message["displayContent"]
    const extracted = textFromValue(rawContent, { textPartsOnly: client === "opencode" || client === "kimi-code" })
    const text = role === "user" ? stripInjectedUserContext(extracted) : extracted
    if (text) messages.push({ role, text, source: "transcript" })
  }
  return messages
}

function codexTurnId(
  record: Record<string, unknown>,
  payload: Record<string, unknown>,
): string | undefined {
  const metadata = asRecord(payload["internal_chat_message_metadata_passthrough"])
  return stringValue(
    metadata["turn_id"],
    metadata["turnId"],
    record["turn_id"],
    record["root_turn_id"],
    payload["turn_id"],
    payload["root_turn_id"],
  )
}

function renderLatestCompletedTurn(messages: NormalizedMessage[], turnId?: string): string | undefined {
  const selectedMessages = turnId
    ? messages.filter((message) => message.turnId === turnId && message.source !== "cerebro_receipt")
    : messages.filter((message) => message.source !== "cerebro_receipt")
  if (turnId && selectedMessages.length === 0) return undefined
  let assistant = selectedMessages.length - 1
  while (assistant >= 0 && selectedMessages[assistant]?.role !== "assistant") assistant--
  if (assistant < 0) return undefined

  let user = assistant - 1
  while (user >= 0 && selectedMessages[user]?.role !== "user") user--
  const selected = selectedMessages.slice(user >= 0 ? user : assistant, assistant + 1)
  if (selected.length === 0) return undefined
  return selected.map((message) => `[${message.role}] ${message.text}`).join("\n\n")
}

function renderLatestCompletedRecentContext(messages: NormalizedMessage[], turnId?: string): ExtractRecentContextEntry[] {
  const conversation = messages.filter((message) => message.source !== "cerebro_receipt")
  const exactConversation = turnId
    ? conversation.filter((message) => message.turnId === turnId)
    : conversation
  const selectedConversation = hasCompletedAssistantTurn(exactConversation)
    ? exactConversation
    : turnId ? conversation : exactConversation
  const assistantMessage = findLast(selectedConversation, (message) => message.role === "assistant")
  if (!assistantMessage) return []
  const assistantIndex = messages.indexOf(assistantMessage)
  let userIndex = assistantIndex - 1
  while (userIndex >= 0) {
    const message = messages[userIndex]
    if (message?.source !== "cerebro_receipt" && message?.role === "user") break
    userIndex--
  }
  if (userIndex < 0) userIndex = assistantIndex
  const selectedTurnId = assistantMessage.turnId
  const selected = messages
    .filter((message, index) => {
      if (selectedTurnId && message.turnId === selectedTurnId) return true
      return index >= userIndex && index <= assistantIndex
    })
    .filter((message) => message.text.trim())
  return selected.map((message) => ({
    ...(message.turnId ? { turnId: message.turnId } : {}),
    role: message.role,
    source: message.source ?? "transcript",
    content: message.text,
    ...(message.operationIds?.length ? { operationIds: message.operationIds } : {}),
  }))
}

function hasCompletedAssistantTurn(messages: NormalizedMessage[]): boolean {
  return messages.some((message) => message.role === "assistant")
}

function findLast<T>(values: T[], predicate: (value: T) => boolean): T | undefined {
  for (let index = values.length - 1; index >= 0; index -= 1) {
    if (predicate(values[index]!)) return values[index]
  }
  return undefined
}

function trustedCerebroReceipt(text: string): { text: string; operationIds?: readonly string[] } | undefined {
  const trustMarkers = [
    "Synapse additional context:",
    "[Synapse control]",
  ]
  const marker = trustMarkers
    .map((value) => ({ value, index: text.indexOf(value) }))
    .filter((item) => item.index >= 0)
    .sort((left, right) => left.index - right.index)[0]
  if (!marker) return undefined
  const context = text.slice(marker.index + marker.value.length).trim()
  const cerebroIndex = context.indexOf("[Cerebro]")
  if (cerebroIndex < 0) return undefined
  const receipt = context.slice(cerebroIndex).trim()
  if (!receipt) return undefined
  const operationIds = uniqueOperationIds(receipt)
  return { text: receipt, ...(operationIds.length ? { operationIds } : {}) }
}

function uniqueOperationIds(text: string): string[] {
  const seen = new Set<string>()
  for (const match of text.matchAll(/\boperationId=([^\s，）,；;]+)/g)) {
    const value = match[1]?.trim()
    if (!value || value.length > 256 || seen.has(value)) continue
    seen.add(value)
    if (seen.size >= 16) break
  }
  return [...seen]
}

function isCodexMainThreadSessionMeta(payload: Record<string, unknown>): boolean {
  const hasThreadShape = "thread_source" in payload || "source" in payload || "parent_thread_id" in payload
  if (!hasThreadShape) return true
  if (payload["thread_source"] !== "user") return false
  if (payload["source"] !== "cli" && payload["source"] !== "exec") return false
  return !stringValue(payload["parent_thread_id"], payload["parentThreadId"])
}

function stringValue(...values: unknown[]): string | undefined {
  return values.find((value): value is string => typeof value === "string" && value.trim().length > 0)?.trim()
}

function samePath(left: string, right: string): boolean {
  return left.replace(/[\\/]+$/, "") === right.replace(/[\\/]+$/, "")
}

function normalizeRole(value: unknown): NormalizedMessage["role"] | undefined {
  if (value === "user") return "user"
  if (value === "assistant" || value === "gemini") return "assistant"
  return undefined
}

function textFromValue(value: unknown, opts: { textPartsOnly?: boolean } = {}): string {
  if (typeof value === "string") return value.trim()
  if (Array.isArray(value)) {
    return value.map((item) => textFromValue(item, opts)).filter(Boolean).join(" ").trim()
  }
  if (!isRecord(value)) return ""
  const record = asRecord(value)
  const type = typeof record["type"] === "string" ? record["type"] : ""
  if ([
    "tool_use",
    "tool_result",
    "functionCall",
    "functionResponse",
    "function_call",
    "function_response",
  ].includes(type)) return ""
  if (opts.textPartsOnly && type && type !== "text") return ""
  for (const key of ["text", "content", "parts"]) {
    const text = textFromValue(record[key], opts)
    if (text) return text
  }
  return ""
}

const INJECTED_USER_CONTEXT_MARKERS = [
  "<hook_context>",
  "Synapse additional context:",
  "[Synapse additional context]",
  "[Synapse control]",
]

/** Prevent Synapse's own injected knowledge from being re-sedimented as user input. */
function stripInjectedUserContext(value: string): string {
  let end = value.length
  for (const marker of INJECTED_USER_CONTEXT_MARKERS) {
    const index = value.indexOf(marker)
    if (index >= 0 && index < end) end = index
  }
  return value.slice(0, end).trim()
}

function asRecord(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {}
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

function ensureTrailingNewline(value: string): string {
  return value.endsWith("\n") ? value : `${value}\n`
}
