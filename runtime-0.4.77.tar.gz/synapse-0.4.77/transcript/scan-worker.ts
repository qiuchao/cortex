import { parentPort } from "node:worker_threads"
import { buildDirectoryManifest } from "./directories.ts"
import { scanOnce } from "./scanner.ts"
import { uploadRecords } from "./upload.ts"
import { createHttpUploader } from "./uploaders/http.ts"
import type { CursorStore } from "./cursor.ts"
import type { ScanWorkerRequest, ScanWorkerResponse } from "./scan-worker-contract.ts"

if (!parentPort) throw new Error("transcript scan worker requires parentPort")
const port = parentPort

port.on("message", (request: ScanWorkerRequest) => {
  void handleRequest(request)
})

async function handleRequest(request: ScanWorkerRequest): Promise<void> {
  let response: ScanWorkerResponse
  try {
    if (request.kind === "manifest") {
      const result = buildDirectoryManifest(request.payload)
      response = {
        id: request.id,
        ok: true,
        kind: "manifest",
        result: {
          ...result,
          projectPathByFile: [...result.projectPathByFile.entries()],
        },
      }
    } else {
      const data = { ...request.payload.cursors }
      const cursors: CursorStore = {
        get: (path) => data[path],
        set: (path, cursor) => {
          data[path] = cursor
        },
        all: () => ({ ...data }),
        save: () => undefined,
      }
      const result = scanOnce({
        configs: request.payload.configs,
        home: request.payload.home,
        codexHome: request.payload.codexHome,
        cursors,
        userId: request.payload.userId,
        minAgeMs: request.payload.minAgeMs,
        allowlist: request.payload.allowlist,
        enabledProjectPaths: request.payload.enabledProjectPaths
          ? new Set(request.payload.enabledProjectPaths)
          : undefined,
        projectPathByFile: request.payload.projectPathByFile
          ? new Map(request.payload.projectPathByFile)
          : undefined,
        stageCursorUpdates: request.payload.stageCursorUpdates,
        now: () => request.payload.nowMs,
      })
      if (request.kind === "scan-upload") {
        const upload = await uploadRecords(result.records, createHttpUploader(request.payload.env, {
          onBatchComplete: () => port.postMessage({ id: request.id, kind: "progress" }),
        }))
        response = {
          id: request.id,
          ok: true,
          kind: "scan-upload",
          result: {
            scanned: result.records.length,
            cursorUpdates: result.cursorUpdates,
            upload,
          },
        }
      } else {
        response = { id: request.id, ok: true, kind: "scan", result }
      }
    }
  } catch (error) {
    response = {
      id: request.id,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
  port.postMessage(response)
}
