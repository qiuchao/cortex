/**
 * runtime/watchdog.ts —— 工作台幂等看管(方案 §3 Phase 6 / spec §61,§103-104)。
 *
 * 工作台(box A)是运行时的**安装器 + 看管者 + GUI 客户端,非宿主**(Docker Desktop 模型):
 *   - 启动时幂等确保运行时在跑(已在跑 → no-op);
 *   - **关窗口不杀运行时**(生命周期独立于 GUI —— 技术岗大概率不开 GUI);
 *   - 崩溃自动重启由此看管逻辑负责。
 *
 * ensureRunning() 是幂等原语:OS 自启与工作台**都调它**(方案 R4c)。
 */
import { spawn } from "node:child_process"
import { fileURLToPath } from "node:url"
import { isRunning } from "./lifecycle.ts"

/** synapse CLI 入口(用它 spawn 一个独立的常驻进程)。 */
const BIN = fileURLToPath(new URL("../bin/synapse.mjs", import.meta.url))

export interface EnsureRunningResult {
  action: "already-running" | "started"
  pid?: number
}

/**
 * 幂等确保运行时在跑。
 *   - 已在跑 → no-op(工作台重复调用安全)。
 *   - 未在跑 → detached spawn 一个独立常驻进程(关工作台不影响它)。
 *
 * @param env 传给判定与子进程的环境(测试可注入 XDG_* 隔离)
 */
export function ensureRunning(env: NodeJS.ProcessEnv = process.env): EnsureRunningResult {
  if (isRunning(env)) return { action: "already-running" }

  // detached:脱离父进程(工作台)存活 —— 关 GUI 不杀运行时
  const child = spawn(process.execPath, [BIN, "runtime", "start"], {
    detached: true,
    stdio: "ignore",
    env,
  })
  child.unref()
  return { action: "started", pid: child.pid }
}
