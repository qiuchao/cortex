/**
 * core/done-contract.ts —— done 契约 = 约定产出物存在性核验(确定性,零 LLM 判断)。
 *
 * 方案 §1 原则 4 / spec §93-95:done 不是 AI/人判断质量,而是"约定的产出物有没有"。
 * 契约随任务下发,daemon 机械核验。
 *
 * 🔴 R4d fail-closed:契约**缺失 / 非法** = 不能声称 done(返回 done:false + reason)。
 *    无有效契约就无法确定性核验 → 默认拒绝声称完成,除非显式 opt-out。
 */
import { existsSync } from "node:fs"
import { isAbsolute, resolve } from "node:path"
import { z } from "zod"

/** 单个期望产出物。Phase 2 先支持文件路径存在性;sha/资产id 留待接主脑资产库。 */
export const ExpectedArtifact = z.object({
  /** 产出物类型:目前只实现 path(文件/目录存在性) */
  kind: z.literal("path").default("path"),
  /** 相对 cwd 或绝对路径 */
  path: z.string().min(1),
})
export type ExpectedArtifact = z.infer<typeof ExpectedArtifact>

export const DoneContract = z.object({
  expected_artifacts: z.array(ExpectedArtifact).default([]),
  /** 显式 opt-out:承认此任务无确定性产出物,跳过 done 核验(非默认) */
  opt_out: z.boolean().optional(),
}).superRefine((contract, ctx) => {
  if (!contract.opt_out && contract.expected_artifacts.length === 0) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["expected_artifacts"], message: "at least one artifact is required unless opt_out is true" })
  }
})
export type DoneContract = z.infer<typeof DoneContract>

export interface VerifyDoneResult {
  done: boolean
  /** 逐产出物核验明细(供上报/诊断) */
  checked: Array<{ path: string; exists: boolean }>
  /** fail-closed / opt-out 等非常规路径的原因 */
  reason?: "no_contract" | "invalid_contract" | "opt_out" | "missing_artifacts" | "ok"
}

/**
 * 确定性核验 done。
 *
 * @param rawContract 任务下发的契约(可能缺失/非法 —— 那就是 fail-closed 的触发点)
 * @param cwd 相对路径的基准目录
 */
export function verifyDone(rawContract: unknown, cwd: string): VerifyDoneResult {
  // 契约缺失 → fail-closed(方案 R4d)
  if (rawContract === undefined || rawContract === null) {
    return { done: false, checked: [], reason: "no_contract" }
  }

  const parsed = DoneContract.safeParse(rawContract)
  if (!parsed.success) {
    // 契约非法 → 同样 fail-closed(不能拿坏契约声称完成)
    return { done: false, checked: [], reason: "invalid_contract" }
  }

  const contract = parsed.data

  // 显式 opt-out:承认无确定性产出物(非默认路径,必须主动声明)
  if (contract.opt_out) {
    return { done: true, checked: [], reason: "opt_out" }
  }

  const base = cwd && isAbsolute(cwd) ? cwd : process.cwd()
  const checked = contract.expected_artifacts.map((a) => {
    const full = isAbsolute(a.path) ? a.path : resolve(base, a.path)
    return { path: a.path, exists: existsSync(full) }
  })

  const allExist = checked.every((c) => c.exists)
  return {
    done: allExist,
    checked,
    reason: allExist ? "ok" : "missing_artifacts",
  }
}
