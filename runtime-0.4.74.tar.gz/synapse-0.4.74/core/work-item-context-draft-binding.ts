import { requiresTaskCapabilityContextBinding, taskCapabilityWriteTarget, type TaskCapabilityWriteCommand } from "@cerebro/wire"
import {
  createWorkItemContextReceipt,
  readWorkItemContextDocuments,
  readWorkItemContextPage,
  validateWorkItemContextReceipt,
} from "../transport/brain-contract-align.ts"
import type { TaskDraftLifecycle } from "./task-draft-lifecycle.ts"
import { stableUuidV4 } from "./stable-uuid.ts"
import {
  loadWorkItemContexts,
  type LoadWorkItemContextsResult,
  type WorkItemContextLoaderPort,
} from "./work-item-context-loader.ts"

export interface WorkItemDraftBinding {
  contextReceiptId: string
  contextTargetPublicId: string
}

export interface WorkItemDraftTrustBinding {
  contextReceiptId: string | null
  contextTargetPublicId: string | null
}

export interface WorkItemDraftContext {
  binding: WorkItemDraftBinding
  loaded: LoadWorkItemContextsResult
}

export interface WorkItemDraftContextDeps {
  load?: typeof loadWorkItemContexts
  port?: WorkItemContextLoaderPort
  validate?: typeof validateWorkItemContextReceipt
}

export function createWorkItemDraftContext(
  env: NodeJS.ProcessEnv = process.env,
  deps: WorkItemDraftContextDeps = {},
) {
  const port = deps.port ?? brainWorkItemContextLoaderPort(env)
  const load = deps.load ?? loadWorkItemContexts
  const validate = deps.validate ?? ((input) => validateWorkItemContextReceipt(input, env))
  const loadedByRequest = new Map<string, Promise<WorkItemDraftContext>>()

  return {
    async load(input: {
      command: TaskCapabilityWriteCommand
      payload: Record<string, unknown>
      taskGoal: string
      requestId: string
    }): Promise<WorkItemDraftContext | undefined> {
      if (!requiresTaskCapabilityContextBinding(input.command, input.payload)) return undefined
      const target = taskCapabilityWriteTarget(input.command, input.payload)
      if (!target) throw new Error("工作项写入缺少唯一上下文目标")
      const cacheKey = `${input.requestId}\0${target}`
      const existing = loadedByRequest.get(cacheKey)
      if (existing) return existing
      const pending = (async (): Promise<WorkItemDraftContext> => {
        const loaded = await load({
          publicIds: [target],
          taskGoal: input.taskGoal,
          requestId: stableReceiptRequestId(input.requestId, target),
        }, port)
        if (loaded.blocked || !loaded.contextReceiptId) throw new Error(renderBlockedContext(loaded, target))
        return {
          binding: {
            contextReceiptId: loaded.contextReceiptId,
            contextTargetPublicId: target,
          },
          loaded,
        }
      })()
      loadedByRequest.set(cacheKey, pending)
      while (loadedByRequest.size > 1_000) loadedByRequest.delete(loadedByRequest.keys().next().value!)
      try {
        return await pending
      } catch (error) {
        if (loadedByRequest.get(cacheKey) === pending) loadedByRequest.delete(cacheKey)
        throw error
      }
    },

    async assertConfirmable(
      lifecycle: TaskDraftLifecycle,
      input: {
        productionId: string
        draftId: string
        requestId: string
        command: TaskCapabilityWriteCommand
        binding: WorkItemDraftTrustBinding
      },
    ): Promise<void> {
      const current = await lifecycle.get(input.productionId, input.draftId)
      if (current.id !== input.draftId || current.requestId !== input.requestId || current.command !== input.command) {
        throw new Error("服务端操作与本地可信引用不一致，未执行写入")
      }
      if (current.contextReceiptId !== input.binding.contextReceiptId
        || current.contextTargetPublicId !== input.binding.contextTargetPublicId) {
        throw new Error("服务端操作的上下文绑定与本地可信引用不一致，未执行写入")
      }
      const payload = current.payload && typeof current.payload === "object" && !Array.isArray(current.payload)
        ? current.payload
        : {}
      if (!requiresTaskCapabilityContextBinding(input.command, payload)) {
        if (input.binding.contextReceiptId !== null || input.binding.contextTargetPublicId !== null) {
          throw new Error("服务端操作包含不应存在的上下文绑定，未执行写入")
        }
        return
      }
      const target = taskCapabilityWriteTarget(input.command, payload)
      if (!target || !input.binding.contextReceiptId || input.binding.contextTargetPublicId !== target
        || !current.contextReceiptId || current.contextTargetPublicId !== target) {
        throw new Error("服务端操作缺少可校验的上下文读取回执，未执行写入")
      }
      const pendingExpected = loadedByRequest.get(`${input.requestId}\0${target}`)
      const expected = pendingExpected ? (await pendingExpected).binding : undefined
      if (expected && (current.contextReceiptId !== expected.contextReceiptId
        || current.contextTargetPublicId !== expected.contextTargetPublicId)) {
        throw new Error("服务端操作的上下文绑定与本次可信读取依据不一致，未执行写入")
      }
      const result = await validate({ contextReceiptId: current.contextReceiptId })
      if (!result.ok) throw new Error("发布前上下文校验失败，未执行写入；请稍后重试确认或刷新上下文")
      if (result.value.contextReceiptId !== current.contextReceiptId) {
        throw new Error("发布前上下文校验回执不匹配，未执行写入；请重新加载工作项")
      }
      if (result.value.status === "refresh_required") {
        throw new Error(`处理依据已变化，未执行写入：${result.value.message}；请重新加载工作项并生成新的操作`)
      }
    },
  }
}

export function commentRevision(
  context: WorkItemDraftContext,
  targetPublicId: string,
  commentId: string,
): number | undefined {
  return context.loaded.inventories
    .find((inventory) => inventory.targetPublicId === targetPublicId)
    ?.comments.find((comment) => comment.sourcePublicId === targetPublicId
      && comment.commentId.toLowerCase() === commentId.toLowerCase()
      && comment.deletedAt === null
      && comment.capabilities.canDelete)?.revision
}

export function relationSetVersion(context: WorkItemDraftContext, bugId: string): number | undefined {
  return context.loaded.inventories
    .find((inventory) => inventory.targetPublicId === bugId)
    ?.overview?.relation?.relationSetVersion
}

function brainWorkItemContextLoaderPort(env: NodeJS.ProcessEnv): WorkItemContextLoaderPort {
  const failure = (result: { reason: string; message: string; httpStatus?: number }) => ({
    ok: false as const,
    code: result.reason,
    message: result.message,
    retryable: result.httpStatus === undefined || result.httpStatus >= 500,
  })
  return {
    async readPage(input, signal) {
      const result = await readWorkItemContextPage(input, env, signal)
      return result.ok ? { ok: true, results: result.value.results } : failure(result)
    },
    async readDocuments(input, signal) {
      const result = await readWorkItemContextDocuments(input, env, signal)
      return result.ok ? { ok: true, documents: result.value.results } : failure(result)
    },
    async createReceipt(input, signal) {
      const result = await createWorkItemContextReceipt(input, env, signal)
      return result.ok ? { ok: true, receipt: result.value } : failure(result)
    },
    async validateReceipt(input, signal) {
      const result = await validateWorkItemContextReceipt(input, env, signal)
      return result.ok ? { ok: true, validation: result.value } : failure(result)
    },
  }
}

function stableReceiptRequestId(requestId: string, target: string): string {
  return stableUuidV4("work-item-context-receipt", requestId, target)
}

function renderBlockedContext(result: LoadWorkItemContextsResult, target: string): string {
  const missing = result.issues
    .filter((issue) => issue.missing.blocking && !issue.acknowledged && !issue.supplemented)
    .map((issue) => issue.missing.key)
  return missing.length > 0
    ? `工作项 ${target} 的上下文尚不完整，未创建写入操作；缺失：${missing.join("、")}`
    : `工作项 ${target} 的上下文读取回执未能校验，未创建写入操作`
}
