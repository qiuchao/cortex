import { readFileSync, statSync } from "node:fs"
import { dirname, join, parse, resolve } from "node:path"

const PROTECTED_BRANCHES = new Set(["main", "master", "develop", "trunk"])

function findGitEntry(cwd) {
  let current = resolve(cwd)
  const root = parse(current).root

  while (true) {
    const entry = join(current, ".git")
    try {
      statSync(entry)
      return entry
    } catch (error) {
      if (error?.code !== "ENOENT") throw error
      if (current === root) return undefined
      current = dirname(current)
    }
  }
}

function resolveGitDir(gitEntry) {
  const stat = statSync(gitEntry)
  if (stat.isDirectory()) return gitEntry
  if (!stat.isFile()) throw new Error(`unsupported .git entry: ${gitEntry}`)

  const match = /^gitdir:\s*(.+)\s*$/i.exec(readFileSync(gitEntry, "utf8"))
  if (!match) throw new Error(`invalid .git pointer: ${gitEntry}`)
  return resolve(dirname(gitEntry), match[1])
}

/** Read branch state directly from Git metadata without spawning git. */
export function readBranchState(cwd) {
  try {
    const gitEntry = findGitEntry(cwd)
    if (!gitEntry) return { state: "not-repo" }
    const gitDir = resolveGitDir(gitEntry)
    const head = readFileSync(join(gitDir, "HEAD"), "utf8").trim()
    const prefix = "ref: refs/heads/"
    return head.startsWith(prefix)
      ? { state: "branch", branch: head.slice(prefix.length) }
      : { state: "detached" }
  } catch (error) {
    return { state: "error", message: error instanceof Error ? error.message : String(error) }
  }
}

/** Compatibility helper for callers that only need the branch name. */
export function readCurrentBranch(cwd) {
  const result = readBranchState(cwd)
  return result.state === "branch" ? result.branch : undefined
}

export function isProtectedBranch(branch) {
  return Boolean(
    branch &&
      (PROTECTED_BRANCHES.has(branch) ||
        branch.startsWith("release/") ||
        branch.startsWith("hotfix/")),
  )
}
