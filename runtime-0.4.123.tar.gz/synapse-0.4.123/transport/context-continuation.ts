import { createHash } from "node:crypto"
import {
  CONTEXT_CONTINUATION_PATH,
  ContextContinuationRequestSchema,
  ContextContinuationResponseSchema,
  type ContextContinuationRequest,
  type ContextContinuationResponse,
} from "@cerebro/wire"
import { getBrainConfig } from "./brain-config.ts"

export type ContextContinuationResult =
  | { ok: true; value: ContextContinuationResponse }
  | { ok: false; reason: "transport_unavailable" | "invalid_input" | "kh_returned_error"; message: string; httpStatus?: number }

/** Send one complete current turn to Cerebro's receipt coordinator. */
export async function continueWorkItemContext(
  input: ContextContinuationRequest,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<ContextContinuationResult> {
  const parsed = ContextContinuationRequestSchema.safeParse(input)
  if (!parsed.success) return { ok: false, reason: "invalid_input", message: "context continuation request failed shared wire schema validation" }
  const cfg = getBrainConfig(env)
  if (!cfg?.machineToken) return { ok: false, reason: "transport_unavailable", message: "brain not configured" }
  const timeout = AbortSignal.timeout(cfg.timeoutMs)
  const requestSignal = signal ? AbortSignal.any([signal, timeout]) : timeout
  try {
    const response = await fetch(`${cfg.brainBaseUrl}${CONTEXT_CONTINUATION_PATH}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.machineToken}`,
      },
      body: JSON.stringify(parsed.data),
      signal: requestSignal,
    })
    const payload = await response.json().catch(() => undefined)
    if (!response.ok) {
      return { ok: false, reason: "kh_returned_error", message: "context continuation request was rejected", httpStatus: response.status }
    }
    requestSignal.throwIfAborted()
    const output = ContextContinuationResponseSchema.safeParse(payload)
    if (!output.success || !contextContinuationMatchesRequest(parsed.data, output.data)) {
      return { ok: false, reason: "kh_returned_error", message: "context continuation response did not match the current event" }
    }
    return { ok: true, value: output.data }
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? error
    return { ok: false, reason: "kh_returned_error", message: "context continuation transport unavailable" }
  }
}

/** Success may carry authority only for the exact event the runtime submitted. */
export function contextContinuationMatchesRequest(
  request: ContextContinuationRequest,
  response: ContextContinuationResponse,
): boolean {
  const binding = response.binding
  if (binding && (binding.version !== request.binding.version
    || binding.machineId !== request.binding.machineId
    || binding.client !== request.binding.client
    || binding.sessionId !== request.binding.sessionId
    || binding.currentTurnId !== request.binding.currentTurnId
    || binding.textVersion !== request.binding.textVersion
    || (request.binding.contextReceiptId && binding.contextReceiptId !== request.binding.contextReceiptId))) return false
  const hash = createHash("sha256").update(request.userInput, "utf8").digest("hex")
  if (response.status === "not_applicable" && (!binding || response.inputHash !== hash)) return false
  if (response.inputHash && response.inputHash !== hash) return false
  // `not_applicable` is the only neutral result. It intentionally has no
  // requestId because no receipt action was claimed; it still must carry the
  // exact binding and hash before the caller may resume ordinary processing.
  const hasAuthority = !["clarify", "blocked", "not_applicable"].includes(response.status)
  return !hasAuthority || Boolean(binding && response.inputHash === hash && response.requestId)
}
