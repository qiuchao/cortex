import { parseLiteralShellWords } from "./safe-json-pipeline.ts"

export interface CapabilityCommandInspection {
  kind: "capability" | "none" | "unsupported"
  reason?: string
  commands?: string[][]
}

type PreparedShell = string | (CapabilityCommandInspection & { safePrefix?: string })

const NONE: CapabilityCommandInspection = { kind: "none" }
const CAPABILITY: CapabilityCommandInspection = { kind: "capability" }
const capabilityNames = new Set([
  "agent", "search", "remember", "recent", "get", "add", "update", "flag", "delete",
  "promote", "demote", "mem-get", "mem-set", "pref-set",
])
const unsupported = (reason: string): CapabilityCommandInspection => ({ kind: "unsupported", reason })
const basename = (word: string): string => word.split(/[\\/]/).pop()!.toLowerCase()

/** Structural inspection of literal shell commands, not arbitrary program analysis. */
export function inspectCapabilityCommand(command: string, powershell = false): CapabilityCommandInspection {
  return inspect(command, powershell, 0)
}

function inspect(command: string, powershell: boolean, depth: number): CapabilityCommandInspection {
  if (depth > 12 || command.length > 256 * 1024) return unsupported("Shell inspection limit exceeded")
  const hereStrings = powershell ? stripPowerShellHereStrings(command) : command
  if (typeof hereStrings !== "string") return inspectSafePrefix(hereStrings, powershell, depth)
  const stripped = stripHeredocs(hereStrings, powershell)
  if (typeof stripped !== "string") return inspectSafePrefix(stripped, powershell, depth)
  command = stripped
  const segments: string[] = []
  let segment = ""
  let quote: "'" | '"' | undefined
  let result = NONE
  const commands: string[][] = []
  const merge = (next: CapabilityCommandInspection): void => {
    commands.push(...next.commands ?? [])
    if (next.kind === "capability" || result.kind === "none") result = next
  }
  const finish = (failure?: CapabilityCommandInspection): CapabilityCommandInspection => {
    if (failure) merge(failure)
    for (const part of segments) merge(inspectSimple(part.trim(), powershell, depth))
    return { ...result, commands }
  }
  for (let i = 0; i < command.length; i++) {
    const char = command[i]!
    if (quote === "'") {
      segment += char
      if (char === "'" && powershell && command[i + 1] === "'") segment += command[++i]
      else if (char === "'") quote = undefined
      continue
    }
    if ((char === "\\" && !powershell || char === "`" && powershell) && command[i + 1]) {
      if (command[i + 1] === "\n") { i++; continue }
      segment += char + command[++i]
      continue
    }
    if (char === "$" && command[i + 1] === "(") {
      const substitution = readSubstitution(command, i + 2, powershell)
      if (!substitution) return finish(unsupported("Unterminated or unsupported command substitution"))
      merge(inspect(substitution.body, powershell, depth + 1))
      segment += "dynamic_substitution"
      i = substitution.end
      continue
    }
    if (quote === '"') {
      segment += char
      if (char === '"') quote = undefined
      continue
    }
    if (char === "'" || char === '"') {
      segment += char
      quote = char
      continue
    }
    if (char === "#" && (!segment || /\s$/.test(segment))) {
      while (i < command.length && command[i] !== "\n") i++
      segments.push(segment)
      segment = ""
      continue
    }
    if (char === "&" && powershell && !segment.trim() && /[\s'"$]/.test(command[i + 1] ?? "")) {
      segment += "& "
      continue
    }
    if (char === ">" || char === "<") {
      const redirect = readRedirect(command, i, powershell)
      if (!redirect) {
        merge(unsupported("Unsupported redirection"))
        segment += char
      } else {
        const operandInspection = inspect(`__redirect_operand__ ${redirect.operand}`, powershell, depth + 1)
        merge({ ...operandInspection, commands: operandInspection.commands?.filter((argv) => argv[0] !== "__redirect_operand__") })
        segment = segment.replace(/(^|\s)\d+$/, "$1")
        segment += " "
        i = redirect.end
      }
      continue
    }
    if (!powershell && (char === "(" || char === ")")) {
      segments.push(segment)
      segment = ""
      continue
    }
    if (char === ";" || char === "|" || char === "&" || char === "\n" || char === "\r") {
      segments.push(segment)
      segment = ""
      if (command[i + 1] === char) i++
      continue
    }
    segment += char
  }
  if (quote) return finish(unsupported("Unterminated shell quote"))
  segments.push(segment)
  return finish()
}

function inspectSimple(command: string, powershell: boolean, depth: number): CapabilityCommandInspection {
  if (!command) return NONE
  if (!powershell) {
    const control = command.match(/^(?:if|then|elif|else|while|until|do)\s+(.+)$/s)
    if (control) return inspectSimple(control[1]!, false, depth)
    if (/^(?:fi|done|then|else|do)$/.test(command)) return NONE
  }
  const called = powershell && /^&/.test(command)
  if (called) command = command.replace(/^&\s*/, "")
  const literal = parseInspectableWords(command, powershell)
  if (!literal) return unsupported("Shell expansions, redirects, or control syntax are outside literal command inspection")
  if (powershell && !called && literal[0]?.fullyQuoted) return NONE
  const words = literal.map((word) => word.value)
  let index = 0
  while (!powershell && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[index] ?? "")) index++
  for (let wrappers = 0; wrappers < 12; wrappers++) {
    const executable = basename(words[index] ?? "")
    if (/^(?:command|exec|nohup)(?:\.exe)?$/.test(executable)) {
      index++
      if (words[index] === "--") index++
      else if (words[index]?.startsWith("-")) return unsupported("Unsupported execution wrapper option")
      continue
    }
    if (/^(?:env|sudo)(?:\.exe)?$/.test(executable)) {
      index++
      while (index < words.length) {
        const option = words[index]!
        if (option === "--") { index++; break }
        if (executable === "env" && /^[A-Za-z_][A-Za-z0-9_]*=/.test(option)) { index++; continue }
        if (["-i", "--ignore-environment", "-n", "-E", "-H"].includes(option)) { index++; continue }
        if (["-u", "--unset", "-C", "--chdir", "-g", "--group", "--user"].includes(option)) { index += 2; continue }
        if (option.startsWith("-")) return unsupported("Unsupported env/sudo option")
        break
      }
      continue
    }
    if (/^(?:npx|bunx)(?:\.cmd|\.exe)?$/.test(executable)) {
      index++
      while (["--yes", "-y", "--no-install", "--"].includes(words[index] ?? "")) index++
      if (words[index]?.startsWith("-")) return unsupported("Unsupported package runner option")
      continue
    }
    if (/^(?:pnpm|yarn)(?:\.cmd|\.exe)?$/.test(executable) && words[index + 1] === "dlx") { index += 2; continue }
    if (/^(?:sh|bash|dash|zsh)(?:\.exe)?$/.test(executable)) {
      if (/^-[a-z]*c[a-z]*$/.test(words[index + 1] ?? "") && words[index + 2] !== undefined) {
        return inspect(words[index + 2]!, false, depth + 1)
      }
      return unsupported("Shell script contents are not inspected")
    }
    if (/^(?:pwsh|powershell)(?:\.exe)?$/.test(executable)) {
      while (/^-(?:NoProfile|NoLogo|NonInteractive)$/i.test(words[index + 1] ?? "")) index++
      if (/^-(?:command|c)$/i.test(words[index + 1] ?? "") && words[index + 2] !== undefined) {
        // A quoted -Command string is shell source. Separate literal argv can
        // be reconstructed with quotes so their arguments stay data.
        const source = words.length === index + 3 ? words[index + 2]!
          : words.slice(index + 2).map((word, offset) => offset === 0 ? word : "'" + word.replace(/'/g, "''") + "'").join(" ")
        return inspect(source, true, depth + 1)
      }
      return unsupported("PowerShell script or options are outside literal command inspection")
    }
    if (/^(?:node|nodejs)(?:\.exe)?$/.test(executable)) {
      const launcherIndex = index
      index++
      while (["--experimental-strip-types", "--no-warnings"].includes(words[index] ?? "")) index++
      if (words[index] === "--") index++
      if (words[index]?.startsWith("-")) return { ...unsupported("Interpreter options or inline code are not inspected"), commands: [words.slice(launcherIndex)] }
      if (basename(words[index] ?? "") !== "synapse.mjs") return { ...NONE, commands: [words.slice(launcherIndex)] }
    }
    if (/^(?:if|then|elif|else|fi|for|while|until|do|done|case|function|eval|source|\.)$/.test(executable)) {
      return unsupported("Shell control flow or dynamic execution is not inspected")
    }
    const kind = /^synapse(?:\.mjs|\.cmd|\.exe)?$/.test(basename(words[index] ?? ""))
      && capabilityNames.has(words[index + 1]?.toLowerCase() ?? "") ? CAPABILITY : NONE
    return { ...(kind.kind === "none" && !powershell && command.includes("`")
      ? unsupported("Backtick substitutions are not inspected") : kind), commands: [words.slice(index)] }
  }
  return unsupported("Execution wrapper nesting limit exceeded")
}

function readSubstitution(command: string, start: number, powershell = false): { body: string; end: number } | undefined {
  let level = 1
  let quote: string | undefined
  for (let i = start; i < command.length; i++) {
    const char = command[i]!
    if ((char === "\\" && !powershell || char === "`" && powershell) && quote !== "'") { i++; continue }
    if (quote) {
      if (char === quote) {
        if (powershell && quote === "'" && command[i + 1] === "'") i++
        else quote = undefined
      }
      continue
    }
    if (char === "'" || char === '"') { quote = char; continue }
    if (char === "(") level++
    if (char === ")" && --level === 0) return { body: command.slice(start, i), end: i }
  }
  return undefined
}

/** Strip only an unambiguous literal heredoc; never scan its data as commands. */
function stripHeredocs(command: string, powershell: boolean): PreparedShell {
  if (!command.includes("<<")) return command
  const lines = command.split("\n")
  const output: string[] = []
  let shellQuote: string | undefined
  const fail = (reason: string, prefix = ""): Exclude<PreparedShell, string> => ({
    ...unsupported(reason), safePrefix: [...output, prefix].join("\n"),
  })
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!
    // Find the operator outside quotes before matching its literal delimiter.
    let heredocAt = -1
    let headerQuote = shellQuote
    for (let j = 0; j < line.length; j++) {
      const char = line[j]!
      if (char === "\\" && headerQuote !== "'") { j++; continue }
      if (headerQuote) { if (char === headerQuote) headerQuote = undefined; continue }
      if (char === "'" || char === '"') { headerQuote = char; continue }
      if (char === "#" && (j === 0 || /\s/.test(line[j - 1]!))) break
      if (line.slice(j, j + 2) === "<<") { heredocAt = j; break }
    }
    const match = heredocAt < 0 ? null : line.slice(heredocAt).match(/^<<(-?)\s*(?:'([A-Za-z_]\w*)'|"([A-Za-z_]\w*)"|([A-Za-z_]\w*))\s*(.*)$/)
    if (!match) {
      for (let j = 0; j < line.length; j++) {
        const char = line[j]!
        if (char === "\\" && shellQuote !== "'") { j++; continue }
        if (shellQuote) { if (char === shellQuote) shellQuote = undefined; continue }
        if (char === "'" || char === '"') { shellQuote = char; continue }
        if (char === "#" && (j === 0 || /\s/.test(line[j - 1]!))) break
        if (line.slice(j, j + 2) === "<<") return fail("Unsupported heredoc or here-string header", line.slice(0, j))
      }
      output.push(line)
      continue
    }
    const delimiter = match[2] ?? match[3] ?? match[4]!
    const tail = match[5]!
    if (tail && !/^[|;&<>\d]/.test(tail)) return fail("Unsupported heredoc header", line.slice(0, heredocAt))
    output.push(`${line.slice(0, heredocAt)} ${tail}`)
    let terminated = false
    while (++i < lines.length) {
      const body = lines[i]!.replace(/\r$/, "")
      if ((match[1] ? body.replace(/^\t+/, "") : body) === delimiter) { terminated = true; break }
      // Unquoted heredocs can execute substitutions; do not claim their body
      // is inert, and do not interpret its plain text as commands.
      if (match[4]) {
        if (body.includes("`")) return fail("Backtick heredoc substitutions are not inspected")
        for (let offset = 0; offset < body.length; offset++) {
          if (body[offset] === "\\") { offset++; continue }
          if (body.slice(offset, offset + 2) !== "$(") continue
          const substitution = readSubstitution(body, offset + 2)
          if (!substitution) return fail("Multiline heredoc substitutions are not inspected")
          output.push(substitution.body)
          offset = substitution.end
        }
      }
    }
    if (!terminated) return fail("Unterminated heredoc")
  }
  return output.join("\n")
}

function readRedirect(command: string, start: number, powershell: boolean): { end: number; operand: string } | undefined {
  let i = start + 1
  while (command[i] === command[start]) i++
  if (command[i] === "&") i++
  while (/[ \t]/.test(command[i] ?? "") && i < command.length) i++
  const operandStart = i
  let quote: string | undefined
  for (; i < command.length; i++) {
    const char = command[i]!
    if ((char === "\\" && !powershell || char === "`" && powershell) && quote !== "'") { i++; continue }
    if (quote !== "'" && char === "$" && command[i + 1] === "(") {
      const substitution = readSubstitution(command, i + 2, powershell)
      if (!substitution) return undefined
      i = substitution.end
      continue
    }
    if (quote) { if (char === quote) quote = undefined; continue }
    if (char === "'" || char === '"') { quote = char; continue }
    if (/[\s;|&<>]/.test(char)) break
  }
  if (quote || i === operandStart) return undefined
  return { end: i - 1, operand: command.slice(operandStart, i) }
}

function stripPowerShellHereStrings(command: string): PreparedShell {
  let quote: string | undefined
  let output = ""
  for (let i = 0; i < command.length; i++) {
    const char = command[i]!
    if (char === "`" && quote !== "'") { output += char + (command[++i] ?? ""); continue }
    if (quote) {
      output += char
      if (char === quote) {
        if (quote === "'" && command[i + 1] === "'") output += command[++i]
        else quote = undefined
      }
      continue
    }
    if (char === "#") {
      while (i < command.length && command[i] !== "\n") output += command[i++]
      output += "\n"
      continue
    }
    if (char === "@" && (command[i + 1] === "'" || command[i + 1] === '"') && /^\r?\n/.test(command.slice(i + 2))) {
      const delimiter = command[i + 1]!
      const bodyStart = command.indexOf("\n", i + 2) + 1
      const terminator = new RegExp("^" + delimiter + "@", "gm")
      terminator.lastIndex = bodyStart
      const end = terminator.exec(command)
      if (!end) return { ...unsupported("Unterminated PowerShell here-string"), safePrefix: output }
      const body = command.slice(bodyStart, end.index)
      if (delimiter === '"' && /\$\(/.test(body)) return { ...unsupported("Expanding PowerShell here-string substitutions are not inspected"), safePrefix: output }
      output += "'literal_here_string'"
      i = end.index + 1
      continue
    }
    if (char === "'" || char === '"') quote = char
    output += char
  }
  return output
}

/** Keep literal executable/verb positions even when other argv are dynamic. */
function parseInspectableWords(command: string, powershell: boolean): ReturnType<typeof parseLiteralShellWords> {
  const direct = parseLiteralShellWords(command, powershell)
  if (direct) return direct
  const words: NonNullable<ReturnType<typeof parseLiteralShellWords>> = []
  let start = 0
  let quote: string | undefined
  const finish = (end: number): boolean => {
    if (end === start) return true
    const token = command.slice(start, end)
    const parsed = parseLiteralShellWords(token, powershell)
    if (parsed) { words.push(...parsed); return true }
    // Only opaque expansion-bearing argv qualify. Structural syntax never
    // becomes a literal command or verb, and program source stays opaque.
    if (!/[$*?`]/.test(token)) return false
    const assignment = token.match(/^[A-Za-z_][A-Za-z0-9_]*=/)?.[0] ?? ""
    words.push({ value: assignment + "__dynamic_shell_argument__", fullyQuoted: false })
    return true
  }
  for (let i = 0; i < command.length; i++) {
    const char = command[i]!
    if ((char === "\\" && !powershell || char === "`" && powershell) && quote !== "'") { i++; continue }
    if (quote) { if (char === quote) quote = undefined; continue }
    if (char === "'" || char === '"') { quote = char; continue }
    if (/\s/.test(char)) {
      if (!finish(i)) return undefined
      start = i + 1
    }
  }
  return !quote && finish(command.length) ? words : undefined
}

function inspectSafePrefix(
  failure: Exclude<PreparedShell, string>, powershell: boolean, depth: number,
): CapabilityCommandInspection {
  if (!failure.safePrefix?.trim()) return unsupported(failure.reason ?? "Unsupported shell body")
  const prefix = inspect(failure.safePrefix, powershell, depth + 1)
  return prefix.kind === "capability" ? prefix : {
    ...unsupported(failure.reason ?? "Unsupported shell body"), commands: prefix.commands,
  }
}
