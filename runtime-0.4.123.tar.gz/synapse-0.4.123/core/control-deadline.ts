/** A bounded control lookup, including dependencies that ignore cancellation. */
export class ControlDeadlineError extends Error {
  constructor() { super("agent control context deadline exceeded") }
}

export async function withControlDeadline<T>(
  load: (signal: AbortSignal) => Promise<T>,
  milliseconds: number,
  parent?: AbortSignal,
): Promise<T> {
  const controller = new AbortController()
  let timer: ReturnType<typeof setTimeout> | undefined
  let rejectAbort!: (reason: unknown) => void
  const aborted = new Promise<never>((_resolve, reject) => { rejectAbort = reject })
  const cancel = (reason: unknown) => {
    controller.abort(reason)
    rejectAbort(reason)
  }
  const onAbort = () => cancel(parent?.reason ?? new Error("control request aborted"))
  parent?.addEventListener("abort", onAbort, { once: true })
  if (parent?.aborted) onAbort()
  timer = setTimeout(() => cancel(new ControlDeadlineError()), milliseconds)
  timer.unref?.()
  try {
    return await Promise.race([
      aborted,
      Promise.resolve().then(() => {
        controller.signal.throwIfAborted()
        return load(controller.signal)
      }),
    ])
  } finally {
    clearTimeout(timer)
    parent?.removeEventListener("abort", onAbort)
  }
}
