/**
 * transcript/upload.ts —— 语料上传(单向、后台、绝不阻塞任何一轮对话;spec §263)。
 *
 * 上传目标是主脑的对话库(按 user_id 聚合)。daemon→brain 协议 out of scope(可逆),
 * 这里定义一个可注入的 uploader 接口:生产接主脑 HTTP,测试注 mock。
 */
import type { TranscriptRecord } from "./scanner.ts"

export type TranscriptUploader = (records: TranscriptRecord[]) => Promise<{ ok: boolean; uploaded: number }>

/** 默认 uploader:占位(brain 协议未接前不真正上传,返回 ok:false 让调用方保守不推进)。 */
export const noopUploader: TranscriptUploader = async () => ({ ok: false, uploaded: 0 })

/**
 * 批量上传;单向、后台。失败不 throw(不阻断),返回 ok:false 由调用方决定是否回退游标。
 */
export async function uploadRecords(
  records: TranscriptRecord[],
  uploader: TranscriptUploader = noopUploader,
): Promise<{ ok: boolean; uploaded: number }> {
  if (records.length === 0) return { ok: true, uploaded: 0 }
  try {
    return await uploader(records)
  } catch {
    return { ok: false, uploaded: 0 }
  }
}
