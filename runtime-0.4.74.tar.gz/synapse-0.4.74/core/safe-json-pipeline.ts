export interface SafeJsonPipeline {
  payload: unknown
  receiver: string
}

export interface LiteralShellWord {
  value: string
  fullyQuoted: boolean
}

export const POWERSHELL_UTF8_PIPELINE_PREFIX = "$OutputEncoding=[Text.UTF8Encoding]::new();"

const UNSAFE_UNQUOTED_SHELL_CHARACTERS = new Set("|;&`\r\n<>()#$*?[]{}~!")

export function safeJsonPipelinePrefix(receiver: string): string {
  return receiver.trimStart().startsWith("& ") ? `${POWERSHELL_UTF8_PIPELINE_PREFIX} ` : ""
}

export function parseSafeJsonPipeline(command: string): SafeJsonPipeline | undefined {
  const value = command.trim()
  const heredoc = parseLiteralHeredocPipeline(value)
  if (heredoc) return heredoc
  const hasPowerShellPrefix = value.startsWith(`${POWERSHELL_UTF8_PIPELINE_PREFIX} `)
  const split = splitPipeline(hasPowerShellPrefix
    ? value.slice(POWERSHELL_UTF8_PIPELINE_PREFIX.length).trimStart()
    : value)
  if (!split) return undefined
  const powershell = split.receiver.startsWith("& ")
  if (powershell !== hasPowerShellPrefix) return undefined
  const words = parseLiteralShellWords(split.producer, powershell)
  if (!words) return undefined

  let payloadWord: LiteralShellWord | undefined
  if (
    words.length === 3
    && words[0]?.value === "printf"
    // JavaScript-based shell tools may decode `\\n` before dispatch, leaving a
    // literal newline inside the still-single-quoted printf format string.
    && (words[1]?.value === "%s" || words[1]?.value === "%s\\n" || words[1]?.value === "%s\n")
    && words[1].fullyQuoted
  ) {
    payloadWord = words[2]
  } else if (
    words.length === 2
    && /^(?:echo(?:\.exe)?|Write-Output)$/i.test(words[0]?.value ?? "")
  ) {
    payloadWord = words[1]
  }
  if (!payloadWord?.fullyQuoted) return undefined

  try {
    const payload = JSON.parse(payloadWord.value) as unknown
    return payload && typeof payload === "object" && !Array.isArray(payload)
      ? { payload, receiver: split.receiver }
      : undefined
  } catch {
    return undefined
  }
}

/**
 * Tokenizes one command without evaluating substitutions, redirects, control
 * operators, or unquoted shell metacharacters. Callers can compare the
 * resulting argv while accepting harmless quoting differences.
 */
export function parseSafeCommandWords(command: string, powershell = false): string[] | undefined {
  let value = command.trim()
  if (powershell) {
    const callOperator = value.match(/^&\s+/)
    if (!callOperator) return undefined
    value = value.slice(callOperator[0].length)
  }
  const words = parseLiteralShellWords(value, powershell)
  return words?.map((word) => word.value)
}

export function parseLiteralShellWords(
  command: string,
  powershell = false,
): LiteralShellWord[] | undefined {
  const words: LiteralShellWord[] = []
  let value = ""
  let active = false
  let hasUnquotedContent = false
  let quote: "single" | "double" | undefined

  const finish = (): void => {
    if (!active) return
    words.push({ value, fullyQuoted: !hasUnquotedContent })
    value = ""
    active = false
    hasUnquotedContent = false
  }

  for (let index = 0; index < command.length; index++) {
    const char = command[index]!
    if (quote === "single") {
      if (char === "'" && powershell && command[index + 1] === "'") {
        value += "'"
        index++
      } else if (char === "'") quote = undefined
      else value += char
      continue
    }
    if (quote === "double") {
      if (char === '"') {
        quote = undefined
        continue
      }
      if (char === "$" || char === "`") return undefined
      if (char === "\\" && !powershell) {
        const next = command[index + 1]
        if (next === '"' || next === "\\") {
          value += next
          index++
        } else {
          value += char
        }
        continue
      }
      value += char
      continue
    }
    if (char === "\r" || char === "\n") return undefined
    if (/\s/.test(char)) {
      finish()
      continue
    }
    active = true
    if (char === "'") {
      quote = "single"
      continue
    }
    if (char === '"') {
      quote = "double"
      continue
    }
    if (char === "\\" && !powershell) {
      const next = command[index + 1]
      if (!next) return undefined
      value += next
      hasUnquotedContent = true
      index++
      continue
    }
    if (UNSAFE_UNQUOTED_SHELL_CHARACTERS.has(char)) return undefined
    value += char
    hasUnquotedContent = true
  }
  if (quote) return undefined
  finish()
  return words
}

function parseLiteralHeredocPipeline(command: string): SafeJsonPipeline | undefined {
  const firstNewline = command.indexOf("\n")
  if (firstNewline < 0) return undefined
  const header = command.slice(0, firstNewline).replace(/\r$/, "")
  const match = header.match(/^cat[ \t]+<<[ \t]*'([A-Za-z_][A-Za-z0-9_]*)'[ \t]*\|[ \t]*(.+)$/)
  if (!match) return undefined

  let bodyAndTerminator = command.slice(firstNewline + 1)
  if (bodyAndTerminator.endsWith("\n")) bodyAndTerminator = bodyAndTerminator.slice(0, -1)
  if (bodyAndTerminator.endsWith("\r")) bodyAndTerminator = bodyAndTerminator.slice(0, -1)
  const terminatorNewline = bodyAndTerminator.lastIndexOf("\n")
  if (terminatorNewline < 0) return undefined
  const terminator = bodyAndTerminator.slice(terminatorNewline + 1).replace(/\r$/, "")
  if (terminator !== match[1]) return undefined

  try {
    const payload = JSON.parse(bodyAndTerminator.slice(0, terminatorNewline)) as unknown
    return payload && typeof payload === "object" && !Array.isArray(payload)
      ? { payload, receiver: match[2]!.trim() }
      : undefined
  } catch {
    return undefined
  }
}

function splitPipeline(command: string): { producer: string; receiver: string } | undefined {
  const value = command.trim()
  if (!value) return undefined
  let quote: "single" | "double" | undefined
  let escaped = false
  let separator = -1

  for (let index = 0; index < value.length; index++) {
    const char = value[index]!
    if (escaped) {
      escaped = false
      continue
    }
    if (quote === "single") {
      if (char === "'") quote = undefined
      continue
    }
    if (quote === "double") {
      if (char === "\\") {
        escaped = true
        continue
      }
      if (char === '"') {
        quote = undefined
        continue
      }
      if (char === "$" || char === "`") return undefined
      continue
    }
    if (char === "'") {
      quote = "single"
      continue
    }
    if (char === '"') {
      quote = "double"
      continue
    }
    if (char === "|") {
      if (separator >= 0 || value[index + 1] === "|") return undefined
      separator = index
      continue
    }
    if (char === "&") {
      const receiverPrefix = separator >= 0 ? value.slice(separator + 1, index).trim() : ""
      if (separator >= 0 && receiverPrefix === "" && /\s/.test(value[index + 1] ?? "")) continue
      return undefined
    }
    if (UNSAFE_UNQUOTED_SHELL_CHARACTERS.has(char)) return undefined
  }
  if (quote || escaped || separator < 0) return undefined
  const producer = value.slice(0, separator).trim()
  const receiver = value.slice(separator + 1).trim()
  return producer && receiver ? { producer, receiver } : undefined
}
