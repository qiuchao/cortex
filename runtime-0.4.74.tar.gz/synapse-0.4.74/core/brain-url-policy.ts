const RETIRED_BRAIN_PORTS = new Set(["8900", "8910"])

/** Whether a URL points at a Cerebro endpoint that clients must no longer use. */
export function hasRetiredBrainPort(rawUrl: string): boolean {
  try {
    return RETIRED_BRAIN_PORTS.has(new URL(rawUrl).port)
  } catch {
    return false
  }
}
