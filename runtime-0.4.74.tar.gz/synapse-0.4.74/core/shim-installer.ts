/**
 * core/shim-installer.ts —— 工作台安装器原语:install/uninstall/check shim。
 *
 * 把各客户端的 hook 配置指向 shims/<client>/{inject,report,[guard]} 脚本。
 * 幂等:重复 install 不重复写;uninstall 只移除 Synapse 加的部分;不整体覆盖已有配置。
 *
 * 客户端 hook 配置格式(调研结果):
 *   claude-code  : ~/.claude/settings.json  hooks.{EventName}[] = [{matcher?,hooks:[{type:"command",command}]}]
 *   codex        : ~/.codex/hooks.json      hooks.{EventName}[] = 同上(与 CC 格式一致)
 *   gemini-cli   : ~/.gemini/settings.json  hooks.{EventName}[] = [{matcher?,hooks:[{type:"command",command}]}]
 *   opencode     : 原生 plugin hooks → 装全局 plugin(~/.config/opencode/plugins/synapse.js);
 *                  git 硬护栏降级走 per-repo pre-commit(D3)。不写 AGENTS.md 等软约束。
 *
 * Token 绝不落盘:本模块只写 hook 路径,不写任何凭证。
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync, copyFileSync, rmSync } from "node:fs"
import { spawnSync } from "node:child_process"
import { homedir } from "node:os"
import { dirname, join, resolve } from "node:path"
import { fileURLToPath } from "node:url"
import { parse as parseToml, stringify as stringifyToml, type TomlTable } from "smol-toml"
import { detectWindowsGitBash } from "./windows-shell.ts"

// Synapse 安装目录(shims 从这里推导)
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const SYNAPSE_ROOT = resolve(__dirname, "..")

/** shim 脚本的绝对路径 */
function shimPath(client: string, script: string): string {
  return join(SYNAPSE_ROOT, "shims", client, script)
}

/**
 * 各 client 的 JSON hook 配置文件路径(CC/codex/gemini;opencode 走 plugin 无此文件)。
 * 单一事实源:isInstalled* 与 isGuardWired 都从这里取,避免路径知识散落多处(DRY)。
 */
function clientConfigPath(client: "claude-code" | "codex" | "gemini-cli", opts?: ShimOpts): string {
  const home = effectiveHome(opts)
  switch (client) {
    case "claude-code":
      return join(home, ".claude", "settings.json")
    case "codex":
      return join(home, ".codex", "hooks.json")
    case "gemini-cli":
      return join(home, ".gemini", "settings.json")
  }
}

/** hook 条目里用于识别 Synapse 注入的唯一标记(嵌在 command 字符串里) */
const SYNAPSE_MARKER = "synapse"

export interface ShimOpts {
  /** 覆盖 home 目录(测试注入用) */
  homeDir?: string
  /** 覆盖当前项目目录(测试注入用) */
  cwd?: string
  /** 覆盖 synapse root(测试注入用) */
  synapseRoot?: string
  /** 覆盖平台(测试注入用;默认 process.platform)。用于在 Linux 上测 win32 分支。 */
  platform?: NodeJS.Platform
  /**
   * 覆盖「git-bash 是否可用」(测试注入用;默认 detectGitBash())。
   * 仅在 platform=win32 时有意义:CC 在 Windows 默认用 git-bash 跑 hook,有 git-bash 时
   * 走 POSIX 薄壳(正斜杠路径 + shell:bash),无则回落 .cmd + PowerShell。
   */
  gitBashPresent?: boolean
  /** 覆盖 Kimi Code 数据目录(默认 KIMI_CODE_HOME 或 ~/.kimi-code)。 */
  kimiCodeHome?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// 内部工具
// ─────────────────────────────────────────────────────────────────────────────

function effectiveHome(opts?: ShimOpts): string {
  return opts?.homeDir ?? homedir()
}

function effectiveCwd(opts?: ShimOpts): string {
  return opts?.cwd ?? process.cwd()
}

function effectiveSynapseRoot(opts?: ShimOpts): string {
  return opts?.synapseRoot ?? SYNAPSE_ROOT
}

function effectiveKimiCodeHome(opts?: ShimOpts): string {
  return opts?.kimiCodeHome ?? process.env["KIMI_CODE_HOME"] ?? join(effectiveHome(opts), ".kimi-code")
}

function shimScriptPath(client: string, script: string, opts?: ShimOpts): string {
  return join(effectiveSynapseRoot(opts), "shims", client, script)
}

function effectivePlatform(opts?: ShimOpts): NodeJS.Platform {
  return opts?.platform ?? process.platform
}

/**
 * git-bash 是否可用(仅 win32 语义)。检测顺序:
 *   ① env CLAUDE_CODE_GIT_BASH_PATH(CC 官方指定 bash 的 env)指向存在文件;
 *   ② 常见安装路径(Program Files / 用户级 scoop-winget)的 bash.exe 存在。
 * 测试可用 ShimOpts.gitBashPresent 直接注入(与 platform 注入同款),不碰真实 fs。
 */
function detectGitBash(opts?: ShimOpts): boolean {
  if (opts?.gitBashPresent !== undefined) return opts.gitBashPresent
  return detectWindowsGitBash({
    platform: effectivePlatform(opts),
    homeDir: effectiveHome(opts),
  })
}

/**
 * Windows 绝对路径 → git-bash 可接受形态:反斜杠转正斜杠。
 * git-bash 把 `C:\Users\x` 里的 `\` 当转义符吃掉(→ `C:Usersx` command not found);
 * `C:/Users/x` 则原样识别(真机验证)。盘符冒号 git-bash 接受,无需转 `/c/` 形态。
 */
function toBashPath(p: string): string {
  return p.replace(/\\/g, "/")
}

/** Quote a POSIX hook command for clients that execute it through `sh -c`. */
function shellQuotePosix(value: string): string {
  // Preserve the historical command string for ordinary paths (Linux/WSL and
  // most Windows installs), changing only paths that the shell would split or
  // interpret specially.
  if (!/[\s'"`$&;|<>()[\]{}*?!#~]/.test(value)) return value
  return `'${value.replace(/'/g, `'\\''`)}'`
}

// ── shim 超时(同源,防漂移)──────────────────────────────────────────────────
//
// 🔴 薄壳/.cmd 的 inject 超时必须覆盖最慢的显式工作项上下文加载。daemon 会为多 ID
//    固定快照分页、正文读取和 receipt 创建保留 18s；外层若仍按普通 KH 的 1.2s 预算会
//    提前掐断，导致模型看不到缺失项和 receipt。这里保留 2s 调度余量。
//    这里定义**单一事实源**,.cmd 从此派生,不再逐处手写魔法数。
const DAEMON_WORK_ITEM_CONTEXT_DEADLINE_MS = 18_000
/** inject 薄壳超时(秒):18s 工作项预算 + 2s 余量。 */
const SHIM_INJECT_TIMEOUT_SEC = Math.ceil(DAEMON_WORK_ITEM_CONTEXT_DEADLINE_MS / 1000) + 2 // = 20
/** report/guard 薄壳超时(秒):不参与 inject 预算赛跑,2s 足够。 */
const SHIM_OTHER_TIMEOUT_SEC = 2

function winCmdTimeoutSec(client: string, verb: string): number {
  if (verb !== "inject") return SHIM_OTHER_TIMEOUT_SEC
  return SHIM_INJECT_TIMEOUT_SEC
}

/**
 * cmd.exe 的 `more > file` 会按当前代码页转码管道内容。Gemini CLI 0.53.0 通过
 * PowerShell 启动 hook 时，这会把 Node 写入的 UTF-8 中文截成非法 JSON。通过
 * OpenStandardInput 按字节复制，避免任何控制台编码参与。
 */
function captureWinStdinTo(envPathName: string): string {
  return `powershell.exe -NoProfile -NonInteractive -Command "$source=[Console]::OpenStandardInput();$target=[IO.File]::Create($env:${envPathName});try{$source.CopyTo($target)}finally{$target.Dispose()}"`
}

// ── Windows .cmd 包装 ──────────────────────────────────────────────────────────
//
// Windows 客户端(CC/Codex/Gemini 是 Node 应用)spawn hook command 时,`#!/bin/sh`
// 无扩展名脚本不可直接执行(无 shebang 语义 + 无关联程序)。故 win32 上为每个 shim 脚本
// 生成一个 .cmd 包装,hook 配置指向 .cmd;.cmd 内部调 curl.exe(Win10 1803+ 自带)走
// daemon 的 loopback TCP 端点(读 runtime.env 取 port + token)。
//
// .cmd 与 sh 薄壳共用同一 daemon TCP 端点,零业务逻辑仍成立(解析全在 daemon)。
// .cmd 放在 runtime 目录下的 shims-win/<client>/,与 bundle 内 sh 脚本分开,避免污染源码树。

/** win32 下生成的 .cmd 包装存放目录(用户运行时目录,非 bundle)。 */
function winCmdDir(client: string, opts?: ShimOpts): string {
  return join(effectiveHome(opts), ".synapse", "shims-win", client)
}

/** win32 下某 verb 的 .cmd 包装绝对路径。 */
function winCmdPath(client: string, verb: string, opts?: ShimOpts): string {
  return join(winCmdDir(client, opts), `${verb}.cmd`)
}

/**
 * 生成一个 .cmd 包装内容:读 runtime.env(%USERPROFILE%\.cache\synapse\runtime.env)取
 * SYNAPSE_PORT + SYNAPSE_TOKEN_FILE,curl.exe POST 原始 stdin 到 loopback TCP 端点。
 * daemon 不可达 → inject 降级、guard 放行到 pre-commit、report 静默。guard 的 curl
 * timeout(28)单独处理:git 修改命令 fail-closed,非 git 命令不误杀。
 */
function renderWinCmd(client: string, verb: string): string {
  // fallback:inject 有降级 JSON,guard 不可达时无决策{},report 静默。
  // 注意:echo 后**不留空格**再接 & / 换行,否则会多印一个尾随空格。
  const fallback =
    verb === "inject"
      ? client === "codex"
        ? `echo.`
        : `echo {}`
      : verb === "guard"
        ? `echo {}`
        : `echo.` // report:输出一个空行(静默上报,内容被忽略);不用 rem(会吞 & exit)
  // curl 的 max-time:inject 必须 >= daemon 预算 + 余量(见 SHIM_INJECT_TIMEOUT_SEC 注释),
  // report/guard 不参与 inject 赛跑用 2s。旧代码 inject=1s < 1.2s 预算 → 冷启动首条丢注入。
  const maxTime = String(winCmdTimeoutSec(client, verb))
  // 注:.cmd 里 % 需转义为 %%;token 经 set /p 从文件读一行。
  // runtime.env 的值被单引号包裹(为 sh source 安全);.cmd 侧用 %%~B(for /f)+ 去引号处理。
  //   %%~B 去掉外层双引号,但 daemon 写的是单引号 → 用变量替换 set "V=!V:'=!" 去掉所有单引号。
  const prefix = [
    `@echo off`,
    `rem Synapse win .cmd 薄壳: ${client} · ${verb}(零业务逻辑,转发 stdin 到 daemon loopback TCP)`,
    `setlocal enabledelayedexpansion`,
    `set "ENV_FILE=%XDG_CACHE_HOME%"`,
    `if "%ENV_FILE%"=="" set "ENV_FILE=%USERPROFILE%\\.cache"`,
    `set "ENV_FILE=%ENV_FILE%\\synapse\\runtime.env"`,
    `set "SYNAPSE_PORT="`,
    `set "SYNAPSE_TOKEN_FILE="`,
    // 旧 daemon 的 runtime.env 没有该字段；兼容旧版始终启用的语义。
    `set "SYNAPSE_GIT_GUARD_ENABLED=true"`,
    `if exist "%ENV_FILE%" (`,
    `  for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (`,
    `    if "%%A"=="SYNAPSE_PORT" set "SYNAPSE_PORT=%%B"`,
    `    if "%%A"=="SYNAPSE_TOKEN_FILE" set "SYNAPSE_TOKEN_FILE=%%B"`,
    `    if "%%A"=="SYNAPSE_GIT_GUARD_ENABLED" set "SYNAPSE_GIT_GUARD_ENABLED=%%B"`,
    `  )`,
    `)`,
    // 去掉 daemon 写入时包裹的单引号(port/token 路径都可能带)。
    `set "SYNAPSE_PORT=!SYNAPSE_PORT:'=!"`,
    `set "SYNAPSE_TOKEN_FILE=!SYNAPSE_TOKEN_FILE:'=!"`,
    `set "SYNAPSE_GIT_GUARD_ENABLED=!SYNAPSE_GIT_GUARD_ENABLED:'=!"`,
    `if "!SYNAPSE_PORT!"=="" (`,
    `  ${fallback}`,
    `  exit /b 0`,
    `)`,
    `set "TOKEN="`,
    `if exist "!SYNAPSE_TOKEN_FILE!" set /p TOKEN=<"!SYNAPSE_TOKEN_FILE!"`,
  ]

  if (verb === "guard") {
    const timeoutDeny =
      client === "gemini-cli"
        ? `echo {"decision":"deny","reason":"Synapse guard timed out while checking a git write; retry the command."}`
        : `echo {"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"Synapse guard timed out while checking a git write; retry the command."}}`
    return [
      ...prefix,
      `set "GUARD_INPUT=%TEMP%\\synapse-guard-input-!RANDOM!-!RANDOM!.json"`,
      `set "GUARD_RESPONSE=%TEMP%\\synapse-guard-response-!RANDOM!-!RANDOM!.json"`,
      captureWinStdinTo("GUARD_INPUT"),
      `curl.exe -s --max-time ${maxTime} -H "Authorization: Bearer !TOKEN!" -H "content-type: application/json" -H "X-Synapse-Client: ${client}" --data-binary @"!GUARD_INPUT!" "http://127.0.0.1:!SYNAPSE_PORT!/guard" > "!GUARD_RESPONSE!" 2>nul`,
      `set "CURL_EXIT=!ERRORLEVEL!"`,
      `if "!CURL_EXIT!"=="0" (`,
      `  type "!GUARD_RESPONSE!"`,
      `) else if "!CURL_EXIT!"=="28" if /i "!SYNAPSE_GIT_GUARD_ENABLED!"=="true" (`,
      `  findstr /i /c:"\\\"tool_name\\\":\\\"Bash\\\"" /c:"\\\"tool_name\\\":\\\"exec_command\\\"" /c:"\\\"tool_name\\\":\\\"shell_command\\\"" /c:"\\\"tool_name\\\":\\\"run_shell_command\\\"" "!GUARD_INPUT!" >nul`,
      `  if !ERRORLEVEL! EQU 0 (`,
      `    findstr /i /c:"git " /c:"git.exe " "!GUARD_INPUT!" >nul`,
      `    if !ERRORLEVEL! EQU 0 (`,
      `      findstr /i /c:" add" /c:" am" /c:" apply" /c:" branch" /c:" checkout" /c:" cherry-pick" /c:" clean" /c:" clone" /c:" commit" /c:" fetch" /c:" merge" /c:" mv" /c:" pull" /c:" push" /c:" rebase" /c:" reset" /c:" restore" /c:" revert" /c:" rm" /c:" stash" /c:" switch" /c:" tag" "!GUARD_INPUT!" >nul`,
      `      if !ERRORLEVEL! EQU 0 (${timeoutDeny}) else echo {}`,
      `    ) else echo {}`,
      `  ) else echo {}`,
      `) else echo {}`,
      `del /q "!GUARD_INPUT!" "!GUARD_RESPONSE!" >nul 2>nul`,
      `endlocal`,
      ``,
    ].join("\r\n")
  }

  if (verb === "inject") {
    return [
      ...prefix,
      `set /a INJECT_TEMP_ATTEMPTS=0`,
      `:synapse_inject_temp_retry`,
      `set /a INJECT_TEMP_ATTEMPTS+=1`,
      `set "INJECT_TEMP_DIR=%TEMP%\\synapse-inject-!RANDOM!-!RANDOM!"`,
      `md "!INJECT_TEMP_DIR!" >nul 2>nul`,
      `if errorlevel 1 (`,
      `  if !INJECT_TEMP_ATTEMPTS! GEQ 5 (`,
      `    ${fallback}`,
      `    endlocal`,
      `    exit /b 0`,
      `  )`,
      `  goto synapse_inject_temp_retry`,
      `)`,
      `set "INJECT_INPUT=!INJECT_TEMP_DIR!\\input.json"`,
      `set "INJECT_RESPONSE=!INJECT_TEMP_DIR!\\response.txt"`,
      captureWinStdinTo("INJECT_INPUT"),
      `curl.exe -f -s --max-time ${maxTime} -H "Authorization: Bearer !TOKEN!" -H "content-type: application/json" -H "X-Synapse-Client: ${client}" --data-binary @"!INJECT_INPUT!" "http://127.0.0.1:!SYNAPSE_PORT!/inject" > "!INJECT_RESPONSE!" 2>nul`,
      `set "CURL_EXIT=!ERRORLEVEL!"`,
      `if "!CURL_EXIT!"=="0" (`,
      `  type "!INJECT_RESPONSE!"`,
      `) else (`,
      `  ${fallback}`,
      `)`,
      `rd /s /q "!INJECT_TEMP_DIR!" >nul 2>nul`,
      `endlocal`,
      ``,
    ].join("\r\n")
  }

  return [
    ...prefix,
    `curl.exe -s --max-time ${maxTime} -H "Authorization: Bearer !TOKEN!" -H "content-type: application/json" -H "X-Synapse-Client: ${client}" --data-binary @- "http://127.0.0.1:!SYNAPSE_PORT!/${verb}" 2>nul || ${fallback}`,
    `endlocal`,
    ``,
  ].join("\r\n")
}

/**
 * win32:为一个 client 的所有 verb 生成 .cmd 包装,返回 {verb: cmdPath} 映射。
 * 幂等:覆盖写(内容固定,无用户数据)。
 */
function ensureWinCmds(client: string, verbs: string[], opts?: ShimOpts): Record<string, string> {
  const dir = winCmdDir(client, opts)
  mkdirSync(dir, { recursive: true })
  const map: Record<string, string> = {}
  for (const verb of verbs) {
    const p = winCmdPath(client, verb, opts)
    writeFileSync(p, renderWinCmd(client, verb), "utf8")
    map[verb] = p
  }
  return map
}

/**
 * 解析某 client/verb 的 hook command:win32 → .cmd 包装路径(先生成);POSIX → sh 脚本路径。
 * 传入的 verbs 用于 win32 一次性生成全部 .cmd(避免逐个建目录)。
 */
function resolveShimCommand(
  client: string,
  verb: string,
  winCmds: Record<string, string> | null,
  opts?: ShimOpts,
): string {
  if (winCmds) return winCmds[verb]
  return shellQuotePosix(shimScriptPath(client, verb, opts))
}

/**
 * isShimInstalled 判定用的脚本路径集:win32 → .cmd 包装路径;POSIX → sh 脚本路径。
 * 与 install 时写进 hook 的 command 一致,才能被 isShimInstalledInJson 的「配置引用 + 文件存在」双校验命中。
 */
function resolveShimInstalledPaths(client: string, verbs: string[], opts?: ShimOpts): string[] {
  const win = effectivePlatform(opts) === "win32"
  return verbs.map((v) => (win ? winCmdPath(client, v, opts) : shimScriptPath(client, v, opts)))
}

function readJson(path: string): Record<string, unknown> {
  if (!existsSync(path)) return {}
  try {
    return JSON.parse(readFileSync(path, "utf8")) as Record<string, unknown>
  } catch {
    return {}
  }
}

function writeJson(path: string, data: unknown): void {
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, JSON.stringify(data, null, 2) + "\n", "utf8")
}

// ─────────────────────────────────────────────────────────────────────────────
// CC / Codex / Gemini 共享 hook 格式
// ─────────────────────────────────────────────────────────────────────────────

/** 单个 hook 命令条目 */
interface HookCmd {
  type: "command"
  command: string
  timeout?: number
  /**
   * 执行 shell(CC 官方字段):"bash" | "powershell"。省略 = 客户端默认。
   * win32 CC:有 git-bash → "bash"(跑 POSIX 薄壳);无 → "powershell"(跑 .cmd)。
   */
  shell?: "bash" | "powershell"
  /**
   * per-platform 命令覆盖(codex 原生字段 commandWindows / command_windows alias):
   * Windows 上 codex 取此值,其他平台取 command。用于 codex win32 走 .cmd 而 POSIX 走 sh。
   */
  commandWindows?: string
}

/** hook group(一个事件下的一组) */
interface HookGroup {
  matcher?: string
  hooks: HookCmd[]
}

/** hook 配置顶层 */
interface HooksConfig {
  hooks?: Record<string, HookGroup[]>
  [key: string]: unknown
}

/**
 * 判断一个 HookCmd 是否属于 Synapse 注入。
 *
 * **必须跨历史路径形态全部命中**(否则升级迁移时旧条目清不掉,残留多条 → git-bash 下
 * 旧条目 command not found 刷噪音,正是 0.4.0 真机复验发现的收尾 bug)。历史三形态:
 *   - 0.2.x 反斜杠 POSIX:`...\shims\<client>\inject`
 *   - 0.3.x .cmd 包装:`...\.synapse\shims-win\<client>\inject.cmd`
 *   - 0.4.0 正斜杠 POSIX:`.../shims/<client>/inject`(command)+ .cmd(commandWindows)
 * 逐一显式匹配 + 兜底「路径含 synapse」(安装根目录恒在 synapse-runtime/.synapse 下)。
 * 同时查 command 与 commandWindows(codex 把 .cmd 放在 commandWindows)。
 */
function isSynapseHookCmd(cmd: HookCmd, client: string): boolean {
  const hit = (s: unknown): boolean =>
    typeof s === "string" &&
    (s.includes(`shims/${client}/`) || // 正斜杠 POSIX
      s.includes(`shims\\${client}\\`) || // 反斜杠 POSIX(旧 Windows)
      s.includes(`shims-win/${client}/`) ||
      s.includes(`shims-win\\${client}\\`) || // .cmd 包装
      s.includes(SYNAPSE_MARKER)) // 兜底:安装根目录含 synapse
  return hit(cmd.command) || hit(cmd.commandWindows)
}

/**
 * 从某事件的 groups 里,移除 Synapse 注入的 hook;若 group 空则整组移除。
 */
function removeSynapseFromGroups(groups: HookGroup[], client: string): HookGroup[] {
  return groups
    .map((g) => ({
      ...g,
      hooks: (g.hooks ?? []).filter((h) => !isSynapseHookCmd(h, client)),
    }))
    .filter((g) => g.hooks.length > 0)
}

/**
 * 检查某事件的 groups 里是否已有指向 script 的 Synapse hook。
 */
function hasShimHook(groups: HookGroup[], scriptPath: string): boolean {
  return groups.some((g) => (g.hooks ?? []).some((h) => h.command === scriptPath))
}

/** 一条待安装 hook 的完整选项(command + 可选 shell / commandWindows / timeout / matcher)。 */
interface HookSpec {
  script: string
  timeout?: number
  shell?: "bash" | "powershell"
  commandWindows?: string
  /** group 级 matcher(gemini 官方范例都带 "*";省略 = 不写 matcher,由客户端默认)。 */
  matcher?: string
}

/**
 * 往 groups 里追加 Synapse hook(若已存在则不追加)。
 * 新增时把 Synapse group 追加到数组末尾(不破坏用户已有 groups)。
 */
function addShimHook(groups: HookGroup[], spec: HookSpec): HookGroup[] {
  if (hasShimHook(groups, spec.script)) return groups
  const cmd: HookCmd = { type: "command", command: spec.script }
  if (spec.timeout !== undefined) cmd.timeout = spec.timeout
  if (spec.shell !== undefined) cmd.shell = spec.shell
  if (spec.commandWindows !== undefined) cmd.commandWindows = spec.commandWindows
  const group: HookGroup = { hooks: [cmd] }
  if (spec.matcher !== undefined) group.matcher = spec.matcher
  return [...groups, group]
}

/**
 * 安装 hook 到 JSON 配置文件(CC/Codex/Gemini 三端共用)。**clean-then-add 语义**:
 *   ① 先把**所有事件**下该 client 的旧 synapse 条目全清掉(跨路径形态,见 isSynapseHookCmd);
 *   ② 再把当前 spec 的一条加回目标事件。
 * 这样跨版本升级(反斜杠 POSIX → .cmd → 正斜杠 POSIX)不残留多条——旧条目在 git-bash 下
 * command not found 刷噪音的收尾 bug 根治于此。用户自己的 hook(非 synapse)全程不动。
 * spec: { EventName: HookSpec, ... }
 */
function installHooksToJson(
  configPath: string,
  client: string,
  spec: Record<string, HookSpec>,
): void {
  const cfg = readJson(configPath) as HooksConfig
  if (!cfg.hooks || typeof cfg.hooks !== "object") cfg.hooks = {}
  // ① 清:遍历所有事件,剥掉该 client 的旧 synapse 条目(空 group 顺带清)。
  for (const [event, groups] of Object.entries(cfg.hooks)) {
    if (!Array.isArray(groups)) continue
    const remaining = removeSynapseFromGroups(groups as HookGroup[], client)
    if (remaining.length > 0) cfg.hooks[event] = remaining
    else delete cfg.hooks[event] // synapse 独占的事件清空后丢键,不留空数组
  }
  // ② 加:当前 spec 的一条(hasShimHook 幂等,重复 install 不叠)。
  for (const [event, hookSpec] of Object.entries(spec)) {
    const existing = Array.isArray(cfg.hooks[event]) ? (cfg.hooks[event] as HookGroup[]) : []
    cfg.hooks[event] = addShimHook(existing, hookSpec)
  }
  writeJson(configPath, cfg)
}

/**
 * 卸载 hook 从 JSON 配置文件。
 */
function uninstallHooksFromJson(configPath: string, client: string): void {
  if (!existsSync(configPath)) return
  const cfg = readJson(configPath) as HooksConfig
  if (!cfg.hooks || typeof cfg.hooks !== "object") return
  const cleaned: Record<string, HookGroup[]> = {}
  for (const [event, groups] of Object.entries(cfg.hooks)) {
    if (!Array.isArray(groups)) continue
    const remaining = removeSynapseFromGroups(groups as HookGroup[], client)
    // 移除 synapse hook 后数组变空 → 丢掉该键,还原到安装前的干净状态。
    // 若数组仍非空(用户有其他 hook),则写回。
    if (remaining.length > 0) cleaned[event] = remaining
  }
  cfg.hooks = cleaned
  writeJson(configPath, cfg)
}

/**
 * 检查 JSON 配置文件里是否已有某 client 的 shim hook。
 *
 * 两层校验(缺一即 false):
 *   ① 配置里确实引用了某个 shim 脚本路径;
 *   ② 该脚本在磁盘上**真实存在**(existsSync)。
 * 只查 ① 会产生假阳性:若配置写了路径但脚本没打进 bundle(历史 bug),运行时
 * hook 会失败/空跑,却仍报「已安装」。加 ② 后,配置引用的脚本命中且文件存在才算装好。
 */
type HookCommandField = "command" | "commandWindows"

function isShimInstalledInJson(
  configPath: string,
  client: string,
  scripts: string[],
  commandField: HookCommandField = "command",
): boolean {
  if (!existsSync(configPath)) return false
  const cfg = readJson(configPath) as HooksConfig
  if (!cfg.hooks || typeof cfg.hooks !== "object") return false
  const allGroups = Object.values(cfg.hooks).flat() as HookGroup[]
  return scripts.some(
    (s) =>
      existsSync(s) && // ② 脚本文件必须真实存在
      allGroups.some((g) =>
        (g.hooks ?? []).some((h) => {
          const command = h[commandField]
          return command === s || command === shellQuotePosix(s)
        }),
      ), // ① 配置引用
  )
}

/**
 * 检查每个脚本是否挂在其要求的事件上。用于事件本身属于客户端契约的 hook：
 * 只在任意事件里找到路径不够，旧事件残留会让 doctor 假报已安装，但运行时不会注入。
 */
function areShimHooksInstalledAtEvents(
  configPath: string,
  required: Array<{ event: string; script: string }>,
  commandField: HookCommandField = "command",
): boolean {
  if (!existsSync(configPath)) return false
  const cfg = readJson(configPath) as HooksConfig
  if (!cfg.hooks || typeof cfg.hooks !== "object") return false
  return required.every(({ event, script }) => {
    if (!existsSync(script)) return false
    const groups = cfg.hooks?.[event]
    return Array.isArray(groups) && groups.some((g) =>
      (g.hooks ?? []).some((h) => {
        const command = h[commandField]
        return command === script || command === shellQuotePosix(script)
      }),
    )
  })
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-client 实现
// ─────────────────────────────────────────────────────────────────────────────

// ── claude-code ──────────────────────────────────────────────────────────────

/**
 * 解析 CC 单个 verb 的 hook 交付形态(command + shell),按 win32 + git-bash 三态:
 *   - 非 win32(POSIX):sh 薄壳绝对路径,无 shell 字段(客户端默认 bash/sh)。
 *   - win32 + 有 git-bash:POSIX 薄壳的**正斜杠**路径 + shell:"bash"(git-bash 跑 sh)。
 *   - win32 + 无 git-bash:.cmd 包装反斜杠路径 + shell:"powershell"(PS 能跑 .cmd)。
 * 🔴 每 verb 只产出**一条** hook(不再同时装 POSIX + .cmd,那是 bash 跑不了 .cmd 报错的根)。
 */
function ccHookSpec(
  verb: string,
  winCmds: Record<string, string> | null,
  opts: ShimOpts | undefined,
  timeout?: number,
): HookSpec {
  const win = effectivePlatform(opts) === "win32"
  if (!win) {
    return { script: shellQuotePosix(shimScriptPath("claude-code", verb, opts)), timeout }
  }
  if (detectGitBash(opts)) {
    // git-bash:正斜杠 POSIX 薄壳路径 + shell:bash。
    return { script: shellQuotePosix(toBashPath(shimScriptPath("claude-code", verb, opts))), timeout, shell: "bash" }
  }
  // 无 git-bash:.cmd + PowerShell。
  return { script: winCmds![verb], timeout, shell: "powershell" }
}

function installClaudeCode(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".claude", "settings.json")
  // .cmd 仅在 win32 + 无 git-bash 时才需要;有 git-bash 直接跑 POSIX 薄壳,不生成 .cmd。
  const needCmd = effectivePlatform(opts) === "win32" && !detectGitBash(opts)
  // 🔴 走 POSIX(git-bash)路径时,清掉可能残留的旧 .cmd 目录:CC 有 git-bash 时 hook 指向
  //    POSIX 薄壳、根本不调 .cmd,但旧版(或曾无 git-bash 时)生成的 shims-win/claude-code/
  //    inject.cmd 会**原地不动**残留(install 不重写它)→ 成为「死路径 + 旧 --max-time」不一致源。
  //    这里在 POSIX 分支主动清理,消除残留(rmSync force 幂等,不存在无害)。
  if (effectivePlatform(opts) === "win32" && !needCmd) {
    rmSync(winCmdDir("claude-code", opts), { recursive: true, force: true })
  }
  const winCmds = needCmd ? ensureWinCmds("claude-code", ["inject", "report", "guard"], opts) : null
  installHooksToJson(configPath, "claude-code", {
    UserPromptSubmit: ccHookSpec("inject", winCmds, opts),
    Stop: ccHookSpec("report", winCmds, opts, 10),
    SessionEnd: ccHookSpec("report", winCmds, opts, 10),
    PreToolUse: ccHookSpec("guard", winCmds, opts, 5),
  })
}

function uninstallClaudeCode(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".claude", "settings.json")
  uninstallHooksFromJson(configPath, "claude-code")
  // .cmd 目录仅在无-git-bash win32 生成过;存在即清(rmSync force 幂等,不存在无害)。
  if (effectivePlatform(opts) === "win32") rmSync(winCmdDir("claude-code", opts), { recursive: true, force: true })
}

/**
 * CC 判定用的脚本路径集,与 install 写入的 command **完全一致**(否则双校验命中不了):
 *   - 非 win32:sh 薄壳路径。
 *   - win32 + git-bash:正斜杠 POSIX 路径(注意:existsSync 对正斜杠 Windows 路径同样有效)。
 *   - win32 + 无 git-bash:.cmd 路径。
 */
function ccInstalledPaths(verbs: string[], opts?: ShimOpts): string[] {
  const win = effectivePlatform(opts) === "win32"
  if (!win) return verbs.map((v) => shimScriptPath("claude-code", v, opts))
  if (detectGitBash(opts)) return verbs.map((v) => toBashPath(shimScriptPath("claude-code", v, opts)))
  return verbs.map((v) => winCmdPath("claude-code", v, opts))
}

function isInstalledClaudeCode(opts?: ShimOpts): boolean {
  const configPath = clientConfigPath("claude-code", opts)
  const inject = ccInstalledPaths(["inject", "report"], opts)
  return isShimInstalledInJson(configPath, "claude-code", inject)
}

// ── codex ─────────────────────────────────────────────────────────────────────

/**
 * codex 单 verb 的 HookSpec:
 *   - 非 win32:command = sh 薄壳路径。
 *   - win32:command = sh 薄壳路径(其他平台/WSL 下的 codex),commandWindows = .cmd 路径
 *     (codex 在 Windows 原生取 commandWindows)。codex 用 ClaudeHooksEngine,契约由 daemon
 *     formatter 处理,薄壳仍零逻辑。
 */
function codexHookSpec(
  verb: string,
  winCmds: Record<string, string> | null,
  opts: ShimOpts | undefined,
  timeout?: number,
): HookSpec {
  const posix = shimScriptPath("codex", verb, opts)
  if (effectivePlatform(opts) !== "win32") return { script: shellQuotePosix(posix), timeout }
  return { script: shellQuotePosix(posix), timeout, commandWindows: winCmds![verb] }
}

function installCodex(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".codex", "hooks.json")
  // codex 支持 PreToolUse 硬护栏(ClaudeHooksEngine,与 CC 同族契约):deny 走
  // hookSpecificOutput.permissionDecision + 非空 permissionDecisionReason(daemon formatter 填)。
  // win32 codex 用 cmd.exe 跑 hook(COMSPEC /C),故 guard 也随 inject/report 生成 .cmd 走 commandWindows。
  const winCmds =
    effectivePlatform(opts) === "win32"
      ? ensureWinCmds("codex", ["inject", "report", "guard"], opts)
      : null
  installHooksToJson(configPath, "codex", {
    UserPromptSubmit: codexHookSpec("inject", winCmds, opts),
    Stop: codexHookSpec("report", winCmds, opts, 10),
    PreToolUse: codexHookSpec("guard", winCmds, opts, 5),
  })
}

function uninstallCodex(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".codex", "hooks.json")
  uninstallHooksFromJson(configPath, "codex")
  if (effectivePlatform(opts) === "win32") rmSync(winCmdDir("codex", opts), { recursive: true, force: true })
}

function isInstalledCodex(opts?: ShimOpts): boolean {
  const configPath = clientConfigPath("codex", opts)
  const win = effectivePlatform(opts) === "win32"
  // Windows Native 实际执行 commandWindows 指向的 .cmd；备用 command 的 POSIX 薄壳
  // 即使存在也不能证明 Windows hook 可用。WSL/POSIX 则仍校验 command。
  const paths = win
    ? resolveShimInstalledPaths("codex", ["inject", "report"], opts)
    : [shimScriptPath("codex", "inject", opts), shimScriptPath("codex", "report", opts)]
  return isShimInstalledInJson(configPath, "codex", paths, win ? "commandWindows" : "command")
}

// ── gemini-cli ────────────────────────────────────────────────────────────────

function installGeminiCli(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".gemini", "settings.json")
  const winCmds =
    effectivePlatform(opts) === "win32"
      ? ensureWinCmds("gemini-cli", ["inject", "report", "guard"], opts)
      : null
  const inject = resolveShimCommand("gemini-cli", "inject", winCmds, opts)
  const report = resolveShimCommand("gemini-cli", "report", winCmds, opts)
  const guard = resolveShimCommand("gemini-cli", "guard", winCmds, opts)
  // 注意:gemini-cli 的 timeout 单位是毫秒(ms),与 CC/codex 的秒(s)不同。
  // 官方 hooks 文档示例: "timeout": 5000 (= 5s)。这里写 10000 = 10s,与 CC/codex 等价。
  // matcher:"*" —— gemini 官方范例的 model/lifecycle hook 都带 matcher,补上防边界情况。
  //
  // BeforeTool 覆盖所有工具，daemon 同时执行 turn-scoped Task 路由与可选 Git 策略。
  // 契约走顶层 {"decision":"deny","reason"};guard 判定 5s(=5000ms)足够。
  installHooksToJson(configPath, "gemini-cli", {
    BeforeAgent: { script: inject, matcher: "*" },
    AfterAgent: { script: report, timeout: 10000, matcher: "*" },
    BeforeTool: { script: guard, timeout: 5000, matcher: "*" },
    SessionEnd: { script: report, timeout: 10000, matcher: "*" },
  })
}

function uninstallGeminiCli(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const configPath = join(home, ".gemini", "settings.json")
  uninstallHooksFromJson(configPath, "gemini-cli")
  if (effectivePlatform(opts) === "win32") rmSync(winCmdDir("gemini-cli", opts), { recursive: true, force: true })
}

function isInstalledGeminiCli(opts?: ShimOpts): boolean {
  const configPath = clientConfigPath("gemini-cli", opts)
  const [inject, report] = resolveShimInstalledPaths("gemini-cli", ["inject", "report"], opts)
  return areShimHooksInstalledAtEvents(configPath, [
    { event: "BeforeAgent", script: inject },
    { event: "AfterAgent", script: report },
    { event: "SessionEnd", script: report },
  ])
}

// ── kimi-code ────────────────────────────────────────────────────────────────

type KimiHook = TomlTable

function kimiConfigPath(opts?: ShimOpts): string {
  return join(effectiveKimiCodeHome(opts), "config.toml")
}

function isKimiHook(value: unknown): value is KimiHook {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false
  const hook = value as Record<string, unknown>
  return typeof hook["event"] === "string" && typeof hook["command"] === "string"
}

function isSynapseKimiHook(hook: KimiHook): boolean {
  const command = hook["command"] as string
  return command.includes("shims/kimi-code/")
    || command.includes("shims\\kimi-code\\")
    || command.includes("shims-win/kimi-code/")
    || command.includes("shims-win\\kimi-code\\")
}

function readKimiConfig(path: string): TomlTable {
  if (!existsSync(path)) return {}
  return parseToml(readFileSync(path, "utf8"))
}

function writeKimiConfig(path: string, config: TomlTable): void {
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, stringifyToml(config), { encoding: "utf8", mode: 0o600 })
}

function kimiHookCommand(verb: string, winCmds: Record<string, string> | null, opts?: ShimOpts): string {
  const command = resolveShimCommand("kimi-code", verb, winCmds, opts)
  // Kimi executes hook commands through a shell. Quote user-level Windows
  // paths so `%USERPROFILE%` values such as `C:\\Users\\Jane Doe` remain one command.
  return winCmds && /[\s&()]/.test(command) ? `"${command.replaceAll('"', '\\"')}"` : command
}

function kimiExpectedHookCommand(path: string, opts?: ShimOpts): string {
  if (effectivePlatform(opts) !== "win32") return shellQuotePosix(path)
  return /[\s&()]/.test(path) ? `"${path.replaceAll('"', '\\"')}"` : path
}

function installKimiCode(opts?: ShimOpts): void {
  const configPath = kimiConfigPath(opts)
  const winCmds = effectivePlatform(opts) === "win32"
    ? ensureWinCmds("kimi-code", ["inject", "report", "guard"], opts)
    : null
  const config = readKimiConfig(configPath)
  const existing = Array.isArray(config["hooks"])
    ? (config["hooks"] as unknown[]).filter(isKimiHook).filter((hook) => !isSynapseKimiHook(hook))
    : []
  config["hooks"] = [
    ...existing,
    { event: "UserPromptSubmit", command: kimiHookCommand("inject", winCmds, opts), timeout: SHIM_INJECT_TIMEOUT_SEC },
    { event: "Stop", command: kimiHookCommand("report", winCmds, opts), timeout: 10 },
    { event: "SessionEnd", command: kimiHookCommand("report", winCmds, opts), timeout: 10 },
    { event: "PreToolUse", matcher: "*", command: kimiHookCommand("guard", winCmds, opts), timeout: 5 },
  ]
  writeKimiConfig(configPath, config)
}

function uninstallKimiCode(opts?: ShimOpts): void {
  const configPath = kimiConfigPath(opts)
  if (existsSync(configPath)) {
    const config = readKimiConfig(configPath)
    if (Array.isArray(config["hooks"])) {
      const remaining = (config["hooks"] as unknown[]).filter(isKimiHook).filter((hook) => !isSynapseKimiHook(hook))
      if (remaining.length > 0) config["hooks"] = remaining
      else delete config["hooks"]
      writeKimiConfig(configPath, config)
    }
  }
  if (effectivePlatform(opts) === "win32") {
    rmSync(winCmdDir("kimi-code", opts), { recursive: true, force: true })
  }
}

function kimiInstalledHooks(opts?: ShimOpts): KimiHook[] {
  const configPath = kimiConfigPath(opts)
  if (!existsSync(configPath)) return []
  const hooks = readKimiConfig(configPath)["hooks"]
  return Array.isArray(hooks) ? (hooks as unknown[]).filter(isKimiHook) : []
}

function isInstalledKimiCode(opts?: ShimOpts): boolean {
  const [inject, report] = resolveShimInstalledPaths("kimi-code", ["inject", "report"], opts)
  const hooks = kimiInstalledHooks(opts)
  return existsSync(inject) && existsSync(report)
    && hooks.some((hook) => hook["event"] === "UserPromptSubmit" && hook["command"] === kimiExpectedHookCommand(inject, opts))
    && hooks.some((hook) => hook["event"] === "Stop" && hook["command"] === kimiExpectedHookCommand(report, opts))
    && hooks.some((hook) => hook["event"] === "SessionEnd" && hook["command"] === kimiExpectedHookCommand(report, opts))
}

// ── opencode ──────────────────────────────────────────────────────────────────
//
// opencode 接入点是 **plugin**:装到 ~/.config/opencode/plugins/ 后启动时自动加载
// (见 shims/opencode/plugin.js)。inject/report/tool.execute.before 都由 plugin 转发给
// 常驻 daemon。这是 cwd 无关的全局集成,取代旧的「只装当前仓库 pre-commit」。
//
// 安装做两件事(只保留硬机制,不写任何软约束文字):
//   ① 拷 plugin.js → ~/.config/opencode/plugins/synapse.js(注入 + 上报 + 工具前置护栏)
//   ② 仍装当前仓库 pre-commit 作为提交阶段的纵深保护(仅当 cwd 是 git 仓库时)
//
// 不写 AGENTS.md:那只是告知性软约束，既不参与注入也不参与工具前置判定。
//
// isShimInstalled 判定的是 **①全局 plugin 是否装好**(cwd 无关),不再查 per-repo
// pre-commit —— 后者是 cwd 相关的 git 兜底,不该代表「一键安装」是否成功。

// ── opencode 全局配置路径(~/.config/opencode/)──
function opencodeConfigDir(opts?: ShimOpts): string {
  return join(effectiveHome(opts), ".config", "opencode")
}
function opencodePluginPath(opts?: ShimOpts): string {
  // opencode 全局 plugin 目录(复数),启动自动加载目录内所有文件。
  return join(opencodeConfigDir(opts), "plugins", "synapse.js")
}

// bundle 内 plugin 源文件(随 shims/ 一起打包)。
function opencodePluginSource(opts?: ShimOpts): string {
  return join(effectiveSynapseRoot(opts), "shims", "opencode", "plugin.js")
}

function preCommitHookPath(cwd: string): string | undefined {
  const result = spawnSync("git", ["rev-parse", "--path-format=absolute", "--git-path", "hooks"], {
    cwd,
    encoding: "utf8",
    windowsHide: true,
  })
  if (result.status !== 0) return undefined
  const hooksDir = result.stdout.trim()
  return hooksDir ? join(resolve(cwd, hooksDir), "pre-commit") : undefined
}

const OPENCODE_PRECOMMIT_BEGIN = "# [synapse:opencode-degrade:begin]"
const OPENCODE_PRECOMMIT_END = "# [synapse:opencode-degrade:end]"

const LEGACY_KH_BEGIN = "<!-- knowledge-hub:start"
const LEGACY_KH_END = "<!-- knowledge-hub:end"

/**
 * 删除旧安装器写入的 knowledge-hub 管理块,保留文件内其余用户内容。
 * marker 历史上带过说明尾巴,因此按注释前缀定位,不依赖某一版完整字符串。
 */
function stripLegacyKnowledgeHubBlocks(content: string): string {
  let next = content
  while (true) {
    const begin = next.indexOf(LEGACY_KH_BEGIN)
    if (begin === -1) break
    const end = next.indexOf(LEGACY_KH_END, begin)
    if (end === -1) break
    const endComment = next.indexOf("-->", end)
    if (endComment === -1) break
    next = next.slice(0, begin) + next.slice(endComment + 3)
  }
  return next.replace(/\n{3,}/g, "\n\n").trim()
}

function cleanLegacyManagedDocument(path: string): void {
  if (!existsSync(path)) return
  const before = readFileSync(path, "utf8")
  const after = stripLegacyKnowledgeHubBlocks(before)
  if (after === before.trim()) return
  if (after) writeFileSync(path, `${after}\n`, "utf8")
  else rmSync(path, { force: true })
}

function removeLegacyOwnedFile(path: string): void {
  if (!existsSync(path)) return
  const content = readFileSync(path, "utf8")
  if (/knowledge-hub|smart_search|save_chat_insight/i.test(content)) rmSync(path, { force: true })
}

/**
 * v4 已下线 legacy knowledge-hub MCP。每次安装任一 shim 时顺手清理可明确归属旧系统的
 * 全局模板/管理块,以及当前项目的受管理规则；不扫描其他仓库,也不碰无 marker 的普通文档。
 */
function cleanupLegacyKnowledgeHubInstructions(opts?: ShimOpts): void {
  const home = effectiveHome(opts)
  const cwd = effectiveCwd(opts)

  removeLegacyOwnedFile(join(home, ".config", "opencode", "context-templates", "kh-instructions.md"))
  removeLegacyOwnedFile(join(home, ".config", "opencode", "rules", "knowledge-hub.mdc"))

  for (const path of [
    join(home, ".config", "opencode", "AGENTS.md"),
    join(home, ".claude", "CLAUDE.md"),
    join(home, ".codex", "AGENTS.md"),
    join(home, ".gemini", "GEMINI.md"),
    join(cwd, "AGENTS.md"),
    join(cwd, "CLAUDE.md"),
    join(cwd, "GEMINI.md"),
  ]) cleanLegacyManagedDocument(path)

  removeLegacyOwnedFile(join(cwd, ".cursor", "rules", "knowledge-hub.mdc"))
}

/** 装 per-repo pre-commit(git 硬护栏降级)。仅当 cwd 是 git 仓库时;非 git 静默跳过。 */
function installOpencodePreCommit(opts?: ShimOpts): void {
  const cwd = effectiveCwd(opts)
  const hookPath = preCommitHookPath(cwd)
  if (!hookPath) return // 非 git 仓库或 git 不可用 → 跳过(不阻断全局安装)
  const synapseScript = shimScriptPath("opencode", "pre-commit", opts)
  const synapseBlock = [
    OPENCODE_PRECOMMIT_BEGIN,
    `# Installed by: synapse install opencode`,
    `# Script: ${synapseScript}`,
    `if [ -f "${synapseScript}" ]; then`,
    `  sh "${synapseScript}" || exit $?`,
    `fi`,
    OPENCODE_PRECOMMIT_END,
  ].join("\n")

  mkdirSync(dirname(hookPath), { recursive: true })
  let existing = ""
  if (existsSync(hookPath)) existing = readFileSync(hookPath, "utf8")
  if (existing.includes(OPENCODE_PRECOMMIT_BEGIN)) return // 幂等
  const header = existing.startsWith("#!/") ? "" : "#!/bin/sh\n"
  const content = header + existing + (existing && !existing.endsWith("\n") ? "\n" : "") + synapseBlock + "\n"
  writeFileSync(hookPath, content, "utf8")
  try {
    chmodSync(hookPath, 0o755)
  } catch {
    // 非致命:chmod 失败不报错
  }
}

function installOpencode(opts?: ShimOpts): void {
  // ① 全局 plugin:拷 plugin.js → ~/.config/opencode/plugins/synapse.js
  const pluginSrc = opencodePluginSource(opts)
  if (!existsSync(pluginSrc)) {
    // plugin 源缺失(打包漏了)→ 如实报错,不静默(否则又是假阳性)。
    throw new Error(`opencode plugin source not found: ${pluginSrc}(bundle 是否打包了 shims/?)`)
  }
  const pluginDest = opencodePluginPath(opts)
  mkdirSync(dirname(pluginDest), { recursive: true })
  copyFileSync(pluginSrc, pluginDest)

  // ② per-repo pre-commit 纵深保护(cwd 是 git 仓库时才装)
  installOpencodePreCommit(opts)
}

function uninstallOpencode(opts?: ShimOpts): void {
  // ① 移除全局 plugin
  const pluginDest = opencodePluginPath(opts)
  if (existsSync(pluginDest)) rmSync(pluginDest, { force: true })

  // ② 移除当前仓库 pre-commit 的 Synapse block
  const cwd = effectiveCwd(opts)
  const hookPath = preCommitHookPath(cwd)
  if (hookPath && existsSync(hookPath)) {
    let content = readFileSync(hookPath, "utf8")
    const beginIdx = content.indexOf(OPENCODE_PRECOMMIT_BEGIN)
    const endIdx = content.indexOf(OPENCODE_PRECOMMIT_END)
    if (beginIdx !== -1 && endIdx !== -1) {
      const before = content.slice(0, beginIdx)
      const after = content.slice(endIdx + OPENCODE_PRECOMMIT_END.length)
      content = (before + after).replace(/\n{3,}/g, "\n\n").trimEnd()
      writeFileSync(hookPath, content ? content + "\n" : "", "utf8")
    }
  }
}

/**
 * opencode「已安装」= 全局 plugin 装好(cwd 无关):
 *   ~/.config/opencode/plugins/synapse.js 存在。
 * 不再查 per-repo pre-commit —— 那是 cwd 相关的 git 兜底,不代表全局集成是否成功。
 */
function isInstalledOpencode(opts?: ShimOpts): boolean {
  return existsSync(opencodePluginPath(opts))
}

// ─────────────────────────────────────────────────────────────────────────────
// 公共 API
// ─────────────────────────────────────────────────────────────────────────────

export type ClientId = "claude-code" | "codex" | "gemini-cli" | "opencode" | "kimi-code"

const INSTALL_MAP: Record<ClientId, (opts?: ShimOpts) => void> = {
  "claude-code": installClaudeCode,
  codex: installCodex,
  "gemini-cli": installGeminiCli,
  opencode: installOpencode,
  "kimi-code": installKimiCode,
}
const UNINSTALL_MAP: Record<ClientId, (opts?: ShimOpts) => void> = {
  "claude-code": uninstallClaudeCode,
  codex: uninstallCodex,
  "gemini-cli": uninstallGeminiCli,
  opencode: uninstallOpencode,
  "kimi-code": uninstallKimiCode,
}
const IS_INSTALLED_MAP: Record<ClientId, (opts?: ShimOpts) => boolean> = {
  "claude-code": isInstalledClaudeCode,
  codex: isInstalledCodex,
  "gemini-cli": isInstalledGeminiCli,
  opencode: isInstalledOpencode,
  "kimi-code": isInstalledKimiCode,
}

/**
 * 安装 shim:把该客户端的 hook 配置指向 Synapse shim 脚本。
 * 幂等、不破坏已有配置(合并语义)。
 * @throws 若 client 不在支持列表
 */
export function installShim(client: ClientId, opts?: ShimOpts): void {
  const fn = INSTALL_MAP[client]
  if (!fn) throw new Error(`unsupported client: ${client}`)
  cleanupLegacyKnowledgeHubInstructions(opts)
  fn(opts)
}

/**
 * 卸载 shim:只移除 Synapse 注入的部分,保留用户已有其他 hooks。
 * @throws 若 client 不在支持列表
 */
export function uninstallShim(client: ClientId, opts?: ShimOpts): void {
  const fn = UNINSTALL_MAP[client]
  if (!fn) throw new Error(`unsupported client: ${client}`)
  fn(opts)
}

/**
 * 检查 shim 是否已安装(装前 false,装后 true)。
 * @throws 若 client 不在支持列表
 */
export function isShimInstalled(client: ClientId, opts?: ShimOpts): boolean {
  const fn = IS_INSTALLED_MAP[client]
  if (!fn) throw new Error(`unsupported client: ${client}`)
  return fn(opts)
}

/**
 * 某 client 的 guard hook 「命令路径集」——与当前平台实际执行字段的值**完全一致**
 * (否则 isShimInstalledInJson 的「配置引用 + 文件存在」双校验命中不了):
 *   - claude-code:ccInstalledPaths(win32 gitbash→正斜杠 POSIX / 无 gitbash→.cmd / POSIX→sh)
 *   - codex:win32→commandWindows 的 .cmd / POSIX→command 的 sh
 *   - gemini-cli:resolveShimInstalledPaths(win32→.cmd / POSIX→sh)
 *   - opencode:guard 在全局 plugin 内，不使用命令路径
 */
function guardCommandPaths(client: ClientId, opts?: ShimOpts): string[] {
  switch (client) {
    case "claude-code":
      return ccInstalledPaths(["guard"], opts)
    case "codex":
      return effectivePlatform(opts) === "win32"
        ? resolveShimInstalledPaths("codex", ["guard"], opts)
        : [shimScriptPath("codex", "guard", opts)]
    case "gemini-cli":
      return resolveShimInstalledPaths("gemini-cli", ["guard"], opts)
    case "kimi-code":
      return resolveShimInstalledPaths("kimi-code", ["guard"], opts)
    case "opencode":
      return []
  }
}

/**
 * guard hook 是否**真正接线**(去 doctor「假绿」的核心)。
 *
 * 双校验(与 isShimInstalledInJson 同款,缺一即 false):
 *   ① 该 client 配置文件的当前平台命令字段确实指向其 guard 薄壳;
 *   ② 该 guard 薄壳脚本在磁盘上真实存在。
 *
 * 为什么必须有它:doctor 旧逻辑用 hardGuardCapable(静态清单 claude/codex/gemini 恒 true)
 * + isShimInstalled(只查 inject/report)判 hardGuard → codex/gemini 只装了 inject/report
 * 就被假报 hard-guard=yes,而它们的配置里根本没接 guard。此函数直接问「guard 到底接没接」。
 *
 * opencode 不走 JSON 配置/命令薄壳；必须检查已安装 plugin 的真实内容包含
 * tool.execute.before，避免旧版只有 inject/report 的 plugin 被误报为已接线。
 * 任何异常降级 false(不让 doctor 崩)。
 */
export function isGuardWired(client: ClientId, opts?: ShimOpts): boolean {
  try {
    if (client === "opencode") {
      const plugin = opencodePluginPath(opts)
      return existsSync(plugin)
        && /["']tool\.execute\.before["']\s*:/.test(readFileSync(plugin, "utf8"))
    }
    if (client === "kimi-code") {
      const [guard] = guardCommandPaths(client, opts)
      return existsSync(guard)
        && kimiInstalledHooks(opts).some((hook) =>
          hook["event"] === "PreToolUse" && hook["matcher"] === "*" && hook["command"] === kimiExpectedHookCommand(guard, opts),
        )
    }
    const paths = guardCommandPaths(client, opts)
    if (paths.length === 0) return false
    const configPath = clientConfigPath(client, opts)
    const commandField = client === "codex" && effectivePlatform(opts) === "win32"
      ? "commandWindows"
      : "command"
    return isShimInstalledInJson(configPath, client, paths, commandField)
  } catch {
    return false
  }
}
