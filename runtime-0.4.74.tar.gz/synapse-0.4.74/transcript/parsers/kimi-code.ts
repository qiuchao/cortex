/** Kimi Code CLI agents/main/wire.jsonl -> canonical corpus messages. */

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

export interface KimiWireParseResult {
  messages: Array<Record<string, unknown>>
  /** False when the chunk ends in an open model step and must be retried from the same byte offset. */
  complete: boolean
}

function visibleUserMessage(message: Record<string, unknown>): boolean {
  const origin = isRecord(message["origin"]) ? message["origin"] : undefined
  const kind = origin?.["kind"]
  if (kind === undefined || kind === "user") return true
  if (kind === "skill_activation" || kind === "plugin_command") return origin?.["trigger"] === "user-slash"
  return kind === "shell_command" && origin?.["phase"] === "input"
}

function withTimestamp(message: Record<string, unknown>, time: unknown): Record<string, unknown> {
  return { ...message, ...(time !== undefined ? { timestamp: time } : {}) }
}

function toolResultMessage(event: Record<string, unknown>, time: unknown): Record<string, unknown> | undefined {
  const toolCallId = typeof event["toolCallId"] === "string" ? event["toolCallId"] : ""
  const result = isRecord(event["result"]) ? event["result"] : undefined
  if (!toolCallId || !result) return undefined
  const output = result["output"]
  const content = typeof output === "string"
    ? [{ type: "text", text: output }]
    : Array.isArray(output) ? output : []
  return withTimestamp({
    id: `${toolCallId}:result`,
    role: "tool",
    content,
    toolCalls: [],
    toolCallId,
    ...(result["isError"] !== undefined ? { isError: result["isError"] } : {}),
    ...(result["note"] !== undefined ? { note: result["note"] } : {}),
  }, time)
}

/**
 * Kimi 0.33 persists user/system messages directly, but assembles assistant messages
 * through context.append_loop_event records. Rebuild the same role/content/toolCalls
 * boundary that Kimi uses when replaying a session.
 */
export function parseKimiWireChunk(records: unknown[]): KimiWireParseResult {
  const messages: Array<Record<string, unknown>> = []
  const openSteps = new Map<string, Record<string, unknown>>()

  function openStep(stepUuid: string, time: unknown): Record<string, unknown> {
    const existing = openSteps.get(stepUuid)
    if (existing) return existing
    const message = withTimestamp({ role: "assistant", content: [], toolCalls: [] }, time)
    messages.push(message)
    openSteps.set(stepUuid, message)
    return message
  }

  for (const record of records) {
    if (!isRecord(record)) continue
    if (record["type"] === "context.append_message") {
      const message = record["message"]
      if (!isRecord(message)) continue
      const role = message["role"]
      if (role !== "user" && role !== "assistant" && role !== "system" && role !== "tool") continue
      if (role === "user" && !visibleUserMessage(message)) continue
      messages.push(withTimestamp(message, record["time"]))
      continue
    }
    if (record["type"] !== "context.append_loop_event") continue
    const event = record["event"]
    if (!isRecord(event)) continue
    const eventType = event["type"]
    if (eventType === "step.begin") {
      if (typeof event["uuid"] === "string") openStep(event["uuid"], record["time"])
      continue
    }
    if (eventType === "content.part") {
      if (typeof event["stepUuid"] !== "string" || !isRecord(event["part"])) continue
      const message = openStep(event["stepUuid"], record["time"])
      ;(message["content"] as unknown[]).push(event["part"])
      continue
    }
    if (eventType === "tool.call") {
      if (typeof event["stepUuid"] !== "string" || typeof event["toolCallId"] !== "string" || typeof event["name"] !== "string") continue
      const message = openStep(event["stepUuid"], record["time"])
      ;(message["toolCalls"] as unknown[]).push({
        type: "function",
        id: event["toolCallId"],
        name: event["name"],
        arguments: event["args"] === undefined ? null : JSON.stringify(event["args"]),
      })
      continue
    }
    if (eventType === "tool.result") {
      const message = toolResultMessage(event, record["time"])
      if (message) messages.push(message)
      continue
    }
    if (eventType === "step.end" && typeof event["uuid"] === "string") {
      const message = openSteps.get(event["uuid"])
      if (!message) continue
      if (typeof event["messageId"] === "string") message["id"] = event["messageId"]
      if (isRecord(event["usage"])) message["usage"] = event["usage"]
      openSteps.delete(event["uuid"])
      const content = message["content"] as unknown[]
      const toolCalls = message["toolCalls"] as unknown[]
      if (content.length === 0 && toolCalls.length === 0) messages.splice(messages.indexOf(message), 1)
    }
  }

  const incomplete = new Set(openSteps.values())
  return {
    messages: messages.filter((message) => !incomplete.has(message)),
    complete: openSteps.size === 0,
  }
}

export function parseKimiWireRecords(records: unknown[]): unknown[] {
  return parseKimiWireChunk(records).messages
}
