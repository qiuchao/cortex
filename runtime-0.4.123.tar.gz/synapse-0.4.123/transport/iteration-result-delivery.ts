/** Authenticated, bounded iteration transport. Identity never comes from a tool argument. */
import { createHash } from "node:crypto"
import type { z } from "zod"
import { IterationDeliveryErrorSchema, type IterationDeliveryBinding } from "@cerebro/wire"
import { getBrainConfig } from "./brain-config.ts"
import { AGENT_JSON_BRIDGE_MAX_BYTES, readAgentJsonStream } from "../runtime/agent-json-transfer.ts"

export function iterationRequestHash(value: unknown): string {
  // The wire projection contains JSON values only; defaults must be parsed first.
  const canonical = (v: unknown): string => {
    if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`
    if (v !== null && typeof v === "object") return `{${Object.keys(v).sort().filter(k => (v as Record<string, unknown>)[k] !== undefined)
      .map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}`
    const result = JSON.stringify(v)
    if (result === undefined) throw new TypeError("invalid canonical JSON")
    return result
  }
  return createHash("sha256").update(canonical(value)).digest("hex")
}

export function createIterationDeliveryTransport(env: NodeJS.ProcessEnv, fetchImpl: typeof fetch = fetch) {
  return async <T>(path: string, schema: z.ZodType<T>, body?: unknown, binding?: IterationDeliveryBinding, signal?: AbortSignal): Promise<T> => {
    const cfg = getBrainConfig(env)
    if (!cfg?.machineToken) throw new Error("iteration delivery unavailable")
    const response = await fetchImpl(`${cfg.brainBaseUrl}${path}`, {
      method: body === undefined ? "GET" : "POST", redirect: "error",
      headers: { Authorization: `Bearer ${cfg.machineToken}`, "Content-Type": "application/json",
        ...(binding ? { "X-Cerebro-Iteration-Binding": Buffer.from(JSON.stringify(binding)).toString("base64url") } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.any([AbortSignal.timeout(3500), ...(signal ? [signal] : [])]),
    })
    if (!response.body) throw new Error("iteration delivery empty response")
    const text = await readAgentJsonStream(response.body, path === "/brain/legacy-task-admission" ? AGENT_JSON_BRIDGE_MAX_BYTES : 512 * 1024)
    const raw: unknown = JSON.parse(text ?? "")
    if (!response.ok || IterationDeliveryErrorSchema.safeParse(raw).success) throw new Error("iteration delivery unavailable")
    signal?.throwIfAborted()
    return schema.parse(raw)
  }
}
