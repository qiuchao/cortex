/**
 * transcript/loop.ts —— 训练语料流的运行时激活:周期扫描 → 上传,并消费 nudge_sync 优先队列。
 *
 * 方案 §3 Phase 5 gate("new turns aggregate by user_id within window")要求语料流在运行时
 * **真的跑起来**。scanner/backfill 是库;这里是把它们接到常驻生命周期的那根线:
 *   - 每 intervalMs 跑一次 scanOnce(稳态:mtime-age gate 生效,只碰不再变动的文件);
 *   - 把结果交给可注入 uploader(默认 noop —— brain 协议 out of scope,不真正上传);
 *   - nudge_sync 到达后按 mtime 安全窗提前触发一次扫描，不再只消费遥测信号。
 *
 * 单向、后台、绝不阻塞任何一轮对话(spec §263):失败吞掉,下周期重试。
 */
import { scanOnce, type ClientScanConfig } from "./scanner.ts"
import { uploadRecords, type TranscriptUploader, noopUploader } from "./upload.ts"
import { buildDirectoryManifest, type DirectorySyncClient } from "./directories.ts"
import type { CursorStore } from "./cursor.ts"
import type { SyncPriorityQueue } from "../core/handlers/nudge-sync.ts"
import { createTranscriptScanWorker, type TranscriptScanPort } from "./scan-worker-client.ts"

export interface TranscriptLoopOptions {
  cursors: CursorStore
  /** user_id 权威来源;null → 本轮跳过(绝不用错身份上传) */
  resolveUserId: () => string | null
  /** machineId 权威来源;目录开关启用时缺失则 fail-closed（不上内容） */
  resolveMachineId?: () => string | undefined
  /** 目录清单/开关同步；生产 runtime 注入，测试可不注入以保留旧扫描语义 */
  directorySync?: DirectorySyncClient
  uploader?: TranscriptUploader
  syncQueue?: SyncPriorityQueue
  configs?: ClientScanConfig[]
  /** 稳态 mtime-age gate(默认 10s) */
  minAgeMs?: number
  now?: () => number
  /** 运行时默认使用常驻 worker；直接 runTranscriptTick 的单测可省略并走同步实现。 */
  scanPort?: TranscriptScanPort
  /** 生产 runtime 设置后，扫描、批处理、JSON 序列化和 HTTP 上传全部留在 worker。 */
  workerUploadEnv?: NodeJS.ProcessEnv
}

export interface TranscriptLoopHandle {
  /** 手动跑一轮(测试/立即触发用) */
  tick: () => Promise<{ scanned: number; uploaded: number; prioritized: string[] }>
  stop: () => void
}

export async function runTranscriptTick(
  opts: TranscriptLoopOptions,
): Promise<{ scanned: number; uploaded: number; prioritized: string[] }> {
  const minAgeMs = opts.minAgeMs ?? 10_000
  // 未达到安全窗的 nudge 保留在队列；由订阅定时器提前触发后续 tick。
  const prioritized = opts.syncQueue ? opts.syncQueue.drain(minAgeMs, opts.now?.() ?? Date.now()) : []

  const userId = opts.resolveUserId()
  if (!userId) {
    const scanOptions = {
      configs: opts.configs,
      cursors: opts.cursors,
      userId,
      minAgeMs,
      now: opts.now,
      stageCursorUpdates: true,
    }
    const res = opts.scanPort ? await opts.scanPort.scan(scanOptions) : scanOnce(scanOptions)
    return { scanned: res.records.length, uploaded: 0, prioritized }
  }

  const machineId = opts.resolveMachineId?.()
  let enabledProjectPaths: Set<string> | undefined
  let projectPathByFile: Map<string, string> | undefined
  if (opts.directorySync) {
    if (!machineId) {
      enabledProjectPaths = new Set<string>()
    } else {
      const manifestOptions = { configs: opts.configs, machineId }
      const manifestResult = opts.scanPort
        ? await opts.scanPort.buildManifest(manifestOptions)
        : buildDirectoryManifest(manifestOptions)
      projectPathByFile = manifestResult.projectPathByFile
      try {
        enabledProjectPaths = await opts.directorySync.sync(manifestResult.request, machineId)
      } catch {
        enabledProjectPaths = new Set<string>()
      }
    }
  }
  const scanOptions = {
    configs: opts.configs,
    cursors: opts.cursors,
    userId,
    minAgeMs,
    enabledProjectPaths,
    projectPathByFile,
    stageCursorUpdates: true,
    now: opts.now,
  }
  if (opts.scanPort?.scanAndUpload && opts.workerUploadEnv) {
    const result = await opts.scanPort.scanAndUpload(scanOptions, opts.workerUploadEnv)
    commitCursorUpdates(opts.cursors, result.cursorUpdates, result.scanned === 0 || result.upload.ok)
    return {
      scanned: result.scanned,
      uploaded: result.upload.ok ? result.upload.uploaded : 0,
      prioritized,
    }
  }

  const res = opts.scanPort ? await opts.scanPort.scan(scanOptions) : scanOnce(scanOptions)

  let uploaded = 0
  if (res.records.length > 0) {
    const up = await uploadRecords(res.records, opts.uploader ?? noopUploader)
    // 只有上传成功才持久化游标(uploader 失败 → 下轮重试,不丢)
    if (up.ok) {
      commitCursorUpdates(opts.cursors, res.cursorUpdates, true)
      uploaded = up.uploaded
    }
  } else if (Object.keys(res.cursorUpdates).length > 0) {
    // scanner 对明确非会话格式(retry:false)的文件会产生安全跳过游标。
    // 它不依赖内容上传成功，必须提交，否则 daemon 每轮都会重复解析同一文件。
    commitCursorUpdates(opts.cursors, res.cursorUpdates, true)
  }
  return { scanned: res.records.length, uploaded, prioritized }
}

function commitCursorUpdates(
  cursors: CursorStore,
  updates: Record<string, NonNullable<ReturnType<CursorStore["get"]>>>,
  commit: boolean,
): void {
  if (!commit || Object.keys(updates).length === 0) return
  for (const [file, cursor] of Object.entries(updates)) cursors.set(file, cursor)
  cursors.save()
}

/** 启动周期语料扫描循环(运行时内部定时任务)。默认 30s。 */
export function startTranscriptLoop(
  opts: TranscriptLoopOptions,
  intervalMs = 30_000,
): TranscriptLoopHandle {
  const scanPort = opts.scanPort ?? createTranscriptScanWorker()
  const loopOpts = { ...opts, scanPort }
  let stopped = false
  let timer: ReturnType<typeof setTimeout> | null = null
  let nudgeTimer: ReturnType<typeof setTimeout> | null = null
  let current: Promise<{ scanned: number; uploaded: number; prioritized: string[] }> | null = null

  const runSingle = () => {
    if (!current) {
      current = runTranscriptTick(loopOpts).finally(() => {
        current = null
      })
    }
    return current
  }

  const schedule = () => {
    if (stopped) return
    timer = setTimeout(() => {
      void runSingle()
        .catch(() => undefined)
        .finally(schedule)
    }, intervalMs)
    if (typeof timer === "object" && timer && "unref" in timer) {
      ;(timer as { unref: () => void }).unref()
    }
  }
  schedule()
  const scheduleNudge = () => {
    if (stopped || !opts.syncQueue) return
    const waitMs = opts.syncQueue.nextReadyIn(opts.minAgeMs ?? 10_000, opts.now?.() ?? Date.now())
    if (waitMs === null) return
    if (nudgeTimer) clearTimeout(nudgeTimer)
    nudgeTimer = setTimeout(() => {
      nudgeTimer = null
      void runSingle()
        .catch(() => undefined)
        .finally(scheduleNudge)
    }, waitMs + 25)
    if (typeof nudgeTimer === "object" && nudgeTimer && "unref" in nudgeTimer) {
      ;(nudgeTimer as { unref: () => void }).unref()
    }
  }
  const unsubscribeNudge = opts.syncQueue?.subscribe?.(scheduleNudge)

  return {
    tick: runSingle,
    stop: () => {
      if (stopped) return
      stopped = true
      if (timer) clearTimeout(timer)
      if (nudgeTimer) clearTimeout(nudgeTimer)
      unsubscribeNudge?.()
      scanPort.stop()
    },
  }
}
