/** Transport-only metadata for a turn-scoped typed capability execution. */
export const SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER = "x-synapse-turn-token" as const

/** Explicit opt-in for the narrow standalone capability execution path. */
export const SYNAPSE_CAPABILITY_EXECUTION_SCOPE_HEADER = "x-synapse-execution-scope" as const
export const SYNAPSE_STANDALONE_EXECUTION_SCOPE = "standalone" as const

/** @deprecated Use SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER. */
export const SYNAPSE_TASK_TURN_TOKEN_HEADER = SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER
