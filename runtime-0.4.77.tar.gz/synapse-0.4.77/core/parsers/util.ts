/**
 * core/parsers/util.ts —— parser 共用的纯 helper(去重;评审 DRY)。
 *
 * 注意:**事件→verb / 字段名映射是有意的 per-client 重复,保留在各 parser 里**
 * (adapter 模式的核心)。这里只抽取与 client 无关的取值 helper。
 */
import { fileURLToPath } from "node:url"
import type { AttachmentObservation, InjectAttachment } from "../../transport/contract.ts"


/** 宽松读第一个存在的 string 字段(变参 = 兼容各家不同字段名)。 */
export function str(o: Record<string, unknown>, ...keys: string[]): string {
  for (const k of keys) {
    const v = o[k]
    if (typeof v === "string" && v) return v
  }
  return ""
}

/** 读取可选的非空字符串；适合路径和 ID，避免把空白值送入契约。 */
export function optionalStr(o: Record<string, unknown>, ...keys: string[]): string | undefined {
  const value = str(o, ...keys).trim()
  return value || undefined
}

/** 把任意值收敛成对象(非对象 → 空对象),供解析容错。 */
export function asObject(raw: unknown): Record<string, unknown> {
  return raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {}
}

export interface ParsedAttachments {
  files?: InjectAttachment[]
  observation: AttachmentObservation
  error?: string
}

const MAX_ATTACHMENTS = 20

export function nestedStr(raw: unknown, ...path: string[]): string {
  let current: unknown = raw
  for (const key of path) current = asObject(current)[key]
  return typeof current === "string" && current ? current : ""
}

export function transcriptTail(raw: unknown): Array<{ role: string; text: string; tool_use?: unknown; tool_result?: unknown }> | undefined {
  const value = asObject(raw)["transcript_tail"] ?? asObject(raw)["transcriptTail"]
  if (!Array.isArray(value)) return undefined
  const tail = value
    .map((item) => {
      const o = asObject(item)
      const role = str(o, "role")
      const text = str(o, "text", "content")
      if (!role || !text) return null
      const entry: { role: string; text: string; tool_use?: unknown; tool_result?: unknown } = { role, text }
      if ("tool_use" in o) entry.tool_use = o["tool_use"]
      if ("toolUse" in o) entry.tool_use = o["toolUse"]
      if ("tool_result" in o) entry.tool_result = o["tool_result"]
      if ("toolResult" in o) entry.tool_result = o["toolResult"]
      return entry
    })
    .filter((item): item is { role: string; text: string; tool_use?: unknown; tool_result?: unknown } => item !== null)
  return tail.length ? tail.slice(-8) : undefined
}

export function supportRails(raw: unknown): Record<string, unknown> | undefined {
  const o = asObject(raw)
  const value = o["support_rails"] ?? o["supportRails"]
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : undefined
}

export function parseAttachments(raw: unknown, completeParts = false): ParsedAttachments {
  const object = asObject(raw)
  const parts = object["parts"]
  const partFiles = Array.isArray(parts) ? parts.flatMap((item) => {
    const entry = asObject(item)
    const kind = str(entry, "type", "kind").toLowerCase()
    return kind === "file" || kind === "attachment" ? [entry] : []
  }) : []
  const candidates = [
    object["attachments"],
    object["files"],
    asObject(object["message"])["attachments"],
    asObject(object["prompt"])["attachments"],
  ]
  const explicit = candidates.find((value) => Array.isArray(value))
  const value = explicit ?? partFiles
  if (!Array.isArray(value)) return { observation: "unknown" }
  if (value.length > MAX_ATTACHMENTS) {
    return { observation: "present", error: `Synapse supports at most ${MAX_ATTACHMENTS} attachments per turn` }
  }
  let invalid = false
  const result = value.flatMap((item) => {
    if (typeof item === "string" && item.trim()) return [{ path: item.trim() }]
    const entry = asObject(item)
    const path = localAttachmentPath(entry)
    if (!path) {
      invalid = true
      return []
    }
    const fileName = str(entry, "fileName", "filename", "name") || undefined
    const mimeType = str(entry, "mimeType", "mime") || undefined
    return [{ path, ...(fileName ? { fileName } : {}), ...(mimeType ? { mimeType } : {}) }]
  })
  if (invalid) return { observation: "present", error: "Synapse could not safely resolve every reported attachment" }
  if (result.length > 0) return { files: result, observation: "present" }
  if (partFiles.length > 0) return { observation: "present" }
  return { observation: explicit !== undefined || (completeParts && Array.isArray(parts)) ? "none" : "unknown" }
}

export function mergeParsedAttachments(
  left: ParsedAttachments,
  right: ParsedAttachments,
): ParsedAttachments {
  if (left.error || right.error) {
    return { observation: "present", error: left.error ?? right.error }
  }
  const files = [...(left.files ?? []), ...(right.files ?? [])]
    .filter((file, index, all) => all.findIndex((candidate) => candidate.path === file.path) === index)
  if (files.length > MAX_ATTACHMENTS) {
    return { observation: "present", error: `Synapse supports at most ${MAX_ATTACHMENTS} attachments per turn` }
  }
  if (files.length) return { files, observation: "present" }
  if (left.observation === "present" || right.observation === "present") return { observation: "present" }
  if (left.observation === "none" && right.observation === "none") return { observation: "none" }
  return { observation: "unknown" }
}

function localAttachmentPath(entry: Record<string, unknown>): string {
  const direct = str(entry, "path", "filePath", "file_path")
  if (direct) return direct
  const url = str(entry, "url")
  if (!url.toLowerCase().startsWith("file:")) return ""
  try {
    return fileURLToPath(url)
  } catch {
    return ""
  }
}

export interface StableTurnIdentity {
  client: string
  sessionId: string
  messageId?: string
  conversationId?: string
  currentText: string
}

export function stableTurnAnchor(
  raw: unknown,
  fallback: StableTurnIdentity,
  ...candidates: string[]
): string | undefined {
  const o = asObject(raw)
  for (const key of candidates) {
    const direct = str(o, key)
    if (direct) return direct
  }
  const nested = [
    nestedStr(o, "message", "id"),
    nestedStr(o, "message", "messageID"),
    nestedStr(o, "request", "id"),
    nestedStr(o, "hook", "request_id"),
  ].find(Boolean)
  if (nested) return nested

  return stableFallbackTurnId(fallback)
}

export function stableFallbackTurnId(identity: StableTurnIdentity): string {
  const canonical = JSON.stringify({
    client: identity.client,
    sessionId: identity.sessionId,
    messageId: identity.messageId || null,
    conversationId: identity.conversationId || null,
    currentText: identity.currentText,
  })
  return `payload:${fnv1a(canonical)}`
}

function fnv1a(text: string): string {
  let hash = 0x811c9dc5
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i)
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, "0")
}
