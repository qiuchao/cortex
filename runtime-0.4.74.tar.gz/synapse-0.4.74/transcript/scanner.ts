/**
 * transcript/scanner.ts —— 训练语料流:扫各客户端本地会话文件 → 增量产出 TranscriptRecord。
 *
 * 方案 §3 Phase 5 / spec §83-86:零新增 hook(直接读文件)。回填与稳态**同一套逻辑**。
 *
 * torn-read 守卫(R5/R7):
 *   (a) mtime-age gate:只摄入 mtime 早于 N 秒的 session(正在写的不碰);
 *   (b) JSONL(CC/Codex):parseJsonlSafe 只到最后完整行,游标记 byteOffset;
 *   (c) 整文件 JSON(opencode):parseWholeJsonSafe,parse 失败跳过+下 tick 重试;
 *   (d) 游标只前进到完全解析过的记录。
 */
import {
  readdirSync,
  statSync,
  lstatSync,
  realpathSync,
  readFileSync,
  existsSync,
  openSync,
  readSync,
  closeSync,
} from "node:fs"
import { join, extname, resolve, sep } from "node:path"
import { homedir } from "node:os"
import { parseJsonlSafe } from "./parsers/jsonl.ts"
import { parseWholeJsonSafe } from "./parsers/json.ts"
import { parseCopilotFile } from "./parsers/copilot.ts"
import type { CopilotRequest } from "./parsers/copilot.ts"
import { normalizeDirectoryPath } from "./path.ts"
import { extractSessionTitle, normalizeSessionTitle } from "./title.ts"
import { TRANSCRIPT_CURSOR_GENERATION, type CursorStore } from "./cursor.ts"
import { parseGeminiSessionFile } from "./adapters/gemini.ts"
import { listOpenCodeSessions, loadOpenCodeMessages } from "./adapters/opencode.ts"
import { listCursorSessions, loadCursorMessages } from "./adapters/cursor.ts"
import { isKimiMainWire, readKimiSessionMetadata } from "./adapters/kimi-code.ts"
import { parseKimiWireChunk } from "./parsers/kimi-code.ts"

const PROJECT_PATH_PREFIX_BYTES = 256 * 1024

export type TranscriptFormat = "jsonl" | "json" | "gemini" | "copilot" | "kimi-code" | "opencode-sqlite" | "cursor-sqlite"

export interface ClientScanConfig {
  client: string
  /** 会话文件所在目录(glob 由 scanner 自行浅遍历) */
  roots: string[]
  format: TranscriptFormat
  /** 只收哪些扩展名 */
  ext: string[]
}

/**
 * 跨平台推断 VS Code User 数据目录。
 * mac: ~/Library/Application Support/Code/User
 * win: %APPDATA%\Code\User (WSL 下映射为 /mnt/c/Users/<u>/AppData/Roaming/Code/User)
 * linux: ~/.config/Code/User
 */
function vscodeUserDir(home: string): string {
  const platform = process.platform
  if (platform === "darwin") {
    return join(home, "Library", "Application Support", "Code", "User")
  }
  if (platform === "win32") {
    const appData = process.env["APPDATA"]
    return appData ? join(appData, "Code", "User") : join(home, "AppData", "Roaming", "Code", "User")
  }
  // linux(含 WSL native)
  // WSL 下若要扫宿主机 Windows 侧的 Copilot 数据,路径为 /mnt/c/Users/<username>/AppData/Roaming/Code/User;
  // 此处先用 linux 路径(WSL native linux Code),宿主机 Windows 侧可后续由用户配置 allowlist 注入。
  return join(home, ".config", "Code", "User")
}

function cursorUserDir(home: string): string {
  if (process.platform === "darwin") return join(home, "Library", "Application Support", "Cursor", "User")
  if (process.platform === "win32") {
    const appData = process.env["APPDATA"]
    return appData ? join(appData, "Cursor", "User") : join(home, "AppData", "Roaming", "Cursor", "User")
  }
  return join(home, ".config", "Cursor", "User")
}

function opencodeDatabaseRoots(home: string): string[] {
  const roots = [join(home, ".local", "share", "opencode", "opencode.db")]
  if (process.platform === "darwin") {
    roots.unshift(join(home, "Library", "Application Support", "opencode", "opencode.db"))
  } else if (process.platform === "win32") {
    const appData = process.env["APPDATA"]
    const localAppData = process.env["LOCALAPPDATA"]
    if (appData) roots.unshift(join(appData, "opencode", "opencode.db"))
    if (localAppData) roots.unshift(join(localAppData, "opencode", "opencode.db"))
  }
  return [...new Set(roots)]
}

function kimiCodeHome(home: string): string {
  return process.env["KIMI_CODE_HOME"] ?? join(home, ".kimi-code")
}

/** 各客户端本地会话存储路径(spec §248-254)。~ 展开为 homedir。 */
export function defaultScanConfigs(home = homedir()): ClientScanConfig[] {
  return [
    { client: "claude-code", roots: [join(home, ".claude", "projects")], format: "jsonl", ext: [".jsonl"] },
    { client: "codex", roots: [join(home, ".codex", "sessions"), join(home, ".codex")], format: "jsonl", ext: [".jsonl"] },
    { client: "opencode", roots: opencodeDatabaseRoots(home), format: "opencode-sqlite", ext: [".db"] },
    { client: "gemini-cli", roots: [join(home, ".gemini", "tmp")], format: "gemini", ext: [".json", ".jsonl"] },
    // copilot:会话存在 workspaceStorage/{hash}/chatSessions/{sessionId}.jsonl
    // 使用 copilot 格式:第一行 kind:0 快照持有完整对话;整文件 mtime+size 游标(与 json 路径相同)。
    { client: "copilot", roots: [join(vscodeUserDir(home), "workspaceStorage")], format: "copilot", ext: [".jsonl"] },
    // Cursor 只接对话语料采集；per-turn inject 仍按 DECISIONS D1 保持 deferred。
    { client: "cursor", roots: [join(cursorUserDir(home), "globalStorage", "state.vscdb")], format: "cursor-sqlite", ext: [".vscdb"] },
    // Kimi Code stores the main agent transcript at
    // sessions/<workdir-key>/<sessionId>/agents/main/wire.jsonl.
    { client: "kimi-code", roots: [join(kimiCodeHome(home), "sessions")], format: "kimi-code", ext: [".jsonl"] },
    // antigravity 暂缓接入(当前无成员使用)。复活时:加回一条 config,候选路径
    //   ~/.gemini/antigravity/conversations/ 存 *.pb(Protocol Buffer,非 json/jsonl,需专用 pb 解析器);
    //   证据见 git 历史 / docs/DECISIONS.md,且需装 agy CLI 实测确认(原 open-question #2)。
  ]
}

/** TranscriptRecord —— 上传单元(新数据模型,不复用任务/KH 结构;spec §262)。 */
export interface TranscriptRecord {
  user_id: string
  /** 历史字段:会话文件所在的存储目录标签（不作为 POST project_path 使用）。 */
  project: string
  /** 会话原始记录中可验证的实际绝对 cwd/project_path；无法可靠提取则为空。 */
  project_path?: string
  session_id: string
  client: string
  /** 客户端提供的会话标题；缺失时由 Cerebro 从首条有效用户消息派生。 */
  title?: string
  timestamp: string
  messages: unknown[]
  /**
   * JSONL 客户端专用:本批 messages[0] 在文件中的**绝对行序号**（0-based 累计）。
   * uploader 用 seqBase + chunk-index 派生 source_message_id，保证跨轮文件绝对稳定。
   * 整文件客户端（json/copilot）全量快照，seqBase 恒为 0，messages 恒为全量。
   */
  seqBase: number
}

export interface ScanOptions {
  configs?: ClientScanConfig[]
  cursors: CursorStore
  /** user_id 权威来源(null → 跳过,绝不用错身份上传) */
  userId: string | null
  /** mtime-age gate:只摄入早于这么多毫秒的文件(默认 10s) */
  minAgeMs?: number
  /** 路径白名单:只扫这些前缀下的文件(回填安全);空=全部允许 */
  allowlist?: string[]
  /**
   * 项目上传开关白名单:稳态只产出当前 machineId enabled=true 的实际 project_path。
   * undefined = 不按目录开关过滤（测试/回填兼容）；空 Set = 全部内容不上传。
   */
  enabledProjectPaths?: Set<string>
  /** 本 tick manifest 已解析出的 file → project_path，用于避免 scanner 再读 JSONL 前缀。 */
  projectPathByFile?: Map<string, string>
  /**
   * true 时不直接写入 CursorStore，而是把游标更新放到 ScanResult.cursorUpdates。
   * 运行时上传成功后再提交，避免 uploader ok:false 时同一 CursorStore 内存游标已推进导致丢重试。
   */
  stageCursorUpdates?: boolean
  /** 当前时间(测试注入);默认 Date.now */
  now?: () => number
}

export interface ScanResult {
  records: TranscriptRecord[]
  /** stageCursorUpdates=true 时待提交的游标更新；否则仅作调试镜像。 */
  cursorUpdates: Record<string, NonNullable<ReturnType<CursorStore["get"]>>>
  /** 因 mtime-age gate 跳过的文件数 */
  skippedTooNew: number
  /** 因 torn/parse 失败跳过(将下 tick 重试)的文件数 */
  skippedTornOrBad: number
  /** 因白名单被拒的文件数 */
  skippedNotAllowed: number
  /** 因目录开关未启用或无法提取实际绝对 project_path 跳过的会话文件数 */
  skippedProjectDisabled: number
  /** 因 userId 缺失整体跳过 */
  skippedNoUser: boolean
}

/** 浅遍历一个 root 下所有符合扩展名的文件(递归)。 */
export function collectFiles(root: string, ext: string[]): string[] {
  if (!existsSync(root)) return []
  try {
    if (lstatSync(root).isFile()) return ext.includes(extname(root)) ? [root] : []
  } catch {
    return []
  }
  let out: string[] = []
  let entries: string[] = []
  try {
    entries = readdirSync(root)
  } catch {
    return out
  }
  for (const e of entries) {
    const p = join(root, e)
    let st
    try {
      // lstat(不跟随符号链接):符号链接一律跳过 —— 防止跟随到 /etc、他人 home,
      // 或目录符号链接构成的环路导致无限递归崩 daemon(安全评审 M1)。
      st = lstatSync(p)
    } catch {
      continue
    }
    if (st.isSymbolicLink()) continue
    if (st.isDirectory()) out = out.concat(collectFiles(p, ext))
    else if (ext.includes(extname(p))) out.push(p)
  }
  return out
}

/**
 * 路径是否在白名单内。**锚定路径分隔符 + realpath 规范化**(安全评审 M1):
 *   - 裸 startsWith 会让 `/home/u/.claude` 放行 `/home/u/.claude-evil/...`;
 *   - 不规范化会被 `..` / 符号链接绕过。
 * 空白名单:稳态扫描允许全部(configs 已限定 roots);回填侧强制非空(backfill.ts 单独 gate)。
 */
function allowed(path: string, allowlist?: string[]): boolean {
  if (!allowlist || allowlist.length === 0) return true
  let real: string
  try {
    real = realpathSync(path)
  } catch {
    return false
  }
  return allowlist.some((prefix) => {
    const base = resolve(prefix)
    return real === base || real.startsWith(base + sep)
  })
}

/** 读取文件从 byteOffset 起的内容(JSONL 增量)。 */
function readFrom(path: string, offset: number): string {
  const fd = openSync(path, "r")
  try {
    const st = statSync(path)
    const len = st.size - offset
    if (len <= 0) return ""
    const buf = Buffer.alloc(len)
    readSync(fd, buf, 0, len, offset)
    return buf.toString("utf8")
  } finally {
    closeSync(fd)
  }
}

/** 有界读取文件前缀：用于从已消费 JSONL 前缀恢复 cwd，避免 manifest/扫描周期全量读大文件。 */
export function readPrefix(path: string, maxBytes = PROJECT_PATH_PREFIX_BYTES): string {
  const fd = openSync(path, "r")
  try {
    const st = statSync(path)
    const len = Math.min(st.size, maxBytes)
    if (len <= 0) return ""
    const buf = Buffer.alloc(len)
    readSync(fd, buf, 0, len, 0)
    return buf.toString("utf8")
  } finally {
    closeSync(fd)
  }
}

/** 从 JSONL 有界前缀恢复实际 project_path；只解析完整行。 */
export function extractProjectPathFromJsonlPrefix(path: string): string | undefined {
  try {
    const parsed = parseJsonlSafe(readPrefix(path), 0)
    return extractProjectPath(parsed.records)
  } catch {
    return undefined
  }
}

/**
 * 扫描一轮,产出待上传记录(增量、torn-read 安全)。
 * **不上传** —— 上传由 upload.ts 负责;本函数纯读+解析+游标推进(便于测试)。
 */
export function scanOnce(opts: ScanOptions): ScanResult {
  const result: ScanResult = {
    records: [],
    cursorUpdates: {},
    skippedTooNew: 0,
    skippedTornOrBad: 0,
    skippedNotAllowed: 0,
    skippedProjectDisabled: 0,
    skippedNoUser: false,
  }

  // user_id 缺失 → 整体跳过(绝不用错身份做不可逆上传;pre-mortem E)
  if (!opts.userId) {
    result.skippedNoUser = true
    return result
  }

  const configs = opts.configs ?? defaultScanConfigs()
  const now = opts.now ?? Date.now
  const minAgeMs = opts.minAgeMs ?? 10_000
  const visitedFiles = new Set<string>()

  function setCursor(file: string, cursorUpdate: NonNullable<ReturnType<CursorStore["get"]>>): void {
    result.cursorUpdates[file] = cursorUpdate
    if (!opts.stageCursorUpdates) opts.cursors.set(file, cursorUpdate)
  }

  for (const cfg of configs) {
    for (const root of cfg.roots) {
      for (const file of collectFiles(root, cfg.ext)) {
        const fileKey = `${cfg.client}\0${resolve(file)}`
        if (visitedFiles.has(fileKey)) continue
        visitedFiles.add(fileKey)

        if (!allowed(file, opts.allowlist)) {
          result.skippedNotAllowed++
          continue
        }
        let st
        try {
          st = statSync(file)
        } catch {
          continue
        }
        // (a) mtime-age gate:太新(可能正在写)→ 跳过
        if (now() - st.mtimeMs < minAgeMs) {
          result.skippedTooNew++
          continue
        }

        const storedCursor = opts.cursors.get(file)
        // Older releases could leave a cursor at EOF before the corrected corpus upload
        // contract was active. Replay that position once; server idempotency removes any
        // rows that were already accepted.
        const cursor = storedCursor?.generation === TRANSCRIPT_CURSOR_GENERATION
          ? storedCursor
          : {}

        if (cfg.format === "opencode-sqlite" || cfg.format === "cursor-sqlite") {
          const sessions = cfg.format === "opencode-sqlite"
            ? listOpenCodeSessions(file)
            : listCursorSessions(file)
          for (const session of sessions) {
            if (!projectAllowed(session.projectPath, opts.enabledProjectPaths)) {
              result.skippedProjectDisabled++
              continue
            }
            const cursorKey = `${file}\0session:${session.id}`
            const sessionCursor = opts.cursors.get(cursorKey)
            if (
              sessionCursor?.generation === TRANSCRIPT_CURSOR_GENERATION &&
              (sessionCursor.updatedAtMs ?? 0) >= session.updatedAtMs
            ) continue
            const messages = cfg.format === "opencode-sqlite"
              ? loadOpenCodeMessages(file, session.id)
              : loadCursorMessages(file, session.id)
            result.records.push({
              user_id: opts.userId,
              project: session.projectPath ?? fileToProject(root, file),
              ...(session.projectPath ? { project_path: session.projectPath } : {}),
              session_id: session.id,
              client: cfg.client,
              ...(session.title ? { title: session.title } : {}),
              timestamp: new Date(session.updatedAtMs || session.createdAtMs || st.mtimeMs).toISOString(),
              messages,
              seqBase: 0,
            })
            setCursor(cursorKey, {
              generation: TRANSCRIPT_CURSOR_GENERATION,
              updatedAtMs: session.updatedAtMs,
              ...(session.projectPath ? { projectPath: session.projectPath } : {}),
              lastUploadedAt: new Date(now()).toISOString(),
            })
          }
        } else if (cfg.format === "gemini") {
          if (!file.split(/[/\\]/).includes("chats") || !/^session-/.test(fileToSessionId(file))) continue
          if (cursor.mtimeMs === st.mtimeMs && cursor.size === st.size) continue
          const parsed = parseGeminiSessionFile(file, readFileSync(file, "utf8"))
          if (!parsed) {
            result.skippedTornOrBad++
            continue
          }
          const project_path = parsed.projectPath ?? opts.projectPathByFile?.get(file)
          if (!projectAllowed(project_path, opts.enabledProjectPaths)) {
            result.skippedProjectDisabled++
            continue
          }
          result.records.push({
            user_id: opts.userId,
            project: fileToProject(root, file),
            ...(project_path ? { project_path } : {}),
            session_id: parsed.sessionId,
            client: cfg.client,
            timestamp: parsed.timestamp,
            messages: parsed.messages,
            seqBase: 0,
          })
          setCursor(file, {
            ...cursor,
            generation: TRANSCRIPT_CURSOR_GENERATION,
            mtimeMs: st.mtimeMs,
            size: st.size,
            ...(project_path ? { projectPath: project_path } : {}),
            lastUploadedAt: new Date(now()).toISOString(),
          })
        } else if (cfg.format === "kimi-code") {
          // Only the main agent wire is a user-facing transcript. Subagent wires,
          // the session index, and legacy root wires are intentionally excluded.
          if (!isKimiMainWire(file)) continue
          const from = cursor.byteOffset ?? 0
          if (from >= st.size) continue
          const chunk = readFrom(file, from)
          const parsed = parseJsonlSafe(chunk, from)
          if (parsed.records.length === 0) {
            result.skippedTornOrBad++
            continue
          }
          const kimi = parseKimiWireChunk(parsed.records)
          if (!kimi.complete) {
            result.skippedTornOrBad++
            continue
          }
          const messages = kimi.messages
          const metadata = readKimiSessionMetadata(file)
          const project_path = metadata.projectPath ?? cursor.projectPath ?? opts.projectPathByFile?.get(file)
          if (!projectAllowed(project_path, opts.enabledProjectPaths)) {
            result.skippedProjectDisabled++
            continue
          }
          const seqBase = cursor.recordCount ?? 0
          if (messages.length > 0) {
            result.records.push({
              user_id: opts.userId,
              project: fileToProject(root, file),
              ...(project_path ? { project_path } : {}),
              session_id: metadata.sessionId,
              client: cfg.client,
              ...(metadata.title ? { title: metadata.title } : {}),
              timestamp: new Date(st.mtimeMs).toISOString(),
              messages,
              seqBase,
            })
          }
          setCursor(file, {
            ...cursor,
            generation: TRANSCRIPT_CURSOR_GENERATION,
            byteOffset: parsed.safeOffset,
            recordCount: seqBase + messages.length,
            ...(project_path ? { projectPath: project_path } : {}),
            lastUploadedAt: new Date(now()).toISOString(),
          })
        } else if (cfg.format === "jsonl") {
          const from = cursor.byteOffset ?? 0
          if (from >= st.size) continue // 无新增
          const chunk = readFrom(file, from)
          const parsed = parseJsonlSafe(chunk, from)
          if (parsed.records.length === 0) {
            // 只有半行 / 无完整行 → 不推进,下 tick 重试
            result.skippedTornOrBad++
            continue
          }
          // seqBase:本批 messages[0] 在文件中的绝对行序号（跨轮累计）。
          // 用于 uploader 派生 source_message_id: `${session_id}:${seqBase+i}`。
          // 这保证：增量 JSONL 每轮只读新字节，但 seq 仍是文件绝对位置，跨轮不碰撞。
          const seqBase = cursor.recordCount ?? 0
          const title = extractSessionTitle(cfg.client, parsed.records)
          const project_path =
            extractProjectPath(parsed.records) ??
            cursor.projectPath ??
            opts.projectPathByFile?.get(file) ??
            (from > 0 ? extractProjectPathFromJsonlPrefix(file) : undefined)
          if (!projectAllowed(project_path, opts.enabledProjectPaths)) {
            result.skippedProjectDisabled++
            continue
          }
          result.records.push({
            user_id: opts.userId,
            project: fileToProject(root, file),
            ...(project_path ? { project_path } : {}),
            session_id: fileToSessionId(file),
            client: cfg.client,
            ...(title ? { title } : {}),
            timestamp: new Date(st.mtimeMs).toISOString(),
            messages: parsed.records,
            seqBase,
          })
          setCursor(file, {
            ...cursor,
            generation: TRANSCRIPT_CURSOR_GENERATION,
            byteOffset: parsed.safeOffset,
            recordCount: seqBase + parsed.records.length,
            ...(project_path ? { projectPath: project_path } : {}),
            lastUploadedAt: new Date(now()).toISOString(),
          })
        } else if (cfg.format === "copilot") {
          // Copilot .jsonl:第一行 kind:0 快照持有完整对话;整文件 mtime+size 游标
          if (cursor.mtimeMs === st.mtimeMs && cursor.size === st.size) continue
          const content = readFileSync(file, "utf8")
          const parsed = parseCopilotFile(content, fileToSessionId(file))
          if (!parsed.ok) {
            if (parsed.retry) {
              // torn / 坏 → 跳过 + 下 tick 重试(不推进游标)
              result.skippedTornOrBad++
            }
            // retry:false = 格式不符(非 kind:0),推进游标避免反复扫同一文件
            else {
              setCursor(file, {
                ...cursor,
                generation: TRANSCRIPT_CURSOR_GENERATION,
                mtimeMs: st.mtimeMs,
                size: st.size,
                lastUploadedAt: new Date(now()).toISOString(),
              })
            }
            continue
          }
          const messages = expandCopilotRequests(parsed.requests)
          const project_path = extractProjectPath(parsed.requests) ?? opts.projectPathByFile?.get(file)
          const title = normalizeSessionTitle(parsed.title)
          if (!projectAllowed(project_path, opts.enabledProjectPaths)) {
            result.skippedProjectDisabled++
            continue
          }
          result.records.push({
            user_id: opts.userId,
            project: fileToProject(root, file),
            ...(project_path ? { project_path } : {}),
            session_id: parsed.sessionId,
            client: cfg.client,
            ...(title ? { title } : {}),
            timestamp: new Date(st.mtimeMs).toISOString(),
            messages,
            seqBase: 0, // 整文件快照,全量消息,绝对 seq 从 0 起
          })
          setCursor(file, {
            ...cursor,
            generation: TRANSCRIPT_CURSOR_GENERATION,
            mtimeMs: st.mtimeMs,
            size: st.size,
            ...(project_path ? { projectPath: project_path } : {}),
            lastUploadedAt: new Date(now()).toISOString(),
          })
        } else {
          // 整文件 JSON:mtime+size 未变 → 已传过,跳过
          if (cursor.mtimeMs === st.mtimeMs && cursor.size === st.size) continue
          const content = readFileSync(file, "utf8")
          const parsed = parseWholeJsonSafe(content)
          if (!parsed.ok) {
            // torn / 坏 → 跳过 + 下 tick 重试(不推进游标)
            result.skippedTornOrBad++
            continue
          }
          const messages = extractWholeFileMessages(parsed.value)
          const title = extractSessionTitle(cfg.client, parsed.value)
          const project_path = extractProjectPath(messages)
          if (!projectAllowed(project_path, opts.enabledProjectPaths)) {
            result.skippedProjectDisabled++
            continue
          }
          result.records.push({
            user_id: opts.userId,
            project: fileToProject(root, file),
            ...(project_path ? { project_path } : {}),
            session_id: fileToSessionId(file),
            client: cfg.client,
            ...(title ? { title } : {}),
            timestamp: new Date(st.mtimeMs).toISOString(),
            messages,
            seqBase: 0, // 整文件快照,全量消息,绝对 seq 从 0 起
          })
          setCursor(file, {
            ...cursor,
            generation: TRANSCRIPT_CURSOR_GENERATION,
            mtimeMs: st.mtimeMs,
            size: st.size,
            ...(project_path ? { projectPath: project_path } : {}),
            lastUploadedAt: new Date(now()).toISOString(),
          })
        }
      }
    }
  }

  return result
}

/** 整文件客户端统一展开会话级 messages 数组，兼容常见的 session/conversation 包装层。 */
export function extractWholeFileMessages(value: unknown): unknown[] {
  if (Array.isArray(value)) return value
  if (value === null || typeof value !== "object") return [value]
  const record = value as Record<string, unknown>
  if (Array.isArray(record["messages"])) return record["messages"]
  for (const key of ["session", "conversation"]) {
    const container = record[key]
    if (container && typeof container === "object" && !Array.isArray(container)) {
      const messages = (container as Record<string, unknown>)["messages"]
      if (Array.isArray(messages)) return messages
    }
  }
  return [value]
}

/** Copilot 每个 request 同时包含问题和回答，上传前拆成可独立浏览且 ID 稳定的消息。 */
export function expandCopilotRequests(requests: CopilotRequest[]): unknown[] {
  const messages: unknown[] = []
  requests.forEach((request, index) => {
    const requestId = request.requestId?.trim() || `request-${index}`
    const timestamp = typeof request.timestamp === "number" ? request.timestamp : undefined
    const userContent = request.message?.text ?? request.message?.parts
    if (typeof userContent === "string" || (Array.isArray(userContent) && userContent.length > 0)) {
      messages.push({
        id: `${requestId}:user`,
        _corpus_role: "user",
        content: userContent,
        ...(timestamp !== undefined ? { timestamp } : {}),
      })
    }

    const responseParts = Array.isArray(request.response)
      ? request.response.flatMap((part) => {
        const text = typeof part.value === "string" ? part.value : part.markdown
        return typeof text === "string" && text ? [{ type: "text", text }] : []
      })
      : []
    if (responseParts.length > 0) {
      messages.push({
        id: `${requestId}:assistant`,
        _corpus_role: "assistant",
        content: responseParts,
        completionTokens: request.completionTokens,
        ...(timestamp !== undefined ? { timestamp } : {}),
      })
    }
  })
  return messages
}

/** 从文件名推 session_id(去扩展名)。 */
export function fileToSessionId(path: string): string {
  const base = path.split(/[/\\]/).pop() ?? path
  return base.replace(/\.[^.]+$/, "")
}

/**
 * 推断 project:文件相对 root 的目录段(CC 把 session 存在
 * ~/.claude/projects/<encoded-project>/xxx.jsonl,有意义的 project 是那层目录,不是 root)。
 * 无子目录(文件直接在 root 下)→ 回落 root 的 basename。
 */
export function fileToProject(root: string, file: string): string {
  const rel = resolve(file).slice(resolve(root).length).replace(/^[/\\]+/, "")
  const seg = rel.split(/[/\\]/)
  if (seg.length > 1) return seg[0]! // 第一层目录 = project
  return root.split(/[/\\]/).filter(Boolean).pop() ?? root
}

function projectAllowed(projectPath: string | undefined, enabledProjectPaths?: Set<string>): boolean {
  if (!enabledProjectPaths) return true
  return projectPath !== undefined && enabledProjectPaths.has(normalizeDirectoryPath(projectPath))
}

const PROJECT_PATH_KEYS = new Set([
  "cwd",
  "project_path",
  "projectPath",
  "workspace",
  "workspacePath",
  "workspace_path",
  "workspaceFolder",
  "workspace_folder",
  "rootPath",
  "repoPath",
  "repositoryPath",
])

/** POSIX / Windows 绝对路径判定；在 Linux 测试中也必须识别 Windows 路径。 */
export function isAbsoluteProjectPath(value: string): boolean {
  const s = value.trim()
  if (!s) return false
  if (s.startsWith("/")) return s.length > 1
  if (/^[A-Za-z]:[\\/]/.test(s)) return true
  if (/^\\\\[^\\/]+[\\/][^\\/]+/.test(s)) return true
  return false
}

/**
 * 从客户端原始记录中提取实际绝对 cwd/project_path。
 * 不从 fileToProject 的存储目录标签伪造路径；找不到可靠绝对路径就返回 undefined。
 */
export function extractProjectPath(value: unknown, maxDepth = 5): string | undefined {
  const seen = new Set<unknown>()

  function visit(v: unknown, depth: number): string | undefined {
    if (depth > maxDepth || v === null || typeof v !== "object") return undefined
    if (seen.has(v)) return undefined
    seen.add(v)

    if (Array.isArray(v)) {
      for (const item of v) {
        const found = visit(item, depth + 1)
        if (found) return found
      }
      return undefined
    }

    const record = v as Record<string, unknown>
    for (const key of PROJECT_PATH_KEYS) {
      const candidate = record[key]
      if (typeof candidate === "string" && isAbsoluteProjectPath(candidate)) return candidate.trim()
    }
    for (const child of Object.values(record)) {
      const found = visit(child, depth + 1)
      if (found) return found
    }
    return undefined
  }

  return visit(value, 0)
}
