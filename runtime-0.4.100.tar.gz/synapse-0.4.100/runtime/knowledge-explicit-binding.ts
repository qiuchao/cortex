import { randomUUID } from "node:crypto"
import {
  KNOWLEDGE_EXPLICIT_BINDING_PROTOCOL_VERSION,
  KnowledgeExplicitBindingResponseSchema,
  type KnowledgeExplicitBindingRequest,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import type { resolveKnowledgeExplicitBindings } from "../transport/brain-contract-align.ts"
import type { TaskTurnActivation, TaskTurnGuardPolicy, TaskTurnGuardRegistry } from "../core/task-turn-guard.ts"
import { renderAgentControlContext, resolveAgentControlTurnId, resolveAgentLauncher } from "./agent-capability-broker.ts"

export type KnowledgeBindingResolver = (
  request: KnowledgeExplicitBindingRequest,
  signal?: AbortSignal,
) => ReturnType<typeof resolveKnowledgeExplicitBindings>

interface BindingAdmission {
  activation: TaskTurnActivation
  input: InjectRequest
  request: KnowledgeExplicitBindingRequest
  invalidated: boolean
  submitted: boolean
}

type AdmissionResult =
  | { kind: "new"; ticket: BindingAdmission }
  | { kind: "repeat" }
  | { kind: "rejected"; clearPending: boolean }

/** Per-active-turn admission only; all capability and argument decisions belong to C. */
export function createKnowledgeBindingController(guards: TaskTurnGuardRegistry, resolve: KnowledgeBindingResolver) {
  const admissions = new Map<string, BindingAdmission>()
  const isCurrent = (ticket: BindingAdmission): boolean => !ticket.invalidated
    && admissions.get(ticket.activation.sessionKey) === ticket
    && guards.isActive(ticket.activation)
  const observe = (input: InjectRequest, activation: TaskTurnActivation | undefined): void => {
    if (!activation || !guards.isActive(activation)) return
    const previous = admissions.get(activation.sessionKey)
    if (previous?.activation.generation === activation.generation
      && previous.activation.turnKey === activation.turnKey
      && previous.input.user_input !== input.user_input) previous.invalidated = true
  }

  return {
    isCurrent,
    observe,
    begin(input: InjectRequest, activation: TaskTurnActivation | undefined): AdmissionResult {
      // The registry bounds active sessions and owns their expiry/revocation.
      for (const [key, ticket] of admissions) {
        if (!guards.isActive(ticket.activation)) admissions.delete(key)
      }
      if (!activation || !guards.isActive(activation)) return { kind: "rejected", clearPending: false }
      observe(input, activation)
      const previous = admissions.get(activation.sessionKey)
      if (previous?.activation.generation === activation.generation
        && previous.activation.turnKey === activation.turnKey) {
        if (previous.input.user_input === input.user_input) return { kind: "repeat" }
        previous.invalidated = true
        return { kind: "rejected", clearPending: true }
      }
      const ticket: BindingAdmission = {
        activation,
        input: { ...input },
        request: {
          protocolVersion: KNOWLEDGE_EXPLICIT_BINDING_PROTOCOL_VERSION,
          client: input.client,
          sessionId: input.session_id,
          turnId: resolveAgentControlTurnId(input),
          requestId: randomUUID(),
          currentText: input.user_input,
        },
        invalidated: false,
        submitted: false,
      }
      admissions.set(activation.sessionKey, ticket)
      return { kind: "new", ticket }
    },
    async decide(
      ticket: BindingAdmission,
      observe?: Parameters<typeof renderAgentControlContext>[3],
      signal?: AbortSignal,
    ): Promise<{ context: string; policy?: TaskTurnGuardPolicy }> {
      signal?.throwIfAborted()
      if (!isCurrent(ticket) || ticket.submitted) throw new Error("Knowledge binding admission is no longer current")
      ticket.submitted = true
      const result = await resolve(ticket.request, signal)
      signal?.throwIfAborted()
      if (!isCurrent(ticket)) throw new Error("Knowledge binding response belongs to a revoked admission")
      if (!result.ok) throw new Error(`Knowledge binding unavailable: ${result.reason}`)
      const parsed = KnowledgeExplicitBindingResponseSchema.safeParse(result.response)
      if (!parsed.success || parsed.data.requestId !== ticket.request.requestId) {
        throw new Error("Knowledge binding response does not match the current request")
      }
      const decision = parsed.data
      if (decision.decision !== "bound") {
        return { context: `[Synapse] knowledge_binding_decision=${JSON.stringify({
          decision: decision.decision,
          code: decision.code,
          ...(decision.decision === "clarify" ? { question: decision.question } : {}),
        })}\n本轮没有可执行知识路由；请直接说明结果或向用户澄清，不得调用工具。` }
      }
      const launcher = resolveAgentLauncher(ticket.input.client)
      if (!launcher || decision.scopedCatalogue.availableCapabilities.length === 0) {
        throw new Error("Knowledge binding has no available route")
      }
      const routeToken = randomUUID()
      return {
        context: renderAgentControlContext(decision.scopedCatalogue, ticket.input, launcher, observe, {
          knowledgeRouteToken: routeToken,
          knowledgeBoundArgsByCapability: decision.boundArgsByCapability,
        }),
        policy: {
          mode: "knowledge_required",
          reason: "本轮已取得 Cerebro Knowledge 绑定决策，首个业务工具必须走 Synapse typed Knowledge。",
          route: {
            kind: "knowledge",
            launcher,
            routeToken,
            protocolVersion: decision.scopedCatalogue.protocolVersion,
            client: ticket.input.client,
            sessionId: ticket.request.sessionId,
            turnId: ticket.request.turnId,
            allowedCommands: decision.scopedCatalogue.availableCapabilities,
            completionCommands: decision.scopedCatalogue.availableCapabilities,
            boundArgsByCapability: decision.boundArgsByCapability,
            answerOnlyAfterCompletion: true,
          },
        },
      }
    },
  }
}
