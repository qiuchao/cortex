/**
 * recovery-helpers.mjs
 * R6/R17 恢复诊断与已推送判断 核心逻辑的可测纯函数
 *
 * ADR: git-operation-state-machine
 *
 * 注意：check-push-status CLI 接口内部允许使用 execSync 调用只读 git 命令（git log），
 * 这与 draft-sync-script.mjs 禁止 child_process 的约束不同——
 * recovery-helpers 仅执行只读查询，不执行任何写操作。
 *
 * 导出：
 *   classifyPushStatus(gitLogOutput, stderr)  → "unpushed" | "pushed" | "conservative-revert"
 *   classifyRecoveryState(porcelain, staged, recentCommits, pushStatus) → 状态字符串
 */

import { execSync } from "node:child_process";

/**
 * S4b-2：判断最近 commit 是否已推送（R17 核心）
 *
 * @param {string} gitLogOutput - `git log origin/<branch>..HEAD --oneline` 的 stdout
 * @param {string} stderr       - 错误输出（如远端不可达）
 * @returns {"unpushed" | "pushed" | "conservative-revert"}
 *
 * 判断逻辑：
 * - stderr 非空（远端不可达 / 无追踪分支）→ "conservative-revert"（保守：视为已推，用 revert）
 * - stdout 非空（本地有远端没有的 commit）→ "unpushed"
 * - stdout 为空（本地 HEAD 已在远端）      → "pushed"
 */
export function classifyPushStatus(gitLogOutput, stderr) {
  if (stderr && stderr.trim().length > 0) return "conservative-revert";
  if (gitLogOutput && gitLogOutput.trim().length > 0) return "unpushed";
  return "pushed";
}

/**
 * S4b-1：分类恢复诊断状态（R6）
 *
 * @param {string} porcelain     - git status --porcelain 的输出（空表示工作区干净）
 * @param {string} staged        - git diff --cached --name-only 的输出（空表示无暂存）
 * @param {string} recentCommits - git log --oneline -5 的输出（空表示无最近提交）
 * @param {string} pushStatus    - "unpushed" | "pushed" | "conservative-revert"
 * @returns {"dirty-unstaged" | "dirty-staged" | "committed-unpushed" | "committed-pushed" | "nothing"}
 *
 * 注意：conservative-revert 状态映射到 "committed-pushed"（保守：视为已推，只允许 revert）
 */
export function classifyRecoveryState(porcelain, staged, recentCommits, pushStatus) {
  const hasPorcelain = porcelain && porcelain.trim().length > 0;
  const hasStaged = staged && staged.trim().length > 0;
  const hasCommits = recentCommits && recentCommits.trim().length > 0;

  // 无任何状态 → nothing
  if (!hasPorcelain && !hasCommits) return "nothing";

  // 有暂存改动（优先于 unstaged 判断）
  if (hasStaged) return "dirty-staged";

  // 有未暂存改动（无暂存）
  if (hasPorcelain && !hasStaged) return "dirty-unstaged";

  // 有提交 + 未推送
  if (hasCommits && pushStatus === "unpushed") return "committed-unpushed";

  // 有提交 + 已推送（含保守状态：conservative-revert 视为已推）
  if (hasCommits && (pushStatus === "pushed" || pushStatus === "conservative-revert")) {
    return "committed-pushed";
  }

  return "nothing";
}

// ─────────────────────────────────────────────────────────────
// CLI 入口（process.argv 传参，绝不拼进 JS 字符串）
//
// 用法（供 Synapse Git policy 调用）：
//   node recovery-helpers.mjs check-push-status <branch> <commitSha>
//     → 输出 "unpushed" | "pushed" | "conservative-revert"
//
//   node recovery-helpers.mjs classify-recovery-state <porcelain> <staged> <pushStatus>
//     → 输出 "dirty-unstaged" | "dirty-staged" | "committed-unpushed" |
//            "committed-pushed" | "nothing"
//
// 注意：check-push-status 内部使用 execSync 调用只读 git 命令（git log），
// 捕获 stderr，任何异常返回 "conservative-revert"
// ─────────────────────────────────────────────────────────────
const isMain = process.argv[1]?.endsWith("recovery-helpers.mjs") ?? false;
if (isMain) {
  const [, , cmd, ...args] = process.argv;

  if (cmd === "check-push-status") {
    // 用法：check-push-status <branch> <commitSha>
    // commitSha 参数保留用于未来扩展（当前判断仅依赖分支名）
    const branch = args[0] || "";
    if (!branch) {
      process.stdout.write("conservative-revert\n");
      process.exit(0);
    }
    try {
      // 只读操作：检查 origin/<branch>..HEAD 是否非空
      const stdout = execSync(
        `git log origin/${branch}..HEAD --oneline`,
        { stdio: ["pipe", "pipe", "pipe"], timeout: 5000 }
      ).toString();
      const result = classifyPushStatus(stdout, "");
      process.stdout.write(result + "\n");
    } catch (err) {
      // 任何异常（远端不可达 / 无追踪分支）→ 保守返回
      const stderr = err.stderr ? err.stderr.toString() : String(err.message || "");
      const result = classifyPushStatus("", stderr || "error");
      process.stdout.write(result + "\n");
    }

  } else if (cmd === "classify-recovery-state") {
    // 用法：classify-recovery-state <porcelain> <staged> <pushStatus>
    const porcelain = args[0] || "";
    const staged = args[1] || "";
    const pushStatus = args[2] || "conservative-revert";
    // recentCommits 默认为非空（CLI 调用时 bash 段已判断有 commit）
    const recentCommits = args[3] || "placeholder";
    const result = classifyRecoveryState(porcelain, staged, recentCommits, pushStatus);
    process.stdout.write(result + "\n");

  } else {
    process.stderr.write(`recovery-helpers: unknown command '${cmd}'\n`);
    process.stderr.write(
      "usage:\n" +
      "  node recovery-helpers.mjs check-push-status <branch> <commitSha>\n" +
      "  node recovery-helpers.mjs classify-recovery-state <porcelain> <staged> <pushStatus> [recentCommits]\n"
    );
    process.exit(1);
  }
}
