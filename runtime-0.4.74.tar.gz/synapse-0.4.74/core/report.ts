/**
 * core/report.ts —— 一个外部 verb `report`,内部三 handler(方案 §1 原则 4 / R3)。
 *
 *   verify_done   —— 确定性、**同步**(在 report ACK 上):done=产出物存在性,契约缺失 fail-closed。
 *   judge_sediment —— 非确定性、**detached**(可调小模型,绝不阻塞 Stop hook)。
 *   nudge_sync    —— IO、**detached**:把本 session 提优先给语料流。
 *
 * 🔴 per-op try/catch 隔离:任何一个 handler 抛错,绝不能带崩另外两个 / 崩掉 server。
 * 🔴 detached 语义:report 的 ACK 只等 verify_done(同步、确定性);judge_sediment 与
 *    nudge_sync 在后台跑,不进 ACK 关键路径 —— Stop hook 不被拖住。
 */
import type { ReportRequest, ReportResponse } from "../transport/contract.ts"
import { handleVerifyDone } from "./handlers/verify-done.ts"
import { handleJudgeSediment, type SedimentTurn } from "./handlers/judge-sediment.ts"
import { handleNudgeSync, type SyncPriorityQueue } from "./handlers/nudge-sync.ts"
import { readMachineId } from "./token-store.ts"

const DEFAULT_TURN_RESOLVE_DELAYS_MS = [0, 75, 200, 500, 1_000] as const

export interface ReportState {
  /** 跨回合的 turn_id 幂等集合(judge_sediment 去重) */
  seenTurns: Set<string>
  /** 主脑已接受或判重的最近自动沉淀时间，限制同一客户端会话的写入频率。 */
  acceptedSedimentSessions: Map<string, number>
  /** 待优先同步队列(nudge_sync → Phase 5 scanner) */
  syncQueue: SyncPriorityQueue
}

export interface ReportDeps {
  state: ReportState
  /** 从请求里取 done 契约的方式(Phase 2:由调用方/任务上下文提供;测试可注入)。 */
  resolveDoneContract?: (req: ReportRequest) => unknown
  /** 从请求里取本回合可判定文本(运行时按 client 解析 transcript 尾部;测试可注入)。 */
  resolveTurnText?: (req: ReportRequest) => string | undefined
  /** judge_sediment 依赖(kh / 小模型)。 */
  sedimentDeps?: Parameters<typeof handleJudgeSediment>[1]
  /** 后台任务登记器(测试用:收集 detached promise 以便 await;生产为 fire-and-forget)。 */
  registerBackground?: (p: Promise<unknown>) => void
  /** transcript 刷盘重试节奏；测试可注入全 0，生产默认总计不超过 1.8s。 */
  turnResolveDelaysMs?: readonly number[]
  /** 后台结果观察器；运行时据此维护真实成功/拒绝/失败指标。 */
  onTurnResolution?: (resolved: boolean) => void
  onSedimentResult?: (result: Awaited<ReturnType<typeof handleJudgeSediment>>) => void
}

/**
 * 处理一次 report。返回的 ReportResponse 只反映**同步**部分(done)确定的结果;
 * sedimented/synced 是"是否已派发后台任务"的即时回执,真正的写入在 detached 任务里完成。
 */
export function handleReport(req: ReportRequest, deps: ReportDeps): ReportResponse {
  const actions: string[] = []
  let done = false
  let sedimented = false
  let synced = false

  // ── verify_done:同步、确定性、fail-closed ──(独立 try/catch)
  try {
    const contract = deps.resolveDoneContract?.(req)
    const r = handleVerifyDone({ done_contract: contract, cwd: req.cwd ?? process.cwd() })
    done = r.done
    actions.push(`verify_done:${r.reason ?? (r.done ? "ok" : "false")}`)
  } catch (e) {
    // fail-closed:核验本身出错 → 不声称 done
    done = false
    actions.push(`verify_done:error:${errMsg(e)}`)
  }

  // ── judge_sediment:detached,绝不阻塞 ACK ──(独立 try/catch)
  try {
    const p = runSediment(req, deps)
    deps.registerBackground?.(p)
    sedimented = true // 已派发(真正写入在后台;此处回执"已受理")
    actions.push("judge_sediment:dispatched")
  } catch (e) {
    sedimented = false
    actions.push(`judge_sediment:error:${errMsg(e)}`)
  }

  // ── nudge_sync:detached IO ──(独立 try/catch)
  try {
    const r = handleNudgeSync(req.session_id, deps.state.syncQueue)
    synced = r.synced
    actions.push(`nudge_sync:${r.reason}`)
  } catch (e) {
    synced = false
    actions.push(`nudge_sync:error:${errMsg(e)}`)
  }

  return { done, sedimented, synced, actions }
}

async function runSediment(
  req: ReportRequest,
  deps: ReportDeps,
): Promise<Awaited<ReturnType<typeof handleJudgeSediment>>> {
  let text: string | undefined
  for (const delayMs of deps.turnResolveDelaysMs ?? DEFAULT_TURN_RESOLVE_DELAYS_MS) {
    if (delayMs > 0) await delay(delayMs)
    try {
      text = deps.resolveTurnText?.(req)
    } catch {
      text = undefined
    }
    if (text?.trim()) break
  }
  try {
    deps.onTurnResolution?.(Boolean(text?.trim()))
  } catch {
    // Observability must never turn detached sedimentation into an unhandled rejection.
  }

  let result: Awaited<ReturnType<typeof handleJudgeSediment>>
  try {
    const turn: SedimentTurn = {
      client: req.client,
      turn_id: req.turn_id,
      session_id: req.session_id,
      text,
      project: req.project,
      cwd: req.cwd,
      machineId: readMachineId(),
    }
    result = await handleJudgeSediment(turn, {
      seenTurns: deps.state.seenTurns,
      acceptedSessions: deps.state.acceptedSedimentSessions,
      ...deps.sedimentDeps,
    })
  } catch {
    result = { sedimented: false, reason: "save_failed" }
  }
  try {
    deps.onSedimentResult?.(result)
  } catch {
    // Same isolation guarantee as the sediment save itself.
  }
  return result
}

export function createReportState(syncQueue: SyncPriorityQueue): ReportState {
  return { seenTurns: new Set<string>(), acceptedSedimentSessions: new Map<string, number>(), syncQueue }
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e)
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
