/** Narrow local reader protocol shared by daemon and installed CLI. No identity/path fields. */
import { z } from "zod"
import { IterationResultChunkSchema } from "@cerebro/wire"
export const IterationLocalReadSchema = z.object({ resultId: z.string().uuid(), cursor: z.string().min(1).max(256) }).strict()
export const IterationLocalReleaseSchema = z.object({
  responseId: z.string().uuid(), nonce: z.string().uuid(), chunkSha256: z.string().regex(/^[a-f0-9]{64}$/),
}).strict()
export const IterationLocalResponseSchema = z.object({
  responseId: z.string().uuid(), expiresAt: z.number().finite(), chunk: IterationResultChunkSchema,
}).strict()
export const IterationLocalPermitSchema = z.object({
  responseId: z.string().uuid(), nonce: z.string().uuid(), chunkSha256: z.string().regex(/^[a-f0-9]{64}$/),
  issuedAt: z.number().finite(), expiresAt: z.number().finite(),
}).strict().refine(value => value.expiresAt > value.issuedAt && value.expiresAt - value.issuedAt <= 100)
