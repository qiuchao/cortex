import type { InjectAttachment } from "../../transport/contract.ts"
import { materializeInlineImages } from "./inline-image-attachments.ts"
import { asObject, str } from "./util.ts"
import { scanJsonlTail } from "./transcript-jsonl.ts"

const INITIAL_TAIL_BYTES = 8 * 1024 * 1024
const MAX_TAIL_BYTES = 64 * 1024 * 1024

export interface ClaudeTranscriptAttachmentRequest {
  transcriptPath: string
  sessionId: string
  promptId: string
  prompt?: string
}

export interface ClaudeTranscriptAttachmentProbe {
  matched: boolean
  attachments?: InjectAttachment[]
}

export function claudeTranscriptAttachments(
  request: ClaudeTranscriptAttachmentRequest,
  env: NodeJS.ProcessEnv = process.env,
): InjectAttachment[] | undefined {
  return probeClaudeTranscriptAttachments(request, env).attachments
}

export function probeClaudeTranscriptAttachments(
  request: ClaudeTranscriptAttachmentRequest,
  env: NodeJS.ProcessEnv = process.env,
): ClaudeTranscriptAttachmentProbe {
  if (!request.transcriptPath || !request.sessionId || !request.promptId) return { matched: false }
  try {
    return scanJsonlTail(
      request.transcriptPath,
      { initialBytes: INITIAL_TAIL_BYTES, maxBytes: MAX_TAIL_BYTES },
      (records) => inspectCurrentPrompt(records, request, env),
    ) ?? { matched: false }
  } catch {
    return { matched: false }
  }
}

function inspectCurrentPrompt(
  records: Record<string, unknown>[],
  request: ClaudeTranscriptAttachmentRequest,
  env: NodeJS.ProcessEnv,
): ClaudeTranscriptAttachmentProbe | undefined {
  let record: Record<string, unknown> | undefined
  for (let index = records.length - 1; index >= 0; index -= 1) {
    const entry = records[index]!
    if (str(entry, "type") === "user"
      && str(entry, "sessionId", "session_id") === request.sessionId
      && str(entry, "promptId", "prompt_id") === request.promptId) {
      record = entry
      break
    }
  }
  if (!record) return undefined
  const message = asObject(record["message"])
  if (str(message, "role") !== "user") return { matched: false }
  const content = message["content"]
  if (typeof content === "string") {
    return !request.prompt || content === request.prompt ? { matched: true } : { matched: false }
  }
  if (!Array.isArray(content)) return { matched: false }
  const text = content
    .flatMap((item) => {
      const part = asObject(item)
      return str(part, "type") === "text" ? [str(part, "text")] : []
    })
    .filter(Boolean)
    .join("\n")
  if (request.prompt && text !== request.prompt) return { matched: false }

  const images = content.flatMap((item) => {
    const part = asObject(item)
    if (str(part, "type") !== "image") return []
    const source = asObject(part["source"])
    return str(source, "type") === "base64"
      ? [{ mimeType: str(source, "media_type", "mediaType"), base64: str(source, "data") }]
      : []
  })
  if (!images.length) return { matched: true }
  return { matched: true, attachments: materializeInlineImages(images, "claude-attachments", env) }
}
