import { closeSync, fstatSync, openSync, readSync } from "node:fs"

export function readJsonlPrefix(path: string, maxBytes: number): Record<string, unknown>[] | undefined {
  let descriptor: number | undefined
  try {
    descriptor = openSync(path, "r")
    const size = fstatSync(descriptor).size
    if (!Number.isSafeInteger(size) || size <= 0) return []
    return jsonLines(readWindow(descriptor, 0, Math.min(size, maxBytes)))
  } catch {
    return undefined
  } finally {
    if (descriptor !== undefined) closeSync(descriptor)
  }
}

/**
 * Scan a transcript tail, growing the window when the first JSONL record is
 * larger than the initial budget. The callback returns undefined to request a
 * wider window and any other value when it has a conclusive result.
 */
export function scanJsonlTail<T>(
  path: string,
  options: { initialBytes: number; maxBytes: number },
  inspect: (records: Record<string, unknown>[]) => T | undefined,
): T | undefined {
  let descriptor: number | undefined
  try {
    descriptor = openSync(path, "r")
    const size = fstatSync(descriptor).size
    if (!Number.isSafeInteger(size) || size <= 0) return undefined
    let windowBytes = Math.min(size, options.initialBytes)
    while (true) {
      const start = Math.max(0, size - windowBytes)
      let text = readWindow(descriptor, start, size - start)
      if (start > 0) {
        const boundary = text.indexOf("\n")
        text = boundary >= 0 ? text.slice(boundary + 1) : ""
      }
      const result = inspect(jsonLines(text))
      if (result !== undefined) return result
      if (start === 0 || windowBytes >= options.maxBytes) return undefined
      windowBytes = Math.min(size, options.maxBytes, windowBytes * 2)
    }
  } catch {
    return undefined
  } finally {
    if (descriptor !== undefined) closeSync(descriptor)
  }
}

function readWindow(descriptor: number, start: number, length: number): string {
  const buffer = Buffer.allocUnsafe(length)
  let offset = 0
  while (offset < length) {
    const read = readSync(descriptor, buffer, offset, length - offset, start + offset)
    if (read === 0) break
    offset += read
  }
  return buffer.subarray(0, offset).toString("utf8")
}

function jsonLines(text: string): Record<string, unknown>[] {
  const records: Record<string, unknown>[] = []
  for (const line of text.split("\n")) {
    if (!line.trim()) continue
    try {
      const parsed: unknown = JSON.parse(line)
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) records.push(parsed as Record<string, unknown>)
    } catch {
      // Concurrently appended and future record types are ignored per line.
    }
  }
  return records
}
