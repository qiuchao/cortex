/**
 * transport/contract.ts — canonical verb 契约(唯一的薄壳↔运行时接口)
 *
 * 所有客户端薄壳只跟运行时说两个规范动词:inject / report。运行时只认这两个,
 * 完全不知道调用者是哪家客户端 → 100% 一份行为代码(方案 §1 原则 1/2)。
 *
 * ⚠️ 本文件只出**类型 + schema**,不出实现(Phase 0 只立契约,Phase 1 起接实现)。
 * ⚠️ 传输层(unix socket / named pipe / token-TCP)藏在 transport interface 后,
 *    socket/pipe 类型**不泄漏到 verb 之上**(方案 R1/D6)。见 ./README.md。
 *
 * 薄壳形态(方案 A,已定):薄壳 = 一行 curl,把 hook 原始 stdin 原样 POST;
 * client 身份走 header `X-Synapse-Client`、verb 走 URL 路径(/inject、/report)。
 * **输入解析在运行时按 client 做**(core/parsers/<client>.ts),薄壳零业务逻辑。
 */
import { z } from "zod"

/**
 * 一级客户端标识(spec 客户端支持矩阵)。
 * Cursor 暂放弃(hook 天花板);Antigravity 暂缓(当前无成员使用,待有人用再接入)——两者都不在此枚举。
 * 复活方式见 docs/DECISIONS.md:重新加回一个枚举项 + parser + shim(map-only)。
 */
export const ClientId = z.enum([
  "claude-code",
  "codex",
  "opencode",
  "gemini-cli",
  "kimi-code",
])
export type ClientId = z.infer<typeof ClientId>

// ────────────────────────────────────────────────────────────────────
// inject —— 每轮注入(高频)。唯一每轮项 = 拿用户本轮输入实时查 KH。
// ────────────────────────────────────────────────────────────────────

/**
 * inject 请求。注意:`user_input` 等字段是**运行时按 client 从原始 stdin 解析出来的**
 * 规范形态,不是薄壳解析后传入的(薄壳只转发原始 stdin + client header)。
 */
export const InjectAttachment = z.object({
  path: z.string().trim().min(1).max(4096),
  fileName: z.string().trim().min(1).max(512).optional(),
  mimeType: z.string().trim().max(128).optional(),
}).strict()
export type InjectAttachment = z.infer<typeof InjectAttachment>

export const DeferredAttachmentSource = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("codex-transcript"),
    transcriptPath: z.string().trim().min(1).max(4096),
  }).strict(),
  z.object({
    kind: z.literal("claude-transcript"),
    transcriptPath: z.string().trim().min(1).max(4096),
  }).strict(),
  z.object({
    kind: z.literal("inline-images"),
    images: z.array(z.object({
      mimeType: z.string().trim().min(1).max(128),
      base64: z.string().min(1).max(14 * 1024 * 1024),
    }).strict()).min(1).max(20),
  }).strict(),
])
export type DeferredAttachmentSource = z.infer<typeof DeferredAttachmentSource>

export const AttachmentObservation = z.enum(["present", "none", "unknown"])
export type AttachmentObservation = z.infer<typeof AttachmentObservation>

export const InjectRequest = z.object({
  client: ClientId,
  /** 客户端原始 hook 事件名(如 UserPromptSubmit / chat.message),用于遥测未映射事件 */
  event: z.string(),
  project: z.string().optional(),
  cwd: z.string().optional(),
  /** 用户本轮输入,作为向量检索 query */
  user_input: z.string(),
  session_id: z.string(),
  /** 当前回合稳定锚点；优先来自客户端原始 turn/message/request id，缺失时由 parser 对原始载荷稳定派生。 */
  turn_id: z.string().optional(),
  /** 客户端原始 message/request id；用于 Cerebro 幂等与审计，不伪造用户内容。 */
  message_id: z.string().optional(),
  /** 客户端/会话层 conversation id；有则透传，没有则不伪造。 */
  conversation_id: z.string().optional(),
  /** 当前客户端可见的本地附件；只传路径和元数据，二进制由 Synapse 按需分片上传。 */
  attachments: z.array(InjectAttachment).max(20).optional(),
  /** 当前 Hook 对附件的观测结论；unknown 不能被当成“无附件”。 */
  attachment_observation: AttachmentObservation.optional(),
  /** Hook 明确暴露了附件，但客户端适配器无法完整、安全地保留它们。 */
  attachment_error: z.string().trim().min(1).max(512).optional(),
  /** hook 尚未公开附件时的延迟来源；只在任务意图需要附件时按需解析。 */
  deferred_attachment_source: DeferredAttachmentSource.optional(),
  /** 客户端原生 transcript 文件；只作为受限上下文读取锚点，不直接注入模型输出。 */
  transcript_path: z.string().trim().min(1).max(4096).optional(),
  /** 已有 transcript 尾部，最多由上游可得字段透传；parser 不读取本地文件、不编造历史。 */
  transcript_tail: z.array(z.object({
    role: z.string(),
    text: z.string(),
    tool_use: z.unknown().optional(),
    tool_result: z.unknown().optional(),
  })).optional(),
  /** support rails 等已有结构化上下文；只透传现有字段。 */
  support_rails: z.record(z.string(), z.unknown()).optional(),
})
export type InjectRequest = z.infer<typeof InjectRequest>

export const InjectResponse = z.object({
  /** 兼容所有现有客户端的完整注入文本。降级且无控制上下文时为空串。 */
  context: z.string(),
  /** 仅包含 Synapse 生成并验证的控制协议；支持分层消息的客户端应放入 system 通道。 */
  trustedContext: z.string().optional(),
  /** 仅包含知识正文、查询结果等外部数据；必须留在不可信数据通道。 */
  untrustedContext: z.string().optional(),
  /** 主脑不可达 / 超 250ms 预算 → 静默降级标记 */
  degraded: z.boolean(),
  /** 当前回合已注册工具前置护栏；plugin 客户端据此决定 daemon 断连时是否 fail-closed。 */
  toolGuardRequired: z.boolean().optional(),
  /** Cerebro intent 元数据；Synapse 只注入结果/notice，不执行 operation。 */
  intent: z.object({
    intentId: z.string().optional(),
    status: z.enum(["execute", "clarify", "deny", "defer"]).optional(),
    selectedCapability: z.string().optional(),
    replayState: z.string().optional(),
    requestIdempotencyKey: z.string().optional(),
  }).optional(),
  /** 已由 Cerebro resolver+execute 生成的当前回合注入文本；formatters 会把它送入模型请求。 */
  resultInjection: z.string().optional(),
})
export type InjectResponse = z.infer<typeof InjectResponse>

// ────────────────────────────────────────────────────────────────────
// report —— 回合级 / 会话级上报。一个外部 verb,运行时内部三 handler。
// ────────────────────────────────────────────────────────────────────

export const ReportRequest = z.object({
  client: ClientId,
  /** 客户端原始结束事件名(Stop / SessionEnd / event:session.ended) */
  event: z.string(),
  session_id: z.string(),
  /** 回合级幂等键(Codex Stop 可能多次触发 → 按 turn_id 去重) */
  turn_id: z.string().optional(),
  project: z.string().optional(),
  cwd: z.string().optional(),
  transcript_path: z.string().trim().min(1).max(4096).optional(),
})
export type ReportRequest = z.infer<typeof ReportRequest>

export const ReportResponse = z.object({
  /** verify_done:按 done 契约核验产出物存在性(确定性,契约缺失 fail-closed) */
  done: z.boolean(),
  /** judge_sediment:本回合是否即时沉淀了一条 KH */
  sedimented: z.boolean(),
  /** nudge_sync:是否已把本 session 提优先给语料流 */
  synced: z.boolean(),
  /** 上报衍生动作，供调用方观测 */
  actions: z.array(z.string()),
  /** Native Stop validation: one correction, then an explicit failure halt. */
  answerValidation: z.object({
    status: z.enum(["correct", "failed"]),
    reason: z.string(),
    /** One native Stop continuation to display terminal failure, not retry work. */
    notificationPrompt: z.string().optional(),
  }).optional(),
})
export type ReportResponse = z.infer<typeof ReportResponse>

// ────────────────────────────────────────────────────────────────────
// health —— GET /health,存活探针(无鉴权也可探活,但不泄漏敏感信息)
// ────────────────────────────────────────────────────────────────────

export const HealthResponse = z.object({
  ok: z.literal(true),
  pid: z.number(),
  started_at: z.string(),
  version: z.string(),
  metrics: z.record(z.string(), z.union([z.number(), z.string()])),
})
export type HealthResponse = z.infer<typeof HealthResponse>

/** 规范动词。所有薄壳只走这两个 + health。 */
export const VERBS = ["inject", "report"] as const
export type Verb = (typeof VERBS)[number]
