import { randomUUID } from "node:crypto"
import { BUG_PUBLIC_ID_PATTERN, REQUIREMENT_PUBLIC_ID_PATTERN, isBugCreateIntentText, isBugPublicId, parseWorkItemPublicId, toTaskOperationId, type TaskCapabilitySourceClient } from "@cerebro/wire"
import type { InjectAttachment, InjectRequest } from "../transport/contract.ts"
import { bugIntakePath } from "../transport/discovery.ts"
import {
  fetchVisibleProductIterations,
  fetchVisibleProductMembers,
  fetchVisibleProductModules,
  fetchVisibleProductions,
  bugAttachmentTokensReady,
  cancelBugAttachmentUpload,
  queryBug,
  queryBugActivity,
  queryBugs,
  resolveRepoContext,
  uploadBugAttachments,
  type BugWorkItem,
  type VisibleProductIteration,
  type VisibleProductModule,
  type VisibleProduction,
  type VisibleUser,
} from "../transport/brain-contract-align.ts"
import { sessionKey } from "./session-store.ts"
import {
  assertTaskIntakeDraftMatches,
  isStoredTaskIntakeRef,
  loadTaskIntakeSessions,
  persistTaskIntakeSessions,
  taskIntakeDraftTrust,
  TaskIntakeRefInvalidError,
  type StoredTaskIntakeRef,
  type TaskIntakeDraftTrust,
} from "./task-intake-session.ts"
import { readMachineId } from "./token-store.ts"
import {
  cancelTaskDraftWithReconciliation,
  defaultTaskDraftLifecycle,
  draftPayload,
  inspectTaskDraftAfterConfirmError,
  readableTaskOperationError,
  replaceTaskDraft,
  TaskDraftReplacementRollbackError,
  type TaskDraftCleanupRef,
  type TaskDraftLifecycle,
} from "./task-draft-lifecycle.ts"
import {
  commentRevision,
  createWorkItemDraftContext,
  type WorkItemDraftContext,
  type WorkItemDraftContextDeps,
} from "./work-item-context-draft-binding.ts"

interface BugCatalogs { users: VisibleUser[]; modules: VisibleProductModule[]; iterations: VisibleProductIteration[] }
interface BugCreateSnapshot {
  title: string
  description: string
  assigneeUserId?: string
  details: Record<string, unknown>
  attachmentTokens?: string[]
}
interface BugCreateDraft {
  kind: "create"
  draftId?: string
  requestId: string
  sourceClient: TaskCapabilitySourceClient
  attempted: boolean
  snapshot: BugCreateSnapshot
  productions: VisibleProduction[]
  production?: VisibleProduction
  catalogs: BugCatalogs
  issues: string[]
  attachmentFiles: InjectAttachment[]
  blockedReason?: string
  cleanupDraftIds?: TaskDraftCleanupRef[]
  draftTrust?: TaskIntakeDraftTrust
}
interface BugOperationDraft {
  kind: "update" | "assign" | "transition" | "comment" | "delete_comment"
  draftId?: string
  requestId: string
  sourceClient: TaskCapabilitySourceClient
  attempted: boolean
  production: VisibleProduction
  bugId: string
  version: number
  expectedRevision?: number
  snapshot: Record<string, unknown>
  catalogs: BugCatalogs
  issues: string[]
  cleanupDraftIds?: TaskDraftCleanupRef[]
  draftTrust?: TaskIntakeDraftTrust
}
type BugPending = BugCreateDraft | BugOperationDraft

export interface BugIntake {
  ownsSession?(request: InjectRequest): boolean
  maybeHandle(request: InjectRequest): Promise<string | undefined>
}
export interface BugIntakeDeps {
  fetchProductions?: () => Promise<VisibleProduction[]>
  fetchMembers?: (productionId: string) => Promise<VisibleUser[]>
  fetchModules?: (productionId: string) => Promise<VisibleProductModule[]>
  fetchIterations?: (productionId: string) => Promise<VisibleProductIteration[]>
  resolveRepoContext?: typeof resolveRepoContext
  queryBug?: typeof queryBug
  queryBugs?: typeof queryBugs
  queryBugActivity?: typeof queryBugActivity
  uploadBugAttachments?: typeof uploadBugAttachments
  cancelBugAttachmentUpload?: typeof cancelBugAttachmentUpload
  bugAttachmentTokensReady?: typeof bugAttachmentTokensReady
  createDraft?: TaskDraftLifecycle["create"]
  getDraft?: TaskDraftLifecycle["get"]
  confirmDraft?: TaskDraftLifecycle["confirm"]
  cancelDraft?: TaskDraftLifecycle["cancel"]
  createTaskCommandDraft?: TaskDraftLifecycle["create"]
  getTaskCommandDraft?: TaskDraftLifecycle["get"]
  findTaskDraftByRequest?: TaskDraftLifecycle["findByRequest"]
  confirmTaskCommandDraft?: TaskDraftLifecycle["confirm"]
  cancelTaskCommandDraft?: TaskDraftLifecycle["cancel"]
  workItemDraftContext?: WorkItemDraftContextDeps
}

const BUG_ID = new RegExp(`\\b${BUG_PUBLIC_ID_PATTERN}\\b`, 'i')
const QUERY = new RegExp(`(?:查询|查看|列出|搜索|我的).*(?:${BUG_PUBLIC_ID_PATTERN}|Bug|缺陷)|\\b${BUG_PUBLIC_ID_PATTERN}\\b`, 'i')
const UPDATE = new RegExp(`^(?:修改|更新)\\s*(${BUG_PUBLIC_ID_PATTERN})(?:\\s*[：:]\\s*([\\s\\S]+))?$`, 'i')
const ASSIGN = new RegExp(`^(?:指派|分配)\\s*(${BUG_PUBLIC_ID_PATTERN})\\s*(?:给|负责人\\s*[：:])\\s*(.+)$`, 'i')
const TRANSITION = new RegExp(`^(?:流转|修改状态)\\s*(${BUG_PUBLIC_ID_PATTERN})\\s*(?:到|为|状态\\s*[：:])\\s*(\\S+)(?:\\s*[：:]\\s*(.*))?$`, 'i')
const COMMENT = new RegExp(`^(?:给|在)?\\s*(${BUG_PUBLIC_ID_PATTERN})\\s*(?:评论|留言)\\s*[：:]\\s*(.+)$`, 'i')
const DELETE_COMMENT = new RegExp(`^删除\\s*(${BUG_PUBLIC_ID_PATTERN})\\s*(?:的)?评论\\s*[：:]?\\s*([0-9a-f-]{36})$`, 'i')
const BUG_OPERATION_ACTION = /^(确认|取消)\s*(?:Bug|缺陷)\s*操作\s*[：:]?\s*(OP-[0-9A-F]{8})[。！!]*$/i
const LEGACY_CONFIRM = /^(?:确认报 bug|确认提交 bug|确认提交)[。！!]*$/i
const LEGACY_CANCEL = /^(?:取消|取消提交|放弃)[。！!]*$/
const ENUMS: Record<string, { key: string; values: Record<string, string> }> = {
  "优先级": { key: "priority", values: { "高": "high", "中": "medium", "低": "low", high: "high", medium: "medium", low: "low" } },
  "严重程度": { key: "severity", values: { "致命": "fatal", "严重": "critical", "一般": "normal", "提示": "notice", "建议": "suggestion", fatal: "fatal", critical: "critical", normal: "normal", notice: "notice", suggestion: "suggestion" } },
  "重现概率": { key: "reproductionProbability", values: { "必现": "always", "大概率": "likely", "小概率": "unlikely", "只出现一次": "once", always: "always", likely: "likely", unlikely: "unlikely", once: "once" } },
  "缺陷类型": { key: "defectType", values: { "功能问题": "functional", "表现问题": "appearance", "UI界面问题": "ui", "体验问题": "experience", "兼容适配问题": "compatibility", "配置问题": "configuration", "性能问题": "performance", "需求问题": "requirement", "接口问题": "interface", "安全问题": "security", "弱网重连问题": "weak_network_reconnect" } },
}
const TEXT_DETAILS: Record<string, string> = { "复现步骤": "reproductionSteps", "重现步骤": "reproductionSteps", "实际结果": "actualResult", "期望结果": "expectedResult", "客户端版本": "clientVersion", "服务端版本": "serverVersion", "服务器": "server", "局内战局 ID": "battleId", "账号 ID": "accountId" }

export function isBugIntakeIntent(input: string): boolean {
  const text = input.trim()
  return !/^(?:不要|别|暂不|不想|不用|无需|确认)/.test(text) && (isBugCreateIntent(text) || QUERY.test(text) || matchesOperation(text))
}

export function isBugCreateIntent(input: string): boolean {
  return isBugCreateIntentText(input)
}

export function isBugOperationAction(input: string): boolean {
  return BUG_OPERATION_ACTION.test(input.trim())
}

export function createBugIntake(env: NodeJS.ProcessEnv = process.env, deps: BugIntakeDeps = {}): BugIntake {
  const path = bugIntakePath(env)
  const state: { sessions: Record<string, BugPending | StoredTaskIntakeRef> } = { sessions: loadTaskIntakeSessions(path) }
  const save = () => persistTaskIntakeSessions(path, state.sessions, bugPendingRef)
  const getProductions = deps.fetchProductions ?? (() => fetchVisibleProductions(env))
  const getMembers = deps.fetchMembers ?? ((id) => fetchVisibleProductMembers(id, env))
  const getModules = deps.fetchModules ?? ((id) => fetchVisibleProductModules(id, env))
  const getIterations = deps.fetchIterations ?? ((id) => fetchVisibleProductIterations(id, env))
  const resolveContext = deps.resolveRepoContext ?? ((cwd, machineId) => resolveRepoContext(cwd, machineId, env))
  const readBug = deps.queryBug ?? ((productionId, id) => queryBug(productionId, id, env))
  const readActivity = deps.queryBugActivity ?? ((productionId, id) => queryBugActivity(productionId, id, env))
  const readBugs = deps.queryBugs ?? ((productionId, filters) => queryBugs(productionId, filters, env))
  const uploadAttachments = deps.uploadBugAttachments ?? ((files, productionId) => uploadBugAttachments(files, productionId, env))
  const cancelAttachment = deps.cancelBugAttachmentUpload ?? ((token, productionId) => cancelBugAttachmentUpload(token, productionId, env))
  const attachmentTokensReady = deps.bugAttachmentTokensReady ?? ((tokens, productionId) => bugAttachmentTokensReady(tokens, productionId, env))
  const defaults = defaultTaskDraftLifecycle(env)
  const draftLifecycle: TaskDraftLifecycle = {
    create: deps.createDraft ?? deps.createTaskCommandDraft ?? defaults.create,
    get: deps.getDraft ?? deps.getTaskCommandDraft ?? defaults.get,
    findByRequest: deps.findTaskDraftByRequest ?? defaults.findByRequest,
    confirm: deps.confirmDraft ?? deps.confirmTaskCommandDraft ?? defaults.confirm,
    cancel: deps.cancelDraft ?? deps.cancelTaskCommandDraft ?? defaults.cancel,
  }
  const draftContext = createWorkItemDraftContext(env, deps.workItemDraftContext)
  const submitting = new Set<string>()

  return {
    ownsSession(request) {
      return Boolean(state.sessions[sessionKey(request)])
    },

    async maybeHandle(request) {
      if (!request.session_id.trim()) return undefined
      const key = sessionKey(request); let pending = state.sessions[key]; const input = request.user_input.trim()
      if (isStoredTaskIntakeRef(pending)) {
        try {
          pending = await restorePending(pending)
          state.sessions[key] = pending
        } catch (error) {
          if (error instanceof TaskIntakeRefInvalidError) {
            delete state.sessions[key]
            save()
            return `[Synapse] 本地 Bug 操作引用无法从 Cerebro 恢复，已安全失效：${readableTaskOperationError(error)}`
          }
          return `[Synapse] 暂时无法从 Cerebro 恢复 Bug 操作，本地引用已保留，可稍后重试：${readableTaskOperationError(error)}`
        }
      }
      if (!pending && !isBugIntakeIntent(input)) return undefined
      if (submitting.has(key)) return "[Synapse] Bug 操作正在确认，当前不能修改或取消。"
      try {
        if (pending) await retryCleanupDrafts(pending)
        const requestedAction = parseBugOperationAction(input)
        if (pending && requestedAction && requestedAction.operationId !== pendingOperationId(pending)) {
          return pending.draftId
            ? `[Synapse] 当前待处理的是 Bug 操作 ${pendingOperationId(pending)}；请回复“${bugOperationActionText(requestedAction.action, pending)}”。`
            : "[Synapse] 当前 Bug 操作尚未生成可确认的操作 ID，请先处理上方待处理项。"
        }
        if (pending && isCancelInput(input, pending)) return await cancelPending(key, pending)
        if (pending?.attempted && !isConfirmInput(input, pending)) {
          return `[Synapse] 上次确认结果未知，Bug 操作已冻结；请回复“${bugOperationActionText("confirm", pending)}”安全重试，或回复“${bugOperationActionText("cancel", pending)}”。`
        }
        if (!pending && QUERY.test(input) && !matchesOperation(input) && !isBugCreateIntent(input)) return await answerQuery(input, request)
        if (!pending && matchesOperation(input)) return await beginOperation(key, input, request)
        if (!pending) return await beginCreate(key, input, request)
        if (pending.production && catalogsEmpty(pending.catalogs)) pending.catalogs = await catalogs(pending.production.id)
        return pending.kind === "create" ? await handleCreate(key, pending, input, request) : await handleOperation(key, pending, input)
      } catch (error) { return `[Synapse] Bug 操作失败：${readableTaskOperationError(error)}` }
    },
  }

  async function catalogs(productionId: string): Promise<BugCatalogs> {
    const [users, modules, iterations] = await Promise.all([getMembers(productionId), getModules(productionId), getIterations(productionId)])
    return { users, modules, iterations }
  }

  async function restorePending(ref: StoredTaskIntakeRef): Promise<BugPending> {
    const lookup = ref.draftId
      ? draftLifecycle.get(ref.productionId, ref.draftId)
      : ref.requestId && draftLifecycle.findByRequest
        ? draftLifecycle.findByRequest(ref.productionId, ref.requestId)
        : Promise.reject(new TaskIntakeRefInvalidError("本地操作引用缺少操作 ID，且当前服务端不支持按 requestId 恢复"))
    const [record, productions] = await Promise.all([lookup, getProductions()])
    assertTaskIntakeDraftMatches(record, ref)
    const payload = draftPayload(record)
    if (record.status !== "pending") {
      if (record.command === "bug.create" && record.status !== "confirmed") await cleanupAttachmentTokens(attachmentTokensOf(payload) ?? [], ref.productionId)
      throw new TaskIntakeRefInvalidError(`服务端操作状态为 ${record.status}`)
    }
    const production = productions.find((item) => item.id === ref.productionId)
    if (!production) throw new TaskIntakeRefInvalidError("操作所属产品当前不可见")
    const productCatalogs = await catalogs(production.id)
    const common = {
      draftId: record.id,
      requestId: ref.requestId,
      sourceClient: ref.sourceClient,
      attempted: ref.attempted,
      production,
      catalogs: productCatalogs,
      issues: ref.blockedReason ? [ref.blockedReason] : [] as string[],
      cleanupDraftIds: ref.cleanupDraftIds,
      blockedReason: ref.blockedReason,
      draftTrust: trustFromRef(ref),
    }
    if (record.command === "bug.create") {
      return { kind: "create", ...common, snapshot: normalizeBugSnapshot(payload), productions, attachmentFiles: [] }
    }
    const kindByCommand = {
      "bug.update": "update", "bug.assign": "assign", "bug.transition": "transition", "bug.comment": "comment", "bug.comment.delete": "delete_comment",
    } as const
    const kind = kindByCommand[record.command as keyof typeof kindByCommand]
    if (!kind || typeof payload.bugId !== "string" || typeof payload.version !== "number") throw new TaskIntakeRefInvalidError("服务端 Bug 操作无法恢复")
    return {
      kind, ...common, bugId: payload.bugId, version: payload.version,
      expectedRevision: typeof payload.expectedRevision === "number" ? payload.expectedRevision : undefined,
      snapshot: bugOperationSnapshot(payload),
    }
  }

  async function beginCreate(key: string, input: string, request: InjectRequest): Promise<string> {
    const [productions, context] = await Promise.all([getProductions(), resolveContext(request.cwd, readMachineId()).catch(() => null)])
    if (!productions.length) return "[Synapse] 当前没有可提交的产品。"
    const choice = chooseProduction(productions, context, input)
    const detail = extractBugDetail(input)
    const snapshot: BugCreateSnapshot = { title: titleOf(detail), description: descriptionOf(request, detail), details: {} }
    const draft: BugCreateDraft = { kind: "create", requestId: randomUUID(), sourceClient: request.client, attempted: false, snapshot, productions, production: choice.production, catalogs: emptyCatalogs(), issues: choice.issue ? [choice.issue] : [], attachmentFiles: [...(request.attachments ?? [])] }
    state.sessions[key] = draft
    if (draft.production) {
      draft.catalogs = await catalogs(draft.production.id)
      draft.issues.push(...applyBugFields(draft.snapshot, input, draft.catalogs))
      if (!draft.issues.some((issue) => issue.includes("产品"))) await installCreateDraft(draft)
    }
    save(); return renderCreate(draft)
  }

  async function handleCreate(key: string, draft: BugCreateDraft, input: string, request: InjectRequest): Promise<string> {
    if (request.attachments?.length && (!draft.production || !draft.draftId)) {
      const knownPaths = new Set(draft.attachmentFiles.map((file) => file.path))
      draft.attachmentFiles.push(...request.attachments.filter((file) => !knownPaths.has(file.path)))
    }
    const explicit = explicitProductionChoice(draft.productions, input)
    if (explicit.specified) {
      if (explicit.issue) { draft.issues = [explicit.issue]; save(); return renderCreate(draft) }
      if (explicit.production && !draft.production) {
        draft.production = explicit.production
        draft.catalogs = await catalogs(explicit.production.id)
        draft.issues = applyBugFields(draft.snapshot, input, draft.catalogs)
        await installCreateDraft(draft)
        save()
        return renderCreate(draft)
      }
      if (explicit.production && explicit.production.id !== draft.production?.id) {
        await switchCreateProduction(draft, explicit.production)
        save(); return renderCreate(draft)
      }
    }
    if (!draft.production) {
      const selected = selectProduction(draft.productions, input)
      if (!selected) return renderProducts(draft.productions, draft.issues)
      draft.production = selected; draft.catalogs = await catalogs(selected.id)
      draft.issues = applyBugFields(draft.snapshot, input, draft.catalogs)
      await installCreateDraft(draft)
      save(); return renderCreate(draft)
    }
    if (request.attachments?.length) {
      const changed = await addCreateAttachments(draft, request.attachments)
      if (changed) { save(); return renderCreate(draft) }
    }
    if (!isConfirmInput(input, draft)) {
      const parsed = await parseCreateEdit(draft, input)
      if (parsed.changed) await replaceCreateDraft(draft, parsed.snapshot)
      draft.snapshot = parsed.snapshot; draft.issues = [...parsed.issues, ...(draft.blockedReason ? [draft.blockedReason] : [])]
      save(); return renderCreate(draft)
    }
    if (draft.issues.length || draft.blockedReason) { save(); return renderCreate(draft) }
    if (!draft.draftId) await installCreateDraft(draft)
    const attachmentTokens = draft.snapshot.attachmentTokens ?? []
    if (attachmentTokens.length && !(await attachmentTokensReady(attachmentTokens, draft.production!.id))) {
      draft.issues = ["附件上传 token 已过期或不可用，请重新附加原文件后再确认"]
      save()
      return renderCreate(draft)
    }
    draft.attempted = true; save(); submitting.add(key)
    try {
      await draftContext.assertConfirmable(draftLifecycle, {
        productionId: draft.production!.id, draftId: draft.draftId!,
        requestId: draft.requestId, command: "bug.create",
        binding: requireDraftTrust(draft),
      })
      const receipt = await draftLifecycle.confirm(draft.production!.id, draft.draftId!)
      const result = parseBugResult(receipt.result, draft.production!.id)
      delete state.sessions[key]; saveAfterWrite(save)
      return `[Synapse] Bug ${result.publicId}“${draft.snapshot.title}”已创建。`
    } catch (error) { return await reconcileConfirmFailure(key, draft, error, "Bug") }
    finally { submitting.delete(key) }
  }

  async function parseCreateEdit(draft: BugCreateDraft, input: string): Promise<{ snapshot: BugCreateSnapshot; issues: string[]; changed: boolean }> {
    const base = normalizeBugSnapshot(draftPayload(await authoritativeCreateDraft(draft)))
    const before = JSON.stringify(base)
    const issues = applyBugFields(base, input, draft.catalogs)
    return { snapshot: base, issues, changed: before !== JSON.stringify(base) }
  }

  async function installCreateDraft(draft: BugCreateDraft): Promise<void> {
    const created = await createPendingDraft(draft, { requestId: draft.requestId, productionId: draft.production!.id, command: "bug.create", payload: bugCreatePayload(draft.snapshot), sourceClient: draft.sourceClient })
    draft.draftId = created.id
    save()
    if (!draft.attachmentFiles.length) return
    let tokens: string[]
    try {
      tokens = await uploadAttachments(draft.attachmentFiles, draft.production!.id)
    } catch (error) {
      draft.blockedReason = "附件上传失败；请重新附加文件后再确认，或先取消此 Bug 操作"
      draft.issues = [draft.blockedReason]
      save()
      throw error
    }
    const snapshot = { ...draft.snapshot, attachmentTokens: tokens }
    try {
      await replaceCreateDraft(draft, snapshot)
      draft.snapshot = snapshot
      save()
    } catch (error) {
      draft.blockedReason = "附件上传或写入失败；请重新附加文件后再确认，或先取消此 Bug 操作"
      draft.issues = [draft.blockedReason]
      save()
      await cleanupAttachmentTokens(tokens, draft.production!.id).catch(() => undefined)
      throw error
    }
  }

  async function addCreateAttachments(draft: BugCreateDraft, files: readonly InjectAttachment[]): Promise<boolean> {
    if (!draft.production || !draft.draftId) return false
    const base = normalizeBugSnapshot(draftPayload(await authoritativeCreateDraft(draft)))
    const existingTokens = base.attachmentTokens ?? []
    const existingReady = existingTokens.length === 0 || await attachmentTokensReady(existingTokens, draft.production.id)
    const knownPaths = new Set(draft.attachmentFiles.map((file) => file.path))
    const additions = existingReady ? files.filter((file) => !knownPaths.has(file.path)) : [...files]
    if (!additions.length) return false
    let newTokens: string[]
    try {
      newTokens = await uploadAttachments(additions, draft.production.id)
    } catch (error) {
      draft.blockedReason = "附件上传或写入失败；请重新附加文件后再确认，或先取消此 Bug 操作"
      draft.issues = [draft.blockedReason]
      save()
      throw error
    }
    const snapshot = { ...base, attachmentTokens: existingReady ? [...existingTokens, ...newTokens] : newTokens }
    try {
      await replaceCreateDraft(draft, snapshot)
    } catch (error) {
      draft.blockedReason = "附件上传或写入失败；请重新附加文件后再确认，或先取消此 Bug 操作"
      draft.issues = [draft.blockedReason]
      save()
      await cleanupAttachmentTokens(newTokens, draft.production.id).catch(() => undefined)
      throw error
    }
    draft.snapshot = snapshot
    draft.attachmentFiles = existingReady ? [...draft.attachmentFiles, ...additions] : [...additions]
    draft.blockedReason = undefined
    draft.issues = draft.issues.filter((issue) => !issue.includes("附件"))
    save()
    if (!existingReady) await cleanupAttachmentTokens(existingTokens, draft.production.id).catch(() => undefined)
    return true
  }

  async function replaceCreateDraft(draft: BugCreateDraft, snapshot: BugCreateSnapshot, oldProductionId = draft.production!.id): Promise<void> {
    const requestId = randomUUID()
    const result = await replacePendingDraft(draft, { productionId: oldProductionId, draftId: draft.draftId }, { requestId, productionId: draft.production!.id, command: "bug.create", payload: bugCreatePayload(snapshot), sourceClient: draft.sourceClient })
    draft.requestId = requestId; draft.draftId = result.id
    save()
  }

  async function switchCreateProduction(draft: BugCreateDraft, production: VisibleProduction): Promise<void> {
    const oldProductionId = draft.production!.id
    const snapshot = normalizeBugSnapshot(draftPayload(await authoritativeCreateDraft(draft)))
    if (snapshot.attachmentTokens?.length) {
      draft.snapshot = snapshot
      draft.issues = ["附件上传 token 已绑定当前产品；请先取消当前 Bug 操作，再在目标产品重新发起并附加文件"]
      return
    }
    snapshot.assigneeUserId = undefined; delete snapshot.details.moduleId; delete snapshot.details.iterationId
    const catalogsForProduction = await catalogs(production.id)
    const requestId = randomUUID()
    const replacement = await replacePendingDraft(draft, { productionId: oldProductionId, draftId: draft.draftId }, { requestId, productionId: production.id, command: "bug.create", payload: bugCreatePayload(snapshot), sourceClient: draft.sourceClient })
    draft.production = production; draft.catalogs = catalogsForProduction; draft.snapshot = snapshot; draft.issues = []
    draft.requestId = requestId; draft.draftId = replacement.id
  }

  async function beginOperation(key: string, input: string, request: InjectRequest): Promise<string> {
    const choice = await currentProduction(request, input)
    const production = choice.production
    if (!production) return `[Synapse] ${choice.issue ?? "无法唯一确定当前产品，未创建 Bug 操作。"}`
    const id = input.match(BUG_ID)?.[0]?.toUpperCase()
    if (!id) return "[Synapse] Bug 操作必须使用产品码-B序号公共 ID，例如 AA-B0001。"
    const [bug, productCatalogs] = await Promise.all([readBug(production.id, id), catalogs(production.id)])
    const changed = input.match(UPDATE); const assigned = input.match(ASSIGN); const transition = input.match(TRANSITION); const comment = input.match(COMMENT); const deleted = input.match(DELETE_COMMENT)
    let operation: BugOperationDraft
    let operationContext: WorkItemDraftContext | undefined
    if (assigned) {
      const assignee = byNameOrId(productCatalogs.users, assigned[2].trim())
      operation = { kind: "assign", requestId: randomUUID(), sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: assignee ? { assigneeUserId: assignee.id } : {}, catalogs: productCatalogs, issues: assignee ? [] : [`当前产品中无法唯一匹配负责人“${assigned[2].trim()}”`] }
    } else if (transition) operation = { kind: "transition", requestId: randomUUID(), sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: { toState: transition[2], ...(transition[3]?.trim() ? { reason: transition[3].trim() } : {}) }, catalogs: productCatalogs, issues: [] }
    else if (comment) operation = { kind: "comment", requestId: randomUUID(), sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: { body: comment[2].trim() }, catalogs: productCatalogs, issues: [] }
    else if (deleted) {
      const requestId = randomUUID()
      operationContext = await draftContext.load({
        command: "bug.comment.delete",
        payload: { bugId: id, version: bug.version, commentId: deleted[2], expectedRevision: 1 },
        taskGoal: input,
        requestId,
      })
      if (!operationContext) throw new Error("评论删除操作缺少上下文")
      const expectedRevision = commentRevision(operationContext, id, deleted[2])
      operation = expectedRevision
        ? { kind: "delete_comment", requestId, sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, expectedRevision, snapshot: { commentId: deleted[2], expectedRevision }, catalogs: productCatalogs, issues: [] }
        : { kind: "delete_comment", requestId, sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: { commentId: deleted[2] }, catalogs: productCatalogs, issues: ["当前 Bug 上下文中未找到可删除的这条评论"] }
    }
    else {
      const parsed = parseBugUpdates(changed?.[2] ?? "", productCatalogs)
      const assigneeUserId = parsed.payload.assigneeUserId; delete parsed.payload.assigneeUserId
      if (typeof assigneeUserId === "string" && Object.keys(parsed.payload).length === 0) operation = { kind: "assign", requestId: randomUUID(), sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: { assigneeUserId }, catalogs: productCatalogs, issues: parsed.issues }
      else { if (assigneeUserId !== undefined) parsed.issues.push("负责人变更请使用“指派 AA-B0001 给 XXX”这类命令，不能与其他 Bug 字段合并修改"); operation = { kind: "update", requestId: randomUUID(), sourceClient: request.client, attempted: false, production, bugId: id, version: bug.version, snapshot: parsed.payload, catalogs: productCatalogs, issues: parsed.issues } }
    }
    // Register before the remote write so a lost create response can be retried
    // with the same idempotency requestId in this daemon.
    state.sessions[key] = operation
    save()
    if (operation.issues.length === 0) {
      const command = operationCommand(operation)
      const payload = operationPayload(operation)
      const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, production.id, command, payload, input, operation.sourceClient, operationContext))
      operation.draftId = created.id
      saveAfterWrite(save)
    }
    save(); return renderOperation(operation)
  }

  async function handleOperation(key: string, operation: BugOperationDraft, input: string): Promise<string> {
    if (!isConfirmInput(input, operation)) {
      if (operation.kind === "update") {
        const base = !operation.draftId ? { ...operation.snapshot } : await authoritativeOperationPayload(operation)
        const parsed = parseBugUpdates(input, operation.catalogs)
        const snapshot = { ...base, ...parsed.payload }
        if (JSON.stringify(base) !== JSON.stringify(snapshot)) {
          if (operation.draftId) await replaceOperationDraft(operation, snapshot)
          else if (parsed.issues.length === 0) {
            const command = operationCommand(operation)
            const payload = operationPayload({ ...operation, snapshot })
            const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, operation.production.id, command, payload, input, operation.sourceClient))
            operation.draftId = created.id
          }
        }
        operation.snapshot = snapshot; operation.issues = parsed.issues
      }
      save(); return renderOperation(operation)
    }
    if (operation.issues.length || !Object.keys(operation.snapshot).length) return renderOperation(operation)
    if (!operation.draftId) {
      const command = operationCommand(operation)
      const payload = operationPayload(operation)
      const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, operation.production.id, command, payload, input, operation.sourceClient))
      operation.draftId = created.id
      saveAfterWrite(save)
    }
    operation.attempted = true; save(); submitting.add(key)
    try {
      await draftContext.assertConfirmable(draftLifecycle, {
        productionId: operation.production.id, draftId: operation.draftId!,
        requestId: operation.requestId, command: operationCommand(operation),
        binding: requireDraftTrust(operation),
      })
      const receipt = await draftLifecycle.confirm(operation.production.id, operation.draftId!)
      const resultText = operationResultText(operation, receipt.result, receipt.draft.confirmedAt ?? receipt.draft.createdAt)
      delete state.sessions[key]; saveAfterWrite(save); return `[Synapse] ${resultText}`
    } catch (error) { return await reconcileConfirmFailure(key, operation, error, "Bug 操作") }
    finally { submitting.delete(key) }
  }

  async function replaceOperationDraft(operation: BugOperationDraft, payload: Record<string, unknown>): Promise<void> {
    const requestId = randomUUID()
    const command = operationCommand(operation)
    const nextPayload = operationPayload({ ...operation, snapshot: payload })
    const input = await createDraftInput(requestId, operation.production.id, command, nextPayload, `修改 ${operation.bugId}`, operation.sourceClient)
    const result = await replacePendingDraft(operation, { productionId: operation.production.id, draftId: operation.draftId }, input)
    operation.requestId = requestId; operation.draftId = result.id
  }

  async function cancelPending(key: string, pending: BugPending): Promise<string> {
    const remoteStatus = pending.draftId
      ? (await cancelTaskDraftWithReconciliation(draftLifecycle, pending.production?.id ?? "", pending.draftId)).status
      : undefined
    if (pending.kind === "create" && remoteStatus !== "confirmed") {
      pending.attempted = true
      save()
      await cleanupAttachmentTokens(pending.snapshot.attachmentTokens ?? [], pending.production?.id ?? "")
    }
    delete state.sessions[key]
    save()
    if (remoteStatus === "confirmed") return "[Synapse] Bug 操作已由 Cerebro 确认，本地引用已清理；请查询对应记录核对。"
    if (remoteStatus === "failed" || remoteStatus === "expired") return `[Synapse] Bug 操作已${remoteStatus === "failed" ? "执行失败" : "过期"}，本地引用已清理。`
    return "[Synapse] 已取消 Bug 操作，服务端未确认任何写入，本地引用已清理。"
  }

  async function replacePendingDraft(
    pending: BugPending,
    oldDraft: { productionId: string; draftId?: string },
    input: Parameters<TaskDraftLifecycle["create"]>[0],
  ) {
    const trust = taskIntakeDraftTrust(input)
    try {
      const created = await replaceTaskDraft(draftLifecycle, oldDraft, input, (record) => {
        assertTaskIntakeDraftMatches(record, { productionId: input.productionId, ...trust })
      })
      pending.requestId = input.requestId
      pending.draftTrust = trust
      return created
    } catch (error) {
      if (error instanceof TaskDraftReplacementRollbackError) {
        const cleanup = { draftId: error.newDraftId, productionId: error.newProductionId }
        if (!pending.cleanupDraftIds?.some((item) => item.draftId === cleanup.draftId && item.productionId === cleanup.productionId)) {
          pending.cleanupDraftIds = [...(pending.cleanupDraftIds ?? []), cleanup]
          save()
        }
      }
      throw error
    }
  }

  async function retryCleanupDrafts(pending: BugPending): Promise<void> {
    if (!pending.cleanupDraftIds?.length) return
    const remaining: TaskDraftCleanupRef[] = []
    const errors: unknown[] = []
    for (const cleanup of pending.cleanupDraftIds) {
      try {
        const result = await cancelTaskDraftWithReconciliation(draftLifecycle, cleanup.productionId, cleanup.draftId)
        if (result.status === "confirmed") errors.push(new Error(`待清理操作 ${toTaskOperationId(cleanup.draftId)} 已被确认，请先查询核对`))
      } catch (error) {
        remaining.push(cleanup)
        errors.push(error)
      }
    }
    pending.cleanupDraftIds = remaining.length ? remaining : undefined
    save()
    if (errors.length === 1) throw errors[0]
    if (errors.length > 1) throw new AggregateError(errors, "仍有服务端操作无法清理")
  }

  async function authoritativeCreateDraft(draft: BugCreateDraft) { if (!draft.draftId) throw new Error("服务端操作尚未创建"); return draftLifecycle.get(draft.production!.id, draft.draftId) }
  async function authoritativeOperationPayload(operation: BugOperationDraft): Promise<Record<string, unknown>> { if (!operation.draftId) throw new Error("服务端操作尚未创建"); return draftPayload(await draftLifecycle.get(operation.production.id, operation.draftId)) }

  async function createDraftInput(
    requestId: string,
    productionId: string,
    command: ReturnType<typeof operationCommand>,
    payload: Record<string, unknown>,
    taskGoal: string,
    sourceClient: TaskCapabilitySourceClient,
    context?: WorkItemDraftContext,
  ) {
    const loaded = context ?? await draftContext.load({ command, payload, taskGoal, requestId })
    return { requestId, productionId, command, payload, sourceClient, ...(loaded?.binding ?? {}) }
  }

  async function createPendingDraft(
    pending: BugPending,
    input: Parameters<TaskDraftLifecycle["create"]>[0],
  ) {
    const trust = taskIntakeDraftTrust(input)
    pending.requestId = input.requestId
    pending.draftTrust = trust
    save()
    const created = await draftLifecycle.create(input)
    assertTaskIntakeDraftMatches(created, { productionId: input.productionId, ...trust })
    return created
  }

  async function reconcileConfirmFailure(key: string, pending: BugPending, error: unknown, label: string): Promise<string> {
    const current = pending.draftId && pending.production
      ? await inspectTaskDraftAfterConfirmError(draftLifecycle, pending.production.id, pending.draftId)
      : undefined
    if (!current) return `[Synapse] ${label}确认结果未知，无法读取服务端状态；请回复“${bugOperationActionText("confirm", pending)}”安全重试，或回复“${bugOperationActionText("cancel", pending)}”：${readableTaskOperationError(error)}`
    if (current.status === "pending") return `[Synapse] ${label}尚未确认，服务端状态仍为 pending；请回复“${bugOperationActionText("confirm", pending)}”安全重试，或回复“${bugOperationActionText("cancel", pending)}”：${readableTaskOperationError(error)}`
    if (current.status === "confirmed") {
      delete state.sessions[key]
      saveAfterWrite(save)
      return `[Synapse] ${label}已由 Cerebro 确认，但本次未取回结果；请查询对应记录核对。`
    }
    if (pending.kind === "create") await cleanupAttachmentTokens(pending.snapshot.attachmentTokens ?? [], pending.production?.id ?? "")
    delete state.sessions[key]
    saveAfterWrite(save)
    const statusText = current.status === "failed" ? "执行失败" : current.status === "expired" ? "已过期" : "已取消"
    return `[Synapse] ${label}在服务端${statusText}，本地引用已清理；请重新发起操作。`
  }

  async function cleanupAttachmentTokens(tokens: readonly string[], productionId: string): Promise<void> {
    if (!tokens.length || !productionId) return
    await Promise.all(tokens.map((token) => cancelAttachment(token, productionId)))
  }

  async function answerQuery(input: string, request: InjectRequest): Promise<string> {
    const requirementId = input.match(new RegExp(`\\b${REQUIREMENT_PUBLIC_ID_PATTERN}\\b`, 'i'))?.[0]?.toUpperCase()
    if (requirementId) return `[Synapse] ${requirementId} 是需求 ID，不能用于 Bug 查询。`
    const choice = await currentProduction(request, input)
    const production = choice.production
    if (!production) return `[Synapse] ${choice.issue ?? "无法唯一确定当前产品，未执行 Bug 查询。"}`
    const id = input.match(BUG_ID)?.[0]?.toUpperCase()
    if (id && /(?:动态|历史|评论|变更)/.test(input)) {
      const activityCursor = input.match(/(?:活动|变更|历史)游标\s*[：:]\s*(\S+)/)?.[1]
      const limitText = input.match(/(?:每页|数量|条数)\s*[：:]\s*(\d+)/)?.[1]
      const activity = await readActivity(production.id, id, {
        ...(activityCursor ? { activityCursor } : {}),
        ...(limitText ? { limit: Number(limitText) } : {}),
      })
      const changes: { items: unknown[]; nextCursor?: string } = Array.isArray(activity.changes) ? { items: activity.changes } : activity.changes
      return `[Synapse] Bug ${id} 动态：\n评论（${activity.comments.length}）\n${activity.comments.slice(0, 10).map(formatActivity).join("\n") || "- 无"}\n变更（${changes.items.length}）\n${changes.items.slice(0, 10).map(formatActivity).join("\n") || "- 无"}${changes.nextCursor ? `\n变更 nextCursor: ${changes.nextCursor}` : ""}`
    }
    if (id) return `[Synapse] ${formatBug(await readBug(production.id, id))}`
    const productCatalogs = await catalogs(production.id)
    const filters: Parameters<typeof queryBugs>[1] = { mine: /我的|我负责/.test(input) }
    const priority = input.match(/优先级\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
      ?? Object.keys(ENUMS["优先级"].values).find((label) => input.includes(`优先级${label}`))
    if (priority && ENUMS["优先级"].values[priority]) filters.priority = ENUMS["优先级"].values[priority] as "high" | "medium" | "low"
    const stateValue = input.match(/(?:状态|当前状态)\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    if (stateValue) filters.state = stateValue
    const iterationLabel = input.match(/(?:所属迭代|迭代)\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    const iteration = iterationLabel ? byNameOrId(productCatalogs.iterations, iterationLabel) : undefined
    if (iteration) filters.iterationId = iteration.id
    const search = input.match(/(?:搜索|关键词|标题)\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    const cursor = input.match(/(?:Bug|列表)游标\s*[：:]\s*(\S+)/i)?.[1]
    const pageSize = input.match(/(?:每页|数量|条数)\s*[：:]\s*(\d+)/)?.[1]
    if (search) filters.search = search
    if (cursor) filters.cursor = cursor
    if (pageSize) filters.limit = Number(pageSize)
    const result = await readBugs(production.id, filters)
    if (!result.items.length) return "[Synapse] 当前产品在该条件下没有 Bug。"
    return `[Synapse] 当前产品 Bug（${result.total} 项）：\n${result.items.map((item) => `- ${formatBug(item)}`).join("\n")}${result.nextCursor ? `\nBug 列表 nextCursor: ${result.nextCursor}` : ""}`
  }

  async function currentProduction(request: InjectRequest, input = ""): Promise<{ production?: VisibleProduction; issue?: string }> {
    const [productions, context] = await Promise.all([getProductions(), resolveContext(request.cwd, readMachineId()).catch(() => null)])
    return chooseProduction(productions, context, input)
  }
}

function matchesOperation(input: string): boolean { return UPDATE.test(input) || ASSIGN.test(input) || TRANSITION.test(input) || COMMENT.test(input) || DELETE_COMMENT.test(input) }
function parseBugOperationAction(input: string): { action: "confirm" | "cancel"; operationId: string } | undefined {
  const match = input.trim().match(BUG_OPERATION_ACTION)
  return match ? { action: match[1] === "确认" ? "confirm" : "cancel", operationId: match[2]!.toUpperCase() } : undefined
}
function isConfirmInput(input: string, pending: BugPending): boolean {
  const action = parseBugOperationAction(input)
  return action
    ? action.action === "confirm" && action.operationId === pendingOperationId(pending)
    : LEGACY_CONFIRM.test(input)
}
function isCancelInput(input: string, pending: BugPending): boolean {
  const action = parseBugOperationAction(input)
  return action
    ? action.action === "cancel" && action.operationId === pendingOperationId(pending)
    : LEGACY_CANCEL.test(input)
}
function bugOperationActionText(action: "confirm" | "cancel", pending: BugPending): string {
  return `${action === "confirm" ? "确认" : "取消"}Bug操作 ${pendingOperationId(pending) ?? "<操作ID>"}`
}
function pendingOperationId(pending: BugPending): string | undefined { return pending.draftId ? toTaskOperationId(pending.draftId) : undefined }
function emptyCatalogs(): BugCatalogs { return { users: [], modules: [], iterations: [] } }
function catalogsEmpty(catalogs: BugCatalogs): boolean { return catalogs.users.length === 0 && catalogs.modules.length === 0 && catalogs.iterations.length === 0 }
function labelValue(input: string, label: string): string | undefined { return input.match(new RegExp(`^${label}\\s*[：:]\\s*(.+)$`))?.[1]?.trim() }
function byNameOrId<T extends { id: string; name: string }>(items: T[], value: string): T | undefined { const found = items.filter((item) => item.id === value || item.name === value || item.name.includes(value)); return found.length === 1 ? found[0] : undefined }
function explicitProductionChoice(items: VisibleProduction[], input: string): { specified: boolean; production?: VisibleProduction; issue?: string } { const match = input.match(/(?:^|\r?\n)\s*产品(?:线)?\s*[：:]\s*([^\n，,]+)/); if (!match) return { specified: false }; const value = match[1]!.trim(); const found = items.filter((item) => item.id === value || item.name === value); if (found.length === 1) return { specified: true, production: found[0] }; return { specified: true, issue: found.length ? `产品“${value}”匹配到多个产品，请明确选择` : `不存在产品“${value}”，请从候选产品中选择` } }
function chooseProduction(items: VisibleProduction[], context: Awaited<ReturnType<typeof resolveRepoContext>>, input: string): { production?: VisibleProduction; issue?: string } {
  // Public ID carries the product key and is authoritative. Resolve every ID in
  // the message first so an explicit product label cannot silently override it.
  const publicIds = [...input.matchAll(new RegExp(`\\b(?:${BUG_PUBLIC_ID_PATTERN}|${REQUIREMENT_PUBLIC_ID_PATTERN})\\b`, 'gi'))]
    .map((match) => parseWorkItemPublicId(match[0]!))
    .filter((parsed): parsed is NonNullable<typeof parsed> => parsed !== null)
  const keys = [...new Set(publicIds.map((parsed) => parsed.workItemKey))]
  if (keys.length > 1) return { issue: '同一条消息包含多个产品的工作项 ID，请分开操作' }
  const idProduct = keys.length === 1 ? items.filter((item) => item.workItemKey?.toUpperCase() === keys[0]) : []
  if (keys.length === 1 && idProduct.length !== 1) return { issue: `无法在当前可见产品中定位 ID 所属产品（${publicIds[0]!.publicId}）` }

  const explicit = explicitProductionChoice(items, input)
  if (explicit.specified) {
    if (explicit.production && idProduct[0] && explicit.production.id !== idProduct[0].id) {
      return { issue: `显式产品与工作项 ID（${publicIds[0]!.publicId}）所属产品不一致` }
    }
    return explicit
  }
  if (idProduct.length === 1) {
    if (context && context.productionId !== idProduct[0]!.id) return { issue: `该 Bug 属于产品“${idProduct[0]!.name}”，与当前工作区产品不一致` }
    return { production: idProduct[0] }
  }
  const named = items.filter((item) => input.includes(item.name)); if (named.length > 1) return { issue: "输入同时提到多个产品，请明确回复“产品：产品名”" }; if (named.length === 1) return { production: named[0] }; const contextual = context ? items.filter((item) => item.id === context.productionId) : []; if (contextual.length === 1) return { production: contextual[0] }; return items.length === 1 ? { production: items[0] } : {}
}
function selectProduction(items: VisibleProduction[], input: string): VisibleProduction | undefined { const explicit = explicitProductionChoice(items, input); if (explicit.specified) return explicit.production; const ordinal = input.match(/第\s*(\d+)\s*个/); if (ordinal) return items[Number(ordinal[1]) - 1]; const found = items.filter((item) => input.includes(item.name)); return found.length === 1 ? found[0] : undefined }

function renderProducts(items: VisibleProduction[], issues: string[] = []): string { return [issues.length ? `待处理：\n${issues.map((issue) => `- ${issue}`).join("\n")}` : "", "[Synapse] 请选择 Bug 所属产品：", ...items.map((item, index) => `${index + 1}. ${item.name}`)].filter(Boolean).join("\n") }

function applyBugFields(snapshot: BugCreateSnapshot, input: string, catalogs: BugCatalogs): string[] { const parsed = parseBugUpdates(input, catalogs); if (typeof parsed.payload.title === "string") snapshot.title = parsed.payload.title; if (typeof parsed.payload.description === "string") snapshot.description = parsed.payload.description; if (typeof parsed.payload.assigneeUserId === "string") snapshot.assigneeUserId = parsed.payload.assigneeUserId; if (parsed.payload.details && typeof parsed.payload.details === "object") snapshot.details = { ...snapshot.details, ...(parsed.payload.details as Record<string, unknown>) }; return parsed.issues }
function parseBugUpdates(input: string, catalogs: BugCatalogs): { payload: Record<string, unknown>; issues: string[] } { const payload: Record<string, unknown> = {}; const details: Record<string, unknown> = {}; const issues: string[] = []; for (const line of input.replace(/，\s*(?=[^，：:]+[：:])/g, "\n").split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) { const title = labelValue(line, "标题"); if (title !== undefined) { payload.title = title.slice(0, 256); continue }; const description = labelValue(line, "问题说明") ?? labelValue(line, "正文") ?? labelValue(line, "描述"); if (description !== undefined) { payload.description = description.slice(0, 200_000); continue }; const assignee = labelValue(line, "负责人") ?? labelValue(line, "指派"); if (assignee !== undefined) { const item = byNameOrId(catalogs.users, assignee); if (item) payload.assigneeUserId = item.id; else issues.push(`当前产品中无法唯一匹配负责人“${assignee}”`); continue }; const moduleName = labelValue(line, "功能模块"); if (moduleName !== undefined) { const item = byNameOrId(catalogs.modules, moduleName); if (item) details.moduleId = item.id; else issues.push(`当前产品中无法唯一匹配模块“${moduleName}”`); continue }; const iterationName = labelValue(line, "所属迭代"); if (iterationName !== undefined) { const item = byNameOrId(catalogs.iterations, iterationName); if (item) details.iterationId = item.id; else issues.push(`当前产品中无法唯一匹配迭代“${iterationName}”`); continue }; let matched = false; for (const [label, config] of Object.entries(ENUMS)) { const value = labelValue(line, label); if (value === undefined) continue; if (config.values[value]) details[config.key] = config.values[value]; else issues.push(`${label}“${value}”无效`); matched = true; break }; if (matched) continue; for (const [label, key] of Object.entries(TEXT_DETAILS)) { const value = labelValue(line, label); if (value !== undefined) { details[key] = value.slice(0, 20_000); matched = true; break } }; if (matched) continue; const observedAt = labelValue(line, "Bug 发现时间") ?? labelValue(line, "Bug 出现时间"); if (observedAt !== undefined) { const date = new Date(observedAt); if (Number.isNaN(date.getTime())) issues.push(`Bug 发现时间“${observedAt}”无法解析`); else details.observedAt = date.toISOString() } }; if (Object.keys(details).length) payload.details = details; return { payload, issues } }
function bugCreatePayload(snapshot: BugCreateSnapshot): Record<string, unknown> { return { title: snapshot.title, description: snapshot.description, ...(snapshot.assigneeUserId ? { assigneeUserId: snapshot.assigneeUserId } : {}), ...(Object.keys(snapshot.details).length ? { details: snapshot.details } : {}), ...(snapshot.attachmentTokens?.length ? { attachmentTokens: snapshot.attachmentTokens } : {}) } }
function normalizeBugSnapshot(payload: Record<string, unknown>): BugCreateSnapshot { return { title: typeof payload.title === "string" ? payload.title : "新 Bug", description: typeof payload.description === "string" ? payload.description : "", assigneeUserId: typeof payload.assigneeUserId === "string" ? payload.assigneeUserId : undefined, details: payload.details && typeof payload.details === "object" && !Array.isArray(payload.details) ? { ...(payload.details as Record<string, unknown>) } : {}, attachmentTokens: attachmentTokensOf(payload) } }
function attachmentTokensOf(payload: Record<string, unknown>): string[] | undefined { return Array.isArray(payload.attachmentTokens) && payload.attachmentTokens.every((token) => typeof token === "string" && token) ? [...payload.attachmentTokens] as string[] : undefined }
function operationCommand(operation: BugOperationDraft): "bug.update" | "bug.assign" | "bug.transition" | "bug.comment" | "bug.comment.delete" { return operation.kind === "update" ? "bug.update" : operation.kind === "assign" ? "bug.assign" : operation.kind === "transition" ? "bug.transition" : operation.kind === "comment" ? "bug.comment" : "bug.comment.delete" }
function operationPayload(operation: BugOperationDraft): Record<string, unknown> { return operation.kind === "update" ? { bugId: operation.bugId, version: operation.version, ...operation.snapshot } : operation.kind === "assign" ? { bugId: operation.bugId, version: operation.version, assigneeUserId: operation.snapshot.assigneeUserId } : operation.kind === "transition" ? { bugId: operation.bugId, version: operation.version, toState: operation.snapshot.toState, ...(operation.snapshot.reason ? { reason: operation.snapshot.reason } : {}) } : operation.kind === "comment" ? { bugId: operation.bugId, version: operation.version, body: operation.snapshot.body } : { bugId: operation.bugId, version: operation.version, commentId: operation.snapshot.commentId, expectedRevision: operation.expectedRevision } }
function bugOperationSnapshot(payload: Record<string, unknown>): Record<string, unknown> { const snapshot = { ...payload }; delete snapshot.bugId; delete snapshot.version; return snapshot }
function operationResultText(operation: BugOperationDraft, result: unknown, confirmedAt: string): string { if (operation.kind === "update" || operation.kind === "assign" || operation.kind === "transition") { const bug = parseBugResult(result, operation.production.id); return operation.kind === "transition" ? `Bug ${bug.publicId} 已流转到 ${bug.currentState}，时间 ${bug.updatedAt}。` : operation.kind === "assign" ? `Bug ${bug.publicId} 已改派，时间 ${bug.updatedAt}。` : `Bug ${bug.publicId} 已更新，时间 ${bug.updatedAt}。` }; if (operation.kind === "comment") { const value = result as { createdAt?: unknown }; return `Bug ${operation.bugId} 已添加评论，时间 ${String(value?.createdAt ?? confirmedAt)}。` }; const value = result as { deletedAt?: unknown }; return `Bug ${operation.bugId} 的评论已删除，时间 ${String(value?.deletedAt ?? confirmedAt)}。` }
function parseBugResult(value: unknown, productionId: string): BugWorkItem { const candidate = (value && typeof value === "object" && "bug" in value) ? (value as { bug?: unknown }).bug : value; const bug = candidate as Record<string, unknown>; if (!bug || typeof bug.id !== "string" || typeof bug.publicId !== "string" || !isBugPublicId(bug.publicId) || bug.productionId !== productionId || typeof bug.title !== "string" || typeof bug.version !== "number") throw new Error("invalid bug confirmation response"); return bug as unknown as BugWorkItem }
function formatBug(item: BugWorkItem): string { const d = item.details; return `Bug ${item.publicId} ${item.title} [${item.currentState}]；负责人 ${item.assigneeUserId}；优先级 ${String(d.priority ?? "未设置")}；迭代 ${String(d.iterationId ?? "需求池")}；发现时间 ${String(d.observedAt ?? "未记录")}；创建 ${item.createdAt}；更新 ${item.updatedAt}` }
function formatActivity(value: unknown): string { const item = value as Record<string, unknown>; const id = item.commentId ?? item.id ?? item.eventId; return `- ${String(item.createdAt ?? item.occurredAt ?? item.recordedAt ?? "时间未知")} ${String(item.eventType ?? "评论")}${typeof id === "string" ? ` [ID: ${id}]` : ""}${typeof item.body === "string" ? `：${item.body}` : ""}` }
function renderCreate(draft: BugCreateDraft): string { if (!draft.production) return renderProducts(draft.productions, draft.issues); const d = draft.snapshot.details; return ["[Synapse] 待确认的 Bug 操作", "操作：创建 Bug", `产品：${draft.production.name}`, `标题：${draft.snapshot.title}`, `描述：${draft.snapshot.description || "[未填写]"}`, `负责人：${draft.catalogs.users.find((item) => item.id === draft.snapshot.assigneeUserId)?.name ?? "[默认当前用户]"}`, `优先级：${String(d.priority ?? "medium")}`, `功能模块：${draft.catalogs.modules.find((item) => item.id === d.moduleId)?.name ?? "[未指定]"}`, `所属迭代：${draft.catalogs.iterations.find((item) => item.id === d.iterationId)?.name ?? "[需求池]"}`, `附件：${draft.snapshot.attachmentTokens?.length ?? draft.attachmentFiles.length} 个`, `严重程度：${String(d.severity ?? "[未指定]")}`, `重现概率：${String(d.reproductionProbability ?? "[未指定]")}`, `缺陷类型：${String(d.defectType ?? "[未指定]")}`, `Bug 发现时间：${String(d.observedAt ?? "[未填写]")}`, ...(draft.issues.length ? ["待处理：", ...draft.issues.map((item) => `- ${item}`)] : []), draft.draftId ? `可继续按字段修改；确认后单独回复“${bugOperationActionText("confirm", draft)}”。` : "请先处理待处理项，系统生成操作 ID 后才可确认。"].join("\n") }
function renderOperation(draft: BugOperationDraft): string { return ["[Synapse] 待确认的 Bug 操作", `产品：${draft.production.name}`, `Bug：${draft.bugId}`, `操作：${draft.kind}`, `字段：${JSON.stringify(draft.snapshot)}`, ...(draft.issues.length ? ["待处理：", ...draft.issues.map((item) => `- ${item}`)] : []), draft.draftId ? `确认后单独回复“${bugOperationActionText("confirm", draft)}”。` : "请先处理待处理项，系统生成操作 ID 后才可确认。"].join("\n") }
function extractBugDetail(input: string): string { return input.replace(/^.*?(?:报|提交|创建|提报|反馈|登记)(?:个|一个)?\s*(?:bug|缺陷)\s*[：:，,]?\s*/i, "").trim() }
function titleOf(detail: string): string { return detail.split(/[。！!\n]/, 1)[0].trim().slice(0, 256) || "新 Bug" }
function descriptionOf(request: InjectRequest, detail: string): string { return [...(request.transcript_tail ?? []).filter((item) => item.role === "user").slice(-2).map((item) => item.text.trim()), detail].filter((item, index, all) => item && all.indexOf(item) === index).join("\n").slice(0, 200_000) }
function bugPendingRef(pending: BugPending): StoredTaskIntakeRef | undefined {
  const productionId = pending.production?.id
  if (!productionId || !pending.draftTrust) return undefined
  return {
    ...(pending.draftId ? { draftId: pending.draftId } : {}),
    productionId,
    attempted: pending.attempted,
    ...pending.draftTrust,
    ...(pending.kind === "create" && pending.blockedReason ? { blockedReason: pending.blockedReason } : {}),
    ...(pending.cleanupDraftIds?.length ? { cleanupDraftIds: pending.cleanupDraftIds } : {}),
  }
}


function trustFromRef(ref: StoredTaskIntakeRef): TaskIntakeDraftTrust {
  return {
    requestId: ref.requestId,
    command: ref.command,
    contextReceiptId: ref.contextReceiptId,
    contextTargetPublicId: ref.contextTargetPublicId,
    sourceClient: ref.sourceClient,
  }
}

function requireDraftTrust(pending: BugPending): TaskIntakeDraftTrust {
  if (!pending.draftTrust) throw new TaskIntakeRefInvalidError("本地操作缺少可信上下文绑定")
  return pending.draftTrust
}
function saveAfterWrite(save: () => void): void { try { save() } catch { /* Remote receipt is authoritative. */ } }
