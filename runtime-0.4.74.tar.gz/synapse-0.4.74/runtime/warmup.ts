/**
 * runtime/warmup.ts —— daemon 启动后持续保温 KH 检索连接。
 *
 * 问题:inject 每轮向量检索走 REST /api/v1/knowledge/search。warm 约 65-160ms,但**会话首轮冷启动**
 * (node fetch 首次建连 TCP/TLS + 服务端 embedding 冷)实测冲到 ~884ms(Windows 偶尔更高),
 * 会破 inject 的延迟预算 → 用户每个会话第一条 prompt 拿不到团队知识。放宽预算是兜底,
 * **根治是持续打低频检索**把连接和服务端 embedding 保持在 warm 路径。
 *
 * 时序坑:工作台的启动顺序是「先起 daemon → 再 set-token / set-config」(machine token 热加载),
 * 所以 daemon 刚起那一刻 brain 往往还没配好。故预热**不是启动即打一次**,而是:
 *   轮询等 getBrainConfig() 就绪(有 url + token)→ 立刻预热 → 每 30s 串行保温。
 * 配置等待有上限(默认 ~2min);全程 best-effort,任何失败静默(绝不影响 daemon)。
 */
import { getBrainConfig } from "../transport/brain-config.ts"
import { searchKnowledge } from "../transport/brain-contract-align.ts"

export interface WarmupHandle {
  stop: () => void
}

export interface WarmupOptions {
  /** 轮询间隔(ms),等 brain 配置就绪。默认 3s。 */
  pollMs?: number
  /** 高频轮询多久(ms)后降为 keepAliveMs 间隔。默认 120s。 */
  maxWaitMs?: number
  /** 配置就绪后的持续保温间隔(ms)。默认 30s。 */
  keepAliveMs?: number
  /** 保温间隔抖动比例。默认 15%；测试可设 0。 */
  jitterRatio?: number
  /** 随机源(测试用)。 */
  random?: () => number
  /** 注入检索(测试用);默认 searchKnowledge。 */
  search?: typeof searchKnowledge
  /** 注入配置读取(测试用);默认 getBrainConfig。 */
  readConfig?: typeof getBrainConfig
  /** 环境(测试用)。 */
  env?: NodeJS.ProcessEnv
}

/**
 * 启动保温:等 brain 配置就绪后立刻检索,随后低频串行重复。
 * 返回 handle 供 daemon stop 时清理。
 */
export function startWarmup(opts: WarmupOptions = {}): WarmupHandle {
  const pollMs = opts.pollMs && opts.pollMs > 0 ? opts.pollMs : 3_000
  const maxWaitMs = opts.maxWaitMs && opts.maxWaitMs > 0 ? opts.maxWaitMs : 120_000
  const keepAliveMs = opts.keepAliveMs && opts.keepAliveMs > 0 ? opts.keepAliveMs : 30_000
  const jitterRatio = opts.jitterRatio !== undefined ? Math.min(0.9, Math.max(0, opts.jitterRatio)) : 0.15
  const random = opts.random ?? Math.random
  const search = opts.search ?? searchKnowledge
  const readConfig = opts.readConfig ?? getBrainConfig
  const env = opts.env ?? process.env

  let stopped = false
  let timer: ReturnType<typeof setTimeout> | null = null
  let waited = 0
  let slowPolling = false

  const done = () => {
    stopped = true
    if (timer) {
      clearTimeout(timer)
      timer = null
    }
  }

  const schedule = (delayMs: number) => {
    if (stopped) return
    timer = setTimeout(() => void tick(), delayMs)
    if (typeof timer === "object" && timer && "unref" in timer) {
      ;(timer as { unref: () => void }).unref()
    }
  }

  const keepAliveDelay = () =>
    Math.max(1, Math.round(keepAliveMs * (1 + jitterRatio * (random() * 2 - 1))))

  const tick = async (): Promise<void> => {
    if (stopped) return
    // 配置就绪?(有 url + machine token 才值得预热;否则等工作台 set-token)
    const cfg = readConfig(env)
    if (cfg && cfg.machineToken) {
      waited = 0
      slowPolling = false
      try {
        // 时间桶避免上游缓存固定 query，让请求确实触达 embedding/search 路径。
        await search(`synapse keepalive ${Math.floor(Date.now() / keepAliveMs)}`, 1, env)
      } catch {
        /* best-effort:本轮失败无害,下一周期继续 */
      }
      schedule(keepAliveDelay())
      return
    }
    // 还没配好 → 继续等,直到上限
    waited += pollMs
    if (waited >= maxWaitMs) {
      // 启动高频等待到点后只降频，不永久停；token 可能在 daemon 生命周期后段才写入/恢复。
      slowPolling = true
      schedule(keepAliveDelay())
      return
    }
    schedule(slowPolling ? keepAliveDelay() : pollMs)
  }

  // 首次不等满一个 pollMs 就先探一次(配置若已就绪则立刻预热)。
  void tick()

  return { stop: done }
}
