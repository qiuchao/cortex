import { randomUUID } from "node:crypto"
import {
  chmodSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs"
import { join } from "node:path"

import type { InjectAttachment } from "../../transport/contract.ts"
import { cacheDir } from "../../transport/discovery.ts"

const MAX_ATTACHMENTS = 20
const MAX_CACHE_BYTES = 1024 * 1024 * 1024
const MAX_CACHE_ENTRIES = 100
const CACHE_TTL_MS = 24 * 60 * 60_000
const MIME_RULES = new Map([
  ["image/jpeg", { extension: "jpg", maxBytes: 10 * 1024 * 1024 }],
  ["image/png", { extension: "png", maxBytes: 10 * 1024 * 1024 }],
  ["image/gif", { extension: "gif", maxBytes: 10 * 1024 * 1024 }],
])

export interface InlineImage {
  mimeType: string
  base64: string
}

export function materializeInlineImages(
  images: readonly InlineImage[],
  cacheNamespace: "claude-attachments" | "kimi-attachments",
  env: NodeJS.ProcessEnv = process.env,
): InjectAttachment[] {
  if (!images.length) return []
  if (images.length > MAX_ATTACHMENTS) throw new Error("too many inline image attachments")

  const decoded = images.map(({ mimeType, base64 }) => decodeInlineImage(mimeType, base64))
  const incomingBytes = decoded.reduce((total, item) => total + item.bytes.length, 0)
  const root = join(cacheDir(env), cacheNamespace)
  preparePrivateRoot(root)
  pruneCache(root, incomingBytes)
  const directory = join(root, randomUUID())
  mkdirSync(directory, { mode: 0o700 })
  try {
    return decoded.map((item, index) => {
      const fileName = `image-${index + 1}.${item.extension}`
      const path = join(directory, fileName)
      writeFileSync(path, item.bytes, { flag: "wx", mode: 0o600 })
      return { path, fileName, mimeType: item.mimeType }
    })
  } catch (error) {
    rmSync(directory, { recursive: true, force: true })
    throw error
  }
}

function decodeInlineImage(mimeType: string, base64: string): {
  mimeType: string
  extension: string
  bytes: Buffer
} {
  const normalizedMime = mimeType.trim().toLowerCase().split(";", 1)[0] ?? ""
  const rule = MIME_RULES.get(normalizedMime)
  if (!rule) throw new Error(`unsupported inline image MIME: ${normalizedMime || "unknown"}`)
  const compact = base64.replace(/[\r\n]/g, "")
  if (!compact || compact.length > Math.ceil(rule.maxBytes / 3) * 4
    || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(compact)) {
    throw new Error("invalid or oversized inline image")
  }
  const bytes = Buffer.from(compact, "base64")
  if (!bytes.length || bytes.length > rule.maxBytes || bytes.toString("base64") !== compact
    || !matchesImageSignature(normalizedMime, bytes)) {
    throw new Error("invalid or oversized inline image")
  }
  return { mimeType: normalizedMime, extension: rule.extension, bytes }
}

function matchesImageSignature(mimeType: string, bytes: Buffer): boolean {
  if (mimeType === "image/png") {
    return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
  }
  if (mimeType === "image/jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
  return bytes.length >= 6 && (bytes.subarray(0, 6).toString("ascii") === "GIF87a" || bytes.subarray(0, 6).toString("ascii") === "GIF89a")
}

function preparePrivateRoot(root: string): void {
  mkdirSync(root, { recursive: true, mode: 0o700 })
  const info = lstatSync(root)
  if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("inline image cache root must be a real directory")
  if (typeof process.getuid === "function" && info.uid !== process.getuid()) {
    throw new Error("inline image cache root must be owned by the current user")
  }
  if (process.platform !== "win32") {
    chmodSync(root, 0o700)
    if ((lstatSync(root).mode & 0o077) !== 0) throw new Error("inline image cache root must be private")
  }
}

function pruneCache(root: string, incomingBytes: number): void {
  const cutoff = Date.now() - CACHE_TTL_MS
  const entries = readdirSync(root, { withFileTypes: true }).flatMap((entry) => {
    if (!entry.isDirectory()) return []
    const path = join(root, entry.name)
    try {
      const info = lstatSync(path)
      if (info.isSymbolicLink()) return []
      if (info.mtimeMs < cutoff) {
        rmSync(path, { recursive: true, force: true })
        return []
      }
      let bytes = 0
      for (const child of readdirSync(path, { withFileTypes: true })) {
        if (!child.isFile()) continue
        const childInfo = statSync(join(path, child.name))
        if (!childInfo.isSymbolicLink()) bytes += childInfo.size
      }
      return [{ path, bytes, mtimeMs: info.mtimeMs }]
    } catch {
      return []
    }
  }).sort((left, right) => left.mtimeMs - right.mtimeMs)
  let totalBytes = entries.reduce((total, entry) => total + entry.bytes, 0)
  while (entries.length && (entries.length + 1 > MAX_CACHE_ENTRIES || totalBytes + incomingBytes > MAX_CACHE_BYTES)) {
    const oldest = entries.shift()!
    rmSync(oldest.path, { recursive: true, force: true })
    totalBytes -= oldest.bytes
  }
  if (totalBytes + incomingBytes > MAX_CACHE_BYTES) throw new Error("inline image cache capacity exceeded")
}
