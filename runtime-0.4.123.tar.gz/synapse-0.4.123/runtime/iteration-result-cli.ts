/** CLI entry helper: receive bytes privately, then obtain fresh permission immediately before stdout. */
import { randomUUID, createHash } from "node:crypto"
import { writeSync } from "node:fs"
import { ITERATION_RESULT_CHUNK_MAX_BYTES } from "@cerebro/wire"
import { IterationLocalResponseSchema, IterationLocalPermitSchema } from "./iteration-result-protocol.ts"
interface Reply { state: string; body?: unknown }
export async function runIterationResultRead(
  argv: string[], bridge: (action: string, body: unknown, token: string) => Promise<Reply>,
  output?: (text: string) => void,
): Promise<void> {
  if (argv.length !== 6 || argv[0] !== "--result-id" || argv[2] !== "--cursor" || argv[4] !== "--turn-token") throw new Error("invalid result reader arguments")
  const token = argv[5]
  const read = await bridge("result-read", { resultId: argv[1], cursor: argv[3] }, token)
  if (read.state !== "answered") throw new Error("iteration read unavailable")
  const result = IterationLocalResponseSchema.parse(read.body)
  const chunk = result.chunk
  if (result.expiresAt <= Date.now() || chunk.resultId !== argv[1] || chunk.cursor !== argv[3]
    || createHash("sha256").update(chunk.text).digest("hex") !== chunk.chunkSha256) throw new Error("iteration response mismatch")
  const text = JSON.stringify(chunk)
  const bytes = Buffer.from(text)
  if (bytes.length > ITERATION_RESULT_CHUNK_MAX_BYTES) throw new Error("iteration output too large")
  const nonce = randomUUID()
  // This clock belongs to this reader process; no cross-process epoch assumption.
  const started = process.hrtime.bigint()
  const released = await bridge("result-release", { responseId: result.responseId, nonce, chunkSha256: chunk.chunkSha256 }, token)
  if (released.state !== "answered") throw new Error("iteration release unavailable")
  const permit = IterationLocalPermitSchema.parse(released.body)
  if (permit.responseId !== result.responseId || permit.nonce !== nonce || permit.chunkSha256 !== chunk.chunkSha256
    || permit.expiresAt > result.expiresAt) throw new Error("iteration release expired or mismatched")
  // Prepared bytes, current wall deadline AND the original request's monotonic
  // limit. No async work or allocation between this check and the actual write.
  if (Date.now() >= permit.expiresAt || process.hrtime.bigint() - started >= 100_000_000n) throw new Error("iteration release expired")
  if (output) output(text)
  else {
    const written = writeSync(1, bytes)
    if (written !== bytes.length) throw new Error("iteration stdout incomplete")
  }
}
