// ADR:git-safety-gateway-runtime-enforcement
//
// lib/git-safety-runtime-helpers.ts — git-safety runtime plugin 的纯逻辑核心
//
// 职责：
//   1. tokenizeCommand: 把 bash 命令字符串切成 token 数组
//      （自实现 shell-words 风格 tokenizer，铁律：不引入新 npm 依赖）
//   2. parseGitCommand: 在 token 流中识别 git 子命令 / commit / bypass 标志
//   3. runGatewayCheck: spawn Synapse 包内 git-safety-gateway.mjs 子进程
//
// Phase 1 范围（按 plan_id plan-20260610-101741-001 §Phase 1）：
//   - 仅做"检测 git commit + 调 gateway + 非 0 throw"
//   - dynamicConstruct / lowLevelBypass 字段已预留但 plugin 端仅作为信号位
//     （SLA 收窄逻辑 Phase 2b/2d 落地）
//
// 不在 Phase 1 范围（明确边界）：
//   - 不改 gateway 脚本本身（Phase 2a）
//   - 不写 .synapse/ 目录（Phase 2b）
//   - 不做 capability detection probe（Phase 2c）
//   - 不实施 fail-closed（Phase 2a）
//
// Phase 0 已知 4 个真坑对应位置：
//   坑 1（OPENCODE_* env 污染）→ runGatewayCheck 的 spawnSync env 清理段
//   坑 2（session-worktree-guard 同 hook 竞拦）→ runtime plugin 层 try/catch + 身份 stderr
//   坑 4（throw 冒泡到 AI）→ buildBlockMessage 包含明确修复指引（不只是 "blocked"）

import { spawnSync } from "node:child_process"
import { existsSync } from "node:fs"
import { fileURLToPath } from "node:url"

// ────────────────────────────────────────────────────────────────────
// 常量
// ────────────────────────────────────────────────────────────────────

/** gateway 子进程默认超时（毫秒）；超时按 fail-closed 处理 */
export const GATEWAY_TIMEOUT_MS = 30_000

/** 随 Synapse 包发布的 gateway 脚本路径。 */
export const DEFAULT_GATEWAY_PATH = fileURLToPath(
  new URL("./git/git-safety-gateway.mjs", import.meta.url),
)

/**
 * 必须在 spawn 子进程时清理的 opencode runtime env，
 * 否则嵌套 spawn 的 gateway 子进程会被 opencode runtime 误识别为
 * "子 session" 并触发 environment-failed（Phase 0 真坑 1）。
 */
export const OPENCODE_ENV_KEYS_TO_STRIP: ReadonlyArray<string> = [
  "OPENCODE",
  "OPENCODE_PID",
  "OPENCODE_PROCESS_ROLE",
  "OPENCODE_RUN_ID",
]

// ────────────────────────────────────────────────────────────────────
// Tokenizer（自实现 shell-words 风格）
// ────────────────────────────────────────────────────────────────────

/**
 * 简化版 bash 命令 tokenizer。
 *
 * 支持：
 *   - 双引号 "..." / 单引号 '...' 内空格不切分
 *   - 反斜杠转义 \"  \'  \\  \空格
 *   - 空白（空格 / tab）作为分隔符
 *
 * **不支持**（Phase 1 SLA 收窄边界）：
 *   - 复杂的变量展开 / command substitution（$(...)、`...`）
 *   - heredoc 内部内容（heredoc 整段会作为单一 token 进入 cmdString，
 *     plugin 层另外检测 'git commit' 子串）
 *
 * 设计权衡：tokenizer 保持"够用且确定"，复杂情况由
 * detectDynamicConstruct 兜底打 audit 标记（Phase 2b 实施）。
 */
export function tokenizeCommand(cmd: string): string[] {
  const tokens: string[] = []
  let current = ""
  let inSingle = false
  let inDouble = false
  let escaping = false
  let hasContent = false

  for (let i = 0; i < cmd.length; i++) {
    const ch = cmd[i]!

    if (escaping) {
      current += ch
      hasContent = true
      escaping = false
      continue
    }

    if (ch === "\\" && !inSingle) {
      // 单引号内 \\ 是字面 \\（POSIX），其他情况转义下一字符
      escaping = true
      continue
    }

    if (ch === "'" && !inDouble) {
      inSingle = !inSingle
      hasContent = true
      continue
    }

    if (ch === '"' && !inSingle) {
      inDouble = !inDouble
      hasContent = true
      continue
    }

    if (!inSingle && !inDouble && (ch === " " || ch === "\t" || ch === "\n")) {
      if (hasContent) {
        tokens.push(current)
        current = ""
        hasContent = false
      }
      continue
    }

    current += ch
    hasContent = true
  }

  if (hasContent) {
    tokens.push(current)
  }

  return tokens
}

// ────────────────────────────────────────────────────────────────────
// parseGitCommand
// ────────────────────────────────────────────────────────────────────

export interface ParsedGitCommand {
  /** 命令串中是否出现 `git commit` 子命令 */
  isGitCommit: boolean
  /** 是否包含 --no-verify / -n 跳 hook 标志 */
  hasNoVerify: boolean
  /** 是否包含 `git -c core.hooksPath=...` 或 `git -c hooks.allownonascii=...` 等 -c 注入 */
  hasCustomHookPath: boolean
  /** 是否包含 GIT_HOOKS_DIR=... env 前置赋值 */
  hasGitHooksEnv: boolean
  /** 是否通过 env/flag 把命令重定向到 cwd 之外的 Git 元数据。 */
  hasExplicitRepoSelector: boolean
  /** 识别到的第一个 git subcommand（commit / push / log / ...），未识别则为空串 */
  subcommand: string
  /**
   * 命令串疑似动态构造（含 `$` 变量引用 / eval / alias / 复杂 heredoc）。
   * Phase 1 仅作为返回字段记录；handler 不基于此字段阻断
   * （SLA 收窄逻辑 Phase 2b/2d 落地）。
   */
  dynamicConstruct: boolean
  /**
   * 命令含 git update-ref / hash-object / fast-import 等低层管道命令。
   * Phase 1 仅作为字段返回；plugin 端不阻断
   * （ADR Consequences 一致：不防低层 bypass）。
   */
  lowLevelBypass: boolean
}

/**
 * 静态分析 bash 命令字符串，识别是否含 git commit + 各种 bypass 信号。
 *
 * **关键设计**：tokenizer 失败 / 命令含 heredoc → 退而求其次用子串扫描兜底。
 * 这是 fail-closed 思路：宁可误判为 commit 走 gateway 也不放过。
 *
 * **边界**（与 ADR 中 §Honest SLA Statement 一致）：
 *   - 拦截字面 git commit / -c hooksPath 注入 / --no-verify / heredoc 字面 commit
 *   - 不拦截 shell 变量动态构造（如 `x=commit; git $x`） → dynamicConstruct=true 标记
 *   - 不拦截 git update-ref / hash-object（低层 bypass，仅 lowLevelBypass=true 标记）
 */
export function parseGitCommand(cmd: string | undefined | null): ParsedGitCommand {
  const result: ParsedGitCommand = {
    isGitCommit: false,
    hasNoVerify: false,
    hasCustomHookPath: false,
    hasGitHooksEnv: false,
    hasExplicitRepoSelector: false,
    subcommand: "",
    dynamicConstruct: false,
    lowLevelBypass: false,
  }

  if (typeof cmd !== "string" || cmd.length === 0) {
    return result
  }

  // ── dynamicConstruct 启发式检测（粗略字符串扫描） ──
  // 含 `git $xxx` / eval / alias 定义 + 含 git
  if (
    /\bgit\s+\$[A-Za-z_]/.test(cmd) ||
    /\$\(/.test(cmd) && /\bgit\b/.test(cmd) ||
    /\beval\b/.test(cmd) && /\bgit\b/.test(cmd) ||
    /\balias\s+\w+\s*=.*\bgit\b/.test(cmd) ||
    /\bfunction\s+\w+\s*\{[^}]*\bgit\b/.test(cmd)
  ) {
    result.dynamicConstruct = true
  }

  // ── lowLevelBypass 启发式 ──
  if (/\bgit\s+(?:-[^\s]+\s+)*(?:update-ref|hash-object|fast-import|mktag|commit-tree)\b/.test(cmd)) {
    result.lowLevelBypass = true
  }

  // ── tokenize ──
  let tokens: string[]
  try {
    tokens = tokenizeCommand(cmd)
  } catch {
    // tokenizer 异常 → 字面回退（fail-closed：含 "git commit" 子串就当 commit 处理）
    tokens = []
  }
  if (tokens.some((token) => /^(?:GIT_DIR|GIT_WORK_TREE)=/i.test(token))) {
    result.hasExplicitRepoSelector = true
  }

  // ── env 前置（GIT_HOOKS_DIR=... git commit ...） ──
  let pos = 0
  while (pos < tokens.length && /^[A-Z_][A-Z0-9_]*=/.test(tokens[pos]!)) {
    if (tokens[pos]!.startsWith("GIT_HOOKS_DIR=") || tokens[pos]!.startsWith("GIT_HOOKS_PATH=")) {
      result.hasGitHooksEnv = true
    }
    if (/^(?:GIT_DIR|GIT_WORK_TREE)=/i.test(tokens[pos]!)) {
      result.hasExplicitRepoSelector = true
    }
    pos++
  }

  // ── 串联命令支持（&&/;/| 之后还可能跟 git commit） ──
  // 简化处理：把每个 token 检查一遍，找到 "git" 后看下一个非 -X 选项的 token
  // 同时支持 `git -c k=v commit -m x` 这样的 -c 注入
  let foundGit = false
  let i = pos
  while (i < tokens.length) {
    const tok = tokens[i]!
    if (tok === "git" || tok === "/usr/bin/git" || tok.endsWith("/git")) {
      foundGit = true
      i++
      // 跳过 git 自身的 -X 选项（注意识别 -c key=value）
      while (i < tokens.length) {
        const next = tokens[i]!
        if (next === "-c") {
          // -c key=value（两个 token）
          const kv = tokens[i + 1] ?? ""
          if (/^(?:core\.hookspath|hooks\.|core\.hooks)/i.test(kv)) {
            result.hasCustomHookPath = true
          }
          i += 2
          continue
        }
        // 内联形式 -ccore.hooksPath=... / -chooks.allownonascii=... 等（Phase 3 补识别）
        if (next.startsWith("-c") && next.length > 2) {
          // -c 后紧跟 key=value（如 -ccore.hooksPath=/dev/null）
          const kv = next.slice(2)
          if (/^(?:core\.hookspath|hooks\.|core\.hooks)/i.test(kv)) {
            result.hasCustomHookPath = true
          }
          i++
          continue
        }
        if (next === "-C") {
          result.hasExplicitRepoSelector = true
          i += 2
          continue
        }
        if (next.startsWith("-C") && next.length > 2) {
          result.hasExplicitRepoSelector = true
          i++
          continue
        }
        if (next.startsWith("--git-dir=") || next.startsWith("--work-tree=") || next.startsWith("--namespace=")) {
          if (!next.startsWith("--namespace=")) result.hasExplicitRepoSelector = true
          i++
          continue
        }
        if (next === "--git-dir" || next === "--work-tree" || next === "--namespace") {
          if (next !== "--namespace") result.hasExplicitRepoSelector = true
          i += 2
          continue
        }
        if (next.startsWith("-")) {
          // 其他 -X 选项放过
          i++
          continue
        }
        // 第一个非 - 开头的 token 即为 subcommand
        if (!result.subcommand) {
          result.subcommand = next
        }
        if (next === "commit") {
          result.isGitCommit = true
        }
        i++
        // commit 之后的所有 args 里找 --no-verify / -n
        while (i < tokens.length) {
          const arg = tokens[i]!
          // 遇到命令分隔符停止本次 git 调用扫描
          if (arg === "&&" || arg === "||" || arg === ";" || arg === "|") {
            break
          }
          if (arg === "--no-verify") {
            result.hasNoVerify = true
          }
          // -n 单独出现（git commit -n）；注意区分 `-am` 这种合并 flag 不含 n
          // 严格匹配 `-n` 单字符；`-nm` 等不视为 --no-verify 缩写（git 本身不支持）
          if (arg === "-n") {
            result.hasNoVerify = true
          }
          // commit -m "msg" --no-verify 等任意位置
          i++
        }
        break // 一次 git 调用扫完，回外层 while 找下一个 git
      }
      continue
    }
    i++
  }

  // ── 字面兜底（tokenizer 没识别到但子串含 "git commit"） ──
  // 主要覆盖 heredoc / 引号嵌套等 tokenizer 不擅长的场景
  if (!result.isGitCommit && /\bgit\s+(?:-[^\s]+\s+(?:[^\s]+\s+)?)*commit\b/.test(cmd)) {
    result.isGitCommit = true
    if (!result.subcommand) result.subcommand = "commit"
  }
  // 字面兜底 --no-verify / -n：要求出现在 git commit 之后（不匹配 shell 赋值中的 --no-verify）
  // 如 `x=--no-verify; git commit $x`：--no-verify 在分号前的赋值里，不算 commit arg
  if (!result.hasNoVerify && /(?<=git\s+(?:-[^\s]+\s+)*commit[^&;|]*?)\s--no-verify\b/.test(cmd)) {
    result.hasNoVerify = true
  }
  if (!result.hasNoVerify && /(?<=git\s+(?:-[^\s]+\s+)*commit[^&;|]*)\s-n\b/.test(cmd)) {
    result.hasNoVerify = true
  }
  if (
    !result.hasCustomHookPath &&
    /\bgit\s+-c\s+(?:core\.hookspath|hooks\.|core\.hooks)/i.test(cmd)
  ) {
    result.hasCustomHookPath = true
  }
  if (!result.hasGitHooksEnv && /\bGIT_HOOKS_(?:DIR|PATH)=/.test(cmd)) {
    result.hasGitHooksEnv = true
  }

  void foundGit
  return result
}

// ────────────────────────────────────────────────────────────────────
// runGatewayCheck —— spawn gateway 子进程
// ────────────────────────────────────────────────────────────────────

export interface GatewayCheckResult {
  /** gateway 退出码；-1 表示 spawn 失败 / 超时；5 表示 commit-required mode 的环境层失败 */
  exitCode: number
  /** gateway 写入 stderr 的全部内容（截断到 8KB） */
  stderr: string
  /** spawn 自身错误（如脚本不存在） */
  spawnError?: string
  /** 是否 spawn 超时 */
  timedOut: boolean
  /** 是否走了"gateway 脚本不存在 → 跳过"路径（Phase 1 fail-open；Phase 2a 在 commit-required mode 下改 fail-closed） */
  scriptMissing: boolean
  /**
   * Phase 2a：gateway 以 exit 5 返回（commit-required mode 的「环境层」失败）。
   * 这是与 1/2/3/4/11（逻辑层 pattern 命中）语义不同的失败类型，
   * plugin / 上层必须把它单独标识为「网关装错了 / 找不到了」而非「检查项命中」。
   */
  environmentFailure: boolean
}

/**
 * gateway --mode 取值（Phase 2a）：
 *   default          老行为，环境层错误 fail-safe exit 0
 *   commit-required  Phase 2a 新模式，环境层错误 fail-closed exit 5
 */
export type GatewayMode = "default" | "commit-required"

export interface RunGatewayCheckOptions {
  /** 工作目录，默认 process.cwd() */
  cwd?: string
  /** gateway 脚本路径，默认 DEFAULT_GATEWAY_PATH */
  gatewayPath?: string
  /** node 执行路径，默认走 PATH 上的 node */
  nodePath?: string
  /** 超时，默认 GATEWAY_TIMEOUT_MS */
  timeoutMs?: number
  /** 注入 env（测试用） */
  env?: NodeJS.ProcessEnv
  /**
   * Phase 2a：gateway --mode 参数。默认 "default"（兼容旧行为）。
   * commit 类拦截路径应传 "commit-required" 触发 fail-closed 语义。
   */
  mode?: GatewayMode
}

/**
 * 解析真实的 node 可执行路径，三级回退：
 *   1. which/where（平台原生命令，PATH 动态探测）
 *   2. 固定常见路径（homebrew / system node，兜住 which 不在 PATH 的情况）
 *   3. process.execPath（最后兜底，可能是 bun/opencode，但不 throw）
 *
 * ADR:git-safety-gateway（Phase 0 真坑 1 延伸）
 */
function resolveNodePath(): string {
  const isWindows = process.platform === "win32"

  // 第一级：which / where（平台分支，各用原生命令，不做 shell 拼接）
  try {
    const result = spawnSync(isWindows ? "where" : "which", ["node"], {
      encoding: "utf8",
      stdio: ["pipe", "pipe", "pipe"],
    })
    if (result.status === 0 && result.stdout) {
      const found = result.stdout.trim().split("\n")[0]?.trim()
      if (found) return found
    }
  } catch {
    // fall through
  }

  // 第二级：固定常见路径（覆盖 homebrew / nvm global / system）
  const FIXED_NODE_PATHS = isWindows
    ? [
        "C:\\Program Files\\nodejs\\node.exe",
        "C:\\Program Files (x86)\\nodejs\\node.exe",
      ]
    : [
        "/usr/local/bin/node",       // homebrew (Intel Mac / Linux)
        "/opt/homebrew/bin/node",    // homebrew (Apple Silicon)
        "/usr/bin/node",             // system node (Linux)
        "/usr/local/nvm/versions/node/current/bin/node", // nvm global（兜底）
      ]

  for (const p of FIXED_NODE_PATHS) {
    try {
      // 用 spawnSync 探测是否可执行（传 --version 验证）
      const probe = spawnSync(p, ["--version"], {
        encoding: "utf8",
        stdio: ["pipe", "pipe", "pipe"],
        timeout: 3000,
      })
      if (probe.status === 0) return p
    } catch {
      // not found, continue
    }
  }

  // 第三级：process.execPath（最后兜底，退化为旧行为，不 throw）
  return process.execPath
}

/**
 * spawn Synapse 包内的 git-safety-gateway.mjs all。
 *
 * Phase 1 行为：
 *   - 脚本不存在 → scriptMissing=true + exitCode=0（fail-open）
 *     （Phase 2a 改为 fail-closed exit=5；本 phase 不改）
 *   - 超时 → timedOut=true + exitCode=-1
 *   - 子进程 env 必须清 OPENCODE_* 系列（Phase 0 真坑 1）
 *
 * **返回**：调用方根据 exitCode 决定是否 throw。
 * 本函数自己**不 throw**，错误信息一律通过返回值传达。
 */
export function runGatewayCheck(opts: RunGatewayCheckOptions = {}): GatewayCheckResult {
  const gatewayPath = opts.gatewayPath ?? DEFAULT_GATEWAY_PATH
  const cwd = opts.cwd ?? process.cwd()
  const timeoutMs = opts.timeoutMs ?? GATEWAY_TIMEOUT_MS
  const nodePath = opts.nodePath ?? resolveNodePath()
  // Phase 2a：mode 决定 gateway 子进程是否走 fail-closed；
  // 默认 "default" 保持向后兼容（不传 mode 行为与 Phase 1 完全一致）。
  const mode: GatewayMode = opts.mode ?? "default"
  const isCommitRequired = mode === "commit-required"

  const result: GatewayCheckResult = {
    exitCode: 0,
    stderr: "",
    timedOut: false,
    scriptMissing: false,
    environmentFailure: false,
  }

  // 脚本不存在：
  //   default mode → Phase 1 fail-open，scriptMissing=true + exitCode=0（兼容旧行为）
  //   commit-required mode → Phase 2a fail-closed，scriptMissing=true + environmentFailure=true + exitCode=5
  // 注意 exitCode 字段仅作信号通道，调用方真正依据是 scriptMissing + environmentFailure 组合。
  if (!existsSync(gatewayPath)) {
    result.scriptMissing = true
    if (isCommitRequired) {
      result.environmentFailure = true
      result.exitCode = 5
    }
    return result
  }

  // 清理 env（Phase 0 真坑 1：不清 OPENCODE_* 会让子进程被识别为子 session 失败）
  const baseEnv = opts.env ?? process.env
  const cleanEnv: NodeJS.ProcessEnv = {}
  for (const [k, v] of Object.entries(baseEnv)) {
    if (OPENCODE_ENV_KEYS_TO_STRIP.includes(k)) continue
    cleanEnv[k] = v
  }

  // Phase 2a：commit-required 模式时透传 --mode 给 gateway 子进程，
  // 让 gateway 内部环境层错误（非 git 仓库 / 顶层 catch）也按 fail-closed 处理 exit 5。
  const args = isCommitRequired
    ? [gatewayPath, "--mode", "commit-required", "all"]
    : [gatewayPath, "all"]

  try {
    const ret = spawnSync(nodePath, args, {
      cwd,
      env: cleanEnv,
      timeout: timeoutMs,
      stdio: ["ignore", "pipe", "pipe"],
      encoding: "utf8",
      // killSignal 默认 SIGTERM，超时时杀子进程
    })

    if (ret.error) {
      // spawn 阶段错误（ENOENT 等）= 环境层失败
      result.spawnError = ret.error.message
      result.exitCode = -1
      if ((ret.error as NodeJS.ErrnoException).code === "ETIMEDOUT") {
        result.timedOut = true
      } else if (isCommitRequired) {
        // commit-required 模式：spawn 自身失败也属于环境层（node not found / 路径异常等）
        result.environmentFailure = true
        result.exitCode = 5
      }
      return result
    }

    if (ret.signal) {
      // 被信号杀掉（包括超时）—— 不属于环境层，按超时/spawn 失败处理（plugin 决定 fail-open vs throw）
      result.timedOut = ret.signal === "SIGTERM"
      result.exitCode = -1
      result.stderr = String(ret.stderr ?? "").slice(0, 8192)
      return result
    }

    const code = typeof ret.status === "number" ? ret.status : -1
    result.exitCode = code
    result.stderr = String(ret.stderr ?? "").slice(0, 8192)
    // Phase 2a：gateway 自身以 5 退出（commit-required mode 内部环境层错误）
    if (code === 5) {
      result.environmentFailure = true
    }
    return result
  } catch (err) {
    result.spawnError = err instanceof Error ? err.message : String(err)
    result.exitCode = -1
    if (isCommitRequired) {
      result.environmentFailure = true
      result.exitCode = 5
    }
    return result
  }
}

// ────────────────────────────────────────────────────────────────────
// buildBlockMessage —— 构造给 AI 看的修复指引
// ────────────────────────────────────────────────────────────────────

/**
 * gateway 退出码对应的人话描述（用于 throw 的 Error message）。
 * 与 scripts/git-safety-gateway.mjs 退出码契约一致：
 *   0 通过 / 1 敏感 / 2 大文件 / 3 main 分支 / 4 高危 / 11 LFS 推荐 / -1 内部错误
 */
export function describeExitCode(code: number): string {
  switch (code) {
    case 0: return "通过（异常分类：本不该 block）"
    case 1: return "检测到敏感信息（credential / key / secret）"
    case 2: return "暂存区有超阈值大文件，建议走 git-lfs"
    case 3: return "当前在受保护分支（main / master / develop / release/*）直接提交"
    case 4: return "命中高危命令模式"
    case 5: return "commit-required 模式：环境层失败（gateway 脚本/依赖缺失或顶层未捕获错误）"
    case 11: return "暂存区有已知大文件类型，应通过 git-lfs 提交"
    case -1: return "gateway 自身执行失败（超时 / spawn 错误）"
    default: return `未知 gateway exitCode=${code}`
  }
}

export interface BuildBlockMessageInput {
  exitCode: number
  stderr: string
  parsed: ParsedGitCommand
  cwd: string
  branchHint?: string
  scriptMissing?: boolean
  /**
   * Phase 2a：是否为 commit-required mode 的「环境层」失败。
   * 如果是，buildBlockMessage 会输出专属的「环境层修复」指引（synapse doctor）
   * 而不是常规的 pattern 命中修复路径。
   */
  environmentFailure?: boolean
}

/**
 * 拼出 throw 给 AI 看的错误消息。
 *
 * 必须包含（Phase 0 真坑 4：throw 完整冒泡，必须写清修复指引）：
 *   - Synapse 身份 marker `[synapse:git-safety]`
 *   - exit code 含义
 *   - gateway stderr 关键行（截断）
 *   - 明确的修复路径：处理命中项或运行 synapse doctor 检查运行时
 */
export function buildBlockMessage(input: BuildBlockMessageInput): string {
  const { exitCode, stderr, parsed, cwd, branchHint, scriptMissing, environmentFailure } = input

  const headLines: string[] = []

  // Phase 2a：环境层失败有专属文案，明确告诉 AI 这不是 pattern 命中，
  // 而是 gateway 本身装坏了 / 找不到了 / 跑挂了，必须排查环境。
  if (environmentFailure) {
    headLines.push(
      "[synapse:git-safety] 拦截：commit-required 模式下安全网关「环境层」失败（fail-closed）。"
    )
    headLines.push(`  cwd: ${cwd}`)
    if (branchHint) headLines.push(`  当前分支: ${branchHint}`)
    headLines.push(`  gateway exitCode=${exitCode}（${describeExitCode(exitCode)}）`)
    headLines.push("")
    headLines.push("⚠ 这不是 pattern 命中（敏感/大文件/main 分支等），而是网关本身无法可信运行：")
    if (scriptMissing) {
      headLines.push(`  · gateway 脚本未找到（${DEFAULT_GATEWAY_PATH}）`)
    } else if (exitCode === 5) {
      headLines.push("  · gateway 子进程以 exit 5 返回（非 git 仓库 / 顶层未捕获错误等）")
    } else {
      headLines.push("  · gateway 子进程 spawn 失败（node 不可用 / 路径异常 / ENOENT 等）")
    }

    if (stderr) {
      const tail = stderr.trim().split("\n").slice(-10).join("\n")
      headLines.push("")
      headLines.push("gateway stderr:")
      headLines.push(tail)
    }

    headLines.push("")
    headLines.push("修复路径（环境层，按推荐顺序）：")
    headLines.push("  1. 运行 `synapse doctor` 检查当前安装和 daemon 状态")
    headLines.push("  2. 若包内 gateway 缺失：重新安装当前版本的 `@andyqiu/synapse`")
    headLines.push("  3. 若 spawn 失败：确认 Node.js 可执行且 Synapse 安装目录可读")
    headLines.push("  4. 修复后再次提交；不要使用 --no-verify 绕过安全检查")
    return headLines.join("\n")
  }

  // 常规路径（pattern 命中类，exit 1/2/3/4/11）
  headLines.push("[synapse:git-safety] 拦截：Git 操作未通过安全检查。")
  headLines.push(`  cwd: ${cwd}`)
  if (branchHint) headLines.push(`  当前分支: ${branchHint}`)
  headLines.push(`  gateway exitCode=${exitCode}（${describeExitCode(exitCode)}）`)

  const flagsHint: string[] = []
  if (parsed.hasNoVerify) flagsHint.push("--no-verify/-n")
  if (parsed.hasCustomHookPath) flagsHint.push("git -c core.hooksPath=…")
  if (parsed.hasGitHooksEnv) flagsHint.push("GIT_HOOKS_DIR/GIT_HOOKS_PATH= env")
  if (flagsHint.length) {
    headLines.push(`  检测到 bypass 标志: ${flagsHint.join(", ")}（Synapse 仍会拦截）`)
  }

  if (stderr) {
    // 取 stderr 最后 ~10 行，保留 gateway 输出的关键信息
    const tail = stderr.trim().split("\n").slice(-10).join("\n")
    headLines.push("")
    headLines.push("gateway stderr:")
    headLines.push(tail)
  }

  if (scriptMissing) {
    headLines.push("")
    headLines.push(`⚠ gateway 脚本未找到（${DEFAULT_GATEWAY_PATH}）`)
    headLines.push("  请重新安装当前版本的 `@andyqiu/synapse`，然后运行 `synapse doctor`")
  }

  headLines.push("")
  headLines.push("修复路径（按推荐顺序）：")
  headLines.push("  1. 根据命中项处理：移除敏感信息、使用 Git LFS、切到开发分支或改用非高危命令")
  headLines.push("  2. 若无法判断命中原因，运行 `synapse doctor` 检查当前运行时")
  headLines.push("  3. 如认为规则误报，与团队管理员确认并人工评审；AI 不得自行绕过")

  return headLines.join("\n")
}

// ────────────────────────────────────────────────────────────────────
// buildBypassBlockMessage —— bypass 显式 flag 专属阻断消息（Phase 3）
// ────────────────────────────────────────────────────────────────────

/**
 * 构造 bypass flag 命中时的专属 throw 消息（Phase 3 新增）。
 *
 * 与 buildBlockMessage（gateway pattern 命中）不同：
 *   - bypass flag 被显式使用 → 直接阻断，不等 gateway 结果（前置拦截）
 *   - 消息明确指出哪个 bypass flag 被禁止，提供对应修复指引
 *
 * 适用场景：
 *   - --no-verify / -n：禁止跳过 git hook
 *   - git -c core.hooksPath=... / git -ccore.hooksPath=...：禁止临时改 hooksPath
 *   - GIT_HOOKS_DIR=... / GIT_HOOKS_PATH=...：禁止 env 注入覆盖 hook 目录
 *
 * SLA 边界（与 ADR §Phase 3 Supplement 一致）：
 *   - 拦截：字面显式 bypass flag（如 --no-verify / -ccore.hooksPath=/dev/null）
 *   - 不拦截：shell 变量构造（如 x=--no-verify; git commit $x）→ dynamicConstruct passthrough
 */
export function buildBypassBlockMessage(parsed: ParsedGitCommand, cwd: string): string {
  const lines: string[] = []
  lines.push("[synapse:git-safety] 拦截：检测到 bypass flag，禁止绕过安全检查。")
  lines.push(`  cwd: ${cwd}`)
  lines.push("")

  if (parsed.hasNoVerify) {
    lines.push("❌ 禁止使用 --no-verify / -n：")
    lines.push("   这些 flag 会跳过 git pre-commit hook（包括 Synapse 安全检查兜底层）。")
    lines.push("   AI 不允许自行决策 bypass；如确需绕过，请与团队 admin 确认并走 PR review。")
  }
  if (parsed.hasCustomHookPath) {
    lines.push("❌ 禁止使用 git -c core.hooksPath=... / git -ccore.hooksPath=...：")
    lines.push("   临时改变 hooksPath 会使 pre-commit hook 完全失效，等同于绕过所有安全检查。")
    lines.push("   如需切换 hooksPath，先运行 `synapse doctor` 并与团队管理员确认，不得临时注入。")
  }
  if (parsed.hasGitHooksEnv) {
    lines.push("❌ 禁止使用 GIT_HOOKS_DIR=... / GIT_HOOKS_PATH=... env 注入：")
    lines.push("   env 覆盖 hook 目录同样使安全检查失效。")
  }

  lines.push("")
  lines.push("修复路径：")
  lines.push("  1. 移除 bypass flag，重新执行原始 Git 操作")
  lines.push("  2. 如 pre-commit hook 疑似误报，运行 `synapse doctor` 并排查具体 hook")
  lines.push("  3. 紧急绕过须与团队 admin 确认，AI 不允许自行决策 bypass")

  return lines.join("\n")
}
