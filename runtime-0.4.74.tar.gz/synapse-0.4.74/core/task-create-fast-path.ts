import {
  resolveSimpleWorkItemCreateIntent,
  type SimpleWorkItemCreateIntent,
  type TaskCapabilityCatalogue,
  type TaskCapabilityWriteCommand,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import type { AgentCapabilityBroker } from "../runtime/agent-capability-broker.ts"
import { hasKnownNoAgentAttachments } from "./agent-attachments.ts"

export interface TaskCreateFastPathResult {
  command: TaskCapabilityWriteCommand
  trustedContext: string
}

export function resolveSimpleTaskCreateIntent(request: InjectRequest): SimpleWorkItemCreateIntent | undefined {
  return resolveSimpleWorkItemCreateIntent(request.user_input)
}

export function resolveTaskCreateFastPath(request: InjectRequest): SimpleWorkItemCreateIntent | undefined {
  const intent = resolveSimpleTaskCreateIntent(request)
  if (!intent) return undefined
  return hasKnownNoAgentAttachments(request) ? intent : undefined
}

export async function executeTaskCreateFastPath(input: {
  requestId: string
  intent: SimpleWorkItemCreateIntent
  catalogue: TaskCapabilityCatalogue
  productionName?: string
  broker: AgentCapabilityBroker
  signal?: AbortSignal
}): Promise<TaskCreateFastPathResult | undefined> {
  const command = input.intent.kind === "bug" ? "bug.create" : "requirement.create"
  if (!input.catalogue.availableCapabilities.includes(command)) return undefined

  const result = await input.broker.execute({
    protocolVersion: input.catalogue.protocolVersion,
    productionId: input.catalogue.productionId,
    command,
    requestId: input.requestId,
    input: { title: input.intent.title },
  }, input.signal)
  if (!result.ok) throw new Error(`deterministic task draft failed: ${result.reason}`)
  const response = result.response
  if (!("kind" in response) || response.kind !== "draft" || response.command !== command
    || !("operationId" in response) || typeof response.operationId !== "string") {
    throw new Error("deterministic task draft returned an invalid response")
  }
  const receipt = {
    kind: "draft",
    command,
    operationId: response.operationId,
    expiresAt: response.expiresAt,
    productionId: input.catalogue.productionId,
    productionName: input.productionName ?? null,
    title: input.intent.title,
  }
  const confirmationLabel = input.intent.kind === "bug" ? "Bug" : "需求"
  return {
    command,
    trustedContext: [
      `[Synapse] task_create_result=${JSON.stringify(receipt)}`,
      "[Synapse control]",
      `Synapse 已通过 typed Task broker 生成待确认的${confirmationLabel}操作，本轮不得再调用任何工具。`,
      `请向用户报告产品、标题、操作编号和过期时间，明确尚未落单，并等待新的用户消息使用“确认${confirmationLabel}操作 ${response.operationId}”或“取消${confirmationLabel}操作 ${response.operationId}”。`,
      "不得显示内部 requestId、draftId、payloadHash，也不得把待确认操作描述成已创建业务单据。",
    ].join("\n"),
  }
}
