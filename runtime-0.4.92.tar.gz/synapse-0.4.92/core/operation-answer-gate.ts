/** Validate native answers against Cerebro's shared facts; never calculate domain facts here. */
import { randomUUID } from "node:crypto"
import {
  guardOperationQueryAnswer,
  hasQueryAnswerBoundary,
} from "@cerebro/wire"
import type { InjectRequest, ReportRequest, ReportResponse } from "../transport/contract.ts"
import type { OperationTurnResponse } from "../runtime/operation-turn-bridge.ts"
import { formatCerebroBlock } from "./operation-result-formatter.ts"
import { isQueryResultMissing, QUERY_RESULT_MISSING_NOTICE } from "./operation-query-result.ts"

const MAX_SESSIONS = 1_024
const TTL_MS = 10 * 60_000

interface AnswerState {
  turnId?: string
  response: Parameters<typeof guardOperationQueryAnswer>[1]
  authoritativeAnswer: string
  canonicalAnswer?: string
  missingBusinessResult: boolean
  identities: string[]
  allowStandaloneCalculation: boolean
  requireAnalysis: boolean
  expiresAt: number
  correctionPrompt?: string
  correctionStarted: boolean
  failurePrompt?: string
  correctionReported?: boolean
  acceptedReported?: boolean
  presentation?: string
}

type Validation = NonNullable<ReportResponse["answerValidation"]>
export const QUERY_ANSWER_FAILURE_NOTICE = "Cerebro 查询回答的范围或事实仍未通过共享校验，已停止自动纠正；不得将本轮回答视为已验证结果。"

/**
 * A Stop correction is a native continuation prompt, not a new business turn.
 * Only the exact, session-bound prompt issued here can reuse the receipt.
 * A normal user turn revokes it; a repeated hook cannot resubmit operations.
 */
export function createOperationAnswerGate(
  now: () => number = Date.now,
  onValidation: (status: "accepted" | "correct" | "failed") => void = () => {},
) {
  const sessions = new Map<string, AnswerState>()
  const key = (request: Pick<ReportRequest, "client" | "session_id">) => JSON.stringify([request.client, request.session_id])
  const accept = (state: AnswerState) => {
    if (state.acceptedReported) return
    state.acceptedReported = true
    state.presentation = state.authoritativeAnswer
    onValidation("accepted")
  }
  const prune = () => {
    for (const [id, state] of sessions) if (state.expiresAt <= now()) sessions.delete(id)
    while (sessions.size > MAX_SESSIONS) sessions.delete(sessions.keys().next().value as string)
  }

  return {
    begin(request: InjectRequest): string | undefined {
      prune()
      const id = key(request)
      const state = sessions.get(id)
      if (state?.failurePrompt === request.user_input.trim()) {
        state.turnId = request.turn_id
        state.expiresAt = now() + TTL_MS
        return state.failurePrompt
      }
      if (state?.correctionPrompt === request.user_input.trim()) {
        state.turnId = request.turn_id
        state.correctionStarted = true
        state.expiresAt = now() + TTL_MS
        return state.correctionPrompt
      }
      if (state && state.turnId !== request.turn_id) sessions.delete(id)
      return undefined
    },

    remember(request: InjectRequest, response: OperationTurnResponse): void {
      const operations = (response.operations ?? []).map(operation => ({
        ...operation, status: String(operation.status ?? ""), action: String(operation.action ?? ""),
      }))
      const blocked = response.ordinary?.dependency === "blocked"
        || (response.ordinary?.dependency !== "none" && operations.some(operation => operation.status !== "executed"))
      const missingBusinessResult = operations.some(isQueryResultMissing)
      if (!blocked && !missingBusinessResult && !hasQueryAnswerBoundary({ operations })) return
      const authoritativeAnswer = formatCerebroBlock(response)
      const existing = sessions.get(key(request))
      if (existing && existing.expiresAt > now() && existing.turnId === request.turn_id
        && existing.authoritativeAnswer === authoritativeAnswer) return
      const identities = (response.operations ?? []).flatMap(operation => typeof operation.operationId === "string" ? [`operationId=${operation.operationId}`] : [])
      sessions.set(key(request), {
        turnId: request.turn_id,
        response: { operations },
        authoritativeAnswer,
        missingBusinessResult,
        ...(blocked || missingBusinessResult ? { canonicalAnswer: authoritativeAnswer } : {}),
        identities,
        allowStandaloneCalculation: response.ordinary?.dependency === "none",
        requireAnalysis: response.ordinary?.dependency === "operation_result",
        expiresAt: now() + TTL_MS,
        correctionStarted: false,
      })
      prune()
    },

    takePresentation(request: ReportRequest): string | undefined {
      const state = sessions.get(key(request))
      if (!state || state.expiresAt <= now() || request.event !== "Stop" || state.turnId !== request.turn_id) return undefined
      const presentation = state.presentation
      state.presentation = undefined
      return presentation
    },

    validate(request: ReportRequest, answer: unknown, stopHookActive = false): Validation | undefined {
      prune()
      const state = sessions.get(key(request))
      if (!state || request.event !== "Stop" || state.turnId !== request.turn_id) return undefined
      const text = typeof answer === "string" ? answer.trim() : ""
      if (state.failurePrompt) {
        // Notification is a terminal failure, even when the model copies it.
        // Repeated reports terminate without another prompt or metric.
        return { status: "failed", reason: QUERY_ANSWER_FAILURE_NOTICE }
      }
      if (!state.missingBusinessResult && state.canonicalAnswer && text === state.canonicalAnswer.trim()) {
        accept(state)
        return undefined
      }
      // Presentation labels never establish trust. Remove only decorative labels
      // matching the identity already obtained from the response; all other
      // identity claims remain visible to the shared factual guard.
      const body = text.split(/\r?\n/).filter(line => {
        const label = line.trim().replace(/^[#>*\s]+/, "").replace(/[*`]/g, "").trim()
        const identity = label.replace(/^\[Cerebro\]\s*/, "").trim().replace(/\s*[:：=]\s*/, "=")
        return label !== "[Cerebro]" && !state.identities.includes(identity)
      }).join("\n").trim()
      const checked = state.missingBusinessResult
        ? { text: QUERY_RESULT_MISSING_NOTICE, rejected: true, reasons: ["missing_business_result"] }
        : guardOperationQueryAnswer(body, state.response, {
        allowStandaloneCalculation: state.allowStandaloneCalculation,
        requireAnalysis: state.requireAnalysis,
        includeItems: true,
      })
      // The shared guard may append authoritative facts for display. That is
      // not a factual conflict or a requirement for the model to recopy them.
      if (!state.canonicalAnswer && !checked.rejected && body) {
        accept(state)
        return undefined
      }
      const canonical = state.canonicalAnswer ?? ["[Cerebro]", ...state.identities, checked.text].join("\n")
      if (state.correctionStarted || (state.correctionPrompt && stopHookActive)) {
        onValidation("failed")
        state.failurePrompt = [
          `Synapse answer failure notice ${randomUUID()}`,
          "查询回答校验已经失败。不得再次纠正、分析、调用工具或重跑主脑操作。请仅逐字输出下方失败通知，随后结束：",
          QUERY_ANSWER_FAILURE_NOTICE,
        ].join("\n\n")
        const result: Validation = {
          status: "failed",
          reason: QUERY_ANSWER_FAILURE_NOTICE,
          notificationPrompt: state.failurePrompt,
        }
        return result
      }
      state.correctionPrompt ??= [
        `Synapse answer correction ${randomUUID()}`,
        state.missingBusinessResult
          ? "回执缺少可信业务结果。不得根据 executed 状态、操作编号或普通正文推断查询成功；仅说明无法提供查询结果和依赖分析。不调用工具，不重跑查询或写入。"
          : "上一份查询回答未通过 Cerebro 共享事实校验或缺少正文。仅修正错误事实或补充有依据的分析；保留正确的独立计算和定性观察。下方是参考数据，权威回执由运行时确定性展示，无需重复生成完整范围、表格、统计或 operationId。不调用工具，不重跑查询或写入。",
        ...(state.requireAnalysis && checked.reasons.includes("missing_analysis")
          ? ["用户要求的分析尚未完成。请根据回执中实际展示的标题补充定性观察和建议；不得伪造全量排名或数量，无法得出排名时明确说明依据不足。"]
          : []),
        canonical,
      ].join("\n\n")
      if (!state.correctionReported) onValidation("correct")
      state.correctionReported = true
      return { status: "correct", reason: state.correctionPrompt }
    },
  }
}
