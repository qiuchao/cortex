/**
 * core/parsers/gemini-cli.ts —— 运行时侧解析 Gemini CLI 的 hook 原始 stdin。
 *
 *   inject ← BeforeAgent   { session_id, cwd, prompt }
 *   report ← AfterAgent(每回合) + SessionEnd(会话兜底)
 *
 * (Gemini 与 Antigravity 事件名不同、本应各自单独支持;Antigravity 现暂缓接入,故此处仅 Gemini。)
 */
import type { InjectRequest, ReportRequest } from "../../transport/contract.ts"
import { parseGeminiClipboardAttachments } from "./gemini-clipboard-attachments.ts"
import { str, asObject, mergeParsedAttachments, parseAttachments, stableTurnAnchor, supportRails, transcriptTail } from "./util.ts"

const GEMINI_INTERNAL_LOOP_RECOVERY_PREFIX = "System: Potential loop detected."

function isGeminiInternalControlMessage(text: string): boolean {
  return text.trimStart().startsWith(GEMINI_INTERNAL_LOOP_RECOVERY_PREFIX)
}

function latestModelUserContent(raw: unknown): unknown {
  const request = asObject(asObject(raw)["llm_request"])
  const messages = request["messages"]
  if (!Array.isArray(messages)) return undefined
  for (let i = messages.length - 1; i >= 0; i--) {
    const message = asObject(messages[i])
    if (message["role"] !== "user") continue
    return message["content"]
  }
  return undefined
}

function modelUserText(content: unknown): string {
  if (typeof content === "string") return content
  if (!Array.isArray(content) || hasFunctionResponse(content)) return ""
  return content
    .map((part) => str(asObject(part), "text", "content"))
    .filter(Boolean)
    .join("\n")
}

function hasFunctionResponse(content: unknown): boolean {
  return Array.isArray(content)
    && content.some((part) => part && typeof part === "object" && "functionResponse" in part)
}

export function isInternalInject(raw: unknown): boolean {
  const o = asObject(raw)
  if (str(o, "hook_event_name", "event") !== "BeforeModel") return false
  const content = latestModelUserContent(o)
  return hasFunctionResponse(content)
    || isGeminiInternalControlMessage(modelUserText(content) || str(o, "prompt", "query", "input", "message"))
}

export function parseInject(raw: unknown): InjectRequest {
  const o = asObject(raw)
  const directAttachments = parseAttachments(o)
  const candidate = modelUserText(latestModelUserContent(o)) || str(o, "prompt", "query", "input", "message")
  const user_input = isGeminiInternalControlMessage(candidate) ? "" : candidate
  const transcriptPath = str(o, "transcript_path")
  const cwd = str(o, "cwd", "workspace")
  const clipboardAttachments = transcriptPath && cwd
    ? parseGeminiClipboardAttachments({ prompt: user_input, transcriptPath, cwd })
    : { observation: "unknown" as const }
  // BeforeAgent's prompt is Gemini 0.52's complete attachment surface: pasted
  // images are rewritten as owned clipboard @files. With no @file reference,
  // an absent generic attachments field is therefore a proven empty turn.
  const parsedAttachments = directAttachments.observation === "unknown"
      && clipboardAttachments.observation === "none"
    ? clipboardAttachments
    : mergeParsedAttachments(directAttachments, clipboardAttachments)
  const session_id = str(o, "session_id", "sessionId")
  const message_id = str(o, "message_id", "request_id", "id") || undefined
  const conversation_id = str(o, "conversation_id", "conversationId") || undefined
  const turn_id = stableTurnAnchor(
    o,
    { client: "gemini-cli", sessionId: session_id, messageId: message_id, conversationId: conversation_id, currentText: user_input },
    "turn_id", "message_id", "request_id", "id",
  )
  return {
    client: "gemini-cli",
    event: str(o, "hook_event_name", "event") || "BeforeAgent",
    project: cwd || undefined,
    cwd: cwd || undefined,
    user_input,
    session_id,
    turn_id,
    message_id,
    conversation_id,
    attachments: parsedAttachments.files,
    attachment_observation: parsedAttachments.observation,
    attachment_error: parsedAttachments.error,
    transcript_tail: transcriptTail(o),
    support_rails: supportRails(o),
  }
}

export function parseReport(raw: unknown): ReportRequest {
  const o = asObject(raw)
  const session_id = str(o, "session_id", "sessionId")
  const prompt = str(o, "prompt")
  const response = str(o, "prompt_response")
  return {
    client: "gemini-cli",
    event: str(o, "hook_event_name", "event") || "AfterAgent",
    session_id,
    turn_id: stableTurnAnchor(
      o,
      { client: "gemini-cli", sessionId: session_id, currentText: `${prompt}\n${response}` },
      "turn_id", "prompt_id", "request_id", "id",
    ),
    project: str(o, "cwd", "workspace") || undefined,
    cwd: str(o, "cwd", "workspace") || undefined,
  }
}
