import { createHash } from "node:crypto"
import { existsSync, lstatSync, readFileSync, readdirSync, realpathSync } from "node:fs"
import { dirname, join, relative, resolve } from "node:path"
import { fileURLToPath } from "node:url"

export interface RuntimeProvenanceFile {
  path: string
  relativePath?: string
  sha256: string
}

export interface RuntimeBundleProvenance {
  root: string
  packageJson: RuntimeProvenanceFile
  entry: RuntimeProvenanceFile
  wire: RuntimeProvenanceFile
  /** All regular files shipped by the runtime bundle, excluding the manifest itself. */
  artifacts: RuntimeProvenanceFile[]
  /** Generated bundle manifest when this runtime was launched from a bundle. */
  manifest?: RuntimeProvenanceFile
}

/**
 * Identify the exact files loaded by a runtime instance. The paths and hashes
 * are written to discovery so an isolated QA run cannot be confused with a
 * different globally installed Synapse bundle.
 */
export function readRuntimeProvenance(
  root = resolve(dirname(fileURLToPath(import.meta.url)), ".."),
): RuntimeBundleProvenance {
  const normalizedRoot = realpathSync(root)
  const packageJsonPath = join(normalizedRoot, "package.json")
  const entryPath = join(normalizedRoot, "bin", "synapse.mjs")
  const wirePath = join(normalizedRoot, "node_modules", "@cerebro", "wire", "dist", "index.js")
  const manifestPath = join(normalizedRoot, "bundle-manifest.json")
  return {
    root: normalizedRoot,
    packageJson: describeFile(packageJsonPath, normalizedRoot),
    entry: describeFile(entryPath, normalizedRoot),
    wire: describeFile(wirePath, normalizedRoot),
    artifacts: collectArtifactFiles(normalizedRoot),
    ...(existsSync(manifestPath) ? { manifest: describeFile(manifestPath, normalizedRoot) } : {}),
  }
}

function describeFile(path: string, root?: string): RuntimeProvenanceFile {
  const resolved = realpathSync(path)
  if (!existsSync(resolved)) throw new Error(`runtime provenance file is missing: ${path}`)
  return {
    path: resolved,
    ...(root ? { relativePath: relative(root, resolved) } : {}),
    sha256: createHash("sha256").update(readFileSync(resolved)).digest("hex"),
  }
}

function collectArtifactFiles(root: string): RuntimeProvenanceFile[] {
  const files = new Set<string>()
  for (const entry of [
    "runtime",
    "core",
    "transport",
    "policy",
    "transcript",
    "ported",
    "bin",
    "shims",
    "node_modules",
    "package.json",
    "package-lock.json",
  ]) {
    collectFiles(join(root, entry), root, files)
  }
  return [...files]
    .filter((path) => path !== join(root, "bundle-manifest.json"))
    .sort()
    .map((path) => describeFile(path, root))
}

function collectFiles(path: string, root: string, files: Set<string>): void {
  if (!existsSync(path)) return
  const stat = lstatSync(path)
  if (stat.isSymbolicLink()) return
  if (stat.isFile()) {
    files.add(realpathSync(path))
    return
  }
  if (!stat.isDirectory()) return
  for (const entry of readdirSync(path)) collectFiles(join(path, entry), root, files)
}
