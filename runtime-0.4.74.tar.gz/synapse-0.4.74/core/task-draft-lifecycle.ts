import {
  cancelTaskCommandDraft,
  confirmTaskCommandDraft,
  createTaskCommandDraft,
  findTaskCommandDraftByRequest,
  getTaskCommandDraft,
  readableBrainError,
  type TaskCommandDraftRecord,
  type TaskCommandReceipt,
  type TaskDraftCommand,
} from "../transport/brain-contract-align.ts"
import type { TaskCapabilitySourceClient } from "@cerebro/wire"

export interface TaskDraftLifecycle {
  create: (input: {
    requestId: string
    productionId: string
    command: TaskDraftCommand
    payload: Record<string, unknown>
    sourceClient?: TaskCapabilitySourceClient
    contextReceiptId?: string
    contextTargetPublicId?: string
  }) => Promise<TaskCommandDraftRecord>
  get: (productionId: string, draftId: string) => Promise<TaskCommandDraftRecord>
  findByRequest?: (productionId: string, requestId: string) => Promise<TaskCommandDraftRecord>
  confirm: (productionId: string, draftId: string) => Promise<TaskCommandReceipt>
  cancel: (productionId: string, draftId: string) => Promise<TaskCommandDraftRecord>
}

export interface TaskDraftCleanupRef {
  draftId: string
  productionId: string
}

export class TaskDraftReplacementRollbackError extends AggregateError {
  readonly newDraftId: string
  readonly newProductionId: string

  constructor(oldCancelError: unknown, newCancelError: unknown, newDraftId: string, newProductionId: string) {
    super([oldCancelError, newCancelError], "旧草稿取消失败，且新草稿回滚失败")
    this.name = "TaskDraftReplacementRollbackError"
    this.newDraftId = newDraftId
    this.newProductionId = newProductionId
  }
}

/** Keep the immutable server protocol private in all user-facing failures. */
export function readableTaskOperationError(error: unknown): string {
  return readableBrainError(error)
    .replace(/task[- ]command\s+drafts?/gi, "操作")
    .replace(/\b(?:task\s+)?drafts?\b/gi, "操作")
    .replace(/草稿/g, "操作")
}

export function defaultTaskDraftLifecycle(env: NodeJS.ProcessEnv = process.env): TaskDraftLifecycle {
  return {
    create: (input) => createTaskCommandDraft(input, env),
    get: (productionId, draftId) => getTaskCommandDraft(productionId, draftId, env),
    findByRequest: (productionId, requestId) => findTaskCommandDraftByRequest(productionId, requestId, env),
    confirm: (productionId, draftId) => confirmTaskCommandDraft(productionId, draftId, env),
    cancel: (productionId, draftId) => cancelTaskCommandDraft(productionId, draftId, env),
  }
}

export function draftPayload(record: TaskCommandDraftRecord): Record<string, unknown> {
  if (!record.payload || typeof record.payload !== "object" || Array.isArray(record.payload)) {
    throw new Error("Cerebro 未返回服务端草稿 payload")
  }
  return { ...record.payload }
}

/** Create the replacement first so a transient cancel failure never loses the user's usable draft. */
export async function replaceTaskDraft(
  lifecycle: TaskDraftLifecycle,
  oldDraft: { productionId: string; draftId?: string },
  input: {
    requestId: string
    productionId: string
    command: TaskDraftCommand
    payload: Record<string, unknown>
    sourceClient?: TaskCapabilitySourceClient
    contextReceiptId?: string
    contextTargetPublicId?: string
  },
  validateCreated?: (draft: TaskCommandDraftRecord) => void,
): Promise<TaskCommandDraftRecord> {
  const draft = await lifecycle.create(input)
  try {
    validateCreated?.(draft)
  } catch (validationError) {
    try {
      await lifecycle.cancel(input.productionId, draft.id)
    } catch (rollbackError) {
      throw new TaskDraftReplacementRollbackError(validationError, rollbackError, draft.id, input.productionId)
    }
    throw validationError
  }
  if (!oldDraft.draftId || oldDraft.draftId === draft.id) return draft
  try {
    await lifecycle.cancel(oldDraft.productionId, oldDraft.draftId)
    return draft
  } catch (oldCancelError) {
    try {
      await lifecycle.cancel(input.productionId, draft.id)
    } catch (newCancelError) {
      throw new TaskDraftReplacementRollbackError(oldCancelError, newCancelError, draft.id, input.productionId)
    }
    throw oldCancelError
  }
}

export async function cancelTaskDraftWithReconciliation(
  lifecycle: TaskDraftLifecycle,
  productionId: string,
  draftId: string,
): Promise<TaskCommandDraftRecord> {
  try {
    const cancelled = await lifecycle.cancel(productionId, draftId)
    if (cancelled.status !== "pending") return cancelled
    throw new Error("服务端草稿取消后仍为 pending")
  } catch (error) {
    const current = await inspectTaskDraftAfterConfirmError(lifecycle, productionId, draftId)
    if (current && current.status !== "pending") return current
    throw error
  }
}

export async function inspectTaskDraftAfterConfirmError(
  lifecycle: TaskDraftLifecycle,
  productionId: string,
  draftId: string,
): Promise<TaskCommandDraftRecord | undefined> {
  try {
    return await lifecycle.get(productionId, draftId)
  } catch {
    return undefined
  }
}
