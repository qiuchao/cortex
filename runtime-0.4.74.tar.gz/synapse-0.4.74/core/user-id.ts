/**
 * core/user-id.ts —— user_id 权威来源(open-question #3;gate 安全回填,pre-mortem E)。
 *
 * 🔴 错 user_id → 不可逆 mis-scoped PII 上传。所以解析必须**确定且显式**,宁可拒绝也不猜。
 *
 * 解析优先级(高→低):
 *   1. 显式配置 SYNAPSE_USER_ID(env)——最权威,团队安装时写入。
 *   2. ~/.config/synapse/config.json 的 user_id 字段。
 *   3. 都没有 → 返回 null(**不回退到 os.userInfo() 猜测**;回填在 null 时必须拒绝上传)。
 *
 * open-question #3 未最终敲定前,这里给出确定性解析 + null 安全兜底,绝不静默猜一个身份。
 */
import { readFileSync } from "node:fs"
import { homedir } from "node:os"
import { join } from "node:path"

export interface ResolveUserIdOptions {
  env?: NodeJS.ProcessEnv
}

export function resolveUserId(opts: ResolveUserIdOptions = {}): string | null {
  const env = opts.env ?? process.env

  // 1) 显式 env(最权威)
  const fromEnv = env["SYNAPSE_USER_ID"]?.trim()
  if (fromEnv) return fromEnv

  // 2) ~/.config/synapse/config.json
  try {
    const home = env["USERPROFILE"]?.trim() || env["HOME"]?.trim() || homedir()
    const cfgPath = join(home, ".config", "synapse", "config.json")
    const cfg = JSON.parse(readFileSync(cfgPath, "utf8")) as Record<string, unknown>
    const uid = cfg["user_id"]
    if (typeof uid === "string" && uid.trim()) return uid.trim()
  } catch {
    /* 配置不存在/坏 → 继续 */
  }

  // 3) 无权威来源 → null(回填侧据此 fail-safe 拒绝,不猜)
  return null
}
