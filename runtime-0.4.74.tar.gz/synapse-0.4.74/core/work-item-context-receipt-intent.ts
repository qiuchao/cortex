import { randomUUID } from "node:crypto"
import { extractWorkItemPublicIds } from "@cerebro/wire"

const RECEIPT_ID = "[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"

export type WorkItemContextReceiptAction =
  | { kind: "ignore"; contextReceiptId: string; requestId: string; targetPublicId: string; missingKeys: string[] }
  | {
      kind: "supplement"
      contextReceiptId: string
      requestId: string
      targetPublicId: string
      sourcePublicId: string
      content: string
      replacesMissingKeys: string[]
    }
  | { kind: "validate"; contextReceiptId: string }

export type WorkItemContextReceiptContinuationIntent =
  | { kind: "ignore"; referencedPublicIds: string[] }
  | { kind: "supplement"; content: string; referencedPublicIds: string[] }

/** Legacy explicit continuation format kept for protocol compatibility. */
export function parseWorkItemContextReceiptAction(text: string): WorkItemContextReceiptAction | undefined {
  const normalized = receiptActionClauses(text).find((clause) => new RegExp(RECEIPT_ID, "i").test(clause))
  if (!normalized) return undefined
  const receipt = normalized.match(new RegExp(`(?:contextReceiptId|receipt(?:\\s+id)?|读取回执|回执)\\s*[：:=]?\\s*(${RECEIPT_ID})`, "i"))?.[1]
  if (!receipt) return undefined

  if (/(?:校验|验证|validate|发布前检查)/i.test(normalized)) {
    return { kind: "validate", contextReceiptId: receipt }
  }

  const keys = extractMissingKeys(normalized)
  if (/(?:忽略|知情继续|ignore)/i.test(normalized) && !hasNegatedIgnoreIntent(normalized)) {
    const targetPublicId = extractLabeledPublicId(normalized, /(?:目标单|处理单|target(?:\s+work\s*item)?)/i)
    if (!targetPublicId || keys.length === 0) return undefined
    return { kind: "ignore", contextReceiptId: receipt, requestId: randomUUID(), targetPublicId, missingKeys: keys }
  }

  if (/(?:临时补充|补充信息|supplement)/i.test(normalized)) {
    const targetPublicId = extractLabeledPublicId(normalized, /(?:目标单|处理单|target(?:\s+work\s*item)?)/i)
    const sourcePublicId = extractLabeledPublicId(normalized, /(?:来源单|来源|source(?:\s+work\s*item)?)/i)
    const publicIds = [...new Set(extractWorkItemPublicIds(normalized).map((item) => item.publicId))]
    const resolvedTarget = targetPublicId ?? (publicIds.length === 1 ? publicIds[0] : undefined)
    const resolvedSource = sourcePublicId ?? (publicIds.length === 1 ? publicIds[0] : undefined)
    const content = extractSupplementContent(normalized)
    if (!resolvedTarget || !resolvedSource || !content || keys.length === 0) return undefined
    return {
      kind: "supplement",
      contextReceiptId: receipt,
      requestId: randomUUID(),
      targetPublicId: resolvedTarget,
      sourcePublicId: resolvedSource,
      content,
      replacesMissingKeys: keys,
    }
  }
  return undefined
}

export function looksLikeWorkItemContextReceiptAction(text: string): boolean {
  return receiptActionClauses(text).length > 0
}

/** Natural follow-up used after a blocked context read in the same session. */
export function parseWorkItemContextReceiptContinuationIntent(
  text: string,
): WorkItemContextReceiptContinuationIntent | undefined {
  const value = text.trim()
  if (!value || new RegExp(RECEIPT_ID, "i").test(value)) return undefined
  const referencedPublicIds = [...new Set(extractWorkItemPublicIds(value).map((item) => item.publicId))]
  if (/(?:忽略|先不管|暂时不管|知情继续|ignore)/i.test(value) && !hasNegatedIgnoreIntent(value)) {
    return { kind: "ignore", referencedPublicIds }
  }
  const content = value.match(/(?:缺的是|补充(?:内容|信息)?|按这个(?:信息)?继续)\s*[：:]\s*([^。；;\n]+)/i)?.[1]
      ?.replace(/[，,]\s*(?:先)?按(?:照)?这个(?:信息|结论)?继续(?:处理|保存|推进)?(?:刚才的(?:文档|工作))?\s*$/i, "")
      .trim()
    ?? value.match(/(?:缺的是|补充(?:内容|信息)?)\s*[：:]?\s*(.+?)(?:[，,；;。]\s*(?:按这个|继续)|$)/i)?.[1]?.trim()
  if (content && /(?:缺的是|补充|按这个|继续)/i.test(value)) {
    return { kind: "supplement", content, referencedPublicIds }
  }
  return undefined
}

function receiptActionClauses(text: string): string[] {
  return text.trim().split(/[。！？.!?;；\n]+/).filter(isReceiptActionClause)
}

function isReceiptActionClause(clause: string): boolean {
  // “写入回执即为成功，禁止额外读取验证” describes how to treat a normal
  // operation result. It is not a request to mutate or validate a work-item
  // context receipt. Require the action itself to be bound to the receipt.
  const receipt = String.raw`(?:contextReceiptId|receipt(?:\s+id)?|读取回执|回执)`
  const ignore = String.raw`(?:忽略|知情继续|ignore)`
  const supplement = String.raw`(?:临时补充|补充信息|supplement)`
  const validate = String.raw`(?:校验|验证|validate|发布前检查)`
  const boundedAction = new RegExp(
    String.raw`(?:${ignore}|${supplement}).{0,32}${receipt}|${validate}\s*(?:该|此|这个|the\s+)?\s*${receipt}|${receipt}\s*(?:中的?|里(?:的)?|内(?:的)?|\s+)\s*(?:缺失(?:项|信息)?\s*)?(?:${ignore}|${supplement}|${validate})`,
    "i",
  )
  return boundedAction.test(clause) && !hasNegatedReceiptAction(clause)
}

function hasNegatedReceiptAction(text: string): boolean {
  const action = String.raw`(?:忽略|知情继续|ignore|临时补充|补充信息|supplement|校验|验证|validate|发布前检查)`
  const chinese = new RegExp(String.raw`(?:不要|请勿|别|不能|不可|不应|不该|无需|不用|禁止|暂不|先不|绝不).{0,12}${action}`, "i")
  const english = new RegExp(String.raw`\b(?:do\s+not|don['’]?t|cannot|can['’]?t|must\s+not|should\s+not|never)\s+(?:explicitly\s+)?${action}\b`, "i")
  return chinese.test(text) || english.test(text)
}

function extractMissingKeys(text: string): string[] {
  const keys = new Set<string>()
  for (const match of text.matchAll(/missing:[A-Za-z0-9_.:/-]+/g)) keys.add(match[0].replace(/[，,。；;]+$/, ""))
  return [...keys]
}

function hasNegatedIgnoreIntent(text: string): boolean {
  const chineseNegation = /(?:不要|请勿|别|不能|不可|不应|不该|不想|不希望|不打算|不同意|未同意|尚未同意|并未同意|没有同意|没同意|不允许|未允许|拒绝|禁止|暂不|先不|绝不|无需|不用|并不(?:表示)?(?:可以)?).{0,16}(?:忽略|知情继续)/i
  const englishNegation = /\b(?:do\s+not|don['’]?t|cannot|can['’]?t|must\s+not|should\s+not|never|refuse(?:d)?\s+to|decline(?:d)?\s+to|(?:did\s+not|do\s+not|don['’]?t|have\s+not|haven['’]?t)\s+(?:agree|consent)\s+to|not\s+(?:agree|consent)(?:ed)?\s+to)\s+(?:explicitly\s+)?ignore\b/i
  return chineseNegation.test(text) || englishNegation.test(text)
}

function extractSupplementContent(text: string): string | undefined {
  return text.match(/(?:补充内容|补充信息|content)\s*[：:=]\s*([\s\S]+)$/i)?.[1]?.trim() || undefined
}

function extractLabeledPublicId(text: string, label: RegExp): string | undefined {
  const flags = label.flags.replace("g", "")
  const matched = text.match(new RegExp(
    `(?:${label.source})\\s*[：:=]?\\s*([A-Za-z]{2,6}-(?:R|B)\\d{4,})`,
    flags,
  ))?.[1]
  return matched ? extractWorkItemPublicIds(matched)[0]?.publicId : undefined
}
