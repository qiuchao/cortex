/**
 * policy/pack.ts —— 能力规范层的**窄契约**(spec §101,反过度抽象)。
 *
 * 每个 pack 只实现两个动作:
 *   validate(intent, ctx) → { ok, reason }   声明式判定一个意图是否违规
 *   execute(intent)       → result           确定性执行(git pack 暂不需要,留接口)
 *
 * 框架(loader)只负责:role→pack 映射 + 生命周期 + 从主脑同步规则。
 * **不设计通用规则 DSL** —— 新规范 = 新 pack(代码),不是新 DSL 语法。
 */

/** 一个待判定的意图。git pack 里 = 一条 git 命令 + cwd。 */
export interface PolicyIntent {
  /** 意图类型(pack 自解释,如 "git.command") */
  kind: string
  /** 原始命令串(git pack:被拦截的 bash 命令) */
  command?: string
  cwd?: string
  /** 附加载荷(pack 自定义) */
  payload?: Record<string, unknown>
}

export interface ValidateResult {
  /** true=放行,false=拒绝 */
  ok: boolean
  /** 拒绝原因 / 提示(注入给模型看,含正确改道指引) */
  reason?: string
  /**
   * 判定可靠性档:
   *   "enforced" —— 确定性硬护栏(能挂 PreToolUse 的客户端)
   *   "degraded" —— 客户端或调用缺少硬判定所需上下文时的降级
   *   "unavailable" —— 该能力在此客户端不可用(如实披露,不假装 guarded)
   */
  enforcement?: "enforced" | "degraded" | "unavailable"
}

export interface ExecuteResult {
  ok: boolean
  message?: string
}

export interface PolicyPack {
  /** pack 唯一标识 */
  id: string
  /** 适用角色(role→pack 映射用);空=所有角色 */
  appliesToRoles?: string[]
  /** 声明式判定一个意图是否违规 */
  validate(intent: PolicyIntent, ctx: PolicyContext): Promise<ValidateResult> | ValidateResult
  /** 确定性执行(可选;git pack 走原生 git,不需要) */
  execute?(intent: PolicyIntent, ctx: PolicyContext): Promise<ExecuteResult> | ExecuteResult
}

/** 判定上下文:客户端能力 + 项目根等。 */
export interface PolicyContext {
  /** 调用来源客户端(决定护栏能不能硬挂) */
  client: string
  /** 该客户端是否支持 PreToolUse 级硬护栏 */
  hardGuardCapable: boolean
  /** 项目根(git pack 需要；缺失时触发降级) */
  cwd?: string
}
