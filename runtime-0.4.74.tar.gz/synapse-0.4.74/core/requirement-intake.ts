import { randomUUID } from "node:crypto"
import { BUG_PUBLIC_ID_PATTERN, REQUIREMENT_PUBLIC_ID_PATTERN, isRequirementCreateIntentText, isRequirementPublicId, parseWorkItemPublicId, toTaskOperationId, type TaskCapabilitySourceClient } from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import { requirementIntakePath } from "../transport/discovery.ts"
import {
  fetchVisibleProductIterations,
  fetchVisibleProductMembers,
  fetchVisibleProductModules,
  fetchVisibleProductions,
  getIteration,
  listIterationActivity,
  listIterations,
  queryRequirementActivity,
  queryRequirementTree,
  queryRequirements,
  queryRequirementLinks,
  resolveRepoContext,
  type ProductIteration,
  type RequirementActivityCollection,
  type RequirementDraft,
  type RequirementWorkItem,
  type VisibleProductIteration,
  type VisibleProductModule,
  type VisibleProduction,
  type VisibleUser,
} from "../transport/brain-contract-align.ts"
import { sessionKey } from "./session-store.ts"
import {
  assertTaskIntakeDraftMatches,
  isStoredTaskIntakeRef,
  loadTaskIntakeSessions,
  persistTaskIntakeSessions,
  taskIntakeDraftTrust,
  TaskIntakeRefInvalidError,
  type StoredTaskIntakeRef,
  type TaskIntakeDraftTrust,
} from "./task-intake-session.ts"
import { readMachineId } from "./token-store.ts"
import {
  cancelTaskDraftWithReconciliation,
  defaultTaskDraftLifecycle,
  draftPayload,
  inspectTaskDraftAfterConfirmError,
  readableTaskOperationError,
  replaceTaskDraft,
  TaskDraftReplacementRollbackError,
  type TaskDraftCleanupRef,
  type TaskDraftLifecycle,
} from "./task-draft-lifecycle.ts"
import {
  commentRevision,
  createWorkItemDraftContext,
  relationSetVersion,
  type WorkItemDraftContext,
  type WorkItemDraftContextDeps,
} from "./work-item-context-draft-binding.ts"

interface ProductCatalogs {
  users: VisibleUser[]
  modules: VisibleProductModule[]
  iterations: VisibleProductIteration[]
}

interface PendingCreate {
  kind: "create"
  draftId?: string
  requestId: string
  sourceClient?: TaskCapabilitySourceClient
  attempted: boolean
  snapshot: RequirementDraft
  candidates: VisibleProduction[]
  production?: VisibleProduction
  catalogs: ProductCatalogs
  issues: string[]
  cleanupDraftIds?: TaskDraftCleanupRef[]
  draftTrust?: TaskIntakeDraftTrust
}

interface PendingOperation {
  kind: "update" | "assign" | "transition" | "lifecycle" | "comment" | "delete_comment" | "iteration" | "iteration_update" | "iteration_transition" | "bug_link" | "bug_unlink"
  draftId?: string
  requestId: string
  sourceClient?: TaskCapabilitySourceClient
  attempted: boolean
  production: VisibleProduction
  requirementId?: string
  iterationId?: string
  version?: number
  action?: "cancel" | "archive" | "recover"
  body?: string
  commentId?: string
  bugId?: string
  relationId?: string
  expectedRevision?: number
  expectedRelationSetVersion?: number
  /** User-visible snapshot only. The server draft remains authoritative. */
  snapshot: Record<string, unknown>
  catalogs: ProductCatalogs
  issues: string[]
  cleanupDraftIds?: TaskDraftCleanupRef[]
  draftTrust?: TaskIntakeDraftTrust
}

type Pending = PendingCreate | PendingOperation

export interface RequirementIntake {
  ownsSession?(request: InjectRequest): boolean
  maybeHandle(request: InjectRequest): Promise<string | undefined>
}

export interface RequirementIntakeDeps {
  fetchProductions?: () => Promise<VisibleProduction[]>
  fetchMembers?: (productionId: string) => Promise<VisibleUser[]>
  fetchModules?: (productionId: string) => Promise<VisibleProductModule[]>
  fetchIterations?: (productionId: string) => Promise<VisibleProductIteration[]>
  queryIterations?: (productionId: string) => Promise<ProductIteration[]>
  queryIteration?: (productionId: string, iterationId: string) => Promise<ProductIteration>
  queryIterationActivity?: (productionId: string, iterationId: string, options?: { cursor?: string; limit?: number } | number) => Promise<{ items: unknown[]; nextCursor?: string }>
  resolveRepoContext?: typeof resolveRepoContext
  queryRequirements?: typeof queryRequirements
  queryRequirementActivity?: typeof queryRequirementActivity
  queryRequirementTree?: typeof queryRequirementTree
  queryRequirementLinks?: typeof queryRequirementLinks
  createDraft?: TaskDraftLifecycle["create"]
  getDraft?: TaskDraftLifecycle["get"]
  confirmDraft?: TaskDraftLifecycle["confirm"]
  cancelDraft?: TaskDraftLifecycle["cancel"]
  createTaskCommandDraft?: TaskDraftLifecycle["create"]
  getTaskCommandDraft?: TaskDraftLifecycle["get"]
  findTaskDraftByRequest?: TaskDraftLifecycle["findByRequest"]
  confirmTaskCommandDraft?: TaskDraftLifecycle["confirm"]
  cancelTaskCommandDraft?: TaskDraftLifecycle["cancel"]
  workItemDraftContext?: WorkItemDraftContextDeps
}

// Presentation-only cleanup after the shared wire contract has authorized a requirement creation.
const REQUIREMENT_CREATE_LEAD = /^(?:(?:我(?:想要|想|要)?|帮我|请|麻烦)\s*)?提(?:个|一个)?需求(?:\s*单)?(?:\s*[：:,，。]|$)/
const REQUIREMENT_OPERATION_ACTION = /^(确认|取消)\s*(需求|迭代)\s*操作\s*[：:]?\s*(OP-[0-9A-F]{8})[。！!]*$/i
const LEGACY_CONFIRM = /^(?:确认提交|提交需求)[。！!]*$/
const LEGACY_CANCEL = /^(?:取消|取消提交|放弃需求)[。！!]*$/
const QUERY = new RegExp(`(?:查询|查看|列出|搜索).*(?:需求|${REQUIREMENT_PUBLIC_ID_PATTERN}|迭代)|\\b${REQUIREMENT_PUBLIC_ID_PATTERN}\\b|\\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\\b`, 'i')
const COMMENT = new RegExp(`^(?:给|在)?\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(评论|留言|交接说明)\\s*[：:]\\s*(.+)$`, 'i')
const DELETE_COMMENT = new RegExp(`^删除\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(?:的)?评论\\s*[：:]?\\s*([0-9a-f-]{36})$`, 'i')
const UPDATE = new RegExp(`^(?:修改|更新)\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})(?:\\s*[：:]\\s*([\\s\\S]+))?$`, 'i')
const ASSIGN = new RegExp(`^(?:指派|分配|交给)\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(?:给|至|：|:)\\s*(.+)$`, 'i')
const TRANSITION = new RegExp(`^(?:流转|修改状态)\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(?:到|为|状态\\s*[：:]|：|:)\\s*(\\S+)$`, 'i')
const LIFECYCLE = new RegExp(`^(取消|归档|恢复)\\s*(${REQUIREMENT_PUBLIC_ID_PATTERN})(?:\\s*[：:]\\s*(.*))?$`, 'i')
const LINK_BUG = new RegExp(`^(?:关联|挂接)\\s*(?:需求\\s*)?(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(?:和|与|到|关联)?\\s*(?:Bug\\s*)?(${BUG_PUBLIC_ID_PATTERN})$`, 'i')
const UNLINK_BUG = new RegExp(`^(?:解除关联|取消关联|解绑)\\s*(?:需求\\s*)?(${REQUIREMENT_PUBLIC_ID_PATTERN})\\s*(?:和|与|的)?\\s*(?:Bug\\s*)?(${BUG_PUBLIC_ID_PATTERN})$`, 'i')
const CREATE_ITERATION = /^创建迭代\s*[：:]\s*(.+)$/
const UUID = "[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"
const ITERATION_UPDATE = new RegExp(`^(?:修改|更新)\\s*迭代\\s*[：:]?\\s*(${UUID})(?:\\s*[：:]\\s*([\\s\\S]+))?$`, "i")
const ITERATION_TRANSITION = new RegExp(`^(?:流转|修改状态)\\s*迭代\\s*[：:]?\\s*(${UUID})(?:\\s*(?:到|为|状态\\s*[：:])\\s*|\\s*[：:]\\s*)(\\S+)(?:\\s*[：:]\\s*(.*))?$`, "i")
const PRIORITIES: Record<string, RequirementDraft["priority"]> = { "最高": "highest", "高": "high", "普通": "normal", "低": "low", highest: "highest", high: "high", normal: "normal", low: "low" }
const STATUSES: Record<string, string> = { "未开始": "not_started", "进行中": "in_progress", "已完成": "done", "挂起": "suspended", not_started: "not_started", in_progress: "in_progress", done: "done", suspended: "suspended" }

export function isRequirementIntakeIntent(input: string): boolean { return isRequirementCreateIntentText(input) }
export function isRequirementOperationAction(input: string): boolean { return REQUIREMENT_OPERATION_ACTION.test(input.trim()) }

export function createRequirementIntake(env: NodeJS.ProcessEnv = process.env, deps: RequirementIntakeDeps = {}): RequirementIntake {
  const path = requirementIntakePath(env)
  const state: { sessions: Record<string, Pending | StoredTaskIntakeRef> } = { sessions: loadTaskIntakeSessions(path) }
  const save = () => persistTaskIntakeSessions(path, state.sessions, requirementPendingRef)
  const getProductions = deps.fetchProductions ?? (() => fetchVisibleProductions(env))
  const getMembers = deps.fetchMembers ?? ((productionId) => fetchVisibleProductMembers(productionId, env))
  const getModules = deps.fetchModules ?? ((productionId) => fetchVisibleProductModules(productionId, env))
  const getIterations = deps.fetchIterations ?? ((productionId) => fetchVisibleProductIterations(productionId, env))
  const readIterations = deps.queryIterations ?? ((productionId) => listIterations(productionId, env))
  const readIteration = deps.queryIteration ?? ((productionId, id) => getIteration(productionId, id, env))
  const readIterationActivity = deps.queryIterationActivity ?? ((productionId, id, options) => listIterationActivity(productionId, id, options, env))
  const resolveContext = deps.resolveRepoContext ?? ((cwd, machineId) => resolveRepoContext(cwd, machineId, env))
  const readRequirements = deps.queryRequirements ?? ((productionId, filters) => queryRequirements(productionId, filters, env))
  const readActivity = deps.queryRequirementActivity ?? ((productionId, id, options) => queryRequirementActivity(productionId, id, options, env))
  const readTree = deps.queryRequirementTree ?? ((productionId, rootId) => queryRequirementTree(productionId, rootId, undefined, env))
  const readLinks = deps.queryRequirementLinks ?? ((productionId, id) => queryRequirementLinks(productionId, id, env))
  const defaults = defaultTaskDraftLifecycle(env)
  const draft: TaskDraftLifecycle = {
    create: deps.createDraft ?? deps.createTaskCommandDraft ?? defaults.create,
    get: deps.getDraft ?? deps.getTaskCommandDraft ?? defaults.get,
    findByRequest: deps.findTaskDraftByRequest ?? defaults.findByRequest,
    confirm: deps.confirmDraft ?? deps.confirmTaskCommandDraft ?? defaults.confirm,
    cancel: deps.cancelDraft ?? deps.cancelTaskCommandDraft ?? defaults.cancel,
  }
  const draftContext = createWorkItemDraftContext(env, deps.workItemDraftContext)
  const submitting = new Set<string>()

  return {
    ownsSession(request) {
      return Boolean(state.sessions[sessionKey(request)])
    },

    async maybeHandle(request) {
      if (!request.session_id.trim()) return undefined
      const key = sessionKey(request)
      let pending = state.sessions[key]
      const input = request.user_input.trim()
      if (isStoredTaskIntakeRef(pending)) {
        try {
          pending = await restorePending(pending)
          state.sessions[key] = pending
        } catch (error) {
          if (error instanceof TaskIntakeRefInvalidError) {
            delete state.sessions[key]
            save()
            return `[Synapse] 本地需求操作引用无法从 Cerebro 恢复，已安全失效：${readableTaskOperationError(error)}`
          }
          return `[Synapse] 暂时无法从 Cerebro 恢复需求操作，本地引用已保留，可稍后重试：${readableTaskOperationError(error)}`
        }
      }
      if (!pending && !isRequirementIntakeIntent(input) && !QUERY.test(input) && !matchesOperation(input)) return undefined
      if (submitting.has(key)) return "[Synapse] 需求操作正在确认，当前不能修改或取消。"
      try {
        if (pending) await retryCleanupDrafts(pending)
        const requestedAction = parseRequirementOperationAction(input)
        if (pending && requestedAction && (requestedAction.operationId !== pendingOperationId(pending) || requestedAction.resource !== pendingResource(pending))) {
          return pending.draftId
            ? `[Synapse] 当前待处理的是${pendingLabel(pending)}操作 ${pendingOperationId(pending)}；请回复“${pendingActionText(requestedAction.action, pending)}”。`
            : `[Synapse] 当前${pendingLabel(pending)}操作尚未生成可确认的操作 ID，请先处理上方待处理项。`
        }
        if (pending && isCancelInput(input, pending)) return await cancelPending(key, pending)
        if (pending?.attempted && !isConfirmInput(input, pending)) return `[Synapse] 上次确认结果未知，${pendingLabel(pending)}操作已冻结；请回复“${pendingActionText("confirm", pending)}”安全重试，或回复“${pendingActionText("cancel", pending)}”。`
        if (!pending && QUERY.test(input) && !matchesOperation(input)) return await answerQuery(input, request)
        if (!pending && matchesOperation(input)) return await beginOperation(key, input, request)
        if (!pending) return await beginCreate(key, input, request)
        if (pending.production && catalogsEmpty(pending.catalogs)) pending.catalogs = await catalogs(pending.production.id)
        return pending.kind === "create" ? await handleCreate(key, pending, input) : await handleOperation(key, pending, input)
      } catch (error) {
        return `[Synapse] 操作失败：${readableTaskOperationError(error)}`
      }
    },
  }

  async function catalogs(productionId: string): Promise<ProductCatalogs> {
    const [users, modules, iterations] = await Promise.all([getMembers(productionId), getModules(productionId), getIterations(productionId)])
    return { users, modules, iterations }
  }

  async function restorePending(ref: StoredTaskIntakeRef): Promise<Pending> {
    const lookup = ref.draftId
      ? draft.get(ref.productionId, ref.draftId)
      : ref.requestId && draft.findByRequest
        ? draft.findByRequest(ref.productionId, ref.requestId)
        : Promise.reject(new TaskIntakeRefInvalidError("本地操作引用缺少操作 ID，且当前服务端不支持按 requestId 恢复"))
    const [record, productions] = await Promise.all([lookup, getProductions()])
    assertTaskIntakeDraftMatches(record, ref)
    if (record.status !== "pending") throw new TaskIntakeRefInvalidError(`服务端操作状态为 ${record.status}`)
    const production = productions.find((item) => item.id === ref.productionId)
    if (!production) throw new TaskIntakeRefInvalidError("操作所属产品当前不可见")
    const productCatalogs = await catalogs(production.id)
    const payload = draftPayload(record)
    const common = {
      draftId: record.id,
      requestId: ref.requestId,
      sourceClient: ref.sourceClient,
      attempted: ref.attempted,
      production,
      catalogs: productCatalogs,
      issues: [] as string[],
      cleanupDraftIds: ref.cleanupDraftIds,
      draftTrust: trustFromRef(ref),
    }
    if (record.command === "requirement.create") {
      return { kind: "create", ...common, snapshot: normalizeRequirementSnapshot(payload), candidates: productions }
    }
    const kindByCommand = {
      "requirement.update": "update", "requirement.assign": "assign", "requirement.transition": "transition", "requirement.lifecycle": "lifecycle",
      "requirement.comment": "comment", "requirement.comment.delete": "delete_comment", "requirement.bug.link": "bug_link", "requirement.bug.unlink": "bug_unlink",
      "iteration.create": "iteration", "iteration.update": "iteration_update", "iteration.transition": "iteration_transition",
    } as const
    const kind = kindByCommand[record.command as keyof typeof kindByCommand]
    if (!kind) throw new TaskIntakeRefInvalidError("服务端需求或迭代操作无法恢复")
    return {
      kind,
      ...common,
      requirementId: typeof payload.requirementId === "string" ? payload.requirementId : undefined,
      iterationId: typeof payload.iterationId === "string" ? payload.iterationId : undefined,
      version: typeof payload.version === "number" ? payload.version : undefined,
      action: payload.action === "cancel" || payload.action === "archive" || payload.action === "recover" ? payload.action : undefined,
      body: typeof payload.body === "string" ? payload.body : undefined,
      commentId: typeof payload.commentId === "string" ? payload.commentId : undefined,
      bugId: typeof payload.bugId === "string" ? payload.bugId : undefined,
      relationId: typeof payload.relationId === "string" ? payload.relationId : undefined,
      expectedRevision: typeof payload.expectedRevision === "number" ? payload.expectedRevision : undefined,
      expectedRelationSetVersion: typeof payload.expectedRelationSetVersion === "number" ? payload.expectedRelationSetVersion : undefined,
      snapshot: { ...payload },
    }
  }

  async function beginCreate(key: string, input: string, request: InjectRequest): Promise<string> {
    const [productions, context] = await Promise.all([getProductions(), resolveContext(request.cwd, readMachineId()).catch(() => null)])
    if (!productions.length) return "[Synapse] 当前没有可提交的产品。"
    const choice = chooseProduction(productions, context, input)
    const snapshot: RequirementDraft = { title: initialTitle(input, request), description: initialDescription(input, request), priority: "normal" }
    const pending: PendingCreate = { kind: "create", requestId: randomUUID(), sourceClient: request.client, attempted: false, snapshot, candidates: productions, production: choice.production, catalogs: emptyCatalogs(), issues: choice.issue ? [choice.issue] : [] }
    // Register the in-memory session before any remote draft call. A timeout must
    // leave the same requestId available for an idempotent retry in this daemon.
    state.sessions[key] = pending
    save()
    if (pending.production) {
      pending.catalogs = await catalogs(pending.production.id)
      pending.issues.push(...applyRequirementFields(pending.snapshot, input, pending.catalogs))
      if (!pending.issues.some((issue) => issue.includes("产品"))) await installCreateDraft(pending)
    }
    save()
    return renderCreate(pending)
  }

  async function handleCreate(key: string, pending: PendingCreate, input: string): Promise<string> {
    const explicit = explicitProductionChoice(pending.candidates, input)
    if (explicit.specified) {
      if (explicit.issue) { pending.issues = [explicit.issue]; save(); return renderCreate(pending) }
      if (explicit.production && !pending.production) {
        pending.production = explicit.production
        pending.catalogs = await catalogs(explicit.production.id)
        pending.issues = applyRequirementFields(pending.snapshot, input, pending.catalogs).filter((issue) => !issue.includes("产品"))
        await installCreateDraft(pending)
        save()
        return renderCreate(pending)
      }
      if (explicit.production && explicit.production.id !== pending.production?.id) {
        await switchCreateProduction(pending, explicit.production)
        save()
        return renderCreate(pending)
      }
    }
    if (!pending.production) {
      const selected = selectProduction(pending.candidates, input)
      if (!selected) return renderProducts(pending.candidates, pending.issues)
      pending.production = selected
      pending.catalogs = await catalogs(selected.id)
      pending.issues = applyRequirementFields(pending.snapshot, input, pending.catalogs).filter((issue) => !issue.includes("产品"))
      await installCreateDraft(pending)
      save()
      return renderCreate(pending)
    }
    if (!isConfirmInput(input, pending)) {
      const parsed = await parseCreateEdit(pending, input)
      if (parsed.changed) await replaceCreateDraft(pending, parsed.snapshot)
      pending.snapshot = parsed.snapshot
      pending.issues = parsed.issues
      save()
      return renderCreate(pending)
    }
    pending.issues = [...pending.issues.filter((issue) => issue.includes("产品") || issue.includes("负责人") || issue.includes("模块") || issue.includes("迭代")), ...validatePlan(pending.snapshot)]
    if (pending.issues.length) { save(); return renderCreate(pending) }
    if (!pending.draftId) await installCreateDraft(pending)
    pending.attempted = true
    save()
    submitting.add(key)
    try {
      await draftContext.assertConfirmable(draft, {
        productionId: pending.production!.id, draftId: pending.draftId!,
        requestId: pending.requestId, command: "requirement.create",
        binding: requireDraftTrust(pending),
      })
      const receipt = await draft.confirm(pending.production!.id, pending.draftId!)
      const result = parseRequirementWorkItemResult(receipt.result, pending.production!.id)
      delete state.sessions[key]
      saveAfterWrite(save)
      return `[Synapse] 需求 ${result.publicId}“${pending.snapshot.title}”已创建。`
    } catch (error) {
      return await reconcileConfirmFailure(key, pending, error, "需求")
    } finally { submitting.delete(key) }
  }

  async function parseCreateEdit(pending: PendingCreate, input: string): Promise<{ snapshot: RequirementDraft; issues: string[]; changed: boolean }> {
    const base = normalizeRequirementSnapshot(draftPayload(await authoritativeDraft(pending)))
    const before = JSON.stringify(base)
    const issues = applyRequirementFields(base, input, pending.catalogs)
    return { snapshot: base, issues, changed: before !== JSON.stringify(base) }
  }

  async function installCreateDraft(pending: PendingCreate): Promise<void> {
    const input = await createDraftInput(pending.requestId, pending.production!.id, "requirement.create", requirementPayload(pending.snapshot), `创建需求：${pending.snapshot.title}`, requireSourceClient(pending))
    const created = await createPendingDraft(pending, input)
    pending.draftId = created.id
    saveAfterWrite(save)
  }

  async function replaceCreateDraft(pending: PendingCreate, snapshot: RequirementDraft, oldProductionId = pending.production!.id): Promise<void> {
    const requestId = randomUUID()
    const input = await createDraftInput(requestId, pending.production!.id, "requirement.create", requirementPayload(snapshot), `创建需求：${snapshot.title}`, requireSourceClient(pending))
    const result = await replacePendingDraft(pending, { productionId: oldProductionId, draftId: pending.draftId }, input)
    pending.requestId = requestId
    pending.draftId = result.id
  }

  async function switchCreateProduction(pending: PendingCreate, production: VisibleProduction): Promise<void> {
    const oldProductionId = pending.production!.id
    const snapshot = normalizeRequirementSnapshot(draftPayload(await authoritativeDraft(pending)))
    snapshot.assigneeUserId = undefined
    snapshot.moduleId = undefined
    snapshot.iterationId = undefined
    const catalogsForProduction = await catalogs(production.id)
    const requestId = randomUUID()
    const input = await createDraftInput(requestId, production.id, "requirement.create", requirementPayload(snapshot), `创建需求：${snapshot.title}`, requireSourceClient(pending))
    const replacement = await replacePendingDraft(pending, { productionId: oldProductionId, draftId: pending.draftId }, input)
    pending.production = production
    pending.catalogs = catalogsForProduction
    pending.snapshot = snapshot
    pending.issues = []
    pending.requestId = requestId
    pending.draftId = replacement.id
  }

  async function beginOperation(key: string, input: string, request: InjectRequest): Promise<string> {
    const choice = await currentProduction(request, input)
    const production = choice.production
    if (!production) return `[Synapse] ${choice.issue ?? "无法唯一确定当前产品，未创建需求或迭代操作。"}`
    const productCatalogs = await catalogs(production.id)
    const comment = input.match(COMMENT)
    const deleted = input.match(DELETE_COMMENT)
    const changed = input.match(UPDATE)
    const assign = input.match(ASSIGN)
    const transition = input.match(TRANSITION)
    const life = input.match(LIFECYCLE)
    const link = input.match(LINK_BUG)
    const unlink = input.match(UNLINK_BUG)
    const iteration = input.match(CREATE_ITERATION)
    const iterationUpdate = input.match(ITERATION_UPDATE)
    const iterationTransition = input.match(ITERATION_TRANSITION)
    let operation: PendingOperation
    let operationContext: WorkItemDraftContext | undefined
    if (assign || transition) {
      const requirementId = (assign?.[1] ?? transition?.[1] ?? "").toUpperCase()
      const record = (await readRequirements(production.id, { id: requirementId })).items[0]
      if (!record) return `[Synapse] 当前产品中未找到需求 ${requirementId}。`
      if (assign) {
        const assigneeValue = assign[2].trim()
        const members = productCatalogs.users.filter((item) => item.id === assigneeValue || item.name === assigneeValue || item.name.includes(assigneeValue))
        const member = members.length === 1 ? members[0] : undefined
        operation = member
          ? { kind: "assign", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, snapshot: { requirementId, version: record.version, assigneeUserId: member.id }, catalogs: productCatalogs, issues: [] }
          : { kind: "assign", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, snapshot: { requirementId, version: record.version }, catalogs: productCatalogs, issues: [`当前产品中无法唯一匹配负责人“${assigneeValue}”`] }
      } else {
        const status = STATUSES[transition![2]!.trim()]
        operation = status
          ? { kind: "transition", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, snapshot: { requirementId, version: record.version, status }, catalogs: productCatalogs, issues: [] }
          : { kind: "transition", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, snapshot: { requirementId, version: record.version, status: transition![2] }, catalogs: productCatalogs, issues: [`需求状态“${transition![2]}”无效`] }
      }
    } else if (link || unlink) {
      const requirementId = (link?.[1] ?? unlink?.[1] ?? "").toUpperCase()
      const bugId = (link?.[2] ?? unlink?.[2] ?? "").toUpperCase()
      const requestId = randomUUID()
      operationContext = await draftContext.load({
        command: link ? "requirement.bug.link" : "requirement.bug.unlink",
        payload: link ? { requirementId, bugId, expectedRelationSetVersion: 0 } : { bugId, relationId: "00000000-0000-4000-8000-000000000000", expectedRelationSetVersion: 0 },
        taskGoal: input,
        requestId,
      })
      if (!operationContext) throw new Error("需求与 Bug 关联操作缺少上下文")
      const relationVersion = relationSetVersion(operationContext, bugId)
      if (relationVersion === undefined) return `[Synapse] Bug ${bugId} 的关系版本不可用，未创建关联操作。`
      if (link) {
        operation = { kind: "bug_link", requestId, attempted: false, production, requirementId, bugId, expectedRelationSetVersion: relationVersion, snapshot: { requirementId, bugId, expectedRelationSetVersion: relationVersion }, catalogs: productCatalogs, issues: [] }
      } else {
        const relations = await readLinks(production.id, requirementId)
        const relation = relations.find((item) => item.bugId.toUpperCase() === bugId)
        operation = relation
          ? { kind: "bug_unlink", requestId, attempted: false, production, requirementId, bugId, relationId: relation.relationId, expectedRelationSetVersion: relationVersion, snapshot: { bugId, relationId: relation.relationId, expectedRelationSetVersion: relationVersion }, catalogs: productCatalogs, issues: [] }
          : { kind: "bug_unlink", requestId, attempted: false, production, requirementId, bugId, expectedRelationSetVersion: relationVersion, snapshot: { bugId, expectedRelationSetVersion: relationVersion }, catalogs: productCatalogs, issues: ["当前需求未关联该 Bug"] }
      }
    } else if (iterationUpdate) {
      const iterationId = iterationUpdate[1]!
      const current = await readIteration(production.id, iterationId)
      const parsed = parseIterationUpdates(iterationUpdate[2] ?? "", productCatalogs, true)
      operation = { kind: "iteration_update", requestId: randomUUID(), attempted: false, production, iterationId, version: current.version, snapshot: { iterationId, version: current.version, name: current.name, ...(current.code !== null ? { code: current.code } : {}), ...(current.goal !== null ? { goal: current.goal } : {}), ...(current.ownerUserId !== null ? { ownerUserId: current.ownerUserId } : {}), status: current.status, ...(current.startsAt !== null ? { startsAt: current.startsAt } : {}), ...(current.endsAt !== null ? { endsAt: current.endsAt } : {}), position: current.position, ...parsed.payload }, catalogs: productCatalogs, issues: parsed.issues }
    } else if (iterationTransition) {
      const iterationId = iterationTransition[1]!
      const current = await readIteration(production.id, iterationId)
      const status = iterationStatus(iterationTransition[2]!)
      operation = { kind: "iteration_transition", requestId: randomUUID(), attempted: false, production, iterationId, version: current.version, snapshot: { iterationId, version: current.version, status: status ?? iterationTransition[2] }, catalogs: productCatalogs, issues: status ? [] : [`迭代状态“${iterationTransition[2]}”无效`] }
    } else if (iteration) {
      operation = { kind: "iteration", requestId: randomUUID(), attempted: false, production, snapshot: { name: iteration[1].trim() }, catalogs: productCatalogs, issues: [] }
    } else {
      const requirementId = (comment?.[1] ?? deleted?.[1] ?? changed?.[1] ?? life?.[2])!.toUpperCase()
      const record = (await readRequirements(production.id, { id: requirementId })).items[0]
      if (!record) return `[Synapse] 当前产品中未找到需求 ${requirementId}。`
      if (comment) operation = { kind: "comment", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, body: comment[3].trim(), snapshot: { body: comment[3].trim() }, catalogs: productCatalogs, issues: [] }
      else if (deleted) {
        const requestId = randomUUID()
        operationContext = await draftContext.load({
          command: "requirement.comment.delete",
          payload: { requirementId, version: record.version, commentId: deleted[2], expectedRevision: 1 },
          taskGoal: input,
          requestId,
        })
        if (!operationContext) throw new Error("评论删除操作缺少上下文")
        const expectedRevision = commentRevision(operationContext, requirementId, deleted[2])
        operation = expectedRevision
          ? { kind: "delete_comment", requestId, attempted: false, production, requirementId, version: record.version, commentId: deleted[2], expectedRevision, snapshot: { commentId: deleted[2], expectedRevision }, catalogs: productCatalogs, issues: [] }
          : { kind: "delete_comment", requestId, attempted: false, production, requirementId, version: record.version, commentId: deleted[2], snapshot: { commentId: deleted[2] }, catalogs: productCatalogs, issues: ["当前需求上下文中未找到可删除的这条评论"] }
      }
      else if (life) operation = { kind: "lifecycle", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, action: ({ "取消": "cancel", "归档": "archive", "恢复": "recover" } as const)[life[1] as "取消" | "归档" | "恢复"], snapshot: { ...(life[3]?.trim() ? { reason: life[3].trim() } : {}) }, catalogs: productCatalogs, issues: [] }
      else {
        const parsed = parseRequirementUpdates(changed?.[2] ?? "", productCatalogs)
        operation = { kind: "update", requestId: randomUUID(), attempted: false, production, requirementId, version: record.version, snapshot: { requirementId, version: record.version, ...parsed.payload }, catalogs: productCatalogs, issues: parsed.issues }
      }
    }
    operation.sourceClient = request.client
    // Keep the operation and requestId before the remote write. If the response
    // is lost, the same daemon can retry the idempotent create instead of
    // starting a second operation.
    state.sessions[key] = operation
    save()
    if (operation.issues.length === 0) {
      const payload = operationPayload(operation)
      const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, production.id, operationCommand(operation), payload, input, requireSourceClient(operation), operationContext))
      operation.draftId = created.id
      saveAfterWrite(save)
    }
    save()
    return renderOperation(operation)
  }

  async function handleOperation(key: string, operation: PendingOperation, input: string): Promise<string> {
    if (!isConfirmInput(input, operation)) {
      if (operation.kind === "update" || operation.kind === "iteration" || operation.kind === "iteration_update") {
        const base = !operation.draftId ? { ...operation.snapshot } : await authoritativeOperationPayload(operation)
        const parsed = operation.kind === "update" ? parseRequirementUpdates(input, operation.catalogs) : parseIterationUpdates(input, operation.catalogs, operation.kind === "iteration_update")
        const merged = { ...base, ...parsed.payload }
        const changed = JSON.stringify(base) !== JSON.stringify(merged)
        if (changed) {
          if (operation.draftId) await replaceOperationDraft(operation, merged)
          else if (parsed.issues.length === 0) {
            const command = operationCommand(operation)
            const payload = operationPayload({ ...operation, snapshot: merged })
            const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, operation.production.id, command, payload, input, requireSourceClient(operation)))
            operation.draftId = created.id
          }
        }
        operation.snapshot = { ...merged }
        operation.issues = parsed.issues
      }
      save()
      return renderOperation(operation)
    }
    if (operation.issues.length || ((operation.kind === "update" || operation.kind === "iteration_update") && !Object.keys(operation.snapshot).some((key) => !["requirementId", "iterationId", "version"].includes(key)))) return renderOperation(operation)
    if (!operation.draftId) {
      const command = operationCommand(operation)
      const payload = operationPayload(operation)
      const created = await createPendingDraft(operation, await createDraftInput(operation.requestId, operation.production.id, command, payload, input, requireSourceClient(operation)))
      operation.draftId = created.id
      saveAfterWrite(save)
    }
    operation.attempted = true
    save()
    submitting.add(key)
    try {
      await draftContext.assertConfirmable(draft, {
        productionId: operation.production.id, draftId: operation.draftId,
        requestId: operation.requestId, command: operationCommand(operation),
        binding: requireDraftTrust(operation),
      })
      const receipt = await draft.confirm(operation.production.id, operation.draftId)
      const resultText = operationResultText(operation, receipt.result, receipt.draft.confirmedAt ?? receipt.draft.createdAt)
      delete state.sessions[key]
      saveAfterWrite(save)
      return `[Synapse] ${resultText}`
    } catch (error) {
      return await reconcileConfirmFailure(key, operation, error, "需求操作")
    } finally { submitting.delete(key) }
  }

  async function replaceOperationDraft(operation: PendingOperation, payload: Record<string, unknown>): Promise<void> {
    const requestId = randomUUID()
    const command = operationCommand(operation)
    const input = await createDraftInput(requestId, operation.production.id, command, payload, `修改 ${operation.requirementId ?? operation.iterationId ?? "工作项"}`, requireSourceClient(operation))
    const result = await replacePendingDraft(operation, { productionId: operation.production.id, draftId: operation.draftId }, input)
    operation.requestId = requestId
    operation.draftId = result.id
  }

  async function authoritativeDraft(pending: PendingCreate): Promise<Awaited<ReturnType<TaskDraftLifecycle["get"]>>> {
    if (!pending.draftId) throw new Error("服务端操作尚未创建")
    return draft.get(pending.production!.id, pending.draftId)
  }

  async function authoritativeOperationPayload(operation: PendingOperation): Promise<Record<string, unknown>> {
    if (!operation.draftId) throw new Error("服务端操作尚未创建")
    return draftPayload(await draft.get(operation.production.id, operation.draftId))
  }

  async function createDraftInput(
    requestId: string,
    productionId: string,
    command: ReturnType<typeof operationCommand> | "requirement.create",
    payload: Record<string, unknown>,
    taskGoal: string,
    sourceClient: TaskCapabilitySourceClient,
    context?: WorkItemDraftContext,
  ) {
    const loaded = context ?? await draftContext.load({ command, payload, taskGoal, requestId })
    return { requestId, productionId, command, payload, sourceClient, ...(loaded?.binding ?? {}) }
  }

  async function createPendingDraft(
    pending: Pending,
    input: Parameters<TaskDraftLifecycle["create"]>[0],
  ) {
    const trust = taskIntakeDraftTrust(input)
    pending.requestId = input.requestId
    pending.draftTrust = trust
    save()
    const created = await draft.create(input)
    assertTaskIntakeDraftMatches(created, { productionId: input.productionId, ...trust })
    return created
  }

  async function cancelPending(key: string, pending: Pending): Promise<string> {
    const remoteStatus = pending.draftId
      ? (await cancelTaskDraftWithReconciliation(draft, pending.production?.id ?? "", pending.draftId)).status
      : undefined
    delete state.sessions[key]
    save()
    if (remoteStatus === "confirmed") return `[Synapse] ${pendingLabel(pending)}操作已由 Cerebro 确认，本地引用已清理；请查询对应记录核对。`
    if (remoteStatus === "failed" || remoteStatus === "expired") return `[Synapse] ${pendingLabel(pending)}操作已${remoteStatus === "failed" ? "执行失败" : "过期"}，本地引用已清理。`
    return `[Synapse] 已取消${pendingLabel(pending)}操作，服务端未确认任何写入，本地引用已清理。`
  }

  async function replacePendingDraft(
    pending: Pending,
    oldDraft: { productionId: string; draftId?: string },
    input: Parameters<TaskDraftLifecycle["create"]>[0],
  ) {
    const trust = taskIntakeDraftTrust(input)
    try {
      const created = await replaceTaskDraft(draft, oldDraft, input, (record) => {
        assertTaskIntakeDraftMatches(record, { productionId: input.productionId, ...trust })
      })
      pending.requestId = input.requestId
      pending.draftTrust = trust
      return created
    } catch (error) {
      if (error instanceof TaskDraftReplacementRollbackError) {
        const cleanup = { draftId: error.newDraftId, productionId: error.newProductionId }
        if (!pending.cleanupDraftIds?.some((item) => item.draftId === cleanup.draftId && item.productionId === cleanup.productionId)) {
          pending.cleanupDraftIds = [...(pending.cleanupDraftIds ?? []), cleanup]
          save()
        }
      }
      throw error
    }
  }

  async function retryCleanupDrafts(pending: Pending): Promise<void> {
    if (!pending.cleanupDraftIds?.length) return
    const remaining: TaskDraftCleanupRef[] = []
    const errors: unknown[] = []
    for (const cleanup of pending.cleanupDraftIds) {
      try {
        const result = await cancelTaskDraftWithReconciliation(draft, cleanup.productionId, cleanup.draftId)
        if (result.status === "confirmed") errors.push(new Error(`待清理操作 ${toTaskOperationId(cleanup.draftId)} 已被确认，请先查询核对`))
      } catch (error) {
        remaining.push(cleanup)
        errors.push(error)
      }
    }
    pending.cleanupDraftIds = remaining.length ? remaining : undefined
    save()
    if (errors.length === 1) throw errors[0]
    if (errors.length > 1) throw new AggregateError(errors, "仍有服务端操作无法清理")
  }

  async function reconcileConfirmFailure(key: string, pending: Pending, error: unknown, label: string): Promise<string> {
    const current = pending.draftId && pending.production
      ? await inspectTaskDraftAfterConfirmError(draft, pending.production.id, pending.draftId)
      : undefined
    if (!current) return `[Synapse] ${label}确认结果未知，无法读取服务端状态；请回复“${pendingActionText("confirm", pending)}”安全重试，或回复“${pendingActionText("cancel", pending)}”：${readableTaskOperationError(error)}`
    if (current.status === "pending") return `[Synapse] ${label}尚未确认，服务端状态仍为 pending；请回复“${pendingActionText("confirm", pending)}”安全重试，或回复“${pendingActionText("cancel", pending)}”：${readableTaskOperationError(error)}`
    delete state.sessions[key]
    saveAfterWrite(save)
    if (current.status === "confirmed") return `[Synapse] ${label}已由 Cerebro 确认，但本次未取回结果；请查询对应记录核对。`
    const statusText = current.status === "failed" ? "执行失败" : current.status === "expired" ? "已过期" : "已取消"
    return `[Synapse] ${label}在服务端${statusText}，本地引用已清理；请重新发起操作。`
  }

  async function answerQuery(input: string, request: InjectRequest): Promise<string> {
    const bugId = input.match(new RegExp(`\\b${BUG_PUBLIC_ID_PATTERN}\\b`, 'i'))?.[0]?.toUpperCase()
    if (bugId) return `[Synapse] ${bugId} 是 Bug ID，不能用于需求查询。`
    const choice = await currentProduction(request, input)
    const production = choice.production
    if (!production) return `[Synapse] ${choice.issue ?? "无法唯一确定当前产品，未执行查询。"}`
    const iterationId = input.match(/\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/i)?.[0]
    if (/(?:迭代|iteration)/i.test(input) && !/(?:需求|[Rr][0-9A-HJKMNP-TV-Z]{2,6}-)/i.test(input)) {
      if (iterationId && /(?:动态|历史|活动)/.test(input)) {
        const cursor = input.match(/(?:动态|活动)游标\s*[：:]\s*(\S+)/)?.[1]
        const activity = await readIterationActivity(production.id, iterationId, { limit: 100, ...(cursor ? { cursor } : {}) })
        return `[Synapse] 迭代 ${iterationId} 动态（${activity.items.length} 项）：\n${activity.items.slice(0, 20).map(formatActivityItem).join("\n") || "- 无"}${nextCursorText("迭代动态", activity.nextCursor)}`
      }
      if (iterationId) return `[Synapse] ${formatIteration(await readIteration(production.id, iterationId))}`
      const items = await readIterations(production.id)
      return `[Synapse] 当前产品迭代（${items.length} 项）：\n${items.map(formatIteration).join("\n") || "- 无"}`
    }
    const id = input.match(new RegExp(`\\b${REQUIREMENT_PUBLIC_ID_PATTERN}\\b`, 'i'))?.[0]?.toUpperCase()
    if (id && /(?:动态|评论|变更)/.test(input)) {
      const activityCursor = input.match(/(?:活动|变更)游标\s*[：:]\s*(\S+)/)?.[1]
      const commentCursor = input.match(/评论游标\s*[：:]\s*(\S+)/)?.[1]
      const limitText = input.match(/(?:每页|数量|条数)\s*[：:]\s*(\d+)/)?.[1]
      const activityOptions = {
        ...(activityCursor ? { activityCursor } : {}),
        ...(commentCursor ? { commentCursor } : {}),
        ...(limitText ? { limit: Number(limitText) } : {}),
      }
      const activity = Object.keys(activityOptions).length > 0
        ? await readActivity(production.id, id, activityOptions)
        : await readActivity(production.id, id)
      const comments = activityItems(activity.comments)
      const changes = activityItems(activity.changes)
      return `[Synapse] 需求 ${id} 动态：\n评论（${comments.items.length}）\n${comments.items.slice(0, 10).map(formatActivityItem).join("\n") || "- 无"}${nextCursorText("评论", comments.nextCursor)}\n变更（${changes.items.length}）\n${changes.items.slice(0, 10).map(formatActivityItem).join("\n") || "- 无"}${nextCursorText("变更", changes.nextCursor)}`
    }
    if (id && /(?:树|子需求|层级)/.test(input)) {
      const items = await readTree(production.id, id)
      return `[Synapse] 需求树 ${id}（${items.length} 项）：\n${items.map(formatRequirement).join("\n")}`
    }
    if (id && /(?:关联|Bug|BUG)/.test(input)) {
      const links = await readLinks(production.id, id)
      return `[Synapse] 需求 ${id} 关联的 Bug（${links.length} 项）：\n${links.map((item) => `- ${item.bugId} · 关联时间 ${item.linkedAt} · 操作人 ${item.linkedBy}`).join("\n") || "- 无"}`
    }
    const filters: Parameters<typeof queryRequirements>[1] = id ? { id } : { mine: /我负责|我的/.test(input) }
    const productCatalogs = await catalogs(production.id)
    const priority = Object.entries(PRIORITIES).find(([label]) => input.includes(label))?.[1]
    const status = Object.entries(STATUSES).find(([label]) => input.includes(label))?.[1]
    if (priority) filters.priority = priority
    if (status) filters.status = status
    const iterationLabel = input.match(/(?:所属迭代|迭代)\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    const iteration = iterationLabel ? byNameOrId(productCatalogs.iterations, iterationLabel) : productCatalogs.iterations.find((item) => input.includes(item.name))
    if (iteration) filters.iterationId = iteration.id
    const plannedFrom = input.match(/计划开始\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    const plannedTo = input.match(/计划结束\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    if (plannedFrom) { const value = parseTime(plannedFrom); if (value) filters.plannedFrom = value }
    if (plannedTo) { const value = parseExclusiveEnd(plannedTo); if (value) filters.plannedTo = value }
    if (/逾期/.test(input)) filters.plannedOverdue = true
    const search = input.match(/(?:搜索|关键词|标题)\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
    const cursor = input.match(/(?:需求|列表)游标\s*[：:]\s*(\S+)/)?.[1]
    const limitText = input.match(/(?:每页|数量|条数)\s*[：:]\s*(\d+)/)?.[1]
    if (search) filters.search = search
    if (cursor) filters.cursor = cursor
    if (limitText) filters.limit = Number(limitText)
    const result = await readRequirements(production.id, filters)
    if (!result.items.length) return "[Synapse] 当前产品在该条件下没有需求。"
    return `[Synapse] 当前产品需求（${result.total} 项）：\n${result.items.map(formatRequirement).join("\n")}${nextCursorText("需求列表", result.nextCursor)}`
  }

  async function currentProduction(request: InjectRequest, input = ""): Promise<{ production?: VisibleProduction; issue?: string }> {
    const [productions, context] = await Promise.all([getProductions(), resolveContext(request.cwd, readMachineId()).catch(() => null)])
    return chooseProduction(productions, context, input)
  }
}

function matchesOperation(input: string): boolean { return COMMENT.test(input) || DELETE_COMMENT.test(input) || UPDATE.test(input) || ASSIGN.test(input) || TRANSITION.test(input) || LIFECYCLE.test(input) || LINK_BUG.test(input) || UNLINK_BUG.test(input) || CREATE_ITERATION.test(input) || ITERATION_UPDATE.test(input) || ITERATION_TRANSITION.test(input) }
function emptyCatalogs(): ProductCatalogs { return { users: [], modules: [], iterations: [] } }
function catalogsEmpty(catalogs: ProductCatalogs): boolean { return catalogs.users.length === 0 && catalogs.modules.length === 0 && catalogs.iterations.length === 0 }
function labelValue(line: string, label: string): string | undefined { return line.match(new RegExp(`^${label}\\s*[：:]\\s*(.+)$`))?.[1]?.trim() }
function byNameOrId<T extends { id: string; name: string }>(items: T[], value: string): T | undefined { const found = items.filter((item) => item.id === value || item.name === value || item.name.includes(value)); return found.length === 1 ? found[0] : undefined }

function explicitProductionChoice(items: VisibleProduction[], input: string): { specified: boolean; production?: VisibleProduction; issue?: string } {
  const match = input.match(/(?:^|\r?\n)\s*产品(?:线)?\s*[：:]\s*([^\n，,]+)/)
  if (!match) return { specified: false }
  const value = match[1]!.trim()
  const found = items.filter((item) => item.id === value || item.name === value)
  if (found.length === 1) return { specified: true, production: found[0] }
  return { specified: true, issue: found.length ? `产品“${value}”匹配到多个产品，请明确选择` : `不存在产品“${value}”，请从候选产品中选择` }
}

function chooseProduction(items: VisibleProduction[], context: Awaited<ReturnType<typeof resolveRepoContext>>, input: string): { production?: VisibleProduction; issue?: string } {
  // Public ID carries the product key and is authoritative. Resolve every ID in
  // the message first so an explicit product label cannot silently override it.
  const publicIds = [...input.matchAll(new RegExp(`\\b(?:${REQUIREMENT_PUBLIC_ID_PATTERN}|${BUG_PUBLIC_ID_PATTERN})\\b`, 'gi'))]
    .map((match) => parseWorkItemPublicId(match[0]!))
    .filter((parsed): parsed is NonNullable<typeof parsed> => parsed !== null)
  const keys = [...new Set(publicIds.map((parsed) => parsed.workItemKey))]
  if (keys.length > 1) return { issue: '同一条消息包含多个产品的工作项 ID，请分开操作' }
  const idProduct = keys.length === 1 ? items.filter((item) => item.workItemKey?.toUpperCase() === keys[0]) : []
  if (keys.length === 1 && idProduct.length !== 1) return { issue: `无法在当前可见产品中定位 ID 所属产品（${publicIds[0]!.publicId}）` }

  const explicit = explicitProductionChoice(items, input)
  if (explicit.specified) {
    if (explicit.production && idProduct[0] && explicit.production.id !== idProduct[0].id) {
      return { issue: `显式产品与工作项 ID（${publicIds[0]!.publicId}）所属产品不一致` }
    }
    return explicit
  }
  if (idProduct.length === 1) {
    if (context && context.productionId !== idProduct[0]!.id) return { issue: `该需求属于产品“${idProduct[0]!.name}”，与当前工作区产品不一致` }
    return { production: idProduct[0] }
  }
  const named = items.filter((item) => input.includes(item.name))
  if (named.length > 1) return { issue: "输入同时提到多个产品，请明确回复“产品：产品名”" }
  if (named.length === 1) return { production: named[0] }
  const contextual = context ? items.filter((item) => item.id === context.productionId) : []
  if (contextual.length === 1) return { production: contextual[0] }
  return items.length === 1 ? { production: items[0] } : {}
}

function selectProduction(items: VisibleProduction[], input: string): VisibleProduction | undefined {
  const explicit = explicitProductionChoice(items, input)
  if (explicit.specified) return explicit.production
  const ordinal = input.match(/第\s*(\d+)\s*个/)
  if (ordinal) return items[Number(ordinal[1]) - 1]
  const found = items.filter((item) => input.includes(item.name))
  return found.length === 1 ? found[0] : undefined
}

function requirementPayload(snapshot: RequirementDraft): Record<string, unknown> {
  return Object.fromEntries(Object.entries(snapshot).filter(([, value]) => value !== undefined))
}

function normalizeRequirementSnapshot(payload: Record<string, unknown>): RequirementDraft {
  const snapshot: RequirementDraft = { title: typeof payload.title === "string" ? payload.title : "新需求" }
  for (const key of ["description", "parentId", "assigneeUserId", "priority", "moduleId", "iterationId", "estimateDays", "plannedStartAt", "plannedEndAt"] as const) {
    const value = payload[key]
    if (value !== undefined) (snapshot as unknown as Record<string, unknown>)[key] = value
  }
  return snapshot
}

function applyRequirementFields(draft: RequirementDraft, input: string, catalogs: ProductCatalogs): string[] {
  const issues: string[] = []
  for (const line of input.replace(/，\s*(?=[^，：:]+[：:])/g, "\n").split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) {
    const title = labelValue(line, "标题"); if (title !== undefined) { draft.title = title.slice(0, 256); continue }
    const description = labelValue(line, "正文") ?? labelValue(line, "描述"); if (description !== undefined) { draft.description = description.slice(0, 200_000); continue }
    const parent = labelValue(line, "父需求"); if (parent !== undefined) { if (isRequirementPublicId(parent)) draft.parentId = parent.toUpperCase(); else issues.push("父需求必须使用产品限定的需求公共 ID"); continue }
    const assignee = labelValue(line, "负责人"); if (assignee !== undefined) { const item = byNameOrId(catalogs.users, assignee); if (item) draft.assigneeUserId = item.id; else issues.push(`当前产品中无法唯一匹配负责人“${assignee}”`); continue }
    const priority = labelValue(line, "优先级"); if (priority !== undefined) { if (PRIORITIES[priority]) draft.priority = PRIORITIES[priority]; else issues.push(`优先级“${priority}”无效`); continue }
    const moduleName = labelValue(line, "功能模块"); if (moduleName !== undefined) { const item = byNameOrId(catalogs.modules, moduleName); if (item) draft.moduleId = item.id; else issues.push(`当前产品中无法唯一匹配模块“${moduleName}”`); continue }
    const iterationName = labelValue(line, "所属迭代"); if (iterationName !== undefined) { const item = byNameOrId(catalogs.iterations, iterationName); if (item) draft.iterationId = item.id; else issues.push(`当前产品中无法唯一匹配迭代“${iterationName}”`); continue }
    const estimate = labelValue(line, "预估工时") ?? labelValue(line, "工时"); if (estimate !== undefined) { const value = Number(estimate.replace(/人\/?天|天/g, "").trim()); if (Number.isFinite(value) && value >= 0) draft.estimateDays = value; else issues.push(`预估工时“${estimate}”无效`); continue }
    const start = labelValue(line, "计划开始"); if (start !== undefined) { const value = parseTime(start); if (value) draft.plannedStartAt = value; else issues.push(`计划开始“${start}”无法解析`); continue }
    const end = labelValue(line, "计划结束"); if (end !== undefined) { const value = parseTime(end); if (value) draft.plannedEndAt = value; else issues.push(`计划结束“${end}”无法解析`); continue }
  }
  return [...issues, ...validatePlan(draft)]
}

function parseRequirementUpdates(input: string, catalogs: ProductCatalogs): { payload: Record<string, unknown>; issues: string[] } {
  const draft: RequirementDraft = { title: "placeholder" }
  const issues = applyRequirementFields(draft, input.replace(/，\s*(?=[^，：:]+[：:])/g, "\n"), catalogs)
  const { title, ...values } = draft
  const payload: Record<string, unknown> = { ...values }
  if (input.split(/\r?\n|，/).some((line) => /^\s*标题\s*[：:]/.test(line))) payload.title = title
  const status = input.match(/(?:^|[\n，,])\s*状态\s*[：:]\s*([^\n，,]+)/)?.[1]?.trim()
  if (status !== undefined) { if (STATUSES[status]) payload.status = STATUSES[status]; else issues.push(`状态“${status}”无效`) }
  if (payload.parentId !== undefined) { delete payload.parentId; issues.push("需求创建后不可调整父需求") }
  return { payload, issues }
}

function parseIterationUpdates(input: string, catalogs: ProductCatalogs, allowClosed = false): { payload: Record<string, unknown>; issues: string[] } {
  const payload: Record<string, unknown> = {}; const issues: string[] = []
  for (const line of input.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) {
    const name = labelValue(line, "名称"); if (name !== undefined) { payload.name = name; continue }
    const goal = labelValue(line, "目标"); if (goal !== undefined) { payload.goal = goal; continue }
    const owner = labelValue(line, "负责人"); if (owner !== undefined) { const item = byNameOrId(catalogs.users, owner); if (item) payload.ownerUserId = item.id; else issues.push(`当前产品中无法唯一匹配负责人“${owner}”`); continue }
    const status = labelValue(line, "状态"); if (status !== undefined) { const value = iterationStatus(status); if (value && (allowClosed || value !== "closed")) payload.status = value; else issues.push(allowClosed ? `迭代状态“${status}”无效` : "新迭代状态只能是规划中或进行中"); continue }
    const start = labelValue(line, "计划开始"); if (start !== undefined) { const value = parseTime(start); if (value) payload.startsAt = value; else issues.push(`计划开始“${start}”无法解析`); continue }
    const end = labelValue(line, "计划结束"); if (end !== undefined) { const value = parseTime(end); if (value) payload.endsAt = value; else issues.push(`计划结束“${end}”无法解析`); continue }
  }
  if (payload.startsAt && payload.endsAt && Date.parse(String(payload.endsAt)) < Date.parse(String(payload.startsAt))) issues.push("计划结束不得早于计划开始")
  return { payload, issues }
}

function iterationStatus(value: string): "planned" | "in_progress" | "closed" | undefined {
  if (value === "规划中" || value === "planned") return "planned"
  if (value === "进行中" || value === "in_progress") return "in_progress"
  if (value === "已关闭" || value === "已完成" || value === "closed") return "closed"
  return undefined
}

function operationCommand(operation: PendingOperation): "requirement.update" | "requirement.assign" | "requirement.transition" | "requirement.lifecycle" | "requirement.comment" | "requirement.comment.delete" | "requirement.bug.link" | "requirement.bug.unlink" | "iteration.create" | "iteration.update" | "iteration.transition" {
  if (operation.kind === "update") return "requirement.update"
  if (operation.kind === "assign") return "requirement.assign"
  if (operation.kind === "transition") return "requirement.transition"
  if (operation.kind === "lifecycle") return "requirement.lifecycle"
  if (operation.kind === "comment") return "requirement.comment"
  if (operation.kind === "delete_comment") return "requirement.comment.delete"
  if (operation.kind === "bug_link") return "requirement.bug.link"
  if (operation.kind === "bug_unlink") return "requirement.bug.unlink"
  if (operation.kind === "iteration_update") return "iteration.update"
  if (operation.kind === "iteration_transition") return "iteration.transition"
  return "iteration.create"
}

function operationPayload(operation: PendingOperation): Record<string, unknown> {
  if (operation.kind === "update") return { requirementId: operation.requirementId!, version: operation.version!, ...withoutTarget(operation.snapshot) }
  if (operation.kind === "assign" || operation.kind === "transition") return { ...operation.snapshot }
  if (operation.kind === "lifecycle") return { requirementId: operation.requirementId!, version: operation.version!, action: operation.action!, ...(operation.snapshot.reason ? { reason: operation.snapshot.reason } : {}) }
  if (operation.kind === "comment") return { requirementId: operation.requirementId!, version: operation.version!, body: operation.body! }
  if (operation.kind === "delete_comment") return { requirementId: operation.requirementId!, version: operation.version!, commentId: operation.commentId!, expectedRevision: operation.expectedRevision! }
  if (operation.kind === "bug_link") return { requirementId: operation.requirementId!, bugId: operation.bugId!, expectedRelationSetVersion: operation.expectedRelationSetVersion! }
  if (operation.kind === "bug_unlink") return { bugId: operation.bugId!, relationId: operation.relationId!, expectedRelationSetVersion: operation.expectedRelationSetVersion! }
  if (operation.kind === "iteration_update") return { iterationId: operation.iterationId!, version: operation.version!, ...withoutTarget(operation.snapshot) }
  if (operation.kind === "iteration_transition") return { iterationId: operation.iterationId!, version: operation.version!, status: operation.snapshot.status! }
  return { ...operation.snapshot }
}

function withoutTarget(snapshot: Record<string, unknown>): Record<string, unknown> {
  const result = { ...snapshot }; delete result.requirementId; delete result.version; return result
}

function operationResultText(operation: PendingOperation, result: unknown, confirmedAt: string): string {
  if (operation.kind === "update") { const updated = parseRequirementWorkItemResult(result, operation.production.id); return `需求 ${updated.publicId} 已更新，更新时间 ${updated.updatedAt}。` }
  if (operation.kind === "assign" || operation.kind === "transition") { const updated = parseRequirementWorkItemResult(result, operation.production.id); return `需求 ${updated.publicId} 已${operation.kind === "assign" ? "完成指派" : "流转状态"}，更新时间 ${updated.updatedAt}。` }
  if (operation.kind === "iteration_update") { const updated = result as ProductIteration; return `迭代 ${updated.name} 已更新，更新时间 ${updated.updatedAt}。` }
  if (operation.kind === "iteration_transition") { const updated = result as ProductIteration; return `迭代 ${updated.name} 已流转到 ${updated.status}，更新时间 ${updated.updatedAt}。` }
  if (operation.kind === "lifecycle") return `需求 ${operation.requirementId} 已${operation.action === "recover" ? "恢复" : operation.action === "archive" ? "归档" : "取消"}，时间 ${confirmedAt}。`
  if (operation.kind === "comment") { const value = result as { createdAt?: unknown }; return `需求 ${operation.requirementId} 已添加评论，时间 ${String(value?.createdAt ?? "未知")}。` }
  if (operation.kind === "delete_comment") { const value = result as { deletedAt?: unknown }; return `需求 ${operation.requirementId} 的评论已删除，时间 ${String(value?.deletedAt ?? confirmedAt)}。` }
  if (operation.kind === "bug_link") return `需求 ${operation.requirementId} 已关联 Bug ${operation.bugId}，时间 ${confirmedAt}。`
  if (operation.kind === "bug_unlink") return `需求 ${operation.requirementId} 已解除与 Bug ${operation.bugId} 的关联，时间 ${confirmedAt}。`
  const value = result as { id?: unknown; createdAt?: unknown }; return `迭代“${String(operation.snapshot.name)}”已创建（${String(value?.id ?? "未知")}），时间 ${String(value?.createdAt ?? confirmedAt)}。`
}

function parseRequirementWorkItemResult(value: unknown, productionId: string): RequirementWorkItem {
  const candidate = (value && typeof value === "object" && "requirement" in value) ? (value as { requirement?: unknown }).requirement : value
  const item = candidate as Record<string, unknown>
  if (!item || typeof item.id !== "string" || typeof item.publicId !== "string" || !isRequirementPublicId(item.publicId) || item.productionId !== productionId || typeof item.title !== "string" || typeof item.version !== "number") {
    throw new Error("invalid requirement confirmation response")
  }
  return item as unknown as RequirementWorkItem
}

function parseTime(value: string): string | undefined { const date = new Date(value); return Number.isNaN(date.getTime()) ? undefined : date.toISOString() }
function parseExclusiveEnd(value: string): string | undefined {
  const parsed = parseTime(value)
  if (!parsed || !/^\d{4}-\d{2}-\d{2}$/.test(value.trim())) return parsed
  const date = new Date(parsed); date.setUTCDate(date.getUTCDate() + 1); return date.toISOString()
}
function parseRequirementOperationAction(input: string): { action: "confirm" | "cancel"; resource: "requirement" | "iteration"; operationId: string } | undefined {
  const match = input.trim().match(REQUIREMENT_OPERATION_ACTION)
  return match ? { action: match[1] === "确认" ? "confirm" : "cancel", resource: match[2] === "需求" ? "requirement" : "iteration", operationId: match[3]!.toUpperCase() } : undefined
}
function pendingResource(pending: Pending): "requirement" | "iteration" { return pending.kind.startsWith("iteration") ? "iteration" : "requirement" }
function pendingLabel(pending: Pending): "需求" | "迭代" { return pendingResource(pending) === "requirement" ? "需求" : "迭代" }
function isConfirmInput(input: string, pending: Pending): boolean {
  const action = parseRequirementOperationAction(input)
  return action ? action.action === "confirm" && action.resource === pendingResource(pending) && action.operationId === pendingOperationId(pending) : LEGACY_CONFIRM.test(input)
}
function isCancelInput(input: string, pending: Pending): boolean {
  const action = parseRequirementOperationAction(input)
  return action ? action.action === "cancel" && action.resource === pendingResource(pending) && action.operationId === pendingOperationId(pending) : LEGACY_CANCEL.test(input)
}
function pendingActionText(action: "confirm" | "cancel", pending: Pending): string { return `${action === "confirm" ? "确认" : "取消"}${pendingLabel(pending)}操作 ${pendingOperationId(pending) ?? "<操作ID>"}` }
function pendingOperationId(pending: Pending): string | undefined { return pending.draftId ? toTaskOperationId(pending.draftId) : undefined }
function validatePlan(draft: RequirementDraft): string[] { return draft.plannedStartAt && draft.plannedEndAt && Date.parse(draft.plannedEndAt) < Date.parse(draft.plannedStartAt) ? ["计划结束不得早于计划开始"] : [] }
function initialTitle(input: string, request: InjectRequest): string { const detail = input.replace(REQUIREMENT_CREATE_LEAD, "").replace(/^[\s，,：:。]+/, "").trim(); return (detail || request.transcript_tail?.filter((item) => item.role === "user").at(-1)?.text || "新需求").split(/[。！？!?\n]/, 1)[0].trim().slice(0, 256) || "新需求" }
function initialDescription(input: string, request: InjectRequest): string { const detail = input.replace(REQUIREMENT_CREATE_LEAD, "").replace(/^[\s，,：:。]+/, "").trim(); return [...(request.transcript_tail ?? []).filter((item) => item.role === "user").slice(-2).map((item) => item.text.trim()), detail].filter((item, index, all) => item && all.indexOf(item) === index).join("\n").slice(0, 200_000) }
function formatRequirement(item: RequirementWorkItem): string { return `- ${item.publicId} ${item.title} [${item.status}/${item.priority}] 负责人 ${item.assigneeUserId}；迭代 ${item.iterationId ?? "需求池"}；工时 ${item.estimateDays ?? "未估"} 人/天；计划 ${item.plannedStartAt ?? "未定"} ~ ${item.plannedEndAt ?? "未定"}；创建 ${item.createdAt}；更新 ${item.updatedAt}` }
function formatIteration(item: ProductIteration): string { return `- ${item.id} ${item.name} [${item.status}]；目标 ${item.goal ?? "未设置"}；负责人 ${item.ownerUserId ?? "未指定"}；计划 ${item.startsAt ?? "未定"} ~ ${item.endsAt ?? "未定"}；进度 ${item.completedItems}/${item.totalItems}（${item.progressPercent}%）` }
function formatActivityItem(value: unknown): string { const item = value as Record<string, unknown>; const at = item.occurredAt ?? item.createdAt ?? item.recordedAt ?? "时间未知"; const type = item.eventType ?? item.kind ?? "记录"; const body = typeof item.body === "string" ? `：${item.body}` : ""; const id = item.commentId ?? item.id ?? item.eventId; return `- ${at} ${type}${typeof id === "string" ? ` [ID: ${id}]` : ""}${body}` }
function activityItems(value: RequirementActivityCollection): { items: unknown[]; nextCursor?: string } { if (Array.isArray(value)) return { items: value }; return { items: value.items, ...(value.nextCursor ? { nextCursor: value.nextCursor } : {}) } }
function nextCursorText(label: string, cursor?: string): string { return cursor ? `\n${label} nextCursor: ${cursor}` : "" }
function renderProducts(items: VisibleProduction[], issues: string[] = []): string { return [issues.length ? `待处理：\n${issues.map((issue) => `- ${issue}`).join("\n")}` : "", "[Synapse] 请选择产品：", ...items.map((item, index) => `${index + 1}. ${item.name}`)].filter(Boolean).join("\n") }
function renderCreate(pending: PendingCreate): string { if (!pending.production) return renderProducts(pending.candidates, pending.issues); const snapshot = pending.snapshot; const c = pending.catalogs; return ["[Synapse] 待确认的需求操作", `产品：${pending.production.name}`, `标题：${snapshot.title}`, `描述：${snapshot.description || "[未填写]"}`, `父需求：${snapshot.parentId ?? "[无]"}`, `负责人：${c.users.find((item) => item.id === snapshot.assigneeUserId)?.name ?? "[默认当前用户]"}`, `优先级：${snapshot.priority ?? "normal"}`, `功能模块：${c.modules.find((item) => item.id === snapshot.moduleId)?.name ?? "[未指定]"}`, `所属迭代：${c.iterations.find((item) => item.id === snapshot.iterationId)?.name ?? "[需求池]"}`, `预估工时：${snapshot.estimateDays ?? "[未填写]"} 人/天`, `计划：${snapshot.plannedStartAt ?? "[未填写]"} ~ ${snapshot.plannedEndAt ?? "[未填写]"}`, ...(pending.issues.length ? ["待处理：", ...pending.issues.map((item) => `- ${item}`)] : []), pending.draftId ? `可继续按字段修改；确认后单独回复“${pendingActionText("confirm", pending)}”。` : "请先处理待处理项，系统生成操作 ID 后才可确认。"].join("\n") }
function renderOperation(operation: PendingOperation): string { const title = operation.kind === "update" ? `更新需求 ${operation.requirementId}` : operation.kind === "assign" ? `指派需求 ${operation.requirementId}` : operation.kind === "transition" ? `流转需求 ${operation.requirementId}` : operation.kind === "lifecycle" ? `${operation.action}需求 ${operation.requirementId}` : operation.kind === "comment" ? `需求 ${operation.requirementId} 评论` : operation.kind === "delete_comment" ? `删除需求 ${operation.requirementId} 评论 ${operation.commentId}` : operation.kind === "bug_link" ? `关联需求 ${operation.requirementId} 与 Bug ${operation.bugId}` : operation.kind === "bug_unlink" ? `解除需求 ${operation.requirementId} 与 Bug ${operation.bugId} 的关联` : operation.kind === "iteration_update" ? `更新迭代 ${operation.iterationId}` : operation.kind === "iteration_transition" ? `流转迭代 ${operation.iterationId}` : "创建迭代"; return [`[Synapse] 待确认的${pendingLabel(operation)}操作`, `产品：${operation.production.name}`, title, ...(Object.keys(operation.snapshot).length ? [`字段：${JSON.stringify(operation.snapshot)}`] : []), ...(operation.issues.length ? ["待处理：", ...operation.issues.map((item) => `- ${item}`)] : []), operation.draftId ? `确认后单独回复“${pendingActionText("confirm", operation)}”。` : "请先处理待处理项，系统生成操作 ID 后才可确认。"].join("\n") }
function formatActivity(value: unknown): string { return formatActivityItem(value) }
function requirementPendingRef(pending: Pending): StoredTaskIntakeRef | undefined {
  const productionId = pending.production?.id
  if (!productionId || !pending.draftTrust) return undefined
  return {
    ...(pending.draftId ? { draftId: pending.draftId } : {}),
    productionId,
    attempted: pending.attempted,
    ...pending.draftTrust,
    ...(pending.cleanupDraftIds?.length ? { cleanupDraftIds: pending.cleanupDraftIds } : {}),
  }
}

function trustFromRef(ref: StoredTaskIntakeRef): TaskIntakeDraftTrust {
  return {
    requestId: ref.requestId,
    command: ref.command,
    contextReceiptId: ref.contextReceiptId,
    contextTargetPublicId: ref.contextTargetPublicId,
    sourceClient: ref.sourceClient,
  }
}

function requireDraftTrust(pending: Pending): TaskIntakeDraftTrust {
  if (!pending.draftTrust) throw new TaskIntakeRefInvalidError("本地操作缺少可信上下文绑定")
  return pending.draftTrust
}
function requireSourceClient(pending: Pending): TaskCapabilitySourceClient {
  if (!pending.sourceClient) throw new TaskIntakeRefInvalidError("本地操作缺少可信 Harness 客户端")
  return pending.sourceClient
}
function saveAfterWrite(save: () => void): void { try { save() } catch { /* Remote receipt is authoritative. */ } }
