/**
 * transcript/repo-clone-probe.ts —— 配置仓库 clone 探测。
 *
 * directory sync tick 的附属 best-effort 步骤：从 Cerebro 拉当前用户可见 repo 配置，
 * 只检查配置给出的 suggestedInstallDir 及其 <suggested>/<repoBaseName> 兼容路径，
 * 用 `git remote get-url origin` 验证 remote，匹配后登记本机 clone 映射。
 *
 * 安全边界：不扫描任意目录、不 shell 拼命令、失败不阻断同步主流程。
 */
import { execFile } from "node:child_process"
import { statSync } from "node:fs"
import { promisify } from "node:util"

const execFileAsync = promisify(execFile)
const GIT_REMOTE_TIMEOUT_MS = 3_000

export interface ConfigRepo {
  id: string
  gitUrl?: string | null
  suggestedInstallDir?: string | null
}

export interface ProbeHttpConfig {
  brainBaseUrl: string
  machineToken: string
  timeoutMs: number
}

export interface ProbeRepoClonesOptions {
  cfg: ProbeHttpConfig
  machineId: string
  execGitRemote?: (localPath: string) => Promise<string>
}

interface OrgReposResponse {
  repos?: unknown
}

interface NormalizeResponse {
  status?: unknown
  normalized?: unknown
}

/** 从 git URL 提取仓库目录基名；仅用于候选路径拼接，不参与 remote 等价判断。 */
export function repoBaseName(gitUrl: string): string {
  const trimmed = gitUrl.trim().replace(/[\\/]+$/, "")
  const last = trimmed.split(/[\\/:]/).filter(Boolean).pop() ?? trimmed
  return last.endsWith(".git") ? last.slice(0, -4) : last
}

/** 跨 POSIX/Windows 字符串拼接；不 resolve、不枚举父目录，避免扩大探测范围。 */
export function joinConfiguredPath(parent: string, child: string): string {
  const rawBase = parent.trim()
  const isPosixRoot = /^\/+$/u.test(rawBase)
  const isWindowsDriveRoot = /^[A-Za-z]:[\\/]*$/u.test(rawBase)
  const base = isPosixRoot
    ? "/"
    : isWindowsDriveRoot
      ? `${rawBase.slice(0, 2)}${rawBase.includes("\\") ? "\\" : "/"}`
      : rawBase.replace(/[\\/]+$/, "")
  const part = child.trim().replace(/^[\\/]+/, "")
  if (!base) return part
  if (!part) return base
  if (base === "/") return `/${part}`
  if (/^[A-Za-z]:[\\/]$/u.test(base)) return `${base}${part}`
  const sep = base.includes("\\") && !base.includes("/") ? "\\" : "/"
  return `${base}${sep}${part}`
}

/** 候选严格来自配置：suggestedInstallDir 本身优先，其次兼容 <suggested>/<repoBaseName>。 */
export function buildConfiguredCloneCandidates(repo: Pick<ConfigRepo, "gitUrl" | "suggestedInstallDir">): string[] {
  const suggested = repo.suggestedInstallDir?.trim()
  const gitUrl = repo.gitUrl?.trim()
  if (!suggested || !gitUrl) return []
  const nested = joinConfiguredPath(suggested, repoBaseName(gitUrl))
  return suggested === nested ? [suggested] : [suggested, nested]
}

export async function probeConfiguredRepoClones(opts: ProbeRepoClonesOptions): Promise<{ registered: number }> {
  try {
    const headers = authJsonHeaders(opts.cfg.machineToken)
    const repos = await fetchConfiguredRepos(opts.cfg, headers)
    let registered = 0

    for (const repo of repos) {
      const gitUrl = repo.gitUrl?.trim()
      if (!repo.id || !gitUrl) continue
      const normalizedConfig = await normalizeRemote(opts.cfg, headers, gitUrl)
      if (!normalizedConfig) continue

      for (const localPath of buildConfiguredCloneCandidates(repo)) {
        if (!isDirectory(localPath)) continue
        const gitRemote = await readGitRemote(localPath, opts.execGitRemote)
        if (!gitRemote) continue
        const normalizedLocal = await normalizeRemote(opts.cfg, headers, gitRemote)
        if (!normalizedLocal || normalizedLocal !== normalizedConfig) continue
        const ok = await registerClone(opts.cfg, headers, {
          machineId: opts.machineId,
          localPath,
          repoId: repo.id,
          gitRemote,
        })
        if (ok) registered++
        break
      }
    }

    return { registered }
  } catch {
    return { registered: 0 }
  }
}

function authJsonHeaders(machineToken: string): Record<string, string> {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${machineToken}`,
  }
}

async function fetchConfiguredRepos(cfg: ProbeHttpConfig, headers: Record<string, string>): Promise<ConfigRepo[]> {
  const res = await fetch(`${cfg.brainBaseUrl}/api/v1/org/repos`, {
    method: "GET",
    headers,
    signal: AbortSignal.timeout(cfg.timeoutMs),
  })
  if (!res.ok) return []
  const parsed = (await res.json()) as OrgReposResponse
  const rawRepos = Array.isArray(parsed.repos) ? parsed.repos : []
  return rawRepos.flatMap((raw): ConfigRepo[] => {
    if (typeof raw !== "object" || raw === null) return []
    const r = raw as { id?: unknown; gitUrl?: unknown; suggestedInstallDir?: unknown }
    if (typeof r.id !== "string") return []
    return [{
      id: r.id,
      gitUrl: typeof r.gitUrl === "string" ? r.gitUrl : null,
      suggestedInstallDir: typeof r.suggestedInstallDir === "string" ? r.suggestedInstallDir : null,
    }]
  })
}

async function normalizeRemote(
  cfg: ProbeHttpConfig,
  headers: Record<string, string>,
  url: string,
): Promise<string | null> {
  try {
    const res = await fetch(`${cfg.brainBaseUrl}/api/v1/utils/normalize-git-remote`, {
      method: "POST",
      headers,
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(cfg.timeoutMs),
    })
    if (!res.ok) return null
    const parsed = (await res.json()) as NormalizeResponse
    return typeof parsed.normalized === "string" ? parsed.normalized : null
  } catch {
    return null
  }
}

function isDirectory(path: string): boolean {
  try {
    return statSync(path).isDirectory()
  } catch {
    return false
  }
}

async function readGitRemote(
  localPath: string,
  injected?: (localPath: string) => Promise<string>,
): Promise<string | null> {
  try {
    if (injected) return (await injected(localPath)).trim() || null
    const { stdout } = await execFileAsync("git", ["-C", localPath, "remote", "get-url", "origin"], {
      shell: false,
      timeout: GIT_REMOTE_TIMEOUT_MS,
      maxBuffer: 64 * 1024,
      windowsHide: true,
    })
    return String(stdout).trim() || null
  } catch {
    return null
  }
}

async function registerClone(
  cfg: ProbeHttpConfig,
  headers: Record<string, string>,
  body: { machineId: string; localPath: string; repoId: string; gitRemote: string },
): Promise<boolean> {
  try {
    const res = await fetch(`${cfg.brainBaseUrl}/api/v1/repo-clones`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(cfg.timeoutMs),
    })
    return res.ok
  } catch {
    return false
  }
}
