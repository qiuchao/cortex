import { randomUUID } from "node:crypto"
import {
  REQUIREMENT_DRAFT_ACTION_PATH, REQUIREMENT_DRAFT_ACTION_VERSION,
  RequirementDraftRequestSchema, parseRequirementDraftResponse,
  type RequirementDraftReference, type RequirementDraftRequest, type RequirementDraftActionResponse,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import { getBrainConfig } from "../transport/brain-config.ts"
import { withControlDeadline } from "./control-deadline.ts"
import { stableUuidV4 } from "./stable-uuid.ts"
import { resolveUserId } from "./user-id.ts"

/** Delivery facts only. Neither these flags nor local clocks grant execution. */
export interface RequirementDraftDeliveryFacts {
  attempted: boolean
  requirementActionKey?: string
  requirementActionVersion?: 1
}
export interface RequirementDraftActionControl {
  signal?: AbortSignal
  isCurrent?: () => boolean
  reconcile?: boolean
  onReference?: () => void
  onLegacyPermission?: () => void
}
export type RequirementDraftCurrent = (() => boolean) & { signal?: AbortSignal }
export type RequirementDraftTransport = (request: RequirementDraftRequest, signal?: AbortSignal) => Promise<unknown>
export interface RequirementDraftDelegateOptions {
  env: NodeJS.ProcessEnv
  transport?: RequirementDraftTransport
}
export interface RequirementDraftLocalReference extends RequirementDraftDeliveryFacts {
  productionId: string
  draftId?: string
  requestId: string
  command?: string
  cleanupPending?: boolean
}

const referenceRevisions = new WeakMap<object, { value: number }>()

/** A process-local CAS, shared across both intakes. It never grants C authority. */
export function requirementDraftRevision(owner: object, current: () => boolean = () => true, advance = false) {
  let revision = referenceRevisions.get(owner)
  if (!revision) { revision = { value: 0 }; referenceRevisions.set(owner, revision) }
  if (advance) revision.value++
  const expected = revision.value
  let snapshot = JSON.stringify(owner)
  const latest = () => revision.value === expected && current()
  const matches = () => latest() && JSON.stringify(owner) === snapshot
  return {
    latest,
    matches,
    commit(change: () => void, persist: () => void, rollback: () => void): boolean {
      if (!matches()) return false
      // All three callbacks are synchronous: no hook can observe a half commit.
      try { change(); persist() } catch (error) { rollback(); throw error }
      snapshot = JSON.stringify(owner)
      return true
    },
    transfer(next: object) { referenceRevisions.set(next, revision) },
  }
}

/** A C permit is usable once for this exact event, local reference and active turn. */
export function createRequirementDraftLegacyPermits() {
  const permits = new WeakMap<InjectRequest, { owner: object; snapshot: string; current: RequirementDraftCurrent }>()
  const snapshot = (request: InjectRequest, owner: object) => JSON.stringify([request, owner])
  const take = (request: InjectRequest, owner: object | undefined): RequirementDraftCurrent | undefined => {
    const permit = permits.get(request)
    permits.delete(request)
    return permit && owner === permit.owner && permit.current() && permit.snapshot === snapshot(request, owner)
      ? permit.current : undefined
  }
  return {
    grant(request: InjectRequest, owner: object, control: RequirementDraftActionControl = {}) {
      const revision = requirementDraftRevision(owner, () => !control.signal?.aborted && (control.isCurrent?.() ?? true))
      permits.set(request, { owner, snapshot: snapshot(request, owner),
        current: Object.assign(revision.latest, { signal: control.signal }) })
    },
    take,
    consume: (request: InjectRequest, owner: object | undefined): boolean => Boolean(take(request, owner)),
  }
}

export const REQUIREMENT_DRAFT_UNAVAILABLE = "[Synapse] Cerebro 未能核定原需求操作；引用已保留。本轮不得确认、取消、修改、替换或通过旧入口重试。"

export function requirementDraftReference(ref: RequirementDraftLocalReference): RequirementDraftReference {
  const recovery = ref.attempted ? "unknown" : ref.requirementActionVersion === 1 ? "unattempted" : "legacy"
  return { ...(ref.draftId ? { kind: "draft" as const, draftId: ref.draftId } : { kind: "request" as const, requestId: ref.requestId }),
    productionId: ref.productionId, recovery, ...(ref.cleanupPending ? { cleanupPending: true } : {}) }
}

/** Authenticated transport shared by action and read-only reconciliation. */
export function createRequirementDraftTransport(env: NodeJS.ProcessEnv, fetchImpl: typeof fetch = fetch): RequirementDraftTransport {
  return async (request, signal) => {
    const cfg = getBrainConfig(env)
    if (!cfg?.machineToken) throw new Error("requirement draft action transport unavailable")
    return withControlDeadline(async (bounded) => {
      bounded.throwIfAborted()
      const response = await fetchImpl(`${cfg.brainBaseUrl}${REQUIREMENT_DRAFT_ACTION_PATH}`, {
        method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${cfg.machineToken}` },
        body: JSON.stringify(RequirementDraftRequestSchema.parse(request)), signal: bounded,
      })
      const payload = await response.json()
      bounded.throwIfAborted()
      if (!response.ok) throw new Error("requirement draft action HTTP failure")
      return payload
    }, 3_500, signal)
  }
}

export function formatRequirementDraftResponse(response: RequirementDraftActionResponse): string {
  return `[Cerebro requirement draft data]\n${JSON.stringify(response)}`
}

export function requirementDraftEventKey(input: InjectRequest, env: NodeJS.ProcessEnv): string | undefined {
  if (!input.turn_id?.trim() || !input.message_id?.trim()) return undefined
  const cfg = getBrainConfig(env)
  return stableUuidV4("cerebro.requirement-draft-action.event", resolveUserId({ env }) ?? "",
    cfg?.brainBaseUrl ?? "", cfg?.machineToken ?? "", input.client, input.session_id, input.turn_id, input.message_id)
}

/** Fresh hooks may send user facts; recovery and repeated delivery can only read.
 * No text classifier, draft get/confirm/cancel helper or business fallback exists here. */
export async function delegateRequirementDraft(
  input: InjectRequest,
  ref: RequirementDraftLocalReference,
  state: RequirementDraftDeliveryFacts,
  save: () => void,
  options: RequirementDraftDelegateOptions,
  control: RequirementDraftActionControl = {},
): Promise<string | undefined> {
  const current = () => !control.signal?.aborted && (control.isCurrent?.() ?? true)
  if (!current()) return REQUIREMENT_DRAFT_UNAVAILABLE
  control.onReference?.()
  const observation = requirementDraftRevision(state, current, true)
  const reference = requirementDraftReference(ref)
  const transport = options.transport ?? createRequirementDraftTransport(options.env)
  try {
    const key = requirementDraftEventKey(input, options.env)
    const reconcile = control.reconcile || (key !== undefined && state.requirementActionKey === key)
    // Missing stable event facts cannot be promoted to a fresh confirmation.
    if (!reconcile && !key) return REQUIREMENT_DRAFT_UNAVAILABLE
    const request = RequirementDraftRequestSchema.parse(reconcile ? {
      protocolVersion: REQUIREMENT_DRAFT_ACTION_VERSION, mode: "reconcile", queryId: randomUUID(), reference,
    } : {
      protocolVersion: REQUIREMENT_DRAFT_ACTION_VERSION, mode: "action", client: input.client,
      sessionId: input.session_id, turnId: input.turn_id, messageId: input.message_id,
      idempotencyKey: key, message: input.user_input, reference,
    })
    const attempted = state.attempted
    if (request.mode === "action") {
      // Persist before sending. A failed save must never send an untracked action.
      const previousKey = state.requirementActionKey
      if (!observation.commit(() => { state.attempted = true; state.requirementActionKey = key }, save,
        () => { state.attempted = attempted; state.requirementActionKey = previousKey })) return REQUIREMENT_DRAFT_UNAVAILABLE
    }
    if (!observation.matches()) return REQUIREMENT_DRAFT_UNAVAILABLE
    const response = parseRequirementDraftResponse(await transport(request, control.signal), request)
    if (!observation.matches() || response.binding?.requestId !== ref.requestId) return REQUIREMENT_DRAFT_UNAVAILABLE
    if (response.status === "not_applicable") {
      // A known create reference contradicting C is never reassigned locally.
      if (ref.command === "requirement.create" && response.reason !== "ordinary_pending_edit") return REQUIREMENT_DRAFT_UNAVAILABLE
      const previousAttempted = state.attempted
      if (!observation.commit(() => { state.attempted = attempted }, save,
        () => { state.attempted = previousAttempted })) return REQUIREMENT_DRAFT_UNAVAILABLE
      control.onLegacyPermission?.()
      return undefined
    }
    // A verified denial/pending response cannot erase an earlier unknown attempt.
    // Retain terminal references too: subsequent recovery is always current-authorized.
    const previousAttempted = state.attempted
    if (!observation.commit(() => { state.attempted = response.status === "pending" || response.status === "rejected" ? attempted : true }, save,
      () => { state.attempted = previousAttempted })) return REQUIREMENT_DRAFT_UNAVAILABLE
    return formatRequirementDraftResponse(response)
  } catch {
    return REQUIREMENT_DRAFT_UNAVAILABLE
  }
}
