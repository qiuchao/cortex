@echo off
if not defined SYNAPSE_BIN set "SYNAPSE_BIN=synapse.exe"
"%SYNAPSE_BIN%" agent inject --client claude-code
