/**
 * runtime/version.ts —— runtime-visible package version source.
 *
 * Do not import package.json as JSON: Node's TS type-stripping path and bundled
 * dist-bundle installs must both be able to run this file directly.
 */
import { existsSync, readFileSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"

let cachedVersion: string | null = null

function findPackageJson(startDir: string): string | null {
  let dir = startDir
  while (true) {
    const candidate = join(dir, "package.json")
    if (existsSync(candidate)) return candidate
    const parent = dirname(dir)
    if (parent === dir) return null
    dir = parent
  }
}

export function getRuntimeVersion(): string {
  if (cachedVersion !== null) return cachedVersion

  const here = dirname(fileURLToPath(import.meta.url))
  const packageJsonPath = findPackageJson(here)
  if (packageJsonPath === null) {
    throw new Error("Unable to locate package.json for Synapse runtime version")
  }

  const pkg = JSON.parse(readFileSync(packageJsonPath, "utf8")) as { version?: unknown }
  if (typeof pkg.version !== "string" || pkg.version.trim() === "") {
    throw new Error("package.json is missing a valid version")
  }

  cachedVersion = pkg.version
  return cachedVersion
}
