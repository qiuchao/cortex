/** Private transient result files. They never authorize a read or survive a boot. */
import { closeSync, existsSync, lstatSync, mkdirSync, openSync, readFileSync, readdirSync, renameSync, rmdirSync, unlinkSync, writeFileSync } from "node:fs"
import { join } from "node:path"
import { initializeWindowsIterationDirectory, assertWindowsIterationPath, createWindowsIterationFiles, type WindowsIterationFiles } from "./iteration-result-windows.ts"
import type { IterationResultDelivery } from "./iteration-result-delivery.ts"

export function assertIterationPrivatePath(path: string, directory: boolean): void {
  const stat = lstatSync(path)
  if (stat.isSymbolicLink() || (directory ? !stat.isDirectory() : !stat.isFile())) throw new Error("unsafe iteration spool")
  if (process.platform !== "win32") {
    if (typeof process.getuid === "function" && stat.uid !== process.getuid() || (stat.mode & 0o077) !== 0) throw new Error("iteration spool permissions")
  } else {
    // Fail closed on unknown/inherited broad ACLs; never assume chmod secures Windows.
    assertWindowsIterationPath(path, directory)
  }
}
export function iterationSpoolPath(root: string, id: string): string {
  if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error("invalid spool id")
  return join(root, "iteration-delivery", `response-${id}.json`)
}
export function createIterationSpool(root: string, delivery: IterationResultDelivery) {
  const dir = join(root, "iteration-delivery")
  if (process.platform === "win32") initializeWindowsIterationDirectory(dir)
  else mkdirSync(dir, { recursive: true, mode: 0o700 })
  if (process.platform !== "win32") assertIterationPrivatePath(dir, true)
  for (const name of process.platform === "win32" ? [] : readdirSync(dir)) {
    if (!/^(?:response-[a-f0-9-]{36}\.json|\.response-[a-f0-9-]{36}\.tmp)$/.test(name)) throw new Error("unexpected result spool entry")
    unlinkSync(join(dir, name))
  }
  const windows = process.platform === "win32" ? createWindowsIterationFiles(dir) : undefined
  const prepared = new Set<string>()
  const pending = new Map<string, { id: string; expires: number; responseId?: string }>()
  const deleting = new Map<string, Promise<void>>()
  let failed = false, stopped = false
  function cleanupFailed() {
    if (failed) return
    failed = true
    console.error("[iteration-delivery] Private result cleanup failed; delivery disabled.")
    delivery.stop()
  }
  function remove(path: string, id: string) {
    if (deleting.has(path)) return deleting.get(path)!
    const task = windows!.remove(id).then(() => { pending.delete(path) }).catch(cleanupFailed).finally(() => { deleting.delete(path) })
    deleting.set(path, task)
    return task
  }
  function clean() {
    if (failed) return
    for (const [path, meta] of pending) {
      if (meta.expires <= Date.now() || meta.responseId && !delivery.responseActive(meta.responseId)) {
        if (windows) { void remove(path, meta.id); continue }
        try { if (existsSync(path)) unlinkSync(path); pending.delete(path) } catch { cleanupFailed() }
      }
    }
  }
  const unsubscribe = delivery.subscribe(clean)
  const timer = setInterval(clean, 500); timer.unref()
  async function prepare(id: string) {
    if (failed || stopped || prepared.has(id)) throw new Error("result spool unavailable")
    if (windows) { await windows.prepare(id); prepared.add(id) }
  }
  async function abort(id: string) {
    if (prepared.delete(id)) await windows?.abort(id)
  }
  async function writeWindows(id: string, status: number, body: unknown) {
    const value = body as { responseId?: string; expiresAt?: number; chunk?: unknown }
    try {
      if (!prepared.has(id)) await prepare(id)
      if (failed || stopped || value.responseId && !delivery.responseActive(value.responseId)) throw new Error("result spool unavailable")
      const deadline = Math.min(Date.now() + 60_000, value.expiresAt ?? Infinity)
      await windows!.commit(id, JSON.stringify({ protocolVersion: "synapse-agent-file.v1", id, status, body }), deadline)
      prepared.delete(id)
      const path = iterationSpoolPath(root, id)
      pending.set(path, { id, expires: deadline, ...(value.responseId ? { responseId: value.responseId } : {}) })
      clean()
    } catch (error) { await abort(id).catch(() => undefined); throw error }
  }
  return {
    prepare, abort,
    write(id: string, status: number, body: unknown) {
      if (windows) return writeWindows(id, status, body)
      if (failed || stopped) throw new Error("result spool unavailable")
      assertIterationPrivatePath(dir, true)
      const value = body as { responseId?: string; expiresAt?: number; chunk?: unknown }
      const path = iterationSpoolPath(root, id), temp = join(dir, `.response-${id}.tmp`)
      const deadline = Math.min(Date.now() + 60_000, value.expiresAt ?? Infinity)
      if (deadline <= Date.now()) throw new Error("result response expired")
      let fd: number | undefined
      try {
        fd = openSync(temp, "wx", 0o600)
        writeFileSync(fd, JSON.stringify({ protocolVersion: "synapse-agent-file.v1", id, status, body }))
        closeSync(fd); fd = undefined
        assertIterationPrivatePath(temp, false)
        renameSync(temp, path)
        pending.set(path, { id, expires: deadline, ...(value.chunk && value.responseId ? { responseId: value.responseId } : {}) })
        clean()
      } finally { if (fd !== undefined) closeSync(fd); if (existsSync(temp)) unlinkSync(temp) }
    },
    stop() {
      if (stopped) return
      stopped = true; clearInterval(timer); unsubscribe()
      const finish = () => { for (const path of pending.keys()) if (existsSync(path)) unlinkSync(path); pending.clear(); if (existsSync(dir)) rmdirSync(dir) }
      if (windows) return (async () => {
        try { await Promise.all([...pending].map(([path, meta]) => remove(path, meta.id))); if (failed) throw new Error("private result cleanup failed") }
        finally { await windows.stop() }
        if (existsSync(dir)) rmdirSync(dir)
      })()
      finish()
    },
  }
}
export type IterationSpool = ReturnType<typeof createIterationSpool>

const readers = new Map<string, WindowsIterationFiles>()
export async function readIterationSpoolResponse(root: string, id: string): Promise<string | undefined> {
  if (process.platform === "win32") {
    let reader = readers.get(root)
    if (!reader) { reader = createWindowsIterationFiles(join(root, "iteration-delivery")); readers.set(root, reader) }
    return reader.read(id)
  }
  const path = iterationSpoolPath(root, id)
  assertIterationPrivatePath(join(root, "iteration-delivery"), true); assertIterationPrivatePath(path, false)
  return readFileSync(path, "utf8")
}
export async function closeIterationSpoolReaders(): Promise<void> {
  const closing = [...readers.values()]; readers.clear()
  await Promise.all(closing.map(reader => reader.stop()))
}
