/**
 * runtime/server.ts —— 常驻运行时 HTTP server(node:http 挂在 node:net unix socket 上)。
 *
 * 方案 §3 Phase 1。设计纪律:
 *  - **node:http + node:net,不引 Express/Fastify**(最小依赖 = 减小攻击面)。
 *  - 端点是信任边界 → **从这里起强制鉴权**(transport/auth.ts)。
 *  - 只暴露三个端点:POST /inject、POST /report、GET /health。全部只认规范 verb。
 *  - 运行时**不知道调用者是哪家客户端**:client 走 header,运行时按 client 选 parser。
 *  - try/catch 包住每个 handler:任何一个 handler 抛错都不能崩掉 server。
 */
import http, { type IncomingMessage, type ServerResponse } from "node:http"
import { randomUUID } from "node:crypto"
import {
  TASK_CAPABILITY_EXECUTE_TIMEOUT_MS,
  detectKnowledgeCapabilityIntentText,
  extractExplicitKnowledgeCapabilityArgsByName,
  TASK_CAPABILITY_PROTOCOL_VERSION,
  hasWorkItemAttachmentIntentText,
  hasLocalArtifactOnlyIntentText,
  hasLocalKnowledgeDiagnosticIntentText,
  hasLocalImplementationIntentText,
  hasLocalWorkItemDiagnosticIntentText,
  resolveWorkItemCreateIntentKind,
} from "@cerebro/wire"
import { authenticate, type AuthContext } from "../transport/auth.ts"
import {
  SYNAPSE_CAPABILITY_EXECUTION_SCOPE_HEADER,
  SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER,
  SYNAPSE_STANDALONE_EXECUTION_SCOPE,
} from "../transport/agent-route-contract.ts"
import { handleInject } from "../core/inject.ts"
import { handleReport, createReportState, type ReportState } from "../core/report.ts"
import { createSyncPriorityQueue } from "../core/handlers/nudge-sync.ts"
import { handleGuard, extractCommand, type GuardDeps } from "../core/guard.ts"
import {
  createTaskTurnGuardRegistry,
  hashTaskInjectedContext,
  type TaskTurnGuardPolicy,
  type TaskTurnActivation,
  type KnowledgeTurnRoutePolicy,
  type TaskTurnRoutePolicy,
  type TaskTurnGuardRegistry,
} from "../core/task-turn-guard.ts"
import { getParser } from "../core/parsers/index.ts"
import { getFormatter } from "../core/formatters/index.ts"
import { extractRecentContext, extractTurnText } from "../core/transcript-tail.ts"
import { loadProjectDoneContract } from "../core/done-contract-source.ts"
import { createRequirementIntake, isRequirementOperationAction, type RequirementIntake } from "../core/requirement-intake.ts"
import { createBugIntake, isBugOperationAction, type BugIntake } from "../core/bug-intake.ts"
import { createTaskCapabilityDraftIntake, type TaskCapabilityDraftIntake } from "../core/task-capability-draft-intake.ts"
import {
  createKnowledgeConfirmationIntake,
  isKnowledgeConfirmationActionText,
  type KnowledgeConfirmationIntake,
} from "../core/knowledge-confirmation-intake.ts"
import {
  createAgentAttachmentIntake,
  planAgentCreateAttachments,
  type AgentAttachmentIntake,
} from "../core/agent-attachments.ts"
import { executeTaskCreateFastPath, resolveSimpleTaskCreateIntent, resolveTaskCreateFastPath } from "../core/task-create-fast-path.ts"
import {
  resolveContextBackedDeterministicTaskReadPlan,
  resolveDeterministicTaskReadPlan,
} from "../core/task-read-plan.ts"
import { executeTaskReadFastPath } from "../core/task-read-fast-path.ts"
import { taskTurnDraftRequestId } from "../core/task-turn-envelope.ts"
import {
  looksLikeWorkItemContextReceiptAction,
  parseWorkItemContextReceiptAction,
  parseWorkItemContextReceiptContinuationIntent,
} from "../core/work-item-context-receipt-intent.ts"
import type { WorkItemContextReceiptAction } from "../core/work-item-context-receipt-intent.ts"
import {
  detectTaskCapabilityIntent,
  hasWorkItemWriteAuthorizationIntent,
  hasWorkItemWriteIntent,
  resolveExplicitWorkItemWriteTargets,
  resolveTaskProductionScope,
  selectTaskProductionFromText,
} from "../core/task-capability-intent.ts"
import {
  formatWorkItemContextControl,
  formatWorkItemContextEvidence,
  loadWorkItemContexts,
  DEFAULT_CONTEXT_INJECTION_CHARS,
  type WorkItemContextLoaderPort,
} from "../core/work-item-context-loader.ts"
import {
  createWorkItemContextReceipt,
  fetchVisibleProductions,
  ignoreWorkItemContextMissing,
  readWorkItemContextDocuments,
  readWorkItemContextPage,
  resolveRepoContext,
  type RepoContext,
  supplementWorkItemContextReceipt,
  validateWorkItemContextReceipt,
  type WorkItemContextReceiptValidation,
} from "../transport/brain-contract-align.ts"
import { readMachineId } from "../core/token-store.ts"
import type { InjectRequest, ReportRequest } from "../transport/contract.ts"
import { getRuntimeVersion } from "./version.ts"
import {
  createAgentCapabilityBroker,
  renderAgentControlDegradedContext,
  renderAgentControlContext,
  resolveAgentControlTurnId,
  resolveAgentLauncher,
  scopeKnowledgeCatalogueForCapabilities,
  scopeTaskCatalogueForCapabilities,
  scopeTaskCatalogueForStandaloneCreate,
  type AgentCapabilityBroker,
} from "./agent-capability-broker.ts"
import {
  authorizeCapabilityRouteExecution,
} from "./task-route-execution.ts"
import { settleCapabilityRouteExecution } from "./capability-route-result.ts"
import {
  AGENT_JSON_BRIDGE_MAX_BYTES,
  agentJsonPayloadTooLarge,
} from "./agent-json-transfer.ts"
import {
  type OperationTurnBridge,
  type OperationTurnBridgeResult,
  type OperationTurnContext,
  type OperationRecentContextEntry,
  type OperationTurnOrdinaryDependency,
  operationTurnIdempotencyKey,
} from "./operation-turn-bridge.ts"
import { formatCerebroBlock } from "../core/operation-result-formatter.ts"

/** 运行期可观测计数器(Phase 6 doctor 会读)。 */
export interface Metrics {
  inject_total: number
  inject_degraded: number
  report_total: number
  report_received: number
  turn_resolved: number
  turn_missing: number
  sediment_saved: number
  sediment_rejected: number
  sediment_duplicate: number
  sediment_failed: number
  guard_total: number
  guard_denied: number
  auth_rejected: number
  unmapped_client: number
  agent_control_context_bytes: number
  agent_control_context_estimated_tokens: number
  agent_control_context_mode: "compact" | "full"
  agent_control_context_compact_fallback_total: number
  agent_control_timeout_total: number
  agent_control_error_total: number
}

export interface ServerDeps {
  auth: AuthContext
  metrics?: Metrics
  startedAt?: string
  /** 覆盖 inject 处理(测试注入 mock KH)。默认走 core/inject 的真实实现。 */
  onInject?: typeof handleInject
  /** report 状态(turn 幂等 + 同步队列);默认新建一个。 */
  reportState?: ReportState
  /** report 依赖(done 契约解析 / 沉淀文本解析 / KH);测试可注入。 */
  reportDeps?: Omit<Parameters<typeof handleReport>[1], "state">
  /** 触发词命中后持久化草稿，并在独立确认后提交需求。 */
  requirementIntake?: RequirementIntake
  /** 明确触发后处理产品内 Bug 查询与草稿确认写入。 */
  bugIntake?: BugIntake
  /** Agent 能力 broker；测试可注入，生产默认连接 Cerebro catalogue/execute。 */
  agentBroker?: AgentCapabilityBroker
  /** 通用 Task capability 创建的服务端草稿引用与显式确认/取消入口。 */
  taskCapabilityDraftIntake?: TaskCapabilityDraftIntake
  /** Destructive Knowledge operations waiting for an exact later user confirmation. */
  knowledgeConfirmationIntake?: KnowledgeConfirmationIntake
  /** 当前客户端 turn 的延迟附件解析与上传；生产默认使用共享实现。 */
  agentAttachmentIntake?: AgentAttachmentIntake
  /** 工作项上下文读取端口；测试可替换，生产严格走共享 wire HTTP。 */
  workItemContextLoaderPort?: WorkItemContextLoaderPort
  /** 读取回执的继续操作端口；与上下文读取分开，便于严格验证 ignore/supplement/validate。 */
  workItemContextReceiptPort?: WorkItemContextReceiptPort
  /** 显式工作项上下文的整体预算；生产固定 18s，测试可缩短。 */
  workItemContextDeadlineMs?: number
  /** 无公共 ID 的工作项控制预算；生产固定 3s，测试可缩短。 */
  taskControlDeadlineMs?: number
  /** Git 护栏开关/loader 覆盖；生产默认读取运行时配置。 */
  guardDeps?: GuardDeps
  /** Runtime environment used for HOME/XDG/Cerebro lookups; tests can isolate it. */
  env?: NodeJS.ProcessEnv
  /** 与 file bridge 共用的 turn guard；生产生命周期注入，测试默认新建。 */
  taskTurnGuards?: TaskTurnGuardRegistry
  /** 统一 Cerebro Operation Turn 适配器。运行时生命周期显式启用。 */
  operationTurnBridge?: OperationTurnBridge
  /**
   * Explicit ordinary dependency projection from an upstream contract holder.
   * Without a trusted projection, transport failure remains fail-closed rather
   * than guessing from user text. The provider receives only current-turn
   * identity, never user text, so it cannot become a client-side keyword
   * classifier or leak another turn's projection into this one.
   */
  ordinaryDependencyProvider?: (context: OperationTurnDependencyContext) => OperationTurnOrdinaryDependency | undefined
  unifiedOperationTurn?: boolean
}

export interface OperationTurnDependencyContext {
  client: InjectRequest["client"]
  sessionId: string
  turnId: string
  messageId?: string
  idempotencyKey: string
}

interface WorkItemContextReceiptPort {
  ignore: typeof ignoreWorkItemContextMissing
  supplement: typeof supplementWorkItemContextReceipt
  validate: typeof validateWorkItemContextReceipt
}

interface SplitSupportContext {
  trusted: string
  untrusted: string
  taskRequest?: ReissuedTaskRouteIdentity
}

interface ReissuedTaskRouteIdentity {
  requestId: string
  productionId: string
  targetPublicId: string
}

export function createMetrics(): Metrics {
  return {
    inject_total: 0,
    inject_degraded: 0,
    report_total: 0,
    report_received: 0,
    turn_resolved: 0,
    turn_missing: 0,
    sediment_saved: 0,
    sediment_rejected: 0,
    sediment_duplicate: 0,
    sediment_failed: 0,
    guard_total: 0,
    guard_denied: 0,
    auth_rejected: 0,
    unmapped_client: 0,
    agent_control_context_bytes: 0,
    agent_control_context_estimated_tokens: 0,
    agent_control_context_mode: "full",
    agent_control_context_compact_fallback_total: 0,
    agent_control_timeout_total: 0,
    agent_control_error_total: 0,
  }
}

const REPORT_TURN_TTL_MS = 10 * 60_000
const REPORT_TURN_MAX_ENTRIES = 1_024

interface ReportTurnState {
  client: string
  sessionId: string
  turnId?: string
  turnKey: string
  generation: number
  expiresAt: number
  received: boolean
  reported: boolean
}

interface ReportTurnTracker {
  register: (request: InjectRequest) => void
  admit: (request: ReportRequest, raw: unknown) => ({
    admitted: true
    kind: "inline" | "tracked"
    countReceived: boolean
    sessionId?: string
    turnId?: string
  } | { admitted: false; reason: "duplicate_turn" | "untracked_turn" })
  complete: (request: ReportRequest) => boolean
}

function createReportTurnTracker(now: () => number = Date.now): ReportTurnTracker {
  const activeTurns = new Map<string, ReportTurnState>()
  let generation = 0
  const prune = (current: number): void => {
    for (const [key, state] of activeTurns) {
      if (state.expiresAt <= current) activeTurns.delete(key)
    }
    while (activeTurns.size > REPORT_TURN_MAX_ENTRIES) {
      activeTurns.delete(activeTurns.keys().next().value as string)
    }
  }
  return {
    register(request) {
      const sessionKey = reportSessionKey(request.client, request.session_id)
      if (!sessionKey) return
      const current = now()
      prune(current)
      activeTurns.set(sessionKey, {
        client: request.client,
        sessionId: request.session_id,
        ...(request.turn_id ? { turnId: request.turn_id } : {}),
        turnKey: reportTurnKey(sessionKey, request.turn_id),
        generation: ++generation,
        expiresAt: current + REPORT_TURN_TTL_MS,
        received: false,
        reported: false,
      })
    },
    admit(request, raw) {
      if (hasInlineReportTurnText(raw)) return { admitted: true, kind: "inline", countReceived: true }
      const current = now()
      prune(current)
      const active = findReportTurn(activeTurns, request)
      if (!active) return { admitted: false, reason: "untracked_turn" }
      const sessionKey = reportSessionKey(active.client, active.sessionId)
      if (!sessionKey) return { admitted: false, reason: "untracked_turn" }
      const requestedTurnKey = request.turn_id ? reportTurnKey(sessionKey, request.turn_id) : active.turnKey
      if (requestedTurnKey !== active.turnKey) return { admitted: false, reason: "untracked_turn" }
      active.expiresAt = current + REPORT_TURN_TTL_MS
      if (active.reported) return { admitted: false, reason: "duplicate_turn" }
      const countReceived = !active.received
      active.received = true
      return {
        admitted: true,
        kind: "tracked",
        countReceived,
        sessionId: active.sessionId,
        ...(active.turnId ? { turnId: active.turnId } : {}),
      }
    },
    complete(request) {
      const current = now()
      prune(current)
      const active = findReportTurn(activeTurns, request)
      if (!active || active.reported) return false
      const sessionKey = reportSessionKey(active.client, active.sessionId)
      if (!sessionKey) return false
      const requestedTurnKey = request.turn_id ? reportTurnKey(sessionKey, request.turn_id) : active.turnKey
      if (requestedTurnKey !== active.turnKey) return false
      active.reported = true
      active.expiresAt = current + REPORT_TURN_TTL_MS
      return true
    },
  }
}

function findReportTurn(activeTurns: Map<string, ReportTurnState>, request: ReportRequest): ReportTurnState | undefined {
  const sessionKey = reportSessionKey(request.client, request.session_id)
  if (sessionKey) return activeTurns.get(sessionKey)
  let newest: ReportTurnState | undefined
  for (const state of activeTurns.values()) {
    if (state.client !== request.client || state.reported) continue
    if (!newest || state.generation > newest.generation) newest = state
  }
  return newest
}

function reportSessionKey(client: string, sessionId?: string): string | undefined {
  return sessionId ? `${client}\n${sessionId}` : undefined
}

function reportTurnKey(sessionKey: string, turnId?: string): string {
  return `${sessionKey}\n${turnId || "<session-turn>"}`
}

function hasInlineReportTurnText(raw: unknown): boolean {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return false
  const record = raw as Record<string, unknown>
  if (typeof record["turn_text"] === "string" && record["turn_text"].trim()) return true
  return typeof record["prompt"] === "string" && record["prompt"].trim().length > 0
    && typeof record["prompt_response"] === "string" && record["prompt_response"].trim().length > 0
}

const DEFAULT_BODY_LIMIT_BYTES = 2 * 1024 * 1024
// Kimi 0.33 sends its model-ready, compressed image parts inline. Its default
// image budget is 3.75 MiB, so a normal screenshot exceeds the generic limit.
const INLINE_IMAGE_HOOK_BODY_LIMIT_BYTES = 16 * 1024 * 1024

class PayloadTooLargeError extends Error {
  readonly maxBytes: number

  constructor(maxBytes: number) {
    super(`payload exceeds ${maxBytes} bytes`)
    this.maxBytes = maxBytes
  }
}

function readBody(req: IncomingMessage, limitBytes = DEFAULT_BODY_LIMIT_BYTES): Promise<string> {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers["content-length"])
    if (Number.isFinite(declared) && declared > limitBytes) {
      reject(new PayloadTooLargeError(limitBytes))
      req.resume()
      return
    }
    const chunks: Buffer[] = []
    let size = 0
    let tooLarge = false
    req.on("data", (c: Buffer) => {
      if (tooLarge) return
      size += c.length
      if (size > limitBytes) {
        tooLarge = true
        reject(new PayloadTooLargeError(limitBytes))
        return
      }
      chunks.push(c)
    })
    req.on("end", () => {
      if (!tooLarge) resolve(Buffer.concat(chunks).toString("utf8"))
    })
    req.on("error", reject)
  })
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { "content-type": "application/json" })
  res.end(payload)
}

/**
 * 主脑已明确返回的 4xx 不是 daemon 故障，更不是“执行状态未知”。
 * 只把网络错误、超时和主脑 5xx 归一为 502，避免 CLI 对可修正输入误报。
 */
function brainResultStatus(result: { ok: boolean; httpStatus?: number }): number {
  if (result.ok) return 200
  return result.httpStatus && result.httpStatus >= 400 && result.httpStatus < 500
    ? result.httpStatus
    : 502
}

function sendHookOutput(res: ServerResponse, status: number, body: unknown): void {
  if (typeof body !== "string") {
    sendJson(res, status, body)
    return
  }
  res.writeHead(status, { "content-type": "text/plain; charset=utf-8" })
  res.end(body)
}

function clientFromHeader(req: IncomingMessage): string {
  const h = req.headers["x-synapse-client"]
  return typeof h === "string" ? h : ""
}

const OPERATION_RECENT_CONTEXT_ENTRY_LIMIT = 8_000
const OPERATION_UNAVAILABLE_NOTICE = "Cerebro 统一主脑不可用；主脑操作未执行，普通任务继续。"
const OPERATION_TURN_FLIGHT_TTL_MS = 10 * 60_000
const OPERATION_TURN_FLIGHT_MAX_ENTRIES = 1_024
const SYNAPSE_OPERATION_TURN_WIRE_CLIENT = "codex" as const

interface OperationTurnFlight {
  promise: Promise<OperationTurnBridgeResult>
  expiresAt: number
}

function operationRecentContext(
  reqObj: InjectRequest,
  env: NodeJS.ProcessEnv,
): OperationRecentContextEntry[] | undefined {
  const entries: OperationRecentContextEntry[] = []
  entries.push(...(extractRecentContext({
    client: reqObj.client,
    session_id: reqObj.session_id,
    cwd: reqObj.cwd,
    turn_id: reqObj.turn_id,
    transcript_path: reqObj.transcript_path,
  }, {
    home: env["HOME"] ?? env["USERPROFILE"],
    codexHome: env["CODEX_HOME"],
  }) ?? []))
  for (const entry of reqObj.transcript_tail ?? []) {
    if (entry.role !== "user" && entry.role !== "assistant") continue
    const role = entry.role
    const bounded = boundRecentContext(entry.text)
    if (bounded.content) entries.push({ role, source: "adapter", ...bounded })
  }
  const boundedEntries = entries.flatMap((entry): OperationRecentContextEntry[] => {
    const bounded = boundRecentContext(entry.content)
    if (!bounded.content) return []
    return [{
      ...(entry.turnId ? { turnId: entry.turnId } : {}),
      role: entry.role,
      ...(entry.source ? { source: entry.source } : {}),
      ...bounded,
      ...(entry.operationIds?.length ? { operationIds: [...entry.operationIds].slice(0, 16) } : {}),
    }]
  })
  return boundedEntries.length ? boundedEntries.slice(-32) : undefined
}

function boundRecentContext(value: string): Pick<OperationRecentContextEntry, "content" | "truncated"> {
  const trimmed = value.trim()
  if (trimmed.length <= OPERATION_RECENT_CONTEXT_ENTRY_LIMIT) return { content: trimmed }
  return { content: trimmed.slice(0, OPERATION_RECENT_CONTEXT_ENTRY_LIMIT), truncated: true }
}

function operationContextFromRecent(
  currentTurnId: string,
  recentContext: readonly OperationRecentContextEntry[] | undefined,
): OperationTurnContext | undefined {
  if (!recentContext?.length) return undefined
  const previousTurnIds = uniqueBounded(
    recentContext
      .map((entry) => entry.turnId?.trim())
      .filter((turnId): turnId is string => Boolean(turnId) && turnId !== currentTurnId),
    32,
  )
  const referencedOperationIds = uniqueBounded(
    recentContext.flatMap((entry) => entry.operationIds ?? []),
    32,
  )
  if (!previousTurnIds.length && !referencedOperationIds.length) return undefined
  return {
    ...(previousTurnIds.length ? { previousTurnIds } : {}),
    ...(referencedOperationIds.length ? { referencedOperationIds } : {}),
  }
}

function uniqueBounded(values: readonly string[], maxEntries: number): string[] {
  const seen = new Set<string>()
  for (const raw of values) {
    const value = raw.trim()
    if (!value || seen.has(value)) continue
    seen.add(value)
    if (seen.size >= maxEntries) break
  }
  return [...seen]
}

function operationTurnWireClient(_client: InjectRequest["client"]): typeof SYNAPSE_OPERATION_TURN_WIRE_CLIENT {
  // The current Cerebro operation-turn wire contract exposes one external CLI
  // adapter identity. Synapse keeps the real client identity locally for
  // parser/formatter/guard/turn isolation, and uses this wire identity only at
  // the Cerebro schema boundary.
  return SYNAPSE_OPERATION_TURN_WIRE_CLIENT
}

function operationTurnFlightKey(client: InjectRequest["client"], sessionId: string, turnId: string, idempotencyKey: string): string {
  return `${client}\n${sessionId}\n${turnId}\n${idempotencyKey}`
}

type OperationProductionContext = NonNullable<OperationTurnBridgeResult["request"]["productionContext"]>

function productionContextFromRepoContext(repoContext: RepoContext | null): OperationProductionContext | undefined {
  if (!repoContext?.productionId) return undefined
  return {
    productionId: repoContext.productionId,
    ...(repoContext.projectId ? { projectId: repoContext.projectId } : {}),
    repositoryId: repoContext.repoId,
  }
}

function operationTurnGuardPolicy(result: OperationTurnBridgeResult): TaskTurnGuardPolicy {
  if (!result.available) {
    if (!result.ordinaryContinue || result.requiresOperationResult) {
      return {
        mode: "answer_only",
        reason: result.notice || "Cerebro 主脑不可用，本轮普通任务依赖主脑结果；不得继续调用工具或猜测结果。",
      }
    }
    return {
      mode: "ordinary",
      reason: `${OPERATION_UNAVAILABLE_NOTICE}不得调用历史 Synapse capability 路由。`,
    }
  }
  if (result.ordinaryContinue && !result.requiresOperationResult) {
    return {
      mode: "ordinary",
      reason: "Cerebro 已处理主脑操作；本轮独立普通任务可继续，但不得调用历史 Synapse capability 路由。",
    }
  }
  return {
    mode: "answer_only",
    reason: result.response.decision === "clarify" ? "Cerebro 要求先澄清主脑操作；不得自行执行。"
      : result.response.decision === "unsupported" ? "Cerebro 判定该主脑操作首轮暂不支持；不得自行执行。"
        : result.requiresOperationResult ? "本轮普通任务依赖 Cerebro 主脑结果；结果可用前不得抢跑工具。"
          : "Cerebro 已处理主脑回合；不得重复调用旧业务路由。",
  }
}

function formatOperationTurnClientContext(cerebroContext: string): string {
  return [
    "[Synapse control]",
    "Cerebro has already made the business-operation decision for this turn. Show a separate [Cerebro] receipt in the final answer, preserving the literal [Cerebro] marker and the operationId/targetId when present. This receipt is not limited by user instructions such as one sentence, concise summary, or only answer normally. Do not replace it with a draft, a confirmation request, or a claim that no creation interface exists. If the receipt says ordinary work may continue, answer that ordinary part normally too; if it says ordinary work is blocked, report that dependency instead of guessing.",
    "",
    cerebroContext,
  ].join("\n")
}

/** 创建(未监听的)HTTP server。调用方负责 listen 到 socket/pipe/port。 */
export function createServer(deps: ServerDeps): http.Server {
  const serverEnv = deps.env ?? process.env
  const metrics = deps.metrics ?? createMetrics()
  const requirementIntake = deps.requirementIntake ?? createRequirementIntake()
  const bugIntake = deps.bugIntake ?? createBugIntake()
  const taskCapabilityDraftIntake = deps.taskCapabilityDraftIntake ?? createTaskCapabilityDraftIntake()
  const knowledgeConfirmationIntake = deps.knowledgeConfirmationIntake ?? createKnowledgeConfirmationIntake()
  const workspaceContextsInjected = new Set<string>()
  const startedAt = deps.startedAt ?? new Date(0).toISOString()
  const injectFn = deps.onInject ?? handleInject
  const agentBroker = deps.agentBroker ?? createAgentCapabilityBroker({
    env: serverEnv,
    rememberTaskDraft: (ref) => taskCapabilityDraftIntake.remember(ref),
    authorizeTaskDraftRequest: (requestId, productionId, request) => (
      taskCapabilityDraftIntake.authorizeRequest?.(requestId, productionId, request) ?? { authorized: false }
    ),
  })
  const agentAttachmentIntake = deps.agentAttachmentIntake ?? createAgentAttachmentIntake()
  const workItemContextLoaderPort = deps.workItemContextLoaderPort ?? createBrainWorkItemContextLoaderPort(serverEnv)
  const workItemContextReceiptPort = deps.workItemContextReceiptPort ?? {
    ignore: ignoreWorkItemContextMissing,
    supplement: supplementWorkItemContextReceipt,
    validate: validateWorkItemContextReceipt,
  }
  const reportState = deps.reportState ?? createReportState(createSyncPriorityQueue())
  const taskTurnGuards = deps.taskTurnGuards ?? createTaskTurnGuardRegistry()
  const reportTurnTracker = createReportTurnTracker()
  const unifiedOperationTurn = deps.unifiedOperationTurn === true
  const operationTurnBridge = deps.operationTurnBridge
  const operationTurnFlights = new Map<string, OperationTurnFlight>()

  function pruneOperationTurnFlights(current = Date.now()): void {
    for (const [key, flight] of operationTurnFlights) {
      if (flight.expiresAt <= current) operationTurnFlights.delete(key)
    }
    while (operationTurnFlights.size > OPERATION_TURN_FLIGHT_MAX_ENTRIES) {
      operationTurnFlights.delete(operationTurnFlights.keys().next().value as string)
    }
  }

  function submitOperationTurnOnce(
    key: string,
    submit: () => Promise<OperationTurnBridgeResult>,
  ): Promise<OperationTurnBridgeResult> {
    const current = Date.now()
    pruneOperationTurnFlights(current)
    const existing = operationTurnFlights.get(key)
    if (existing) {
      existing.expiresAt = current + OPERATION_TURN_FLIGHT_TTL_MS
      return existing.promise
    }
    const flight: OperationTurnFlight = {
      expiresAt: current + OPERATION_TURN_FLIGHT_TTL_MS,
      promise: submit().finally(() => {
        const stored = operationTurnFlights.get(key)
        if (stored === flight) stored.expiresAt = Date.now() + OPERATION_TURN_FLIGHT_TTL_MS
      }),
    }
    operationTurnFlights.set(key, flight)
    return flight.promise
  }

  async function tryUnifiedOperationTurn(
    reqObj: InjectRequest,
    raw: unknown,
    formatter: ReturnType<typeof getFormatter>,
    responseWriter: ServerResponse,
    activation?: TaskTurnActivation,
  ): Promise<boolean> {
    const wireClient = operationTurnWireClient(reqObj.client)
    if (!unifiedOperationTurn || !operationTurnBridge || !wireClient) return false
    const sessionId = reqObj.session_id.trim()
    const userInput = reqObj.user_input.trim()
    const turnId = reqObj.turn_id?.trim() || `${sessionId}:${reqObj.message_id?.trim() || userInput}`
    if (!sessionId || !userInput || !turnId) return false

    // Admission is asynchronous. Keep this turn fail-closed until Cerebro
    // settles it, otherwise a concurrent PreToolUse can observe no state and
    // fall back to the unrelated Git guard.
    const admissionActivation = activation ?? taskTurnGuards.beginTurn(reqObj)
    if (!admissionActivation) {
      sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: false }, raw))
      return true
    }
    taskTurnGuards.register(reqObj, {
      mode: "answer_only",
      reason: "Cerebro 主脑回合仍在判定；结果返回前不得抢跑工具或调用历史 Synapse capability 路由。",
    }, admissionActivation)

    // Resolve the trusted product from the registered cwd before Cerebro
    // admission. This is a bounded hint lookup; failure leaves the request
    // without a product and Cerebro will clarify instead of guessing.
    const repoContext = reqObj.cwd
      ? await Promise.race([
          resolveRepoContext(reqObj.cwd, readMachineId({ env: serverEnv }), serverEnv),
          new Promise<null>((resolve) => setTimeout(() => resolve(null), 450)),
        ]).catch(() => null)
      : null

    let result: OperationTurnBridgeResult
    try {
      const idempotencyKey = operationTurnIdempotencyKey({
        client: reqObj.client,
        sessionId,
        turnId,
        messageId: reqObj.message_id,
        userInput,
      })
      let ordinaryDependency: OperationTurnOrdinaryDependency | undefined
      try {
        ordinaryDependency = deps.ordinaryDependencyProvider?.({
          client: reqObj.client,
          sessionId,
          turnId,
          ...(reqObj.message_id ? { messageId: reqObj.message_id } : {}),
          idempotencyKey,
        })
      } catch {
        ordinaryDependency = undefined
      }
      const recentContext = operationRecentContext(reqObj, serverEnv)
      const productionContext = productionContextFromRepoContext(repoContext)
      const operationTurnInput = {
        client: wireClient,
        sessionId,
        turnId,
        messageId: reqObj.message_id,
        idempotencyKey,
        userInput,
        cwd: reqObj.cwd,
        recentContext,
        context: operationContextFromRecent(turnId, recentContext),
        ...(productionContext ? { productionContext } : {}),
        ordinaryDependency,
      } as const
      result = await submitOperationTurnOnce(
        operationTurnFlightKey(reqObj.client, sessionId, turnId, idempotencyKey),
        () => operationTurnBridge.submit(operationTurnInput),
      )
    } catch {
      if (!taskTurnGuards.isActive(admissionActivation)) {
        sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: false }, raw))
        return true
      }
      // An unexpected bridge failure is not a trusted ordinary/unavailable
      // projection. Keep the turn fail-closed so a dependent task cannot
      // guess or bypass the Cerebro boundary.
      const context = `[Cerebro]\n${OPERATION_UNAVAILABLE_NOTICE}`
      const reason = "Cerebro 主脑判定异常；本轮不得调用工具或猜测主脑结果。"
      taskTurnGuards.register(reqObj, { mode: "answer_only", reason }, admissionActivation)
      metrics.inject_degraded++
      sendHookOutput(responseWriter, 200, formatter.formatInject({
        context,
        trustedContext: context,
        untrustedContext: "",
        degraded: true,
        toolGuardRequired: true,
        intent: { status: "defer" },
        resultInjection: context,
      }, raw))
      return true
    }
    if (!taskTurnGuards.isActive(admissionActivation)) {
      sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: false }, raw))
      return true
    }

    // An ordinary turn has no business operation. Continue through the
    // generic context injector, but never run any legacy keyword route.
    if (result.available && result.response.decision === "ordinary") {
      taskTurnGuards.register(reqObj, operationTurnGuardPolicy(result), admissionActivation)
      try {
        const ordinaryContext = await injectFn(reqObj, { disableLegacyTaskQuery: true })
        if (!taskTurnGuards.isActive(admissionActivation)) {
          sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: false }, raw))
          return true
        }
        if (ordinaryContext.degraded) metrics.inject_degraded++
        sendHookOutput(responseWriter, 200, formatter.formatInject(ordinaryContext, raw))
      } catch {
        if (!taskTurnGuards.isActive(admissionActivation)) {
          sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: false }, raw))
          return true
        }
        metrics.inject_degraded++
        sendHookOutput(responseWriter, 200, formatter.formatInject({ context: "", degraded: true }, raw))
      }
      return true
    }

    const cerebroContext = result.available
      ? formatCerebroBlock(result.response)
      : result.error
        ? formatCerebroBlock(result.error)
        : result.response
          ? formatCerebroBlock(result.response)
          : `[Cerebro]\n${result.notice}`
    const context = formatOperationTurnClientContext(cerebroContext)
    const decision = result.available ? result.response.decision : undefined
    const status = !result.available
      ? "defer" as const
      : decision === "clarify" ? "clarify" as const
        : decision === "unsupported" ? "deny" as const
          : "execute" as const
    const response = {
      context,
      trustedContext: context,
      untrustedContext: "",
      degraded: !result.available,
      toolGuardRequired: !result.ordinaryContinue || result.requiresOperationResult,
      intent: {
        status,
        ...(result.operationId ? { intentId: result.operationId } : {}),
        requestIdempotencyKey: result.idempotencyKey,
      },
      resultInjection: context,
    }
    if (response.degraded) metrics.inject_degraded++
    taskTurnGuards.register(reqObj, operationTurnGuardPolicy(result), admissionActivation)
    sendHookOutput(responseWriter, 200, formatter.formatInject(response, raw))
    return true
  }

  const server = http.createServer((req, res) => {
    // 顶层 try/catch:任何意外都不能崩 server
    handle(req, res).catch((err) => {
      try {
        const tooLarge = err instanceof PayloadTooLargeError
        sendJson(res, tooLarge ? 413 : 500, {
          error: tooLarge ? "payload_too_large" : "internal",
          message: String(err?.message ?? err),
        })
      } catch {
        /* response 已发出,忽略 */
      }
    })
  })
  server.requestTimeout = TASK_CAPABILITY_EXECUTE_TIMEOUT_MS
  return server

  async function handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const url = req.url ?? "/"
    const method = req.method ?? "GET"
    // path 去掉 query string，用于路由匹配（url 仍保留完整串，供 URLSearchParams 解析）
    const path = url.split("?")[0]

    // ── GET /health(存活探针,不泄漏敏感信息;不需要鉴权即可探活) ──
    if (method === "GET" && url === "/health") {
      sendJson(res, 200, {
        ok: true,
        pid: process.pid,
        started_at: startedAt,
        version: getRuntimeVersion(),
        metrics,
      })
      return
    }

    // ── 鉴权(信任边界:所有 verb 端点强制) ──
    const auth = authenticate(req, deps.auth)
    if (!auth.ok) {
      metrics.auth_rejected++
      sendJson(res, 401, { error: "unauthorized", reason: auth.reason })
      return
    }

    // ── Agent capability broker：所有客户端共享同一 typed 执行面。──
    if (method === "GET" && path === "/agent/capabilities") {
      const params = new URL(url, "http://127.0.0.1").searchParams
      const productionId = params.get("productionId")?.trim() || undefined
      const publicId = params.get("publicId")?.trim() || undefined
      const taskOnly = params.get("taskOnly") === "1"
      if (taskOnly && !productionId && !publicId) {
        sendJson(res, 400, { ok: false, reason: "invalid_input", message: "task-only describe requires productionId or publicId" })
        return
      }
      if (taskOnly) {
        const result = await agentBroker.describeTask({ productionId, publicId })
        if (!result.ok) {
          sendJson(res, brainResultStatus(result), result)
          return
        }
        sendJson(res, 200, { taskCatalogue: result.catalogue })
        return
      }
      const result = await agentBroker.describe({ productionId, publicId })
      if (!result.ok) {
        sendJson(res, brainResultStatus(result), result)
        return
      }
      sendJson(res, 200, result.catalogue)
      return
    }
    if (method === "POST" && path === "/agent/execute") {
      const contentLength = Number(req.headers["content-length"])
      if (Number.isFinite(contentLength) && contentLength > AGENT_JSON_BRIDGE_MAX_BYTES) {
        req.resume()
        sendJson(res, 413, agentJsonPayloadTooLarge(AGENT_JSON_BRIDGE_MAX_BYTES))
        return
      }
      let bodyText: string
      try {
        bodyText = await readBody(req, AGENT_JSON_BRIDGE_MAX_BYTES)
      } catch (error) {
        if (!(error instanceof PayloadTooLargeError)) throw error
        sendJson(res, 413, agentJsonPayloadTooLarge(error.maxBytes))
        return
      }
      const requestUrl = new URL(url, "http://127.0.0.1")
      if (requestUrl.searchParams.has("turnToken")) {
        sendJson(res, 400, {
          ok: false,
          reason: "validation_error",
          message: `turn token must be sent in ${SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER}`,
        })
        return
      }
      let body: unknown
      try {
        body = JSON.parse(bodyText)
      } catch {
        sendJson(res, 400, { ok: false, reason: "validation_error", message: "request body must be valid JSON" })
        return
      }
      const rawRouteToken = req.headers[SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER]
      const routeToken = typeof rawRouteToken === "string" ? rawRouteToken.trim() : undefined
      if (rawRouteToken !== undefined && !routeToken) {
        sendJson(res, 403, { ok: false, reason: "turn_scope_denied", message: "Capability turn token header is invalid" })
        return
      }
      const rawExecutionScope = req.headers[SYNAPSE_CAPABILITY_EXECUTION_SCOPE_HEADER]
      const executionScope = typeof rawExecutionScope === "string" ? rawExecutionScope.trim() : undefined
      if (rawExecutionScope !== undefined && executionScope !== SYNAPSE_STANDALONE_EXECUTION_SCOPE) {
        sendJson(res, 403, { ok: false, reason: "turn_scope_denied", message: "Capability execution scope is invalid" })
        return
      }
      if (routeToken && executionScope) {
        sendJson(res, 400, { ok: false, reason: "validation_error", message: "standalone execution scope cannot be combined with a turn token" })
        return
      }
      const requestClient = clientFromHeader(req).trim() || undefined
      // /agent/execute must always pass through the turn guard, including the
      // real CLI shape where the optional client header is absent. When the
      // header is present, bind it to every authorization check (including the
      // attachment re-check) instead of allowing a later check to lose it.
      const executionGuards: TaskTurnGuardRegistry = requestClient
        ? {
            ...taskTurnGuards,
            authorizeExecution: (token, value, _expectedClient, scope) => (
              taskTurnGuards.authorizeExecution(token, value, requestClient, scope)
            ),
          }
        : taskTurnGuards
      const routed = await authorizeCapabilityRouteExecution(
        executionGuards,
        agentAttachmentIntake,
        routeToken,
        body,
        executionScope === SYNAPSE_STANDALONE_EXECUTION_SCOPE ? SYNAPSE_STANDALONE_EXECUTION_SCOPE : undefined,
      )
      if (!routed.ok) {
        sendJson(res, routed.status, { ok: false, reason: routed.reason, message: routed.message })
        return
      }
      const routeAuthorization = routed.authorization
      const authorizedBody = routeAuthorization.request ?? body
      const executed = await agentBroker.execute(authorizedBody as Parameters<AgentCapabilityBroker["execute"]>[0])
      const result = await settleCapabilityRouteExecution({
        broker: agentBroker,
        confirmationIntake: knowledgeConfirmationIntake,
        guards: taskTurnGuards,
        routeToken,
        authorization: routeAuthorization,
        request: authorizedBody,
        result: executed,
      })
      if (!result.ok) {
        sendJson(res, brainResultStatus(result), result)
        return
      }
      sendJson(res, 200, result.response)
      return
    }
    // ── Phase 6: 知识库主动读写路由（canonical-verb 纪律：method+名词路径，无动词路径段）──
    //
    // 路由对应 cerebro 最终 REST 契约（Phase 5 重命名后）:
    //   POST   /knowledge/search    → searchKnowledge
    //   GET    /knowledge/recent    → listRecent
    //   POST   /knowledge           → addKnowledge
    //   PUT    /knowledge/:id       → updateKnowledge
    //   POST   /knowledge/:id/deprecate → flagOutdated
    //   destructive legacy routes return 410; only /agent/execute may mutate them
    //   GET    /working-memory              → getWorkingMemory
    //   POST   /working-memory              → updateWorkingMemory
    //   PUT    /preferences         → updateUserPreference
    //   GET    /context             → getContext
    //
    // 每个路由直连 REST，不经 inject 层；确定的主脑 4xx 原样保留，其他失败返回 502。

    if (path.startsWith("/knowledge") || path.startsWith("/working-memory") || path.startsWith("/preferences") || path.startsWith("/context")) {
      const bodyText = method !== "GET" ? await readBody(req) : ""
      let body: Record<string, unknown> = {}
      try { body = bodyText ? JSON.parse(bodyText) : {} } catch { body = {} }

      const {
        searchKnowledge, listRecent, getKnowledge, addKnowledge, updateKnowledge,
        flagOutdated,
        getWorkingMemory, updateWorkingMemory, updateUserPreference, getContext,
        resolveKnowledgeIntent, getKnowledgeIntent, sedimentInsight,
      } = await import("../transport/brain-contract-align.ts")

      // POST /knowledge/intents:server-owned resolver+execute+ledger passthrough.
      if (method === "POST" && path === "/knowledge/intents") {
        const r = await resolveKnowledgeIntent(body as unknown as Parameters<typeof resolveKnowledgeIntent>[0])
        sendJson(res, brainResultStatus(r), r); return
      }
      // GET /knowledge/intents/:id:ledger read passthrough.
      if (method === "GET" && path.startsWith("/knowledge/intents/")) {
        const id = decodeURIComponent(path.slice("/knowledge/intents/".length))
        const r = await getKnowledgeIntent(id)
        sendJson(res, brainResultStatus(r), r); return
      }
      // POST /knowledge/sediment (explicit CLI remember; automatic report path stays in report handler)
      if (method === "POST" && path === "/knowledge/sediment") {
        const r = await sedimentInsight(
          String(body["insight"] ?? ""),
          typeof body["category"] === "string" ? body["category"] : undefined,
          typeof body["cwd"] === "string" ? body["cwd"] : undefined,
          typeof body["machineId"] === "string" ? body["machineId"] : undefined,
          "explicit",
        )
        sendJson(res, brainResultStatus(r), r); return
      }
      // POST /knowledge/search (名词子资源 + POST，与 cerebro 契约一致)
      if (method === "POST" && path === "/knowledge/search") {
        const query = String(body["query"] ?? "").trim()
        const limit = typeof body["limit"] === "number" ? body["limit"] : 5
        const r = await searchKnowledge(query, limit)
        sendJson(res, brainResultStatus(r), r); return
      }
      // GET /knowledge/recent[?days=&limit=]
      if (method === "GET" && path === "/knowledge/recent") {
        const qs = new URLSearchParams(url.split("?")[1] ?? "")
        const r = await listRecent(Number(qs.get("days") ?? 7), Number(qs.get("limit") ?? 10))
        sendJson(res, brainResultStatus(r), r); return
      }
      // GET /knowledge/:id (exact full entry read)
      if (method === "GET" && path.startsWith("/knowledge/") && !path.startsWith("/knowledge/intents/")) {
        const id = decodeURIComponent(path.slice("/knowledge/".length))
        const r = await getKnowledge(id)
        sendJson(res, brainResultStatus(r), r); return
      }
      // POST /knowledge  (add)
      if (method === "POST" && path === "/knowledge") {
        const r = await addKnowledge(body as Parameters<typeof addKnowledge>[0])
        sendJson(res, brainResultStatus(r), r); return
      }
      // PUT /knowledge/:id  (update)
      if (method === "PUT" && path.startsWith("/knowledge/") && !path.includes("/deprecate") && !path.includes("/promote") && !path.includes("/demote")) {
        const id = decodeURIComponent(path.slice("/knowledge/".length))
        const r = await updateKnowledge(id, body as Parameters<typeof updateKnowledge>[1])
        sendJson(res, brainResultStatus(r), r); return
      }
      // POST /knowledge/:id/deprecate  (flag)
      if (method === "POST" && path.match(/^\/knowledge\/[^/]+\/deprecate$/)) {
        const id = decodeURIComponent(path.slice("/knowledge/".length, path.lastIndexOf("/deprecate")))
        const r = await flagOutdated(id, String(body["reason"] ?? "过时"))
        sendJson(res, brainResultStatus(r), r); return
      }
      // DELETE /knowledge/:id  (delete)
      if (method === "DELETE" && path.startsWith("/knowledge/") && !path.includes("/deprecate") && !path.includes("/promote") && !path.includes("/demote")) {
        sendJson(res, 410, destructiveRouteDisabled("delete_knowledge")); return
      }
      // POST /knowledge/:id/promote
      if (method === "POST" && path.match(/^\/knowledge\/[^/]+\/promote$/)) {
        sendJson(res, 410, destructiveRouteDisabled("promote_knowledge")); return
      }
      // POST /knowledge/:id/demote
      if (method === "POST" && path.match(/^\/knowledge\/[^/]+\/demote$/)) {
        sendJson(res, 410, destructiveRouteDisabled("demote_knowledge")); return
      }
      // GET /working-memory[?section=]
      if (method === "GET" && path === "/working-memory") {
        const qs = new URLSearchParams(url.split("?")[1] ?? "")
        const r = await getWorkingMemory(qs.get("section") ?? undefined)
        sendJson(res, brainResultStatus(r), r); return
      }
      // POST /working-memory
      if (method === "POST" && path === "/working-memory") {
        const r = await updateWorkingMemory(
          String(body["section"] ?? "in_progress"),
          (body["items"] as Array<{ content: string; priority?: number }>) ?? [],
          Boolean(body["replace"] ?? false),
        )
        sendJson(res, brainResultStatus(r), r); return
      }
      // PUT /preferences (matches cerebro PUT /me/preferences)
      if (method === "PUT" && path === "/preferences") {
        const r = await updateUserPreference(
          String(body["key"] ?? ""), String(body["value"] ?? ""),
          (body["action"] as "set" | "delete") ?? "set",
        )
        sendJson(res, brainResultStatus(r), r); return
      }
      // GET /context
      if (method === "GET" && path === "/context") {
        const r = await getContext()
        sendJson(res, brainResultStatus(r), r); return
      }
    }

    if (method !== "POST") {
      sendJson(res, 405, { error: "method_not_allowed" })
      return
    }

    // ── client 识别 + parser 选择 ──
    const clientId = clientFromHeader(req)
    const parser = getParser(clientId)
    if (!parser) {
      metrics.unmapped_client++
      sendJson(res, 400, { error: "unknown_client", client: clientId })
      return
    }
    // 出站格式化器:把 canonical 响应翻译成该 client 的 hook 契约(见 core/formatters/)。
    const formatter = getFormatter(clientId)

    const bodyText = await readBody(
      req,
      url === "/inject" && clientId === "kimi-code"
        ? INLINE_IMAGE_HOOK_BODY_LIMIT_BYTES
        : DEFAULT_BODY_LIMIT_BYTES,
    )
    let raw: unknown = {}
    try {
      raw = bodyText ? JSON.parse(bodyText) : {}
    } catch {
      // hook 载荷不是合法 JSON:inject 降级(不阻断),report 也宽容处理
      raw = {}
    }

    if (url === "/inject") {
      metrics.inject_total++
      // Gemini emits BeforeModel callbacks for loop recovery and tool
      // continuations. Only callbacks positively identified by the client
      // parser are skipped; an empty real user prompt is still a new turn.
      if (parser.isInternalInject?.(raw)) {
        sendHookOutput(res, 200, formatter.formatInject({ context: "", degraded: false }, raw))
        return
      }
      const reqObj = parser.parseInject(raw)
      reportTurnTracker.register(reqObj)
      const unifiedActivation = unifiedOperationTurn
        ? taskTurnGuards.beginTurn(reqObj)
        : undefined
      if (await tryUnifiedOperationTurn(reqObj, raw, formatter, res, unifiedActivation)) return
      // UserPromptSubmit/BeforeAgent is the earliest reliable turn boundary.
      // Revoke the prior turn before any asynchronous control lookup can race it.
      const taskTurnActivation = taskTurnGuards.beginTurn(reqObj)
      const knowledgeConfirmationAction = isKnowledgeConfirmationActionText(reqObj.user_input)
      const taskIntent = detectTaskCapabilityIntent(reqObj.user_input)
      const writeAuthorized = hasWorkItemWriteAuthorizationIntent(reqObj.user_input)
      const deterministicTaskReadPlan = !writeAuthorized
        ? resolveDeterministicTaskReadPlan(reqObj.user_input)
        : undefined
      const effectiveTaskRequested = taskIntent.requested || Boolean(deterministicTaskReadPlan)
      const knowledgeIntent = detectKnowledgeCapabilityIntentText(reqObj.user_input)
      const knowledgeRequested = !knowledgeConfirmationAction && !effectiveTaskRequested && knowledgeIntent.requested
      const workItemDiagnosticRequested = !knowledgeConfirmationAction && !effectiveTaskRequested && !knowledgeRequested
        && hasLocalWorkItemDiagnosticIntentText(reqObj.user_input)
      const knowledgeDiagnosticRequested = !knowledgeConfirmationAction && !effectiveTaskRequested && !knowledgeRequested
        && hasLocalKnowledgeDiagnosticIntentText(reqObj.user_input)
      const localDiagnosticRequested = workItemDiagnosticRequested || knowledgeDiagnosticRequested
      const knowledgeBoundArgsByCapability = knowledgeRequested
        ? extractExplicitKnowledgeCapabilityArgsByName(reqObj.user_input, knowledgeIntent.capabilities)
        : {}
      if (effectiveTaskRequested) {
        // Register before the first await. If the inject hook times out while
        // Task scope/catalogue is loading, PreToolUse must remain fail-closed
        // instead of observing an active turn with no policy yet.
        taskTurnGuards.register(reqObj, {
          mode: "answer_only",
          reason: "本轮 Task 控制仍在加载；不得先调用本地、外部协议、浏览器或桌面 UI 工具。请等待 Synapse typed Task 路由。",
        }, taskTurnActivation)
      } else if (knowledgeRequested) {
        taskTurnGuards.register(reqObj, {
          mode: "answer_only",
          reason: "本轮 Knowledge 控制仍在加载；不得先调用本地、外部协议、浏览器或桌面 UI 工具。请等待 Synapse typed Knowledge 路由。",
        }, taskTurnActivation)
      } else if (localDiagnosticRequested) {
        taskTurnGuards.register(reqObj, {
          mode: "local_diagnostic",
          reason: "本轮只允许在本地仓库中诊断、修改和测试业务能力实现；不得调用 Cerebro/Synapse capability、外部协议、浏览器或桌面 UI。",
        }, taskTurnActivation)
      } else {
        taskTurnGuards.register(reqObj, {
          mode: "ordinary",
          reason: "普通回合没有获得 Cerebro capability 授权。",
        }, taskTurnActivation)
      }
      const knowledgeConfirmationContext = deps.onInject
        ? undefined
        : await knowledgeConfirmationIntake.handleTurn(reqObj, (request) => agentBroker.execute(request))
      const receiptActionRequested = looksLikeWorkItemContextReceiptAction(reqObj.user_input)
      const continuationIntent = parseWorkItemContextReceiptContinuationIntent(reqObj.user_input)
      const resolvedContinuation = continuationIntent
        ? taskCapabilityDraftIntake.resolveContextReceiptContinuation?.(reqObj, continuationIntent)
        : undefined
      const receiptAction = parseWorkItemContextReceiptAction(reqObj.user_input)
        ?? (resolvedContinuation && !("error" in resolvedContinuation) ? resolvedContinuation : undefined)
      const receiptContinuationWriteAuthorized = hasReceiptContinuationWriteAuthorization(reqObj.user_input)
      const receiptActionContext: SplitSupportContext | undefined = deps.onInject || !receiptActionRequested
        ? continuationIntent && resolvedContinuation
          ? "error" in resolvedContinuation
            ? { trusted: `[Synapse] ${resolvedContinuation.error}`, untrusted: "" }
            : await executeWorkItemContextReceiptAction(
                resolvedContinuation,
                reqObj.client,
                receiptContinuationWriteAuthorized,
                workItemContextReceiptPort,
                taskCapabilityDraftIntake,
              )
          : undefined
        : receiptAction
          ? await executeWorkItemContextReceiptAction(
              receiptAction,
              reqObj.client,
              receiptContinuationWriteAuthorized,
              workItemContextReceiptPort,
              taskCapabilityDraftIntake,
            )
          : {
              trusted: "[Synapse] 这次上下文继续操作的信息不完整。请在同一会话里说明要忽略哪张单缺失的文档或评论；如果要临时补充，请直接说明缺失的业务内容。不要要求用户提供回执、缺失项键或其他内部标识。",
              untrusted: "",
            }
      let taskTurnGuardPolicy: TaskTurnGuardPolicy | undefined
      let knowledgeTurnGuardPolicy: TaskTurnGuardPolicy | undefined
      const writeTargets = resolveExplicitWorkItemWriteTargets(reqObj.user_input, taskIntent.publicIds)
      const writeIntent = hasWorkItemWriteIntent(reqObj.user_input)
      const localArtifactOnly = taskIntent.publicIds.length > 0
        && hasLocalArtifactOnlyIntentText(reqObj.user_input)
        && !writeIntent
      const localImplementationOnly = !localArtifactOnly && taskIntent.publicIds.length > 0
        && hasLocalImplementationIntentText(reqObj.user_input)
        && !writeIntent
      const localRepositoryOnly = localArtifactOnly || localImplementationOnly
      const createIntentKind = resolveWorkItemCreateIntentKind(reqObj.user_input)
      const ambiguousWorkItemWriteScope = taskIntent.publicIds.length > 1 && !writeTargets.explicit
      const writeTargetError = ambiguousWorkItemWriteScope && writeAuthorized
        ? `[Synapse] work_item_write_target_required=${JSON.stringify({ message: "本轮包含多个需求/Bug单号；一次写入只能选择一个具体单号。请拆分并明确本次写入目标。", publicIds: taskIntent.publicIds })}`
        : ""
      const createKindError = createIntentKind === "ambiguous"
        ? `[Synapse] work_item_create_kind_required=${JSON.stringify({ message: "本轮要求创建工作项，但未能唯一确定是需求还是 Bug；请先向用户确认类型。" })}`
        : ""
      const continueWithReceiptTaskRoute = Boolean(
        receiptContinuationWriteAuthorized
          && effectiveTaskRequested
          && receiptActionContext?.taskRequest,
      )
      const genericOperationOwned = taskCapabilityDraftIntake.ownsAction?.(reqObj.user_input) === true
      const taskDraftContext = deps.onInject || receiptActionContext || localDiagnosticRequested || !genericOperationOwned
        ? undefined
        : await taskCapabilityDraftIntake.maybeHandle(reqObj)
      const legacyRequirementContext = deps.onInject || localDiagnosticRequested || taskDraftContext || !isRequirementOperationAction(reqObj.user_input)
        || requirementIntake.ownsSession?.(reqObj) !== true
        ? undefined
        : await requirementIntake.maybeHandle(reqObj)
      const legacyBugContext = deps.onInject || localDiagnosticRequested || taskDraftContext || legacyRequirementContext
        || !isBugOperationAction(reqObj.user_input) || bugIntake.ownsSession?.(reqObj) !== true
        ? undefined
        : await bugIntake.maybeHandle(reqObj)
      const missingOperationContext = deps.onInject || localDiagnosticRequested || taskDraftContext || legacyRequirementContext || legacyBugContext
        || !(isRequirementOperationAction(reqObj.user_input) || isBugOperationAction(reqObj.user_input))
        ? undefined
        : await taskCapabilityDraftIntake.maybeHandle(reqObj)
      const requirementContext = deps.onInject || localDiagnosticRequested || taskDraftContext || legacyRequirementContext || legacyBugContext || missingOperationContext || effectiveTaskRequested
        || requirementIntake.ownsSession?.(reqObj) !== true
        ? undefined
        : await requirementIntake.maybeHandle(reqObj)
      const bugContext = deps.onInject || localDiagnosticRequested || taskDraftContext || legacyRequirementContext || legacyBugContext || missingOperationContext || requirementContext || effectiveTaskRequested
        || bugIntake.ownsSession?.(reqObj) !== true
        ? undefined
        : await bugIntake.maybeHandle(reqObj)
      const supportContext = taskDraftContext ?? legacyRequirementContext ?? legacyBugContext ?? missingOperationContext ?? requirementContext ?? bugContext
      const localDiagnosticContext = localDiagnosticRequested
        ? `[Synapse] local_diagnostic_scope=${JSON.stringify({
            domains: [workItemDiagnosticRequested ? "work_item" : "", knowledgeDiagnosticRequested ? "knowledge" : ""].filter(Boolean),
            message: "仅在当前本地仓库中诊断、修改和测试对应业务能力；禁止调用 Cerebro/Synapse capability、外部协议、浏览器、桌面客户端或 UI 自动化。",
          })}\n\n[Synapse control]\nLocal-diagnostic turn: inspect, edit, and test the local repository as needed. Do not invoke Cerebro or Synapse capabilities, external protocols, browser/desktop UI, or UI automation.`
        : ""
      const result = knowledgeConfirmationContext
        ? {
            context: knowledgeConfirmationContext,
            trustedContext: knowledgeConfirmationContext,
            untrustedContext: "",
            degraded: false,
          }
        : receiptActionContext && !continueWithReceiptTaskRoute
        ? {
            context: [receiptActionContext.untrusted, receiptActionContext.trusted].filter(Boolean).join("\n\n"),
            trustedContext: receiptActionContext.trusted,
            untrustedContext: receiptActionContext.untrusted,
            degraded: false,
          }
        : supportContext
        ? { context: supportContext, trustedContext: supportContext, untrustedContext: "", degraded: false }
        : localDiagnosticRequested
        ? { context: localDiagnosticContext, trustedContext: localDiagnosticContext, untrustedContext: "", degraded: false }
        : deps.onInject
        ? await injectFn(reqObj)
        : await handleInject(reqObj, {
            taskIntent: effectiveTaskRequested,
            knowledgeIntent: knowledgeRequested,
            agentControlContext: async (request, signal) => {
              if (knowledgeRequested) {
                const described = await agentBroker.describe()
                signal?.throwIfAborted()
                if (!described.ok) {
                  throw new Error(`knowledge capability catalogue unavailable: ${described.reason}`)
                }
                const scopedCatalogue = scopeKnowledgeCatalogueForCapabilities(
                  described.catalogue,
                  knowledgeIntent.capabilities,
                )
                if (scopedCatalogue.availableCapabilities.length === 0) {
                  throw new Error("requested Knowledge capabilities are unavailable for the authenticated actor")
                }
                const launcher = resolveAgentLauncher(request.client)
                if (!launcher) throw new Error("Synapse agent launcher is unavailable")
                const routeToken = randomUUID()
                const turnId = resolveAgentControlTurnId(request)
                const context = renderAgentControlContext(
                  scopedCatalogue,
                  request,
                  launcher,
                  (observation) => {
                    metrics.agent_control_context_bytes = observation.bytes
                    metrics.agent_control_context_estimated_tokens = observation.estimatedTokens
                    metrics.agent_control_context_mode = observation.mode
                    if (observation.compactFallback) metrics.agent_control_context_compact_fallback_total++
                  },
                  {
                    knowledgeRouteToken: routeToken,
                    knowledgeBoundArgsByCapability,
                  },
                )
                const route: KnowledgeTurnRoutePolicy = {
                  kind: "knowledge",
                  launcher,
                  routeToken,
                  protocolVersion: scopedCatalogue.protocolVersion,
                  client: request.client,
                  sessionId: request.session_id,
                  turnId,
                  allowedCommands: scopedCatalogue.availableCapabilities,
                  completionCommands: scopedCatalogue.availableCapabilities,
                  boundArgsByCapability: knowledgeBoundArgsByCapability,
                  answerOnlyAfterCompletion: true,
                }
                knowledgeTurnGuardPolicy = {
                  mode: "knowledge_required",
                  reason: "本轮已解析到 scoped Knowledge capability，首个业务工具必须走 Synapse typed Knowledge。",
                  route,
                }
                return context
              }
              const cataloguePublicId = writeTargets.explicit && taskIntent.publicIds.length > 1
                ? writeTargets.targets[0]
                : !taskIntent.multipleProducts
                  ? taskIntent.publicIds[0]
                  : undefined
              const needsTaskCatalogue = effectiveTaskRequested && !localRepositoryOnly
              const scopedTaskCataloguePromise = needsTaskCatalogue && cataloguePublicId
                ? agentBroker.describeTask({ publicId: cataloguePublicId }, signal)
                : null
              const workItemContextPromise = taskIntent.publicIds.length > 0
                ? loadWorkItemContexts({
                    publicIds: taskIntent.publicIds,
                    taskGoal: request.user_input,
                    mode: requestsAllWorkItemContext(request.user_input) ? "all" : "selective",
                    signal,
                  }, workItemContextLoaderPort).catch((error) => {
                    if (signal?.aborted) throw signal.reason ?? error
                    return undefined
                  })
                : Promise.resolve(undefined)
              const workspacePromise = resolveRepoContext(request.cwd, readMachineId({ env: serverEnv }), serverEnv, signal)
              const visibleProductionsPromise = needsTaskCatalogue
                ? fetchVisibleProductions(serverEnv, signal).then((productions) => ({ productions, failed: false })).catch((error) => {
                    if (signal?.aborted) throw signal.reason ?? error
                    return { productions: [], failed: true }
                  })
                : Promise.resolve({ productions: [], failed: false })
              const [loadedWorkItemContext, workspace, visibleProductionResult, scopedTaskCatalogue] = await Promise.all([
                workItemContextPromise,
                workspacePromise,
                visibleProductionsPromise,
                scopedTaskCataloguePromise ?? Promise.resolve(null),
              ])
              const visibleProductions = visibleProductionResult.productions
              const workItemContext = loadedWorkItemContext
                ? {
                    trusted: formatWorkItemContextControl(loadedWorkItemContext),
                    untrusted: formatWorkItemContextEvidence(loadedWorkItemContext),
                  }
                : taskIntent.publicIds.length > 0
                  ? {
                      trusted: "[Synapse] work_item_context_error=工作项上下文加载失败，请稍后重试；不得假设已读取完整上下文。",
                      untrusted: "",
                    }
                  : { trusted: "", untrusted: "" }
              signal?.throwIfAborted()
              const workspaceKey = `${request.client}\n${request.session_id}\n${request.cwd ?? ""}`
              const needsWorkspaceContext = !workspaceContextsInjected.has(workspaceKey)
              const selection = needsTaskCatalogue
                ? selectTaskProductionFromText(request.user_input, visibleProductions)
                : { explicit: false, ambiguous: false }
              const scope = resolveTaskProductionScope(
                taskIntent.publicIds.length > 0 ? undefined : workspace?.productionId,
                selection,
              )
              if (visibleProductionResult.failed
                && (selection.explicit || (taskIntent.publicIds.length === 0 && !workspace?.productionId))) {
                throw new Error("visible product catalogue unavailable for task scope resolution")
              }
              const productionId = scope.productionId
              const described = needsTaskCatalogue
                ? scopedTaskCatalogue
                  ? scopedTaskCatalogue
                  : productionId
                    ? await agentBroker.describeTask({ productionId }, signal)
                    : null
                : null
              signal?.throwIfAborted()
              if (effectiveTaskRequested && described && !described.ok) {
                throw new Error(`task capability catalogue unavailable: ${described.reason}`)
              }
              const workspaceContext = needsWorkspaceContext && workspace?.productionName && workspace.repoName
                ? `[当前工作区] 产品线：${workspace.productionName}；仓库：${workspace.repoName}`
                : ""
              if (workspaceContext) workspaceContextsInjected.add(workspaceKey)
              const describedProductionId = described?.ok
                ? described.catalogue.productionId
                : undefined
              const publicIdProductConflict = Boolean(taskIntent.publicIds.length > 0
                && selection.explicit && selection.product && describedProductionId
                && selection.product.id !== describedProductionId)
              const explicitProductUnresolved = selection.explicit && (!selection.product || selection.ambiguous)
              const taskScopeBlocked = publicIdProductConflict || scope.conflict || explicitProductUnresolved
              const crossProductReadOnly = taskIntent.multipleProducts && !writeAuthorized && !localRepositoryOnly
              const localContextBlocked = localRepositoryOnly && loadedWorkItemContext?.blocked !== false
              const taskScopeError = publicIdProductConflict
                  ? `[Synapse] task_scope_error=${JSON.stringify({ message: "明确指定的产品与工作项 ID 所属产品不一致，未执行需求或 Bug 操作", requestedProduct: selection.product, workItemProductionId: describedProductionId })}`
                : scope.conflict
                  ? `[Synapse] task_scope_error=${JSON.stringify({ message: "明确指定的产品与当前仓库产品不一致，未执行需求或 Bug 操作", workspaceProduct: { id: workspace?.productionId, name: workspace?.productionName }, requestedProduct: selection.product })}`
                : taskIntent.publicIds.length > 0 && explicitProductUnresolved
                  ? `[Synapse] task_scope_error=${JSON.stringify({ message: selection.ambiguous ? "明确指定的产品匹配不唯一，未执行需求或 Bug 操作" : "明确指定的产品不存在，未执行需求或 Bug 操作", products: visibleProductions.map(({ id, name, workItemKey }) => ({ id, name, workItemKey })) })}`
                : localContextBlocked
                  ? `[Synapse] task_scope_local_context_blocked=${JSON.stringify({ message: "工作项上下文未完整加载，本轮不得读取、编辑或测试仓库；请直接说明加载失败并让用户重试。", publicIds: taskIntent.publicIds })}`
                : localArtifactOnly
                  ? `[Synapse] task_scope_local_artifact=${JSON.stringify({ message: "本轮只生成明确要求的本地文件。请使用已注入的工作项上下文写入该文件；不得探索仓库、执行 Task、调用外部协议或操作浏览器/桌面 UI。", publicIds: taskIntent.publicIds })}`
                : localImplementationOnly
                  ? `[Synapse] task_scope_local_implementation=${JSON.stringify({ message: "本轮使用已注入的工作项上下文完成本地仓库实现。可以检查、编辑并测试仓库；不得执行 Task、调用外部协议或操作浏览器/桌面 UI。", publicIds: taskIntent.publicIds })}`
                : crossProductReadOnly
                  ? `[Synapse] task_scope_read_only=${JSON.stringify({ message: "本轮是跨产品只读比较。请直接使用已注入的工作项上下文回答；无需选择单一产品，不得执行 Task、浏览器、桌面客户端或 UI 自动化。", publicIds: taskIntent.publicIds })}`
                : effectiveTaskRequested && taskIntent.publicIds.length === 0 && !productionId
                  ? `[Synapse] task_scope_required=${JSON.stringify({ message: selection.explicit ? "指定的产品不存在或匹配不唯一，请重新选择" : "请明确选择要操作的产品", products: visibleProductions.map(({ id, name, workItemKey }) => ({ id, name, workItemKey })) })}`
                  : ""
              const bugInventory = loadedWorkItemContext?.inventories.find((inventory) => inventory.overview?.subjectType === "bug")
              const bugRelationWriteContext = bugInventory?.overview?.relation
                ? {
                    bugId: bugInventory.targetPublicId,
                    relationSetVersion: bugInventory.overview.relation.relationSetVersion,
                    relations: bugInventory.sources.flatMap((source) => source.relationId
                      ? [{ requirementId: source.publicId, relationId: source.relationId }]
                      : []),
                  }
                : undefined
              const workItemDocumentWriteContexts = loadedWorkItemContext?.inventories.flatMap((inventory) => inventory.overview
                ? [{
                    targetPublicId: inventory.targetPublicId,
                    baseContextSnapshotId: inventory.overview.contextSnapshotId,
                    contextVersion: inventory.overview.contextVersion,
                    documents: inventory.documents.map((document) => ({
                      documentId: document.documentId,
                      sourcePublicId: document.sourcePublicId,
                      revision: document.revision,
                      path: document.path,
                      title: document.metadata.title,
                      archivedAt: document.archivedAt,
                    })),
                  }]
                : [])
              const workItemCommentWriteContexts = loadedWorkItemContext?.inventories.flatMap((inventory) => (
                inventory.comments.map((comment) => ({
                  targetPublicId: inventory.targetPublicId,
                  sourcePublicId: comment.sourcePublicId,
                  commentId: comment.commentId,
                  body: comment.body,
                  authorDisplayName: comment.author.displayName,
                  canEdit: comment.capabilities.canEdit,
                  canDelete: comment.capabilities.canDelete,
                }))
              ))
              let taskRoutePolicy: TaskTurnRoutePolicy | undefined
              let taskCreateFastPathCompleted = false
              let taskReadFastPathCompleted = false
              let taskReadFastPathUntrustedContext = ""
              let taskAttachmentBlockedReason: string | undefined
              const brokerContext = described?.ok
                ? (!effectiveTaskRequested || "productionId" in described.catalogue)
                  ? await (async () => {
                    const discoveredTaskCatalogue = effectiveTaskRequested && "productionId" in described.catalogue
                      ? described.catalogue
                      : undefined
                    const standaloneCreate = taskIntent.publicIds.length === 0
                      && (createIntentKind === "requirement" || createIntentKind === "bug")
                    const resolvedTaskReadPlan = deterministicTaskReadPlan
                      ?? (loadedWorkItemContext?.blocked === false
                        ? resolveContextBackedDeterministicTaskReadPlan(request.user_input, taskIntent.publicIds)
                        : undefined)
                    const preferredTaskRead = resolvedTaskReadPlan
                      && discoveredTaskCatalogue?.availableCapabilities.includes(resolvedTaskReadPlan.command)
                      ? resolvedTaskReadPlan
                      : undefined
                    const preferredTaskCommand = standaloneCreate
                      ? createIntentKind === "bug" ? "bug.create" as const : "requirement.create" as const
                      : undefined
                    const simpleCreateIntent = standaloneCreate
                      ? resolveSimpleTaskCreateIntent(request)
                      : undefined
                    const taskCatalogue = discoveredTaskCatalogue
                      ? standaloneCreate
                        ? scopeTaskCatalogueForStandaloneCreate(discoveredTaskCatalogue, createIntentKind, {
                            simple: simpleCreateIntent !== undefined,
                          })
                        : preferredTaskRead
                          ? scopeTaskCatalogueForCapabilities(discoveredTaskCatalogue, [preferredTaskRead.command])
                          : discoveredTaskCatalogue
                      : undefined
                    const taskDraftRequestId = taskTurnDraftRequestId(
                      request,
                      taskCatalogue?.productionId ?? describedProductionId ?? "unscoped",
                    )
                    const receiptTaskRequest = receiptActionContext?.taskRequest
                    const reissuedTaskRequest = receiptTaskRequest?.productionId === taskCatalogue?.productionId
                      ? receiptTaskRequest
                      : undefined
                    const effectiveTaskDraftRequestId = reissuedTaskRequest?.requestId ?? taskDraftRequestId
                    if (taskCatalogue?.productionId && !preferredTaskRead) {
                      if (!reissuedTaskRequest) {
                        taskCapabilityDraftIntake.registerRequest?.(
                          effectiveTaskDraftRequestId,
                          taskCatalogue.productionId,
                          request,
                          {
                          // The request identity may outlive this inject response. Keep every
                          // multi-item scope fail-closed even when natural-language verb detection
                          // classified the current turn as read-only.
                          workItemWritesBlocked: !writeAuthorized || ambiguousWorkItemWriteScope
                            || createIntentKind === "ambiguous" || taskScopeBlocked,
                          ...(writeTargets.explicit && writeTargets.targets[0]
                            ? { workItemWriteTarget: writeTargets.targets[0] }
                            : taskIntent.publicIds.length === 1
                              ? { workItemWriteTarget: taskIntent.publicIds[0] }
                              : {}),
                          ...(loadedWorkItemContext?.contextReceiptId
                            ? { contextReceiptId: loadedWorkItemContext.contextReceiptId }
                            : {}),
                          contextReceiptValidated: loadedWorkItemContext?.blocked === false,
                          blockingContextMissingKeys: loadedWorkItemContext
                            ? loadedWorkItemContext.issues
                                .filter((issue) => issue.missing.blocking && !issue.acknowledged && !issue.supplemented)
                                .map((issue) => ({ targetPublicId: issue.targetPublicId, missingKey: issue.missing.key }))
                            : taskIntent.publicIds.length > 0
                              ? taskIntent.publicIds.map((publicId) => ({
                                  targetPublicId: publicId,
                                  missingKey: `missing:runtime:${publicId}:content_unavailable`,
                                }))
                              : [],
                          },
                        )
                      }
                    }
                    if (taskCatalogue) {
                      if (preferredTaskRead && !taskScopeBlocked) {
                        const fastReadResult = await executeTaskReadFastPath({
                          plan: preferredTaskRead,
                          catalogue: taskCatalogue,
                          broker: agentBroker,
                          signal,
                        })
                        if (fastReadResult) {
                          taskReadFastPathCompleted = true
                          taskReadFastPathUntrustedContext = fastReadResult.untrustedContext
                          return fastReadResult.trustedContext
                        }
                      }
                      const attachmentRequested = hasWorkItemAttachmentIntentText(request.user_input)
                      const attachmentPlan = standaloneCreate && !taskScopeBlocked
                        ? planAgentCreateAttachments(request, createIntentKind, attachmentRequested)
                        : undefined
                      const attachmentHandle = attachmentPlan?.action === "prepare"
                        ? agentAttachmentIntake.register(request, taskCatalogue.productionId, {
                            requireFiles: attachmentPlan.requireFiles,
                            mode: attachmentPlan.mode,
                          })
                        : undefined
                      const attachmentPolicy = attachmentPlan?.action === "prepare"
                        ? attachmentPlan.policy
                        : undefined
                      if (attachmentPlan?.action === "blocked") {
                        taskAttachmentBlockedReason = attachmentPlan.message
                      } else if (attachmentPlan?.action === "prepare" && !attachmentHandle) {
                        taskAttachmentBlockedReason = attachmentPlan.policy === "bug-upload"
                          ? "当前客户端报告或要求携带附件，但 Synapse 无法为本回合建立安全附件来源。"
                          : "当前客户端未能证明本回合没有附件，无法安全创建需求。"
                      }
                      const fastIntent = !taskScopeBlocked && writeAuthorized && !ambiguousWorkItemWriteScope
                          && attachmentPlan?.action === "none"
                        ? resolveTaskCreateFastPath(request)
                        : undefined
                      if (fastIntent) {
                        const productionName = visibleProductions.find((item) => item.id === taskCatalogue.productionId)?.name
                          ?? (workspace?.productionId === taskCatalogue.productionId ? workspace.productionName ?? undefined : undefined)
                        const fastResult = await executeTaskCreateFastPath({
                          requestId: effectiveTaskDraftRequestId,
                          intent: fastIntent,
                          catalogue: taskCatalogue,
                          productionName,
                          broker: agentBroker,
                          signal,
                        })
                        if (fastResult) {
                          taskCreateFastPathCompleted = true
                          return fastResult.trustedContext
                        }
                      }
                      if (taskAttachmentBlockedReason) {
                        return [
                          `[Synapse] task_attachment_error=${taskAttachmentBlockedReason}`,
                          "请告知用户本轮没有生成待确认操作；不得静默丢弃附件，也不得改用浏览器、主脑桌面客户端或 UI 自动化模拟上传。",
                        ].join("\n")
                      }
                      const launcher = resolveAgentLauncher(request.client)
                      if (!launcher) throw new Error("Synapse agent launcher is unavailable")
                      const taskRouteToken = randomUUID()
                      const availableCommands = new Set(taskCatalogue.availableCapabilities)
                      const writeCommands = taskCatalogue.capabilities
                        .filter((entry) => entry.mode === "draft" && availableCommands.has(entry.name))
                        .map((entry) => entry.name)
                      const completionCommands = preferredTaskRead
                        ? [preferredTaskRead.command]
                        : preferredTaskCommand
                        ? [preferredTaskCommand]
                        : writeAuthorized
                          ? writeCommands
                        : taskCatalogue.availableCapabilities
                      const context = renderAgentControlContext(
                        { taskCatalogue },
                        request,
                        launcher,
                        (observation) => {
                          metrics.agent_control_context_bytes = observation.bytes
                          metrics.agent_control_context_estimated_tokens = observation.estimatedTokens
                          metrics.agent_control_context_mode = observation.mode
                          if (observation.compactFallback) metrics.agent_control_context_compact_fallback_total++
                        },
                        {
                          taskDraftRequestId: effectiveTaskDraftRequestId,
                          attachmentHandle,
                          attachmentPolicy,
                          taskRouteToken,
                          taskOnly: true,
                          preferredTaskCommand,
                          preferredTaskRead,
                          bugRelationWriteContext,
                          workItemDocumentWriteContexts,
                          workItemCommentWriteContexts,
                          workItemContextBlocked: loadedWorkItemContext?.blocked,
                          workItemContextInjected: taskIntent.publicIds.length > 0 && loadedWorkItemContext?.blocked === false,
                          ...(simpleCreateIntent ? { preferredTaskInput: { title: simpleCreateIntent.title } } : {}),
                        },
                      )
                      taskRoutePolicy = {
                        launcher,
                        routeToken: taskRouteToken,
                        draftRequestId: effectiveTaskDraftRequestId,
                        protocolVersion: taskCatalogue.protocolVersion,
                        productionId: taskCatalogue.productionId,
                        allowedCommands: taskCatalogue.availableCapabilities,
                        completionCommands,
                        answerOnlyAfterCompletion: Boolean(preferredTaskRead || writeAuthorized),
                        allowCommandDescribe: !preferredTaskRead && !simpleCreateIntent,
                        ...(preferredTaskRead
                          ? { boundInputByCommand: { [preferredTaskRead.command]: preferredTaskRead.input } }
                          : simpleCreateIntent && preferredTaskCommand
                            ? { boundInputByCommand: { [preferredTaskCommand]: { title: simpleCreateIntent.title } } }
                            : {}),
                        ...(attachmentHandle && attachmentPolicy ? { attachmentHandle, attachmentPolicy } : {}),
                      }
                      return context
                    }
                    throw new Error("Task catalogue is unavailable in a Task turn")
                    })()
                  : ""
                : effectiveTaskRequested && !described
                  ? localContextBlocked
                    ? "[Synapse control]\nLocal work-item context is blocked or unavailable. Explain the loading failure and ask the user to retry. Do not inspect, edit, or test the repository, and do not invoke Task, external protocols, browser/desktop UI, or unrelated tools."
                    : localArtifactOnly
                      ? "[Synapse control]\nLocal-artifact turn: use the injected work-item context and the requested write tool to create only the explicit local file. Do not inspect the repository or invoke Task, external protocols, browser/desktop UI, or unrelated tools."
                    : localImplementationOnly
                    ? "[Synapse control]\nLocal-implementation turn: use the injected work-item context, then inspect, edit, and test the local repository as needed. Do not invoke Task, external protocols, browser/desktop UI, or unrelated tools."
                    : crossProductReadOnly
                      ? "[Synapse control]\nCross-product read is answer-only: use the injected work-item context directly. Do not choose one product and do not invoke Task, browser, desktop UI, external protocol, or local tools."
                    : renderAgentControlContext(
                        {},
                        request,
                        undefined,
                        (observation) => {
                          metrics.agent_control_context_bytes = observation.bytes
                          metrics.agent_control_context_estimated_tokens = observation.estimatedTokens
                          metrics.agent_control_context_mode = observation.mode
                          if (observation.compactFallback) metrics.agent_control_context_compact_fallback_total++
                        },
                        { taskOnly: true },
                      )
                  : renderAgentControlDegradedContext(described!)
              if (effectiveTaskRequested) {
                const answerOnlyReason = localContextBlocked
                  ? "本轮工作项上下文未完整加载，请直接说明失败并让用户重试；不得读取、编辑或测试仓库，也不得调用 Task、外部协议、浏览器或桌面 UI。"
                  : crossProductReadOnly
                  ? "本轮是跨产品只读比较，请直接使用已注入上下文回答，不得调用本地、外部协议、浏览器或桌面 UI 工具。"
                  : taskScopeBlocked || !productionId && taskIntent.publicIds.length === 0
                    ? "本轮 Task 产品范围未唯一确定，请直接询问用户选择产品，不得调用本地、外部协议、浏览器或桌面 UI 工具。"
                    : taskAttachmentBlockedReason
                      ? `${taskAttachmentBlockedReason} 不得改用浏览器或桌面 UI。`
                    : (ambiguousWorkItemWriteScope && writeAuthorized) || createIntentKind === "ambiguous"
                      ? "本轮工作项写入目标或类型不唯一，请直接询问用户澄清，不得调用本地、外部协议、浏览器或桌面 UI 工具。"
                      : undefined
                taskTurnGuardPolicy = taskReadFastPathCompleted
                  ? {
                      mode: "answer_only",
                      reason: "Synapse 已完成本轮确定性只读 Task 查询；请直接使用已注入结果回答，不得再次调用工具。",
                    }
                  : taskCreateFastPathCompleted
                  ? {
                      mode: "answer_only",
                      reason: "Synapse 已生成本轮待确认操作；不得再次调用工具或重复生成草稿。",
                    }
                  : answerOnlyReason
                    ? { mode: "answer_only", reason: answerOnlyReason }
                  : localArtifactOnly
                  ? {
                      mode: "local_artifact_only",
                      reason: "本轮只允许基于已注入工作项上下文写入明确要求的本地文件；不得探索仓库或调用 Task、外部协议、浏览器、桌面 UI。",
                    }
                  : localImplementationOnly
                  ? {
                      mode: "local_implementation",
                      reason: "本轮只允许基于已注入工作项上下文检查、编辑和测试本地仓库；不得调用 Task、外部协议、浏览器或桌面 UI。",
                    }
                  : described?.ok && "productionId" in described.catalogue && taskRoutePolicy
                    ? {
                        mode: "task_required",
                        reason: "本轮已解析到可信 Task catalogue，首个业务工具必须走 Synapse typed Task。",
                        route: taskRoutePolicy,
                      }
                    : {
                        mode: "answer_only",
                      reason: "本轮 Task 控制上下文不可用，不得改用本地、外部协议、浏览器或桌面 UI 工具。",
                    }
              }
              const effectiveProductionId = taskIntent.publicIds.length > 0 ? describedProductionId : productionId ?? describedProductionId
              const selectedName = visibleProductions.find((item) => item.id === effectiveProductionId)?.name
                ?? (workspace?.productionId === effectiveProductionId ? workspace?.productionName : undefined)
              const taskProductContext = effectiveTaskRequested && (effectiveProductionId || taskIntent.publicIds.length > 0)
                ? `[Synapse] task_scope=${JSON.stringify({
                    productionId: effectiveProductionId ?? null,
                    productionName: selectedName ?? null,
                    publicIds: taskIntent.publicIds,
                    ...(createIntentKind !== "none" ? { createIntentKind } : {}),
                    writeTargetRequired: ambiguousWorkItemWriteScope && writeAuthorized,
                    writeTarget: writeTargets.explicit ? writeTargets.targets[0] ?? null : null,
                  })}`
                : ""
              return {
                // Keep scope and executable routing at the head. Claude Code
                // previews only the first 2KB when additionalContext spills.
                trusted: [taskScopeError, writeTargetError, createKindError, taskProductContext, receiptActionContext?.trusted, brokerContext, workItemContext.trusted, workspaceContext].filter(Boolean).join("\n\n"),
                untrusted: [taskReadFastPathUntrustedContext, receiptActionContext?.untrusted, workItemContext.untrusted].filter(Boolean).join("\n\n"),
              }
            },
            agentControlFailureContext: effectiveTaskRequested
              ? (_request, reason) => reason === "timeout" && taskIntent.publicIds.length > 0
                ? workItemContextTimeoutContext(taskIntent.publicIds)
                : taskControlFailureContext(reason)
              : knowledgeRequested
                ? (_request, reason) => reason === "timeout"
                  ? "[Synapse] agent_control_timeout=知识操作控制加载超时，本轮不得执行知识操作；不得改用旧 capability、浏览器或主脑桌面客户端。"
                  : "[Synapse] agent_control_error=知识操作控制加载失败，本轮不得执行知识操作；不得改用旧 capability、浏览器或主脑桌面客户端。"
              : undefined,
            onAgentControlFailure: effectiveTaskRequested || knowledgeRequested
              ? (reason) => {
                  if (reason === "timeout") metrics.agent_control_timeout_total++
                  else metrics.agent_control_error_total++
                }
              : undefined,
            agentControlDeadlineMs: taskIntent.publicIds.length > 0
              ? deps.workItemContextDeadlineMs ?? 18_000
              : effectiveTaskRequested
                ? deps.taskControlDeadlineMs ?? 3_000
                : knowledgeRequested
                  ? deps.taskControlDeadlineMs ?? 3_000
                : undefined,
          })
      if (result.degraded) metrics.inject_degraded++
      if (knowledgeConfirmationContext) {
        taskTurnGuards.register(reqObj, {
          mode: "answer_only",
          reason: "Synapse 已处理本轮知识确认或取消；不得调用任何工具或重复执行该操作。",
        }, taskTurnActivation)
      } else if (effectiveTaskRequested) {
        if (reqObj.client === "claude-code" && taskTurnGuardPolicy?.mode === "task_required"
          && taskTurnGuardPolicy.route) {
          taskTurnGuardPolicy.route.injectedContextSha256 = hashTaskInjectedContext(result.context)
        }
        taskTurnGuards.register(reqObj, result.degraded
          ? {
              mode: "answer_only",
              reason: "本轮 Task 控制加载失败或超时，不得改用本地、外部协议、浏览器或桌面 UI 工具。",
            }
          : taskTurnGuardPolicy ?? {
              mode: "answer_only",
              reason: "本轮没有可安全执行的 Task 路由，请直接回答或询问用户，不得调用其他工具。",
            }, taskTurnActivation)
      } else if (knowledgeRequested) {
        if (reqObj.client === "claude-code" && knowledgeTurnGuardPolicy?.mode === "knowledge_required") {
          knowledgeTurnGuardPolicy.route.injectedContextSha256 = hashTaskInjectedContext(result.context)
        }
        taskTurnGuards.register(reqObj, result.degraded
          ? {
              mode: "answer_only",
              reason: "本轮 Knowledge 控制加载失败或超时，不得改用本地、外部协议、浏览器或桌面 UI 工具。",
            }
          : knowledgeTurnGuardPolicy ?? {
              mode: "answer_only",
              reason: "本轮没有可安全执行的 Knowledge 路由，请直接报告控制不可用，不得调用其他工具。",
            }, taskTurnActivation)
      } else if (localDiagnosticRequested) {
        taskTurnGuards.register(reqObj, {
          mode: "local_diagnostic",
          reason: "本轮只允许在本地仓库中诊断、修改和测试业务能力实现；不得调用 Cerebro/Synapse capability、外部协议、浏览器或桌面 UI。",
        }, taskTurnActivation)
      } else {
        taskTurnGuards.register(reqObj, {
          mode: "ordinary",
          reason: "普通回合没有获得 Cerebro capability 授权。",
        }, taskTurnActivation)
      }
      // OpenCode 的 plugin 需要在 /guard 断连时区分普通回合与已受控 Task 回合。
      // 意图分类仍只在 daemon 内完成；plugin 不复制自然语言规则。
      const guardedResult = {
        ...result,
        toolGuardRequired: Boolean(knowledgeConfirmationContext) || effectiveTaskRequested || knowledgeRequested || localDiagnosticRequested,
      }
      // 按 client 契约格式化(CC/codex→additionalContext;opencode→identity)。
      sendHookOutput(res, 200, formatter.formatInject(guardedResult, raw))
      return
    }

    if (url === "/guard") {
      // PreToolUse 硬护栏:判定一条 bash/git 命令是否放行(能挂护栏的客户端才会调)。
      metrics.guard_total++
      const command = extractCommand(raw)
      const cwd =
        typeof (raw as Record<string, unknown>)?.["cwd"] === "string"
          ? ((raw as Record<string, unknown>)["cwd"] as string)
          : undefined
      const g = taskTurnGuards.evaluate(clientId, raw)
        ?? await handleGuard({ client: clientId, command, cwd }, deps.guardDeps)
      if (!g.allow) metrics.guard_denied++
      // deny → hookSpecificOutput.permissionDecision(CC/codex);allow → {}(走正常权限流)。
      sendJson(res, 200, formatter.formatGuard(g))
      return
    }

    if (url === "/report") {
      metrics.report_total++
      const parsedReport = parser.parseReport(raw)
      const admission = reportTurnTracker.admit(parsedReport, raw)
      if (!admission.admitted) {
        sendJson(res, 200, formatter.formatReport({
          done: false,
          sedimented: false,
          synced: false,
          actions: [`report:${admission.reason}`],
        }))
        return
      }
      const reqObj = admission.kind === "tracked"
        ? {
            ...parsedReport,
            session_id: parsedReport.session_id || admission.sessionId || "",
            turn_id: parsedReport.turn_id ?? admission.turnId,
          }
        : parsedReport
      if (admission.countReceived) metrics.report_received++
      const transcriptTurnId = parsedReport.turn_id?.trim() || undefined
      let countSedimentResult = admission.kind === "inline"
      const resolveDoneContract = deps.reportDeps?.resolveDoneContract ??
        ((req: typeof reqObj): unknown =>
          (raw as Record<string, unknown>)?.["done_contract"] ?? loadProjectDoneContract(req.cwd))
      // 一个外部 verb,内部三 handler(verify_done 同步 / judge_sediment / nudge_sync detached)。
      // 运行时按 client 从原始载荷补充 done 契约与回合文本(默认从 raw 里取,测试可覆盖)。
      //
      // done_contract 来自 brain 派发的任务上下文(不在本地 transcript),是 brain 依赖,此处不解析。
      const result = handleReport(reqObj, {
        state: reportState,
        resolveDoneContract,
        resolveTurnText:
          deps.reportDeps?.resolveTurnText ??
          ((req): string | undefined => {
            // 1) 显式 turn_text 字段(测试 / shim 直传)
            const v = (raw as Record<string, unknown>)?.["turn_text"]
            if (typeof v === "string") return v
            // Gemini AfterAgent 官方 payload 直接提供本轮 prompt/response，优先于等待文件刷盘。
            const prompt = (raw as Record<string, unknown>)?.["prompt"]
            const response = (raw as Record<string, unknown>)?.["prompt_response"]
            if (typeof prompt === "string" && typeof response === "string") {
              return `[user] ${prompt}\n\n[assistant] ${response}`
            }
            // 2) 从本地 transcript 文件尾部提取(client + session_id)
            return extractTurnText({
              client: clientId,
              session_id: req.session_id,
              cwd: req.cwd,
              turn_id: transcriptTurnId,
              transcript_path: req.transcript_path,
            }, {
              home: serverEnv["HOME"] ?? serverEnv["USERPROFILE"],
              codexHome: serverEnv["CODEX_HOME"],
              xdgDataHome: serverEnv["XDG_DATA_HOME"],
            })
          }),
        sedimentDeps: deps.reportDeps?.sedimentDeps,
        registerBackground: deps.reportDeps?.registerBackground,
        turnResolveDelaysMs: deps.reportDeps?.turnResolveDelaysMs,
        onTurnResolution: (resolved) => {
          if (admission.kind === "tracked") {
            if (!resolved) return
            if (!reportTurnTracker.complete(reqObj)) return
            countSedimentResult = true
          }
          if (resolved) metrics.turn_resolved++
          else metrics.turn_missing++
          deps.reportDeps?.onTurnResolution?.(resolved)
        },
        onSedimentResult: (sediment) => {
          if (!countSedimentResult) return
          if (sediment.reason === "saved") metrics.sediment_saved++
          else if (sediment.reason === "duplicate") metrics.sediment_duplicate++
          else if (sediment.reason === "save_failed") metrics.sediment_failed++
          else metrics.sediment_rejected++
          deps.reportDeps?.onSedimentResult?.(sediment)
        },
      })
      taskTurnGuards.endTurn(reqObj)
      // report 纯副作用:CC/codex/gemini → {}(不回 additionalContext 免「继续对话」);
      // opencode → identity(plugin 不读 report 返回,identity 无害)。
      sendJson(res, 200, formatter.formatReport(result))
      return
    }

    sendJson(res, 404, { error: "not_found", path: url })
  }

}

function requestsAllWorkItemContext(input: string): boolean {
  const clause = "[^。！？!?;；\\n]{0,128}"
  const read = "(?:加载|读取|查看|看(?:一?下)?|读(?:一?遍)?)"
  const materials = "(?:上下文|资料|文档|评论|留言)"
  return new RegExp(
    `${read}${clause}(?:全部|所有)(?:的)?${materials}|(?:全部|所有)(?:的)?${materials}${clause}${read}|${materials}(?:和${materials})?${clause}都${clause}${read}|load\\s+all`,
    "i",
  ).test(input)
}

function createBrainWorkItemContextLoaderPort(env: NodeJS.ProcessEnv): WorkItemContextLoaderPort {
  return {
    async readPage(input, signal) {
      const result = await readWorkItemContextPage(input, env, signal)
      return result.ok
        ? { ok: true, results: result.value.results }
        : transportLoadFailure(result)
    },
    async readDocuments(input, signal) {
      const result = await readWorkItemContextDocuments(input, env, signal)
      return result.ok
        ? { ok: true, documents: result.value.results }
        : transportLoadFailure(result)
    },
    async createReceipt(input, signal) {
      const result = await createWorkItemContextReceipt(input, env, signal)
      return result.ok
        ? { ok: true, receipt: result.value }
        : transportLoadFailure(result)
    },
    async validateReceipt(input, signal) {
      const result = await validateWorkItemContextReceipt(input, env, signal)
      return result.ok
        ? { ok: true, validation: result.value }
        : transportLoadFailure(result)
    },
  }
}

function workItemContextTimeoutContext(publicIds: readonly string[]): SplitSupportContext {
  const missing = publicIds.map((publicId) => ({
    key: `missing:runtime:${publicId}:timeout`,
    publicId,
    kind: "runtime",
    code: "TIMEOUT",
    blocking: true,
    retryable: true,
    ignorable: false,
    acknowledged: false,
    supplemented: false,
  }))
  const inventories = publicIds.map((targetPublicId) => ({
    targetPublicId,
    complete: false,
    overview: null,
    sources: [],
    documents: [],
    comments: [],
    failure: missing.find((item) => item.publicId === targetPublicId),
  }))
  return {
    trusted: [
      "[Synapse] agent_control_timeout=工作项控制与完整上下文未在时限内加载完成。",
      "[Synapse - Cortex work item context]",
      `requested_public_ids=${JSON.stringify(publicIds)}`,
      "context_receipt_id=unavailable",
      "context_load_status=blocked",
      `complete_inventory_json=${JSON.stringify(inventories)}`,
      `context_missing_json=${JSON.stringify(missing)}`,
      "Do not continue the work item yet. Explain in ordinary language which requested work item could not finish loading and ask the user to retry. Never expose internal keys, receipt IDs, paths, or protocol terms. This runtime failure cannot be ignored or supplemented.",
      taskControlFailClosedInstruction(),
    ].join("\n"),
    untrusted: `[Synapse - Cortex work item context diagnostics]\n${JSON.stringify(publicIds.map((publicId) => ({ publicId, message: "工作项上下文未能在加载时限内完成，完整清单和读取回执均未创建。" })))}`,
  }
}

function taskControlFailureContext(reason: "timeout" | "error"): SplitSupportContext {
  const label = reason === "timeout" ? "agent_control_timeout" : "agent_control_error"
  const message = reason === "timeout" ? "工作项控制加载超时" : "工作项控制加载失败"
  return {
    trusted: [
      `[Synapse] ${label}=${message}，本轮未提供可执行的主脑接口协议。`,
      taskControlFailClosedInstruction(),
    ].join("\n"),
    untrusted: "",
  }
}

function taskControlFailClosedInstruction(): string {
  return "不得使用浏览器、主脑桌面客户端或 UI 自动化模拟人工操作；不得直接访问 Cerebro 数据库或存储。请告知用户主脑任务接口本轮加载失败并重试。"
}

async function executeWorkItemContextReceiptAction(
  action: WorkItemContextReceiptAction,
  sourceClient: InjectRequest["client"],
  writeAuthorized: boolean,
  port: WorkItemContextReceiptPort,
  draftIntake: TaskCapabilityDraftIntake,
): Promise<SplitSupportContext> {
  if (action.kind === "ignore") {
    const result = await port.ignore({
      contextReceiptId: action.contextReceiptId,
      requestId: action.requestId,
      targetPublicId: action.targetPublicId,
      missingKeys: action.missingKeys,
    })
    if (!result.ok) return workItemContextReceiptActionFailure(action, result)
    draftIntake.resolveContextMissing?.(action.contextReceiptId, action.targetPublicId, action.missingKeys)
    draftIntake.recordContextReceiptValidation?.(action.contextReceiptId, false)
    const validation = await port.validate({ contextReceiptId: action.contextReceiptId })
    if (!validation.ok) return workItemContextReceiptPostActionValidationFailure(action.contextReceiptId, validation)
    if (validation.value.status === "refresh_required") return workItemContextReceiptRefreshRequired(action.contextReceiptId, validation.value)
    draftIntake.recordContextReceiptValidation?.(action.contextReceiptId, true)
    const reissued = draftIntake.reissueRequestForContext?.(
      action.contextReceiptId,
      action.targetPublicId,
      sourceClient,
      writeAuthorized,
    )
    return {
      trusted: `[Synapse] 已按用户要求记录对本次缺失资料的知情忽略。对应资料不再阻断本次处理，可以继续；仍不得把它描述为已经读取。不要向用户展示回执、缺失项键或内部标识。${renderReissuedTaskRouteStatus(reissued, writeAuthorized)}`,
      untrusted: "",
      ...(reissued ? { taskRequest: reissued } : {}),
    }
  }
  if (action.kind === "supplement") {
    const renderedSupplement = `[Temporary user supplement for target ${action.targetPublicId} from source ${action.sourcePublicId}]\n${action.content}`
    if (renderedSupplement.length > DEFAULT_CONTEXT_INJECTION_CHARS) {
      return {
        trusted: `[Synapse] 临时补充超过单轮上下文上限 ${DEFAULT_CONTEXT_INJECTION_CHARS} 字符，未记录、未解除缺失项。请缩短补充内容后重试。`,
        untrusted: "",
      }
    }
    const result = await port.supplement({
      contextReceiptId: action.contextReceiptId,
      requestId: action.requestId,
      targetPublicId: action.targetPublicId,
      sourcePublicId: action.sourcePublicId,
      content: action.content,
      replacesMissingKeys: action.replacesMissingKeys,
    })
    if (!result.ok) return workItemContextReceiptActionFailure(action, result)
    draftIntake.resolveContextMissing?.(action.contextReceiptId, action.targetPublicId, action.replacesMissingKeys)
    draftIntake.recordContextReceiptValidation?.(action.contextReceiptId, false)
    const validation = await port.validate({ contextReceiptId: action.contextReceiptId })
    if (!validation.ok) return workItemContextReceiptPostActionValidationFailure(action.contextReceiptId, validation)
    if (validation.value.status === "refresh_required") return workItemContextReceiptRefreshRequired(action.contextReceiptId, validation.value)
    draftIntake.recordContextReceiptValidation?.(action.contextReceiptId, true)
    const reissued = draftIntake.reissueRequestForContext?.(
      action.contextReceiptId,
      action.targetPublicId,
      sourceClient,
      writeAuthorized,
    )
    return {
      trusted: `[Synapse] 已按用户要求记录本次临时补充。对应资料不再阻断本次处理，可以继续；补充内容只对本次处理有效，不是 Cortex 权威工作项内容。不要向用户展示回执、缺失项键、来源标识或内部标识。${renderReissuedTaskRouteStatus(reissued, writeAuthorized)}`,
      untrusted: renderedSupplement,
      ...(reissued ? { taskRequest: reissued } : {}),
    }
  }
  const result = await port.validate({ contextReceiptId: action.contextReceiptId })
  if (!result.ok) {
    draftIntake.recordContextReceiptValidation?.(action.contextReceiptId, false)
    return workItemContextReceiptActionFailure(action, result)
  }
  const validation = result.value
  draftIntake.recordContextReceiptValidation?.(
    action.contextReceiptId,
    validation.status !== "refresh_required",
  )
  return {
    trusted: validation.status === "refresh_required"
      ? `[Synapse] 发布前校验要求刷新。请重新加载${renderAffectedWorkItems(validation.affectedPublicIds)}后再生成或确认写入操作。只用普通业务语言说明，不展示回执、文档或评论内部标识。`
      : "[Synapse] 发布前校验通过。只用普通业务语言继续，不展示回执或其他内部标识。",
    untrusted: "",
  }
}

function renderReissuedTaskRouteStatus(
  value: ReissuedTaskRouteIdentity | undefined,
  writeAuthorized: boolean,
): string {
  if (!writeAuthorized) return ""
  return value
    ? "\n[Synapse] 本轮继续写入只能使用随后注入的、带本轮令牌的统一 Task execute_command。禁止使用旧入口，禁止向用户展示命令、请求标识或任何内部字段。Cortex 工作项是唯一权威来源；写入失败或受阻时必须停止，禁止改写仓库或 Git 文件作为替代。"
    : "\n[Synapse] 本轮无法重新建立可信 Task 路由。停止写入并用普通语言请用户稍后重试；禁止使用浏览器、主脑桌面客户端、UI 自动化、仓库或 Git 文件作为替代。"
}

function hasReceiptContinuationWriteAuthorization(text: string): boolean {
  const hasSeparateContinuation = text.split(/[。！？.!?;；\n]+/).some((clause) => (
    clause.trim().length > 0 && !looksLikeWorkItemContextReceiptAction(clause)
  ))
  return hasSeparateContinuation && hasWorkItemWriteAuthorizationIntent(text)
}

function workItemContextReceiptRefreshRequired(
  _contextReceiptId: string,
  validation: WorkItemContextReceiptValidation,
): SplitSupportContext {
  return {
    trusted: `[Synapse] 上下文缺失处理已记录，但发布前校验要求刷新。请重新加载${renderAffectedWorkItems(validation.affectedPublicIds)}后再生成或确认写入操作。只用普通业务语言说明，不展示回执、文档或评论内部标识。`,
    untrusted: "",
  }
}

function workItemContextReceiptActionFailure(
  _action: WorkItemContextReceiptAction,
  result: { message: string; httpStatus?: number },
): SplitSupportContext {
  const unavailable = result.message === "UNAVAILABLE" || result.httpStatus === 403 || result.httpStatus === 404
  return {
    trusted: unavailable
      ? "[Synapse] 这次缺失资料处理不可用或当前用户无权操作。未记录忽略或临时补充，不能据此继续。只用普通业务语言说明，不展示回执或内部标识。"
      : "[Synapse] 这次缺失资料处理失败。未记录忽略或临时补充，不能据此继续；请用户稍后重试。只用普通业务语言说明，不展示回执或内部标识。",
    untrusted: "",
  }
}

function workItemContextReceiptPostActionValidationFailure(
  _contextReceiptId: string,
  result: { message: string; httpStatus?: number },
): SplitSupportContext {
  const unavailable = result.message === "UNAVAILABLE" || result.httpStatus === 403 || result.httpStatus === 404
  return {
    trusted: unavailable
      ? "[Synapse] 上下文缺失处理已记录，但发布前校验当前不可用或无权执行，仍不能继续写入。请用户稍后重试。只用普通业务语言说明，不展示回执或内部标识。"
      : "[Synapse] 上下文缺失处理已记录，但尚未通过发布前校验，仍不能继续写入。请用户稍后重试校验。只用普通业务语言说明，不展示回执或内部标识。",
    untrusted: "",
  }
}

function renderAffectedWorkItems(publicIds: readonly string[]): string {
  const unique = [...new Set(publicIds)]
  return unique.length > 0 ? `工作项 ${unique.join("、")}` : "受影响的工作项"
}

function transportLoadFailure(result: { reason: string; message: string; httpStatus?: number }) {
  const unavailable = result.message === "UNAVAILABLE" || result.httpStatus === 403 || result.httpStatus === 404
  return {
    ok: false as const,
    code: unavailable ? "UNAVAILABLE" : result.reason === "kh_returned_error" ? "CONTENT_UNAVAILABLE" : "RUNTIME_FAILURE",
    message: unavailable ? "UNAVAILABLE" : result.message,
    retryable: !unavailable && result.httpStatus !== 400,
  }
}

function destructiveRouteDisabled(capability: string): Record<string, unknown> {
  return {
    ok: false,
    reason: "typed_executor_required",
    capability,
    message: "Use /agent/execute so confirmation, authorization, and idempotency are enforced.",
  }
}
