/** Kimi Code hook payloads -> Synapse canonical requests. */
import type { InjectRequest, ReportRequest } from "../../transport/contract.ts"
import { asObject, mergeParsedAttachments, parseAttachments, stableTurnAnchor, str, supportRails, transcriptTail, type ParsedAttachments } from "./util.ts"

function contentText(value: unknown): string {
  if (typeof value === "string") return value
  if (!Array.isArray(value)) return ""
  return value
    .map((part) => {
      if (typeof part === "string") return part
      return str(asObject(part), "text", "content")
    })
    .filter(Boolean)
    .join("\n")
}

function inlineImages(value: unknown): ParsedAttachments & { images?: Array<{ mimeType: string; base64: string }> } {
  if (typeof value === "string") return { observation: "none" }
  if (!Array.isArray(value)) return { observation: "unknown" }
  const media = value.filter((part) => /^(?:image_url|video_url|audio_url)$/.test(str(asObject(part), "type")))
  if (!media.length) return { observation: "none" }
  if (media.length > 20) return { observation: "present", error: "Synapse supports at most 20 attachments per turn" }
  const images: Array<{ mimeType: string; base64: string }> = []
  for (const rawPart of media) {
    const part = asObject(rawPart)
    if (str(part, "type") !== "image_url") {
      return { observation: "present", error: "Synapse cannot safely preserve this Kimi media attachment" }
    }
    const url = str(asObject(part["imageUrl"]), "url")
    const match = url.match(/^data:([^;,]+);base64,([\s\S]+)$/i)
    if (!match) return { observation: "present", error: "Synapse cannot safely preserve this Kimi image attachment" }
    images.push({ mimeType: match[1]!, base64: match[2]! })
  }
  return { observation: "present", images }
}

export function parseInject(raw: unknown): InjectRequest {
  const o = asObject(raw)
  const prompt = o["prompt"]
  const directAttachments = parseAttachments(o)
  const inline = inlineImages(prompt)
  const combinedCount = (directAttachments.files?.length ?? 0) + (inline.images?.length ?? 0)
  const parsedAttachments: ParsedAttachments = combinedCount > 20
    ? { observation: "present", error: "Synapse supports at most 20 attachments per turn" }
    : directAttachments.observation === "unknown" && !directAttachments.error
      ? inline
      : mergeParsedAttachments(directAttachments, inline)
  const user_input = contentText(prompt) || str(o, "query", "input", "message")
  const session_id = str(o, "session_id", "sessionId")
  const message_id = str(o, "prompt_id", "message_id", "request_id", "id") || undefined
  const conversation_id = str(o, "conversation_id", "conversationId") || undefined
  return {
    client: "kimi-code",
    event: str(o, "hook_event_name", "event") || "UserPromptSubmit",
    project: str(o, "cwd", "workspace") || undefined,
    cwd: str(o, "cwd", "workspace") || undefined,
    user_input,
    session_id,
    turn_id: stableTurnAnchor(
      o,
      { client: "kimi-code", sessionId: session_id, messageId: message_id, conversationId: conversation_id, currentText: user_input },
      "turn_id", "prompt_id", "message_id", "request_id", "id",
    ),
    message_id,
    conversation_id,
    attachments: parsedAttachments.files,
    attachment_observation: parsedAttachments.observation,
    attachment_error: parsedAttachments.error,
    deferred_attachment_source: !parsedAttachments.error && inline.images?.length
      ? { kind: "inline-images", images: inline.images }
      : undefined,
    transcript_tail: transcriptTail(o),
    support_rails: supportRails(o),
  }
}

export function parseReport(raw: unknown): ReportRequest {
  const o = asObject(raw)
  const session_id = str(o, "session_id", "sessionId")
  return {
    client: "kimi-code",
    event: str(o, "hook_event_name", "event") || "Stop",
    session_id,
    // Kimi 0.33 Stop/SessionEnd only expose session_id/cwd. A session-only
    // fallback aliases every turn; leave it empty so sedimentation deduplicates
    // with the resolved turn-text fingerprint instead.
    turn_id: str(o, "turn_id", "prompt_id", "message_id", "request_id", "id") || undefined,
    project: str(o, "cwd", "workspace") || undefined,
    cwd: str(o, "cwd", "workspace") || undefined,
  }
}
