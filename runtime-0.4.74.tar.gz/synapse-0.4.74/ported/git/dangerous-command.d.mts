export const DANGEROUS_COMMAND_PATTERNS: string[]
export function matchDangerousCommand(
  command: string | undefined | null,
): { pattern: string } | undefined
