import {
  hasWorkItemWriteIntentText,
  isOperationNonExecutionFraming,
  type TaskCapabilityReadCommand,
} from "@cerebro/wire"

export interface DeterministicTaskReadPlan {
  command: TaskCapabilityReadCommand
  input: Readonly<Record<string, unknown>>
}

const CHINESE_FIRST_REQUIREMENT_TARGET_SOURCE = '(?:当前|现在)?\\s*(?:需求\\s*(?:列表|清单|池)|(?:列表|清单)\\s*(?:里|中|内)?(?:的)?\\s*需求)\\s*(?:里|中|内)?(?:的)?\\s*(?:第\\s*(?:一|1)\\s*(?:条|个|项)(?:记录)?|首\\s*(?:条|个|项))'
const CHINESE_FIRST_REQUIREMENT_TARGET_RE = new RegExp(CHINESE_FIRST_REQUIREMENT_TARGET_SOURCE, "i")
const FIRST_REQUIREMENT_REFERENCE_SOURCE = `(?:${CHINESE_FIRST_REQUIREMENT_TARGET_SOURCE}|\\bfirst\\s+(?:item|entry|requirement)\\s+in\\s+the\\s+requirement\\s+list\\b)`
const ENGLISH_FIRST_REQUIREMENT_CLAUSE_RE = /^(?:please\s+)?what\s+is\s+the\s+first\s+(?:item|entry|requirement)\s+in\s+the\s+requirement\s+list$/i
const CHINESE_READ_VERB_RE = /^(?:(?:请(?:你)?|麻烦(?:你)?|帮我)\s*)?(?:一起\s*)?(?:告诉我|查(?:一下|下)?|查询(?:一下|下)?|查看(?:一下|下)?|看(?:一下|下|看)?|读取(?:一下|下)?|列出|显示|展示)\s*/i
const CHINESE_READ_ANSWER_RE = /^(?:是|为)?\s*(?:什么|哪(?:一)?(?:条|个|项)|内容)\s*/i
const PRODUCT_QUALIFIER_RE = /^(?:在|从)?\s*[\p{L}\p{N}_. -]{1,48}(?:产品|项目)?(?:里|中|内|的)?$/u
const PRODUCT_QUALIFIER_ACTION_RE = /(?:不要|请勿|别|无需|不用|然后|同时|并且|另外|顺便|接着|告诉|查|清理|清除|缓存|构建|编译|安装|依赖|重启|服务|切换|分支|部署|发布|运行|执行|测试|搜索|查询|查看|读取|创建|更新|修改|删除|回答|天气|知识|代码|修复|优化|分析|排查|定位|解释|浏览器|桌面)/i
const PRODUCT_QUALIFIER_SEQUENCE_RE = /(?:之后|以后|以前|之前|然后|接着|并且|同时|先|再|后|前|完(?:成|毕)?)/i
const OUTPUT_MARKER_CLAUSE_RE = /^(?:[,，]\s*)?(?:(?:并|然后|再)\s*)?(?:请\s*)?(?:在\s*)?回答(?:的)?(?:末尾|最后)\s*(?:带上|附上|加上|输出|写上)\s*(?:校验)?标识\s*(?:为|是|[:：])?\s*[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/i
const ENGLISH_OUTPUT_MARKER_CLAUSE_RE = /^(?:,?\s*(?:and\s+)?)?(?:include|append|add)\s+(?:the\s+)?(?:validation\s+)?marker\s*(?:[:=]|as)?\s*[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/i
const WORK_ITEM_PUBLIC_ID_TOKEN_RE = /[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi
const INJECTED_CONTEXT_READ_PREFIX_RE = /^\s*(?:(?:请|麻烦(?:你)?|帮我)\s*)?(?:一起\s*)?(?:看(?:一下|下|看)?|查看(?:一下|下)?|读取(?:一下|下)?|比较|对比|核对|梳理|总结)?\s*$/i
const INJECTED_CONTEXT_ID_CONNECTOR_RE = /^\s*(?:和|与|及|、|,|，)\s*$/
const INJECTED_CONTEXT_COMPARISON_TAIL_RE = /^\s*(?:(?:请)?(?:确认|比较|对比|核对|总结|说明|告诉我)\s*)?(?:(?:它们|两者|这些工作项)(?:的)?\s*)?(?:(?:[\p{L}\p{N}\s]{1,24}(?:的)?)?(?:处理方向|业务方向|方向|内容|结论|要求|规则|方案|表现|描述|目标|范围|行为|语义|口径|结果)\s*)?(?:是否|有无)\s*(?:一致|冲突|差异)(?:吗|呢)?\s*$/iu
const INJECTED_CONTEXT_NON_ANALYSIS_TERM_RE = /(?:重构|编辑|调试|实现|优化|写入|修改|更新|删除|创建|新增|保存|生成|导出|运行|执行|测试|部署|发布|构建|编译|安装|重启|切换|调用|连接|读取本地|打开|操作|使用|curl|PowerShell|仓库|代码|文件|服务|数据库|前端|页面|浏览器|主脑客户端|桌面|UI|命令|脚本|报告|文档)/i

/** Resolve only reads whose command and complete input are unambiguous. */
export function resolveDeterministicTaskReadPlan(text: string): DeterministicTaskReadPlan | undefined {
  const clauses = splitTaskReadClauses(text)
  if (clauses.length === 0) return undefined

  let readCount = 0
  for (const clause of clauses) {
    if (isExactFirstRequirementReadClause(clause)) {
      readCount++
      continue
    }
    if (isOutputMarkerClause(clause)) continue
    return undefined
  }
  return readCount === 1
    ? { command: "requirement.list", input: { limit: 1 } }
    : undefined
}

/**
 * Resolve the one remaining Task read after Synapse has already loaded every
 * explicit work item in the other clauses. This stays separate from the
 * strict resolver so incomplete repository/UI requests cannot become reads.
 */
export function resolveContextBackedDeterministicTaskReadPlan(
  text: string,
  injectedPublicIds: readonly string[],
): DeterministicTaskReadPlan | undefined {
  const injected = new Set(injectedPublicIds.map((value) => value.toUpperCase()))
  if (injected.size === 0) return undefined
  const clauses = splitTaskReadClauses(text)
  if (clauses.length < 2) return undefined

  let readCount = 0
  let contextClauseCount = 0
  for (const clause of clauses) {
    if (isExactFirstRequirementReadClause(clause)) {
      readCount++
      continue
    }
    if (isOutputMarkerClause(clause)) continue
    if (!isInjectedWorkItemContextReadClause(clause, injected)) return undefined
    contextClauseCount++
  }
  return readCount === 1 && contextClauseCount > 0
    ? { command: "requirement.list", input: { limit: 1 } }
    : undefined
}

function splitTaskReadClauses(text: string): string[] {
  return (text ?? "").split(/[。！？!?;；\n]+/)
    .map((clause) => clause.trim())
    .filter(Boolean)
}

function isInjectedWorkItemContextReadClause(clause: string, injected: ReadonlySet<string>): boolean {
  if (hasWorkItemWriteIntentText(clause)) return false
  const matches = [...clause.matchAll(WORK_ITEM_PUBLIC_ID_TOKEN_RE)]
  if (matches.length === 0 || matches.some((match) => !injected.has(match[0].toUpperCase()))) return false

  const segments = clause.split(WORK_ITEM_PUBLIC_ID_TOKEN_RE)
  const prefix = segments[0] ?? ""
  const between = segments.slice(1, -1)
  let tail = segments.at(-1) ?? ""
  if (!INJECTED_CONTEXT_READ_PREFIX_RE.test(prefix)
    || between.some((segment) => !INJECTED_CONTEXT_ID_CONNECTOR_RE.test(segment))) return false

  tail = tail.replace(/^\s*[,，]\s*/, "")
  if (!tail.trim()) return true
  return !INJECTED_CONTEXT_NON_ANALYSIS_TERM_RE.test(tail)
    && INJECTED_CONTEXT_COMPARISON_TAIL_RE.test(tail)
}

function isExactFirstRequirementReadClause(clause: string): boolean {
  const value = clause.trim()
  if (isOperationNonExecutionFraming(value, FIRST_REQUIREMENT_REFERENCE_SOURCE)) return false
  if (ENGLISH_FIRST_REQUIREMENT_CLAUSE_RE.test(value)) return true

  const target = CHINESE_FIRST_REQUIREMENT_TARGET_RE.exec(value)
  if (!target) return false
  if (!isAllowedChineseReadPrefix(value.slice(0, target.index))) return false

  let suffix = value.slice(target.index + target[0].length).trim()
  const answer = CHINESE_READ_ANSWER_RE.exec(suffix)
  if (answer) suffix = suffix.slice(answer[0].length).trim()
  return suffix === "" || suffix === "呢" || isOutputMarkerClause(suffix)
}

function isAllowedChineseReadPrefix(prefix: string): boolean {
  let value = prefix.trim().replace(
    /^(?:然后|再|接着)\s*(?=(?:(?:请(?:你)?|麻烦(?:你)?|帮我)\s*)?(?:告诉我|查|查询|查看|看|读取|列出|显示|展示))/i,
    "",
  )
  const verb = CHINESE_READ_VERB_RE.exec(value)
  if (verb) value = value.slice(verb[0].length).trim()
  if (!value) return true
  return !PRODUCT_QUALIFIER_ACTION_RE.test(value)
    && !PRODUCT_QUALIFIER_SEQUENCE_RE.test(value)
    && PRODUCT_QUALIFIER_RE.test(value)
}

function isOutputMarkerClause(clause: string): boolean {
  return OUTPUT_MARKER_CLAUSE_RE.test(clause.trim())
    || ENGLISH_OUTPUT_MARKER_CLAUSE_RE.test(clause.trim())
}
