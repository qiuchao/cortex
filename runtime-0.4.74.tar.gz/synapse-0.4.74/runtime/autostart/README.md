# runtime/autostart/ — OS 自启瘦服务模板

> 方案 §3 Phase 6:OS 自启 + 工作台幂等看管。**不用 pm2 等重进程管理器** —— 用各 OS 原生服务。
> 所有模板最终都调同一个幂等原语 `synapse watchdog`(= ensure-running,已在跑则 no-op)。

安装器(工作台/`synapse` 安装脚本)按平台落地对应文件:

- **Linux**:`systemd` user service → `~/.config/systemd/user/synapse.service`,
  `systemctl --user enable --now synapse`。
- **macOS**:`launchd` LaunchAgent → `~/Library/LaunchAgents/com.andyqiu.synapse.plist`,
  `launchctl load`。
- **Windows**(box A 就位再做):Task Scheduler `ONLOGON` 任务(需 named-pipe ACL 鉴权派生,per-OS TODO)。

生命周期独立于 GUI:这些是登录级后台服务,关工作台窗口不影响(spec §61,§103)。
`{{NODE}}` / `{{SYNAPSE_BIN}}` 由安装器替换为真实路径。
