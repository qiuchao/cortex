import type { RequirementDraftDeliveryFacts } from "./requirement-draft-action.ts"
import { loadSessionState, persistSessionState } from "./session-store.ts"
import {
  TaskCapabilitySourceClientSchema,
  TaskCapabilityWriteCommandSchema,
  WorkItemPublicIdSchema,
  type TaskCapabilitySourceClient,
  type TaskCapabilityWriteCommand,
} from "@cerebro/wire"
import type { TaskCommandDraftRecord } from "../transport/brain-contract-align.ts"
import type { TaskDraftCleanupRef, TaskDraftLifecycle } from "./task-draft-lifecycle.ts"

export interface TaskIntakeDraftTrust {
  requestId: string
  command: TaskCapabilityWriteCommand
  contextReceiptId: string | null
  contextTargetPublicId: string | null
  sourceClient: TaskCapabilitySourceClient
}

export interface StoredTaskIntakeRef extends TaskIntakeDraftTrust, RequirementDraftDeliveryFacts {
  draftId?: string
  productionId: string
  attempted: boolean
  blockedReason?: string
  cleanupDraftIds?: TaskDraftCleanupRef[]
  replacement?: TaskIntakeReplacementRef
}

export interface TaskIntakeReplacementRef extends TaskIntakeDraftTrust {
  productionId: string
  sessionId: string
}

/** Older incomplete references may identify a C record, but never authorize local restore. */
export interface StoredTaskIntakeRecoveryRef extends RequirementDraftDeliveryFacts {
  recoveryOnly: true
  productionId: string
  requestId: string
  draftId?: string
  command?: undefined
  cleanupPending?: true
}

export function isTaskIntakeRecoveryRef(value: unknown): value is StoredTaskIntakeRecoveryRef {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false
  const ref = value as Record<string, unknown>
  return ref.recoveryOnly === true && typeof ref.productionId === "string" && Boolean(ref.productionId)
    && typeof ref.requestId === "string" && Boolean(ref.requestId) && typeof ref.attempted === "boolean"
    && (ref.draftId === undefined || (typeof ref.draftId === "string" && Boolean(ref.draftId)))
}

export function loadRecoverableTaskIntakeSessions(path: string): Record<string, StoredTaskIntakeRef | StoredTaskIntakeRecoveryRef> {
  return loadSessionState(path, () => ({}), (value) => {
    const state = value as Partial<StoredTaskIntakeState>
    if (state.version !== 1 || !state.sessions || typeof state.sessions !== "object" || Array.isArray(state.sessions)) return {}
    return Object.fromEntries(Object.entries(state.sessions).flatMap<[string, StoredTaskIntakeRef | StoredTaskIntakeRecoveryRef]>(([key, value]) => {
      if (isStoredTaskIntakeRef(value)) return [[key, value]]
      if (!value || typeof value !== "object" || Array.isArray(value)) return []
      const raw = value as unknown as Record<string, unknown>
      if (typeof raw.productionId !== "string" || !raw.productionId || typeof raw.requestId !== "string" || !raw.requestId
        || (raw.draftId !== undefined && (typeof raw.draftId !== "string" || !raw.draftId))) return []
      const ref: StoredTaskIntakeRecoveryRef = {
        recoveryOnly: true, productionId: raw.productionId, requestId: raw.requestId,
        ...(typeof raw.draftId === "string" ? { draftId: raw.draftId } : {}),
        // Missing delivery metadata is uncertainty, never proof of an unattempted action.
        attempted: raw.attempted !== false,
        ...(typeof raw.requirementActionKey === "string" && raw.requirementActionKey ? { requirementActionKey: raw.requirementActionKey } : {}),
        ...(raw.cleanupPending === true || (raw.cleanupDraftIds !== undefined
          && (!Array.isArray(raw.cleanupDraftIds) || raw.cleanupDraftIds.length > 0)) ? { cleanupPending: true as const } : {}),
      }
      return [[key, ref]]
    }))
  })
}

export class TaskIntakeRefInvalidError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "TaskIntakeRefInvalidError"
  }
}

interface StoredTaskIntakeState {
  version: 1
  sessions: Record<string, StoredTaskIntakeRef | StoredTaskIntakeRecoveryRef>
}

export function isStoredTaskIntakeRef(value: unknown): value is StoredTaskIntakeRef {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false
  const ref = value as Record<string, unknown>
  if ((ref.draftId !== undefined && (typeof ref.draftId !== "string" || !ref.draftId)) || typeof ref.productionId !== "string" || !ref.productionId || typeof ref.attempted !== "boolean") return false
  if (typeof ref.requestId !== "string" || !ref.requestId || !TaskCapabilityWriteCommandSchema.safeParse(ref.command).success) return false
  if (!TaskCapabilitySourceClientSchema.safeParse(ref.sourceClient).success) return false
  if (!validStoredBinding(ref.contextReceiptId, ref.contextTargetPublicId)) return false
  if (ref.blockedReason !== undefined && (typeof ref.blockedReason !== "string" || !ref.blockedReason)) return false
  if (ref.cleanupDraftIds !== undefined && (!Array.isArray(ref.cleanupDraftIds) || ref.cleanupDraftIds.some((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return true
    const cleanup = item as Record<string, unknown>
    return typeof cleanup.draftId !== "string" || typeof cleanup.productionId !== "string"
      || !Object.keys(cleanup).every((key) => key === "draftId" || key === "productionId")
  }))) return false
  if (ref.replacement !== undefined) {
    if (!ref.replacement || typeof ref.replacement !== "object" || Array.isArray(ref.replacement)) return false
    const next = ref.replacement as Record<string, unknown>
    if (typeof next.productionId !== "string" || !next.productionId || typeof next.sessionId !== "string" || !next.sessionId
      || next.command !== "requirement.create" || typeof next.requestId !== "string" || !next.requestId
      || !TaskCapabilitySourceClientSchema.safeParse(next.sourceClient).success
      || !validStoredBinding(next.contextReceiptId, next.contextTargetPublicId)
      || !Object.keys(next).every(key => ["productionId", "sessionId", "command", "requestId", "sourceClient", "contextReceiptId", "contextTargetPublicId"].includes(key))) return false
  }
  if (ref.requirementActionKey !== undefined && (typeof ref.requirementActionKey !== "string" || !ref.requirementActionKey)) return false
  if (ref.requirementActionVersion !== undefined && ref.requirementActionVersion !== 1) return false
  return Object.keys(ref).every((key) => ["replacement", "requirementActionKey", "requirementActionVersion", "draftId", "productionId", "requestId", "command", "contextReceiptId", "contextTargetPublicId", "sourceClient", "attempted", "blockedReason", "cleanupDraftIds"].includes(key))
}

export function taskIntakeDraftTrust(
  input: Parameters<TaskDraftLifecycle["create"]>[0],
): TaskIntakeDraftTrust {
  const contextReceiptId = input.contextReceiptId ?? null
  const contextTargetPublicId = input.contextTargetPublicId ?? null
  if (!validStoredBinding(contextReceiptId, contextTargetPublicId)) {
    throw new TaskIntakeRefInvalidError("操作上下文绑定无效")
  }
  const sourceClient = TaskCapabilitySourceClientSchema.safeParse(input.sourceClient)
  if (!sourceClient.success) throw new TaskIntakeRefInvalidError("操作缺少可信 Harness 客户端")
  return { requestId: input.requestId, command: input.command, contextReceiptId, contextTargetPublicId, sourceClient: sourceClient.data }
}

export function assertTaskIntakeDraftMatches(
  record: TaskCommandDraftRecord,
  expected: TaskIntakeDraftTrust & { productionId: string; draftId?: string },
): void {
  if ((expected.draftId && record.id !== expected.draftId)
    || record.productionId !== expected.productionId
    || record.requestId !== expected.requestId
    || record.command !== expected.command
    || record.sourceClient !== expected.sourceClient
    || record.contextReceiptId !== expected.contextReceiptId
    || record.contextTargetPublicId !== expected.contextTargetPublicId) {
    throw new TaskIntakeRefInvalidError("服务端操作与本地可信引用不一致")
  }
}

export function loadTaskIntakeSessions(path: string): Record<string, StoredTaskIntakeRef> {
  return loadSessionState(path, () => ({}), (value) => {
    const state = value as Partial<StoredTaskIntakeState>
    if (state.version !== 1 || !state.sessions || typeof state.sessions !== "object" || Array.isArray(state.sessions)) return {}
    return Object.fromEntries(Object.entries(state.sessions).filter((entry): entry is [string, StoredTaskIntakeRef] => isStoredTaskIntakeRef(entry[1])))
  })
}

export function persistTaskIntakeSessions<T>(
  path: string,
  sessions: Record<string, T | StoredTaskIntakeRef | StoredTaskIntakeRecoveryRef>,
  project: (value: T) => StoredTaskIntakeRef | undefined,
): void {
  const refs = Object.entries(sessions).flatMap(([key, value]) => {
    const ref = isStoredTaskIntakeRef(value) || isTaskIntakeRecoveryRef(value) ? value : project(value as T)
    return ref ? [[key, ref] as const] : []
  })
  persistSessionState(path, { version: 1, sessions: Object.fromEntries(refs) } satisfies StoredTaskIntakeState)
}

function validStoredBinding(receipt: unknown, target: unknown): boolean {
  if (receipt === null && target === null) return true
  return typeof receipt === "string"
    && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(receipt)
    && WorkItemPublicIdSchema.safeParse(target).success
}
