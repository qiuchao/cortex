import {
  chmodSync,
  existsSync,
  lstatSync,
  mkdirSync,
  openSync,
  closeSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmdirSync,
  unlinkSync,
  writeFileSync,
} from "node:fs"
import { join } from "node:path"
import { agentSpoolDir } from "../transport/discovery.ts"
import type { AgentCapabilityBroker } from "./agent-capability-broker.ts"
import {
  AGENT_JSON_BRIDGE_MAX_BYTES,
  agentJsonPayloadTooLarge,
  cleanupAgentJsonTransfers,
  removeAgentJsonTransferEntryIfStale,
} from "./agent-json-transfer.ts"
import type { TaskTurnGuardRegistry } from "../core/task-turn-guard.ts"
import type { AgentAttachmentIntake } from "../core/agent-attachments.ts"
import type { KnowledgeConfirmationIntake } from "../core/knowledge-confirmation-intake.ts"
import {
  authorizeCapabilityRouteExecution,
} from "./task-route-execution.ts"
import { settleCapabilityRouteExecution } from "./capability-route-result.ts"

const REQUEST_RE = /^request-([a-f0-9-]{36})\.json$/
const STALE_MS = 5 * 60_000
const CLOCK_SKEW_MS = 30_000

interface FileBridgeRequest {
  protocolVersion: "synapse-agent-file.v1"
  id: string
  action: "describe" | "execute"
  body?: unknown
  routeToken?: string
  standalone?: boolean
  createdAt: string
}

export interface AgentFileBridge {
  path: string
  stop(): Promise<void>
}

export function startAgentFileBridge(
  broker: AgentCapabilityBroker,
  env: NodeJS.ProcessEnv = process.env,
  taskTurnGuards?: TaskTurnGuardRegistry,
  agentAttachmentIntake?: AgentAttachmentIntake,
  knowledgeConfirmationIntake?: KnowledgeConfirmationIntake,
): AgentFileBridge {
  const path = agentSpoolDir(env)
  prepareSpoolDirectory(path)
  // A configured spool can survive a daemon crash. Clear protocol-owned state
  // before this bridge is discoverable; runtime scanning never reclaims locks.
  cleanupAgentJsonTransfers(path)
  let stopped = false
  let scanning = false
  const active = new Set<Promise<void>>()

  const scan = () => {
    if (stopped || scanning) return
    scanning = true
    try {
      for (const name of readdirSync(path)) {
        if (removeAgentJsonTransferEntryIfStale(path, name)) continue
        const match = REQUEST_RE.exec(name)
        if (!match) {
          removeIfStale(path, name)
          continue
        }
        const requestPath = join(path, name)
        let stat
        try { stat = lstatSync(requestPath) } catch { continue }
        if (!stat.isFile() || stat.isSymbolicLink()) {
          safeUnlink(requestPath)
          continue
        }
        const claimedPath = join(path, `processing-${match[1]}.json`)
        try { renameSync(requestPath, claimedPath) } catch { continue }
        const task = processRequest(
          claimedPath,
          match[1],
          path,
          broker,
          taskTurnGuards,
          agentAttachmentIntake,
          knowledgeConfirmationIntake,
        )
          .finally(() => active.delete(task))
        active.add(task)
      }
    } finally {
      scanning = false
    }
  }
  const timer = setInterval(scan, 25)
  timer.unref()
  scan()

  return {
    path,
    stop: async () => {
      stopped = true
      clearInterval(timer)
      await Promise.allSettled([...active])
      cleanupSpoolDirectory(path)
    },
  }
}

async function processRequest(
  claimedPath: string,
  id: string,
  spoolPath: string,
  broker: AgentCapabilityBroker,
  taskTurnGuards?: TaskTurnGuardRegistry,
  agentAttachmentIntake?: AgentAttachmentIntake,
  knowledgeConfirmationIntake?: KnowledgeConfirmationIntake,
): Promise<void> {
  let status = 200
  let body: unknown
  try {
    const stat = lstatSync(claimedPath)
    if (!stat.isFile() || stat.isSymbolicLink()) {
      throw new Error("invalid file bridge request")
    }
    if (stat.size > AGENT_JSON_BRIDGE_MAX_BYTES) {
      status = 413
      body = agentJsonPayloadTooLarge(AGENT_JSON_BRIDGE_MAX_BYTES)
    } else {
      const request = JSON.parse(readFileSync(claimedPath, "utf8")) as FileBridgeRequest
      const createdAt = Date.parse(request.createdAt)
      if (
        request.protocolVersion !== "synapse-agent-file.v1"
        || request.id !== id
        || !Number.isFinite(createdAt)
        || createdAt < Date.now() - STALE_MS
        || createdAt > Date.now() + CLOCK_SKEW_MS
      ) {
        status = 400
        body = { ok: false, reason: "validation_error", message: "invalid file bridge envelope" }
      } else if (request.action === "describe") {
        const options = request.body && typeof request.body === "object" && !Array.isArray(request.body)
          ? request.body as { productionId?: string; publicId?: string; taskOnly?: boolean }
          : undefined
        const result = options?.taskOnly
          ? await broker.describeTask({ productionId: options.productionId, publicId: options.publicId })
          : await broker.describe(options)
        status = result.ok ? 200 : result.httpStatus ?? 502
        body = result.ok
          ? options?.taskOnly ? { taskCatalogue: result.catalogue } : result.catalogue
          : result
      } else if (request.action === "execute") {
        if (request.standalone !== undefined && typeof request.standalone !== "boolean") {
          status = 400
          body = { ok: false, reason: "validation_error", message: "standalone must be a boolean" }
          return await writeResponse(spoolPath, id, status, body, claimedPath)
        }
        const routed = await authorizeCapabilityRouteExecution(
          taskTurnGuards,
          agentAttachmentIntake,
          request.routeToken,
          request.body,
          request.standalone === true ? "standalone" : undefined,
        )
        if (!routed.ok) {
          status = routed.status
          body = { ok: false, reason: routed.reason, message: routed.message }
          return await writeResponse(spoolPath, id, status, body, claimedPath)
        }
        const routeAuthorization = routed.authorization
        const authorizedBody = routeAuthorization?.request ?? request.body
        const executed = await broker.execute(authorizedBody)
        const result = await settleCapabilityRouteExecution({
          broker,
          confirmationIntake: knowledgeConfirmationIntake,
          guards: taskTurnGuards,
          routeToken: request.routeToken,
          authorization: routeAuthorization,
          request: authorizedBody,
          result: executed,
        })
        status = result.ok ? 200 : result.httpStatus ?? 502
        body = result.ok ? result.response : result
      } else {
        status = 400
        body = { ok: false, reason: "validation_error", message: "unsupported file bridge action" }
      }
    }
  } catch (error) {
    status = 400
    body = { ok: false, reason: "validation_error", message: String(error instanceof Error ? error.message : error) }
  } finally {
    safeUnlink(claimedPath)
  }
  await writeResponse(spoolPath, id, status, body)
}

async function writeResponse(
  spoolPath: string,
  id: string,
  status: number,
  body: unknown,
  claimedPath?: string,
): Promise<void> {
  if (claimedPath) safeUnlink(claimedPath)
  const responsePath = join(spoolPath, `response-${id}.json`)
  const tempPath = join(spoolPath, `.response-${id}.tmp`)
  let fd: number | undefined
  try {
    fd = openSync(tempPath, "wx", 0o600)
    writeFileSync(fd, JSON.stringify({ protocolVersion: "synapse-agent-file.v1", id, status, body }))
    closeSync(fd)
    fd = undefined
    renameSync(tempPath, responsePath)
  } catch {
    if (fd !== undefined) try { closeSync(fd) } catch { /* best effort */ }
    safeUnlink(tempPath)
  }
}

function removeIfStale(path: string, name: string): void {
  if (!/^(?:processing|response)-[a-f0-9-]{36}\.json$|^\.(?:request|response)-[a-f0-9-]{36}\.tmp$/.test(name)) return
  const target = join(path, name)
  try {
    if (Date.now() - lstatSync(target).mtimeMs > STALE_MS) safeUnlink(target)
  } catch { /* disappeared during scan */ }
}

function prepareSpoolDirectory(path: string): void {
  mkdirSync(path, { recursive: true, mode: 0o700 })
  const stat = lstatSync(path)
  if (!stat.isDirectory() || stat.isSymbolicLink()) {
    throw new Error(`agent spool path must be a real directory: ${path}`)
  }
  if (typeof process.getuid === "function" && stat.uid !== process.getuid()) {
    throw new Error(`agent spool path must be owned by the current user: ${path}`)
  }
  try { chmodSync(path, 0o700) } catch { /* Windows ACL is managed by the user temp directory. */ }
  const secured = lstatSync(path)
  if (process.platform !== "win32" && (secured.mode & 0o077) !== 0) {
    throw new Error(`agent spool path must not be accessible by group or others: ${path}`)
  }
}

function cleanupSpoolDirectory(path: string): void {
  try {
    cleanupAgentJsonTransfers(path)
    for (const name of readdirSync(path)) {
      if (/^(?:request|processing|response)-[a-f0-9-]{36}\.json$|^\.(?:request|response)-[a-f0-9-]{36}\.tmp$/.test(name)) {
        safeUnlink(join(path, name))
      }
    }
    rmdirSync(path)
  } catch { /* Leave unrelated or concurrently-created files intact. */ }
}

function safeUnlink(path: string): void {
  try { if (existsSync(path)) unlinkSync(path) } catch { /* best effort */ }
}
