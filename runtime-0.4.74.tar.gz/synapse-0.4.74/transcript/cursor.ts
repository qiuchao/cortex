/**
 * transcript/cursor.ts —— 上传游标存储(幂等键:每个会话文件已安全消费到的位置)。
 *
 * 方案 R5:游标只前进到**完全解析过的记录**。JSONL 用 byteOffset,整文件 JSON 用 mtime+size。
 * 存 JSON 文件(低频数据,不上 SQLite;方案最小依赖原则)。
 *
 * 幂等:重跑扫描时,已消费部分不再上传(回填与稳态同一套逻辑靠它去重)。
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs"
import { dirname } from "node:path"

/**
 * Bump when already-persisted cursors must be replayed against a corrected upload contract.
 * Server-side corpus keys make the replay idempotent; the marker prevents repeating it.
 */
export const TRANSCRIPT_CURSOR_GENERATION = 4

export interface FileCursor {
  /** Upload contract generation that successfully consumed this file position. */
  generation?: number
  /** JSONL:已安全消费的字节偏移 */
  byteOffset?: number
  /** 整文件 JSON:上次成功上传时的 mtimeMs + size(变化才重传) */
  mtimeMs?: number
  size?: number
  /** 上次上传时间(遥测) */
  lastUploadedAt?: string
  /** JSONL:已消费的消息条数累计(用于跨轮 seq 偏移,保证 source_message_id 文件绝对稳定) */
  recordCount?: number
  /** 从会话 raw 元数据提取到的实际绝对 project_path；JSONL 后续增量 chunk 可能不再携带 cwd。 */
  projectPath?: string
  /** 数据库型客户端按 session 保存的更新时间水位。 */
  updatedAtMs?: number
}

export interface CursorStore {
  get(path: string): FileCursor | undefined
  set(path: string, cursor: FileCursor): void
  all(): Record<string, FileCursor>
  save(): void
}

/** 从磁盘加载游标存储(不存在则空)。 */
export function loadCursorStore(storePath: string): CursorStore {
  let data: Record<string, FileCursor> = {}
  if (existsSync(storePath)) {
    try {
      data = JSON.parse(readFileSync(storePath, "utf8")) as Record<string, FileCursor>
    } catch {
      data = {} // 坏文件 → 从空开始(保守:可能导致重传,但不丢/不错传)
    }
  }
  return {
    get: (p) => data[p],
    set: (p, c) => {
      data[p] = c
    },
    all: () => ({ ...data }),
    save: () => {
      mkdirSync(dirname(storePath), { recursive: true })
      writeFileSync(storePath, JSON.stringify(data, null, 2))
    },
  }
}
