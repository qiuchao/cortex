/**
 * transcript/parsers/json.ts —— 整文件 JSON 会话的 torn-read 安全解析(opencode)。
 *
 * 方案 R5/R7:整文件 JSON 若正在被写,读到的是**不完整 JSON** → JSON.parse 失败。
 * 守卫:全读 → parse 成功才消费;**parse 失败 = 跳过 + 下 tick 重试**(不推进游标)。
 */
export interface JsonParseResult {
  ok: boolean
  value?: unknown
  /** parse 失败(可能是 torn write)→ 调用方应跳过本 tick、下次重试 */
  retry: boolean
}

export function parseWholeJsonSafe(content: string): JsonParseResult {
  const trimmed = content.trim()
  if (!trimmed) return { ok: false, retry: true }
  try {
    return { ok: true, value: JSON.parse(trimmed), retry: false }
  } catch {
    // 不完整 / 损坏 → 跳过,下 tick 重试(可能正在写)
    return { ok: false, retry: true }
  }
}
