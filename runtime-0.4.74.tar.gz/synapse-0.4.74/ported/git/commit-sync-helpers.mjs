/**
 * commit-sync-helpers.mjs
 * R13/R22 判定逻辑的可测纯函数
 *
 * ADR: git-operation-state-machine
 *
 * 导出：
 *   classifyBehind(behind)         → "skip" | "needs-sync"
 *   classifyPushError(output)      → "remote-ahead" | "auth-error" | "network-error" | "conflict" | "unknown"
 *   canRetry(retryCount)           → boolean（最多 1 次，retryCount=0 可重试，>=1 不可重试）
 *   hasMergeConflict(mergeOutput)  → boolean（含 CONFLICT 关键词）
 */

/**
 * S5c-2：判断是否需要同步
 * @param {number|string} behind - git rev-list 计算出的「目标分支比当前分支多出的 commit 数」
 * @returns {"skip" | "needs-sync"}
 */
export function classifyBehind(behind) {
  const n = typeof behind === "string" ? parseInt(behind, 10) : behind;
  if (isNaN(n) || n <= 0) return "skip";
  return "needs-sync";
}

/**
 * R22：分类 push 错误
 * @param {string} output - push 命令的 stderr/stdout 输出
 * @returns {"remote-ahead" | "auth-error" | "network-error" | "conflict" | "unknown"}
 *
 * 分类规则：
 * - remote-ahead：含 rejected + (non-fast-forward | fetch first)，表示远端领先，需重试
 * - conflict：含 CONFLICT，表示合并产生冲突，需转 S4
 * - auth-error：含 Permission denied / Authentication failed，认证问题，不重试
 * - network-error：含 Could not resolve host / Connection refused / timed out，网络问题，不重试
 * - unknown：不符合以上任一
 */
export function classifyPushError(output) {
  const text = String(output || "");

  // 冲突优先判定（merge 输出也可能含 CONFLICT）
  if (/CONFLICT/i.test(text)) {
    return "conflict";
  }

  // 远端领先（non-fast-forward / fetch first / rejected）
  if (/rejected/i.test(text) && /(non-fast-forward|fetch first)/i.test(text)) {
    return "remote-ahead";
  }

  // 认证失败
  if (/Permission denied|Authentication failed|could not read Username/i.test(text)) {
    return "auth-error";
  }

  // 网络错误
  if (/Could not resolve host|Connection refused|timed out|network unreachable/i.test(text)) {
    return "network-error";
  }

  return "unknown";
}

/**
 * R22 防死循环：判断是否还可以重试
 * @param {number} retryCount - 已重试次数（0=未曾重试，1=已重试一次）
 * @returns {boolean} true=可以重试；false=已达上限，不再重试
 *
 * 约束：R22 重试最多执行 1 次，retryCount >= 1 即不可再试。
 */
export function canRetry(retryCount) {
  return retryCount < 1;
}

/**
 * S5c-3 / R22：检测 merge 输出是否包含冲突
 * @param {string} mergeOutput - git merge 命令的输出
 * @returns {boolean} true=有冲突需进 S4；false=合并干净
 *
 * 检测关键词：CONFLICT (content) / CONFLICT (modify/delete) / Automatic merge failed
 */
export function hasMergeConflict(mergeOutput) {
  const text = String(mergeOutput || "");
  return /CONFLICT|Automatic merge failed/i.test(text);
}

// ─────────────────────────────────────────────────────────────
// CLI 入口（isDirectRun 模式，与 stash-track-helper.mjs / branch-parent-helper.mjs 风格一致）
// process.argv 传参，绝不拼进 JS 字符串（避免 Windows/特殊字符转义地狱）
//
// 用法（供 Synapse Git policy 调用）：
//   node commit-sync-helpers.mjs classify-behind   <count>
//   node commit-sync-helpers.mjs classify-push-error <push_output>
//   node commit-sync-helpers.mjs can-retry          <retryCount>
//   node commit-sync-helpers.mjs has-conflict       <merge_output>
// ─────────────────────────────────────────────────────────────
const isMain = process.argv[1]?.endsWith("commit-sync-helpers.mjs") ?? false;
if (isMain) {
  const [, , cmd, ...args] = process.argv;
  if (cmd === "classify-behind") {
    const count = parseInt(args[0] || "0", 10);
    process.stdout.write(classifyBehind(count) + "\n");
  } else if (cmd === "classify-push-error") {
    const result = classifyPushError(args[0] || "");
    process.stdout.write(result + "\n");
  } else if (cmd === "can-retry") {
    const retryCount = parseInt(args[0] || "0", 10);
    process.stdout.write(canRetry(retryCount) ? "true\n" : "false\n");
  } else if (cmd === "has-conflict") {
    const result = hasMergeConflict(args[0] || "");
    process.stdout.write(result ? "true\n" : "false\n");
  } else {
    process.stderr.write(`commit-sync-helpers: unknown command '${cmd}'\n`);
    process.exit(1);
  }
}
