/**
 * policy/packs/git/index.ts —— 第一个 policy pack:git 分支规范 + 危险命令护栏。
 *
 * 🔴 边界铁律(方案 §1 原则 / 风险 B):
 *   - **import 安全部分**:parseGitCommand / buildBlockMessage / matchDangerousCommand
 *     (纯 helper,0 exit)进程内 import;
 *     git-rules-loader(0 exit)进程内 import 读分支规则。
 *   - **仓库读取**:check-branch 直接读 .git/HEAD(含 worktree pointer),不 spawn git/node。
 *
 * enforcement 档(方案 R2 / D3):
 *   - 一级客户端(hardGuardCapable + cwd):真 deny,fail-closed。
 *   - 缺失可信 cwd 的调用:降级放行，由 pre-commit 提供提交阶段纵深保护。
 */
import { parseGitCommand, buildBlockMessage } from "../../../ported/git-safety-runtime-helpers.ts"
import { isProtectedBranch, readBranchState } from "../../../ported/git/branch-protection.mjs"
import { matchDangerousCommand } from "../../../ported/git/dangerous-command.mjs"
import { fileURLToPath } from "node:url"
import type {
  PolicyPack,
  PolicyIntent,
  PolicyContext,
  ValidateResult,
} from "../../pack.ts"

/** 仅供 doctor 报告 bundle 内 gateway 是否存在；daemon guard 判定不会执行该脚本。 */
export const GATEWAY_PATH = fileURLToPath(
  new URL("../../../ported/git/git-safety-gateway.mjs", import.meta.url),
)

/**
 * 判定一条 git 命令是否违规。
 *
 * 检查两类:
 *   - 受保护主干直接提交(check-branch → exit 3)
 *   - 危险命令(进程内纯正则,不 spawn)
 */
function validateGitCommand(intent: PolicyIntent, ctx: PolicyContext): ValidateResult {
  const command = intent.command ?? ""
  const parsed = parseGitCommand(command)

  // 缺失工具前置能力或可信 cwd 时不能核实仓库状态，降级到 pre-commit。
  if (!ctx.hardGuardCapable || !ctx.cwd) {
    return {
      ok: true,
      enforcement: "degraded",
      reason: "工具前置调用缺少可信工作目录，Git 护栏已降级到 pre-commit 纵深保护。",
    }
  }

  const cwd = ctx.cwd

  // 1) 纯字符串规则必须留在 resident process 内。Windows 每次 spawn node 会被 AV
  // 扫描拖到数秒，超过客户端 hook 上限后让薄壳进入降级路径。
  const dangerous = matchDangerousCommand(command)
  if (dangerous) {
    const stderr =
      `[synapse-gateway] DANGEROUS_COMMAND: pattern="${dangerous.pattern}" cmd="${command}"\n`
    return {
      ok: false,
      enforcement: "enforced",
      reason: buildBlockMessage({ exitCode: 4, stderr, parsed, cwd }),
    }
  }

  // 2) 受保护主干直接提交。直接读 Git 元数据，避免 Windows AV 放大 child-node 冷启动。
  if (parsed.isGitCommit) {
    if (parsed.hasExplicitRepoSelector) {
      return {
        ok: false,
        enforcement: "enforced",
        reason:
          "Synapse 无法安全核实带 GIT_DIR/GIT_WORK_TREE 或 --git-dir/--work-tree 的提交目标。请切换到目标仓库目录后再执行 git commit。",
      }
    }

    const branchState = readBranchState(cwd)
    if (branchState.state === "error") {
      return {
        ok: false,
        enforcement: "enforced",
        reason: `Synapse 无法读取当前仓库分支，已安全拒绝 git commit；请检查 .git/HEAD 后重试。(${branchState.message})`,
      }
    }
    if (branchState.state === "branch" && isProtectedBranch(branchState.branch)) {
      const stderr =
        `[synapse-gateway] PROTECTED_BRANCH: branch="${branchState.branch}" (direct commit blocked)\n`
      return {
        ok: false,
        enforcement: "enforced",
        reason: buildBlockMessage({ exitCode: 3, stderr, parsed, cwd }),
      }
    }
  }

  return { ok: true, enforcement: "enforced" }
}

export const gitPack: PolicyPack = {
  id: "git",
  // 所有涉及 git 的角色都适用(空=全部);细化 role 映射在 loader
  validate(intent, ctx) {
    if (intent.kind !== "git.command") return { ok: true }
    return validateGitCommand(intent, ctx)
  },
}
