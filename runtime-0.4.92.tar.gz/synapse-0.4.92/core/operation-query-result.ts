/** A status/identity alone is not a query result. No domain facts are inferred. */
export function hasQueryBusinessResult(operation: { result?: unknown; resultProjection?: unknown }): boolean {
  if (operation.resultProjection !== undefined && operation.resultProjection !== null) return true
  let result = operation.result
  if (result && typeof result === "object" && !Array.isArray(result)
    && "kind" in result && result.kind === "result") {
    result = "result" in result ? result.result : undefined
  }
  return Array.isArray(result) || (result !== null && typeof result === "object" && Object.keys(result).length > 0)
}

export function isQueryResultMissing(operation: { status?: unknown; action?: unknown; result?: unknown; resultProjection?: unknown }): boolean {
  return operation.status === "executed" && operation.action === "query" && !hasQueryBusinessResult(operation)
}

export const QUERY_RESULT_MISSING_NOTICE = "Cerebro 查询回执缺少可信业务结果，无法确认查询范围、数量、条目或据此分析；executed 状态不能替代业务结果。"
