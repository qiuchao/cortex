import { lstatSync, readFileSync, realpathSync } from "node:fs"
import { isAbsolute, join, relative } from "node:path"
import { DoneContract, type DoneContract as DoneContractValue } from "./done-contract.ts"

export const PROJECT_DONE_CONTRACT_PATH = ".synapse/done-contract.json"
const MAX_CONTRACT_BYTES = 64 * 1024

/** Load a repository-declared done contract without following symlinks or escaping cwd. */
export function loadProjectDoneContract(cwd: string | undefined): DoneContractValue | undefined {
  if (!cwd || !isAbsolute(cwd)) return undefined
  const file = join(cwd, PROJECT_DONE_CONTRACT_PATH)
  try {
    const stat = lstatSync(file)
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > MAX_CONTRACT_BYTES) return undefined
    const realRoot = realpathSync(cwd)
    const realFile = realpathSync(file)
    const fromRoot = relative(realRoot, realFile)
    if (!fromRoot || isAbsolute(fromRoot) || fromRoot === ".." || fromRoot.startsWith(`..${process.platform === "win32" ? "\\" : "/"}`)) {
      return undefined
    }
    const parsedJson = JSON.parse(readFileSync(file, "utf8")) as unknown
    const parsed = DoneContract.safeParse(parsedJson)
    if (!parsed.success) return undefined
    // Project-declared contracts are repository-relative by definition.
    if (parsed.data.expected_artifacts.some((artifact) => !isSafeProjectArtifactPath(artifact.path))) {
      return undefined
    }
    return parsed.data
  } catch {
    return undefined
  }
}

export function isSafeProjectArtifactPath(path: string): boolean {
  return !portableAbsolute(path) && relativeDepth(path) > 0
}

function portableAbsolute(path: string): boolean {
  return isAbsolute(path) || /^[A-Za-z]:[\\/]/.test(path) || /^[/\\]{2}/.test(path)
}

function relativeDepth(path: string): number {
  const parts = path.replaceAll("\\", "/").split("/")
  let depth = 0
  for (const part of parts) {
    if (!part || part === ".") continue
    if (part === "..") {
      if (depth === 0) return -1
      depth--
    } else {
      depth++
    }
  }
  return depth
}
