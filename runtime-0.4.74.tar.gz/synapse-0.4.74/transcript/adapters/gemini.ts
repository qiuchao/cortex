import { readFileSync, statSync } from "node:fs"
import { dirname, join } from "node:path"

export interface GeminiSessionSnapshot {
  sessionId: string
  projectPath?: string
  timestamp: string
  messages: unknown[]
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function parseLines(content: string): unknown[] | undefined {
  const trimmed = content.trim()
  if (!trimmed) return undefined
  const lines: unknown[] = []
  try {
    for (const line of trimmed.split(/\r?\n/)) {
      if (line.trim()) lines.push(JSON.parse(line))
    }
  } catch {
    return undefined
  }
  return lines
}

function readProjectPath(file: string): string | undefined {
  try {
    const value = readFileSync(join(dirname(dirname(file)), ".project_root"), "utf8").trim()
    return value || undefined
  } catch {
    return undefined
  }
}

function sessionIdFromFile(file: string): string {
  const basename = file.split(/[/\\]/).pop() ?? file
  return basename.replace(/\.[^.]+$/, "")
}

function fileTimestamp(file: string): string {
  try {
    return statSync(file).mtime.toISOString()
  } catch {
    return new Date(0).toISOString()
  }
}

/** 兼容 Gemini 旧整文件 JSON 与新版 append-only JSONL。 */
export function parseGeminiSessionFile(file: string, content: string): GeminiSessionSnapshot | undefined {
  let records: unknown[]
  const trimmed = content.trim()
  if (!trimmed) return undefined
  try {
    const whole = JSON.parse(trimmed) as unknown
    records = Array.isArray(whole)
      ? [{ sessionId: sessionIdFromFile(file), messages: whole }]
      : [whole]
  } catch {
    const lines = parseLines(content)
    if (!lines) return undefined
    records = lines
  }

  const first = asRecord(records[0])
  const wholeMessages = Array.isArray(first?.["messages"]) ? first["messages"] as unknown[] : []
  const messages: unknown[] = [...wholeMessages]
  let sessionId = typeof first?.["sessionId"] === "string" ? first["sessionId"] : ""
  let timestamp = typeof first?.["lastUpdated"] === "string"
    ? first["lastUpdated"]
    : typeof first?.["startTime"] === "string" ? first["startTime"] : ""

  for (const value of records.slice(1)) {
    const record = asRecord(value)
    if (!record) continue
    const set = asRecord(record["$set"])
    if (set) {
      if (Array.isArray(set["messages"])) messages.push(...set["messages"] as unknown[])
      if (typeof set["lastUpdated"] === "string") timestamp = set["lastUpdated"]
      continue
    }
    if (record["type"] === "user" || record["type"] === "gemini") messages.push(record)
  }

  const deduplicated: unknown[] = []
  const seen = new Set<string>()
  for (const value of messages) {
    const record = asRecord(value)
    const id = typeof record?.["id"] === "string" ? record["id"] : undefined
    if (id && seen.has(id)) continue
    if (id) seen.add(id)
    deduplicated.push(value)
  }

  if (!sessionId) {
    const candidate = asRecord(deduplicated[0])?.["sessionId"]
    if (typeof candidate === "string") sessionId = candidate
  }
  if (!sessionId) sessionId = sessionIdFromFile(file)
  return {
    sessionId,
    projectPath: readProjectPath(file),
    timestamp: timestamp || fileTimestamp(file),
    messages: deduplicated,
  }
}
