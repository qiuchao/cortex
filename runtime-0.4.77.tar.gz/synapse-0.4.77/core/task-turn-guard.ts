import { createHash } from "node:crypto"
import { lstatSync, readFileSync, realpathSync } from "node:fs"
import { basename, dirname, isAbsolute, normalize, resolve } from "node:path"
import type { InjectRequest } from "../transport/contract.ts"
import type { GuardResult } from "./guard.ts"
import { readHookTool } from "./hook-tool.ts"
import { inspectCapabilityCommand } from "./capability-command.ts"
import { parseSafeCommandWords, parseSafeJsonPipeline } from "./safe-json-pipeline.ts"
import { quoteAgentCommandArgForLauncher } from "./agent-command-line.ts"
import { agentCommandShell, inferAgentCommandShell } from "./agent-command-line.ts"
import { bindTaskTurnEnvelope } from "./task-turn-envelope.ts"
import {
  AGENT_JSON_CHUNK_MAX_BYTES,
  AGENT_JSON_CHUNK_MAX_CHARS,
  AGENT_JSON_TRANSFER_MAX_BYTES,
  AGENT_JSON_TRANSFER_MAX_CHUNKS,
  decodeAgentJsonBase64Url,
} from "../runtime/agent-json-transfer.ts"
import {
  KnowledgeAgentExecuteRequestSchema,
  TaskCapabilityWriteCommandSchema,
  TaskCapabilityExecuteRequestSchema,
  type KnowledgeCapabilityBoundArgs,
  type KnowledgeCapabilityName,
} from "@cerebro/wire"

export type TaskTurnGuardMode = "task_required" | "knowledge_required" | "answer_only" | "local_artifact_only" | "local_implementation" | "local_diagnostic" | "ordinary"
export type CapabilityExecutionScope = "standalone"

export interface TaskTurnRoutePolicy {
  kind?: "task"
  launcher: string
  routeToken: string
  draftRequestId: string
  protocolVersion: string
  productionId: string
  allowedCommands: readonly string[]
  completionCommands: readonly string[]
  /** Trusted complete inputs for deterministic commands in this turn. */
  boundInputByCommand?: Readonly<Record<string, Readonly<Record<string, unknown>>>>
  /** Deterministic routes have no reason to inspect a command schema first. */
  allowCommandDescribe?: boolean
  attachmentHandle?: string
  attachmentPolicy?: "bug-upload" | "requirement-empty-check"
  /** A completed create draft must return to the user instead of unlocking unrelated tools. */
  answerOnlyAfterCompletion?: boolean
  /** Hash of Claude Code's exact hook context, used to authorize its spill-file read. */
  injectedContextSha256?: string
}

export interface KnowledgeTurnRoutePolicy {
  kind: "knowledge"
  launcher: string
  routeToken: string
  protocolVersion: string
  client: InjectRequest["client"]
  sessionId: string
  turnId: string
  allowedCommands: readonly string[]
  completionCommands: readonly string[]
  /** Trusted user-message arguments, isolated by the selected capability. */
  boundArgsByCapability?: KnowledgeCapabilityBoundArgs
  answerOnlyAfterCompletion?: boolean
  injectedContextSha256?: string
}

export type CapabilityTurnRoutePolicy = TaskTurnRoutePolicy | KnowledgeTurnRoutePolicy

interface TaskTurnGuardPolicyBase {
  reason: string
}

export type TaskTurnGuardPolicy =
  | (TaskTurnGuardPolicyBase & { mode: "task_required"; route: TaskTurnRoutePolicy })
  | (TaskTurnGuardPolicyBase & { mode: "knowledge_required"; route: KnowledgeTurnRoutePolicy })
  | (TaskTurnGuardPolicyBase & {
      mode: Exclude<TaskTurnGuardMode, "task_required" | "knowledge_required">
      route?: undefined
    })

export interface TaskTurnGuardRegistryOptions {
  now?: () => number
  ttlMs?: number
  maxEntries?: number
}

export interface TaskTurnExecutionAuthorization {
  tracked: boolean
  allowed: boolean
  reason?: string
  request?: unknown
  command?: string
  completesRoute?: boolean
  /** Exact user text bound to a Knowledge route; never accepted from the model envelope. */
  knowledgeUserInput?: string
  attachmentPreparation?: {
    handle: string
    policy: "bug-upload" | "requirement-empty-check"
  }
}

export interface TaskTurnActivation {
  sessionKey: string
  turnKey: string
  generation: number
}

export interface TaskTurnGuardRegistry {
  beginTurn(request: InjectRequest): TaskTurnActivation | undefined
  isActive(activation: TaskTurnActivation | undefined): boolean
  register(request: InjectRequest, policy: TaskTurnGuardPolicy, activation?: TaskTurnActivation): void
  endTurn(request: Pick<InjectRequest, "client" | "session_id" | "turn_id">, activation?: TaskTurnActivation): void
  evaluate(client: string, raw: unknown): GuardResult | undefined
  authorizeExecution(
    routeToken: string | undefined,
    raw: unknown,
    expectedClient?: string,
    executionScope?: CapabilityExecutionScope,
  ): TaskTurnExecutionAuthorization
  markAttachmentsPrepared(attachmentHandle: string, attachmentTokens: readonly string[]): boolean
  markRouted(routeToken: string, command: string): boolean
}

type TaskTurnGuardState = TaskTurnGuardPolicy & {
  key: string
  client: InjectRequest["client"]
  sessionId: string
  expiresAt: number
  routed: boolean
  userInput: string
  preparedAttachmentTokens?: string[]
}

interface ActiveTaskTurn {
  turnKey: string
  generation: number
  expiresAt: number
}

const DEFAULT_TTL_MS = 10 * 60_000
const DEFAULT_MAX_ENTRIES = 1_024

export function createTaskTurnGuardRegistry(
  options: TaskTurnGuardRegistryOptions = {},
): TaskTurnGuardRegistry {
  const now = options.now ?? Date.now
  const ttlMs = options.ttlMs ?? DEFAULT_TTL_MS
  const maxEntries = options.maxEntries ?? DEFAULT_MAX_ENTRIES
  const states = new Map<string, TaskTurnGuardState>()
  const tokenKeys = new Map<string, string>()
  const attachmentKeys = new Map<string, string>()
  const activeTurns = new Map<string, ActiveTaskTurn>()
  const revokedTurns = new Map<string, { expiresAt: number; userInput?: string }>()
  const revokedActiveTurns = new Map<string, { turnKey: string; expiresAt: number }>()
  let generation = 0

  const remove = (key: string): void => {
    const state = states.get(key)
    if (state?.route?.routeToken) tokenKeys.delete(state.route.routeToken)
    if (isTaskRoute(state?.route) && state.route.attachmentHandle) {
      attachmentKeys.delete(state.route.attachmentHandle)
    }
    states.delete(key)
  }
  const forgetRevoked = (key: string): void => {
    revokedTurns.delete(key)
    for (const [sessionKey, revoked] of revokedActiveTurns) {
      if (revoked.turnKey === key) revokedActiveTurns.delete(sessionKey)
    }
  }
  const revoke = (key: string, current: number): void => {
    const state = states.get(key)
    remove(key)
    forgetRevoked(key)
    revokedTurns.set(key, { expiresAt: current + ttlMs, ...(state?.userInput ? { userInput: state.userInput } : {}) })
    while (revokedTurns.size > maxEntries) {
      forgetRevoked(revokedTurns.keys().next().value as string)
    }
  }
  const prune = (current: number): void => {
    for (const [key, state] of states) if (state.expiresAt <= current) remove(key)
    for (const [key, active] of activeTurns) if (active.expiresAt <= current) activeTurns.delete(key)
    for (const [key, revoked] of revokedTurns) if (revoked.expiresAt <= current) forgetRevoked(key)
    for (const [key, revoked] of revokedActiveTurns) {
      if (revoked.expiresAt <= current) revokedActiveTurns.delete(key)
    }
  }
  const stateForToken = (routeToken: string): TaskTurnGuardState | undefined => {
    const key = tokenKeys.get(routeToken)
    if (!key) return undefined
    return states.get(key)
  }

  return {
    beginTurn(request) {
      const current = now()
      prune(current)
      const sessionKey = taskSessionKey(request.client, request.session_id)
      const key = turnKey(request.client, request.session_id, request.turn_id)
      if (!sessionKey || !key) return undefined
      const previous = activeTurns.get(sessionKey)
      const revoked = revokedTurns.get(key)
      if (revoked !== undefined) {
        if (previous && previous.turnKey !== key && (!revoked.userInput || revoked.userInput === request.user_input)) {
          revokedActiveTurns.set(sessionKey, { turnKey: key, expiresAt: revoked.expiresAt })
          return undefined
        }
        forgetRevoked(key)
      }
      revokedActiveTurns.delete(sessionKey)
      if (previous?.turnKey === key) {
        previous.expiresAt = current + ttlMs
        return { sessionKey, turnKey: key, generation: previous.generation }
      } else if (previous) {
        revoke(previous.turnKey, current)
      }
      const activation = { sessionKey, turnKey: key, generation: ++generation }
      activeTurns.set(sessionKey, { ...activation, expiresAt: current + ttlMs })
      while (activeTurns.size > maxEntries) {
        const oldestSession = activeTurns.keys().next().value as string
        const oldestTurn = activeTurns.get(oldestSession)
        if (oldestTurn) {
          revoke(oldestTurn.turnKey, current)
          const revoked = revokedTurns.get(oldestTurn.turnKey)
          if (revoked !== undefined) {
            revokedActiveTurns.set(oldestSession, { turnKey: oldestTurn.turnKey, expiresAt: revoked.expiresAt })
          }
        }
        activeTurns.delete(oldestSession)
      }
      return activation
    },
    isActive(activation) {
      if (!activation) return false
      prune(now())
      const active = activeTurns.get(activation.sessionKey)
      return Boolean(active
        && active.turnKey === activation.turnKey
        && active.generation === activation.generation)
    },
    register(request, policy, activation) {
      const current = now()
      prune(current)
      const currentActivation = activation ?? this.beginTurn(request)
      if (!currentActivation) return
      const active = activeTurns.get(currentActivation.sessionKey)
      if (!active
        || active.turnKey !== currentActivation.turnKey
        || active.generation !== currentActivation.generation) return
      const key = turnKey(request.client, request.session_id, request.turn_id)
      if (!key || key !== currentActivation.turnKey) return
      remove(key)
      forgetRevoked(key)
      const route = policy.route
      if ((policy.mode === "task_required" || policy.mode === "knowledge_required")
        && !validRoutePolicy(policy.mode, route)) {
        policy = {
          mode: "answer_only",
          reason: "本轮 capability 路由凭据不完整，不得调用本地、外部协议、浏览器或桌面 UI 工具。",
        }
      }
      const state: TaskTurnGuardState = {
        ...policy,
        key,
        client: request.client,
        sessionId: request.session_id!,
        userInput: request.user_input,
        expiresAt: current + ttlMs,
        routed: false,
      }
      states.set(key, state)
      active.expiresAt = state.expiresAt
      if (state.route) tokenKeys.set(state.route.routeToken, key)
      if (isTaskRoute(state.route) && state.route.attachmentHandle) {
        attachmentKeys.set(state.route.attachmentHandle, key)
      }
      while (states.size > maxEntries) revoke(states.keys().next().value as string, current)
    },
    endTurn(request, activation) {
      const current = now()
      prune(current)
      const sessionKey = activation?.sessionKey ?? taskSessionKey(request.client, request.session_id)
      const key = activation?.turnKey ?? turnKey(request.client, request.session_id, request.turn_id)
      if (!sessionKey || !key) return
      const active = activeTurns.get(sessionKey)
      if (activation && (!active
        || active.turnKey !== activation.turnKey
        || active.generation !== activation.generation)) return
      if (active?.turnKey === key) activeTurns.delete(sessionKey)
      revoke(key, current)
      const revoked = revokedTurns.get(key)
      if (revoked !== undefined) revokedActiveTurns.set(sessionKey, { turnKey: key, expiresAt: revoked.expiresAt })
    },
    evaluate(client, raw) {
      prune(now())
      const identity = hookTurnIdentity(raw)
      const sessionKey = taskSessionKey(client, identity.sessionId)
      if (!sessionKey) return undefined
      const key = turnKey(client, identity.sessionId, identity.turnId)
        ?? activeTurns.get(sessionKey)?.turnKey
        ?? revokedActiveTurns.get(sessionKey)?.turnKey
      if (!key) return undefined
      const state = states.get(key)
      if (!state) {
        return revokedTurns.has(key)
          ? deny("该 Task 回合已被后续用户回合取代，拒绝执行迟到的工具调用。")
          : undefined
      }
      if (state.mode === "ordinary") {
        const tool = readHookTool(raw)
        if (tool.error) return deny(tool.error)
        const ordinaryCommand = tool.command
        return ordinaryCommand && isAgentCapabilityCommand(ordinaryCommand, tool.powershell ?? agentCommandShell(process.platform, client) === "powershell")
          ? deny("普通回合没有获得 Cerebro capability 授权；拒绝执行历史上下文中的 Synapse agent capability 命令。")
          : undefined
      }
      if (state.mode === "answer_only") return deny(state.reason)
      if (state.mode === "local_artifact_only") {
        return isLocalArtifactTool(raw) ? undefined : deny(state.reason)
      }
      if (state.mode === "local_implementation" || state.mode === "local_diagnostic") {
        return isLocalImplementationTool(raw, client) ? undefined : deny(state.reason)
      }
      if (state.routed) {
        if (state.route?.answerOnlyAfterCompletion) {
          return deny("Synapse 已生成本轮待确认操作；不得再次调用工具、重复生成草稿或改用浏览器/桌面 UI。")
        }
        // A read may legitimately require more than one typed Task call (for
        // example list followed by detail). Keep the exact route available,
        // but never unlock unrelated local, browser, desktop, or MCP tools.
      }

      // Claude Code persists oversized UserPromptSubmit additionalContext to a
      // session-local file and asks the model to Read it. This is transport,
      // not repository exploration: authorize only the exact hashed payload
      // that Synapse injected for this controlled turn.
      if (client === "claude-code" && state.route
        && isAuthorizedClaudeContextRead(raw, state.sessionId, state.route.injectedContextSha256)) {
        return undefined
      }

      const command = hookCommand(raw)
      if (command && state.route) {
        const pipeline = validateAuthorizedExecutePipeline(command, state.route, state.preparedAttachmentTokens)
        if (pipeline.matched) {
          // PreToolUse only authorizes this exact call. The daemon marks the turn
          // routed after the typed broker has returned success.
          return pipeline.allowed ? undefined : deny(pipeline.reason)
        }
      }
      if (command && isTaskRoute(state.route) && state.route.allowCommandDescribe !== false
        && isAuthorizedTaskDescribeCommand(command, state.route)) return undefined
      return deny(
        state.mode === "knowledge_required"
          ? "本轮是明确的 Knowledge 操作。首个业务工具必须是注入中携带本轮令牌的完整 Synapse capability 管道；不得先浏览仓库、调用其他外部协议、操作浏览器/主脑桌面客户端或用 UI 自动化模拟人工操作。"
          : "本轮是可执行的需求/Bug/迭代操作。首个业务工具必须是注入中携带本轮令牌的完整 Synapse Task 管道；不得先浏览仓库、调用外部协议、操作浏览器/主脑桌面客户端或用 UI 自动化模拟人工操作。",
      )
    },
    authorizeExecution(routeToken, raw, expectedClient, executionScope) {
      prune(now())
      const identity = capabilityExecutionIdentity(raw)
      const taskCapabilityShape = isTaskCapabilityShape(raw)
      if (executionScope === "standalone" && activeTurns.size > 0) {
        return {
          tracked: true,
          allowed: false,
          reason: "standalone execution is unavailable while a guarded turn is active",
        }
      }
      if (executionScope === "standalone" && identity.kind === "incomplete") {
        return {
          tracked: true,
          allowed: false,
          reason: "standalone execution requires a complete request identity or an identity-free Task write envelope",
        }
      }
      if (executionScope === "standalone" && identity.kind === "complete" && taskCapabilityShape) {
        return {
          tracked: true,
          allowed: false,
          reason: "standalone Task execution must be an identity-free write envelope",
        }
      }
      if (!routeToken && identity.kind === "incomplete") {
        return {
          tracked: true,
          allowed: false,
          reason: "turn-scoped capability execution requires a complete request identity or an active turn token",
        }
      }
      if (!routeToken && executionScope !== "standalone" && taskCapabilityShape) {
        return {
          tracked: true,
          allowed: false,
          reason: "Task capability execution requires a route token; standalone scope must be explicit",
        }
      }
      if (!routeToken) {
        if (identity.kind === "complete"
          && expectedClient?.trim()
          && identity.client !== expectedClient.trim()) {
          return {
            tracked: true,
            allowed: false,
            reason: "capability request client does not match the authenticated client",
          }
        }
        const exactKey = identity.kind === "complete"
          ? turnKey(identity.client, identity.sessionId, identity.turnId)
          : undefined
        const sessionKey = identity.kind === "complete"
          ? taskSessionKey(identity.client, identity.sessionId)
          : undefined
        const activeKey = sessionKey
          ? activeTurns.get(sessionKey)?.turnKey ?? revokedActiveTurns.get(sessionKey)?.turnKey
          : undefined
        const key = exactKey ?? activeKey
        const state = key ? states.get(key) : undefined
        if (state || key && revokedTurns.has(key) || activeKey) {
          return { tracked: true, allowed: false, reason: "turn-scoped capability execution requires the active turn token" }
        }
        if (executionScope !== "standalone" && identity.kind === "complete" && activeTurns.size > 0) {
          return {
            tracked: true,
            allowed: false,
            reason: "standalone scope must be explicit for direct Knowledge capability execution",
          }
        }
        if (executionScope !== "standalone") {
          return {
            tracked: true,
            allowed: false,
            reason: identity.kind === "none"
              ? "identity-free Task capability execution requires a route token; standalone scope must be explicit"
              : "standalone scope must be explicit for direct Knowledge capability execution",
          }
        }
        if (!standaloneExecutionRequest(raw)) {
          return {
            tracked: true,
            allowed: false,
            reason: "standalone execution only permits a valid Task write or complete Knowledge envelope",
          }
        }
        return { tracked: false, allowed: true }
      }
      if (executionScope === "standalone") {
        return {
          tracked: true,
          allowed: false,
          reason: "standalone execution cannot carry a turn route token",
        }
      }
      const token = routeToken.trim()
      const state = stateForToken(token)
      if (!state || !state.route || (state.mode !== "task_required" && state.mode !== "knowledge_required")) {
        return { tracked: true, allowed: false, reason: "capability turn token is invalid or expired" }
      }
      if (expectedClient?.trim() && state.client !== expectedClient.trim()) {
        return {
          tracked: true,
          allowed: false,
          reason: "capability turn token does not match the authenticated client",
        }
      }
      if (state.routed && state.route.answerOnlyAfterCompletion) {
        return { tracked: true, allowed: false, reason: "Task turn already completed its pending operation" }
      }
      const taskRoute = isTaskRoute(state.route) ? state.route : undefined
      const knowledgeRoute = isKnowledgeRoute(state.route) ? state.route : undefined
      if (!taskRoute && !knowledgeRoute) {
        return { tracked: true, allowed: false, reason: "capability turn route type does not match its policy" }
      }
      const validated = taskRoute
        ? validateTaskEnvelope(raw, taskRoute, state.preparedAttachmentTokens)
        : validateKnowledgeEnvelope(raw, knowledgeRoute!)
      return validated.ok
        ? {
            tracked: true,
            allowed: true,
            request: validated.request,
            command: validated.command,
            completesRoute: validated.completesRoute,
            ...(knowledgeRoute ? { knowledgeUserInput: state.userInput } : {}),
            ...(validated.needsAttachmentPreparation && taskRoute?.attachmentHandle && taskRoute.attachmentPolicy
              ? {
                  attachmentPreparation: {
                    handle: taskRoute.attachmentHandle,
                    policy: taskRoute.attachmentPolicy,
                  },
                }
              : {}),
          }
        : { tracked: true, allowed: false, reason: validated.reason }
    },
    markAttachmentsPrepared(attachmentHandle, attachmentTokens) {
      prune(now())
      const key = attachmentKeys.get(attachmentHandle.trim())
      const state = key ? states.get(key) : undefined
      const route = state?.route
      if (!state || state.mode !== "task_required" || !isTaskRoute(route)
        || route.attachmentHandle !== attachmentHandle.trim()) return false
      const tokens = [...attachmentTokens]
      if (!tokens.every((token) => typeof token === "string" && token.trim() && token.length <= 512)
        || new Set(tokens).size !== tokens.length) return false
      if (route.attachmentPolicy === "requirement-empty-check" && tokens.length > 0) return false
      if (state.preparedAttachmentTokens
        && !sameStringArray(state.preparedAttachmentTokens, tokens)) return false
      state.preparedAttachmentTokens = tokens
      return true
    },
    markRouted(routeToken, command) {
      prune(now())
      const state = stateForToken(routeToken.trim())
      if (!state || (state.mode !== "task_required" && state.mode !== "knowledge_required")
        || !state.route?.completionCommands.includes(command)) return false
      state.routed = true
      return true
    },
  }
}

function standaloneTaskExecutionRequest(raw: unknown): boolean {
  const parsed = TaskCapabilityExecuteRequestSchema.safeParse(raw)
  if (!parsed.success || !("requestId" in parsed.data)) return false
  return TaskCapabilityWriteCommandSchema.safeParse(parsed.data.command).success
}

function standaloneExecutionRequest(raw: unknown): boolean {
  return standaloneTaskExecutionRequest(raw) || standaloneKnowledgeExecutionRequest(raw)
}

function standaloneKnowledgeExecutionRequest(raw: unknown): boolean {
  const parsed = KnowledgeAgentExecuteRequestSchema.safeParse(raw)
  return parsed.success && parsed.data.confirmation === undefined
}

function isTaskCapabilityShape(raw: unknown): boolean {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return false
  const record = raw as Record<string, unknown>
  return typeof record.protocolVersion === "string"
    && typeof record.productionId === "string"
    && typeof record.command === "string"
    && "input" in record
}

function validRoutePolicy(
  mode: "task_required" | "knowledge_required",
  route: CapabilityTurnRoutePolicy | undefined,
): route is CapabilityTurnRoutePolicy {
  if (mode === "knowledge_required") {
    return Boolean(
      isKnowledgeRoute(route)
        && route.launcher.trim()
        && route.routeToken.trim()
        && route.protocolVersion.trim()
        && route.client
        && route.sessionId.trim()
        && route.turnId.trim()
        && route.allowedCommands.length > 0
        && route.completionCommands.length > 0
        && route.completionCommands.every((command) => route.allowedCommands.includes(command))
        && validKnowledgeBoundArgs(route),
    )
  }
  return Boolean(
    isTaskRoute(route)
      && route.launcher.trim()
      && route.routeToken.trim()
      && route.draftRequestId.trim()
      && route.protocolVersion.trim()
      && route.productionId.trim()
      && route.allowedCommands.length > 0
      && route.completionCommands.length > 0
      && route.completionCommands.every((command) => route.allowedCommands.includes(command))
      && validTaskBoundInputs(route)
      && Boolean(route.attachmentHandle) === Boolean(route.attachmentPolicy)
      && (route.attachmentPolicy !== "bug-upload" || route.allowedCommands.includes("bug.create"))
      && (route.attachmentPolicy !== "requirement-empty-check" || route.allowedCommands.includes("requirement.create")),
  )
}

export function hashTaskInjectedContext(context: string): string {
  return createHash("sha256").update(context.trim()).digest("hex")
}

function turnKey(client: string, sessionId?: string, turnId?: string): string | undefined {
  const session = sessionId?.trim()
  const turn = turnId?.trim()
  return client && session && turn ? `${client}\n${session}\n${turn}` : undefined
}

function taskSessionKey(client: string, sessionId?: string): string | undefined {
  const session = sessionId?.trim()
  return client && session ? `${client}\n${session}` : undefined
}

function isKnowledgeRoute(
  route: CapabilityTurnRoutePolicy | undefined,
): route is KnowledgeTurnRoutePolicy {
  return route?.kind === "knowledge"
}

function isTaskRoute(
  route: CapabilityTurnRoutePolicy | undefined,
): route is TaskTurnRoutePolicy {
  return Boolean(route && route.kind !== "knowledge")
}

function hookTurnIdentity(raw: unknown): { sessionId?: string; turnId?: string } {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {}
  const record = raw as Record<string, unknown>
  return {
    sessionId: stringField(record, "session_id", "sessionId"),
    turnId: stringField(record, "turn_id", "turnId"),
  }
}

function hookCommand(raw: unknown): string {
  return readHookTool(raw).command ?? ""
}

function hookToolName(raw: unknown): string {
  return readHookTool(raw).name
}

function isLocalImplementationTool(raw: unknown, client: string): boolean {
  const tool = readHookTool(raw)
  if (tool.kind === "unknown" || tool.error) return false
  if (tool.kind !== "shell") return true
  const command = tool.command ?? ""
  const powershell = tool.powershell ?? agentCommandShell(process.platform, client) === "powershell"
  const analysis = inspectCapabilityCommand(command, powershell || inferAgentCommandShell(command) === "powershell")
  return analysis.kind !== "capability" && !isExternalOrUiCommand(analysis.commands ?? [])
}

function isLocalArtifactTool(raw: unknown): boolean {
  return readHookTool(raw).kind === "file-write"
}

function isAgentCapabilityCommand(command: string, powershell = false): boolean {
  return inspectCapabilityCommand(command, powershell || inferAgentCommandShell(command) === "powershell").kind === "capability"
}

function isExternalOrUiCommand(commands: readonly string[][]): boolean {
  return commands.some((words) => {
    const executable = (words[0] ?? "").split(/[\\/]/).pop()?.replace(/\.exe$/i, "").toLowerCase() ?? ""
    if (/^(?:curl|wget|http|https|ftp|sftp|ssh|scp|nc|ncat|netcat|telnet|websocat|playwright|selenium|chromium|chromium-browser|google-chrome|chrome|firefox|msedge|open|xdg-open|gio|osascript|xdotool|wmctrl|cliclick|cerebro|invoke-webrequest|invoke-restmethod|start-process|iwr|irm)$/.test(executable)) return true
    if (executable === "git" && /^(?:clone|fetch|pull|push|ls-remote)$/.test(words[1] ?? "")) return true
    if (/^(?:npx|bunx|pnpm|yarn)$/.test(executable)) {
      const args = words.slice(1)
      if (/^(?:pnpm|yarn)$/.test(executable) && args.shift() !== "dlx") return false
      if (args[0] === "--yes") args.shift()
      if (/^(?:@[^/]+\/)?(?:playwright|selenium)$/.test(args[0] ?? "")) return true
    }
    // Preserve the existing bounded local-diagnostic rule for explicit inline
    // network scripts. This is not an attempt to infer arbitrary program effects.
    const source = words.slice(2).join(" ")
    if (/^(?:node|nodejs|bun|deno)$/.test(executable) && /^(?:--eval|-e)$/.test(words[1] ?? "")) {
      return /https?:\/\/|\bfetch\s*\(|\b(?:https?|net)\s*\.|require\s*\(\s*['"](?:node:)?(?:https?|net)|from\s+['"](?:node:)?(?:https?|net)/i.test(source)
    }
    if (/^(?:python|python3|py)$/.test(executable) && /^(?:-c|\/c)$/.test(words[1] ?? "")) {
      return /https?:\/\/|urllib|requests|httpx|aiohttp|socket/i.test(source)
    }
    return false
  })
}

function isAuthorizedClaudeContextRead(
  raw: unknown,
  sessionId: string,
  expectedHash?: string,
): boolean {
  if (!expectedHash || hookToolName(raw) !== "Read") return false
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return false
  const record = raw as Record<string, unknown>
  const input = record["tool_input"]
  if (!input || typeof input !== "object" || Array.isArray(input)) return false
  const fields = input as Record<string, unknown>
  if (Object.keys(fields).some((key) => !["file_path", "offset", "limit"].includes(key))) return false
  const filePath = fields["file_path"]
  if (typeof filePath !== "string" || !isAbsolute(filePath)) return false
  if (fields["offset"] !== undefined && (!Number.isInteger(fields["offset"]) || Number(fields["offset"]) < 0)) return false
  if (fields["limit"] !== undefined && (!Number.isInteger(fields["limit"]) || Number(fields["limit"]) < 1)) return false

  const normalized = normalize(filePath)
  if (basename(dirname(normalized)) !== "tool-results") return false
  if (basename(dirname(dirname(normalized))) !== sessionId) return false
  if (!/^hook-[a-f0-9-]+-\d+-additionalContext\.txt$/i.test(basename(normalized))) return false
  try {
    const stat = lstatSync(normalized)
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 2 * 1024 * 1024) return false
    if (realpathSync(normalized) !== resolve(normalized)) return false
    return hashTaskInjectedContext(readFileSync(normalized, "utf8")) === expectedHash
  } catch {
    return false
  }
}



function stringField(record: Record<string, unknown>, ...names: string[]): string | undefined {
  for (const name of names) {
    const value = record[name]
    if (typeof value === "string" && value.trim()) return value.trim()
  }
  return undefined
}

function validateAuthorizedExecutePipeline(
  command: string,
  route: CapabilityTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  return isTaskRoute(route)
    ? validateTaskExecutePipeline(command, route, preparedAttachmentTokens)
    : validateKnowledgeExecutePipeline(command, route)
}

function validateTaskExecutePipeline(
  command: string,
  route: TaskTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  const pipeline = parseJsonPipeline(command)
  const payload: AgentJsonArgvPayload = pipeline && sameSafeCommand(pipeline.receiver, taskExecuteReceiver(route), route.launcher)
    ? { matched: true, ready: true, value: pipeline.payload }
    : parseAgentJsonArgvExecute(command, route)
  if (!payload.matched) return { matched: false }
  if (!payload.ready) {
    return payload.valid
      ? { matched: true, allowed: true }
      : { matched: true, allowed: false, reason: payload.reason }
  }
  const validated = validateTaskEnvelope(payload.value, route, preparedAttachmentTokens)
  return validated.ok
    ? { matched: true, allowed: true }
    : { matched: true, allowed: false, reason: validated.reason }
}

function validateKnowledgeExecutePipeline(
  command: string,
  route: KnowledgeTurnRoutePolicy,
): { matched: false } | { matched: true; allowed: true } | { matched: true; allowed: false; reason: string } {
  const pipeline = parseJsonPipeline(command)
  const payload: AgentJsonArgvPayload = pipeline && sameSafeCommand(pipeline.receiver, agentExecuteReceiver(route), route.launcher)
    ? { matched: true, ready: true, value: pipeline.payload }
    : parseAgentJsonArgvExecute(command, route)
  if (!payload.matched) return { matched: false }
  if (!payload.ready) {
    return payload.valid
      ? { matched: true, allowed: true }
      : { matched: true, allowed: false, reason: payload.reason }
  }
  const validated = validateKnowledgeEnvelope(payload.value, route)
  return validated.ok
    ? { matched: true, allowed: true }
    : { matched: true, allowed: false, reason: validated.reason }
}

type CapabilityExecutionIdentity =
  | { kind: "none" }
  | { kind: "incomplete" }
  | {
      kind: "complete"
      client: string
      sessionId: string
      turnId: string
    }

function capabilityExecutionIdentity(raw: unknown): CapabilityExecutionIdentity {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { kind: "none" }
  const record = raw as Record<string, unknown>
  const hasClient = "client" in record
  const hasSessionId = "sessionId" in record || "session_id" in record
  const hasTurnId = "turnId" in record || "turn_id" in record
  const hasKnowledgeCapability = "capability" in record
  const client = stringField(record, "client")
  const sessionId = stringField(record, "sessionId", "session_id")
  const turnId = stringField(record, "turnId", "turn_id")
  if (client && sessionId && turnId) {
    return { kind: "complete", client, sessionId, turnId }
  }
  return hasClient || hasSessionId || hasTurnId || hasKnowledgeCapability
    ? { kind: "incomplete" }
    : { kind: "none" }
}

function validateKnowledgeEnvelope(
  raw: unknown,
  route: KnowledgeTurnRoutePolicy,
): {
  ok: true
  request: unknown
  command: string
  completesRoute: boolean
  needsAttachmentPreparation: false
} | { ok: false; reason: string } {
  const parsed = KnowledgeAgentExecuteRequestSchema.safeParse(bindKnowledgeRouteArgs(raw, route))
  if (!parsed.success) {
    const issues = parsed.error.issues
      .slice(0, 6)
      .map((issue) => `${issue.path.join(".") || "request"}: ${issue.message}`)
      .join("; ")
    return { ok: false, reason: `Knowledge envelope schema validation failed: ${issues}` }
  }
  const request = parsed.data
  if (request.confirmation) {
    return { ok: false, reason: "Knowledge confirmation is accepted only from a new explicit user turn" }
  }
  if (request.protocolVersion !== route.protocolVersion) {
    return { ok: false, reason: "Knowledge envelope protocolVersion does not match this turn" }
  }
  if (request.client !== route.client
    || request.sessionId !== route.sessionId
    || request.turnId !== route.turnId) {
    return { ok: false, reason: "Knowledge envelope identity does not match this turn" }
  }
  if (!route.allowedCommands.includes(request.capability)) {
    return { ok: false, reason: "Knowledge envelope capability is unavailable in this turn" }
  }
  return {
    ok: true,
    request,
    command: request.capability,
    completesRoute: route.completionCommands.includes(request.capability),
    needsAttachmentPreparation: false,
  }
}

function bindKnowledgeRouteArgs(raw: unknown, route: KnowledgeTurnRoutePolicy): unknown {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return raw
  const request = raw as Record<string, unknown>
  const capability = request["capability"]
  if (typeof capability !== "string") return raw
  const boundArgs = route.boundArgsByCapability?.[capability as KnowledgeCapabilityName]
  if (!boundArgs || Object.keys(boundArgs).length === 0) return raw
  const modelArgs = request["args"] && typeof request["args"] === "object" && !Array.isArray(request["args"])
    ? request["args"] as Record<string, unknown>
    : {}
  return { ...request, args: { ...modelArgs, ...boundArgs } }
}

function validKnowledgeBoundArgs(route: KnowledgeTurnRoutePolicy): boolean {
  return Object.entries(route.boundArgsByCapability ?? {}).every(([capability, args]) => (
    route.allowedCommands.includes(capability)
      && args !== null
      && typeof args === "object"
      && !Array.isArray(args)
  ))
}

function validateTaskEnvelope(
  raw: unknown,
  route: TaskTurnRoutePolicy,
  preparedAttachmentTokens?: readonly string[],
): {
  ok: true
  request: unknown
  command: string
  completesRoute: boolean
  needsAttachmentPreparation: boolean
} | { ok: false; reason: string } {
  const bound = bindTaskTurnEnvelope(bindTaskRouteInput(raw, route), {
    draftRequestId: route.draftRequestId,
    allowMatchingRequestId: true,
  })
  if (!bound.ok) return bound
  if (bound.request.protocolVersion !== route.protocolVersion) {
    return { ok: false, reason: "Task envelope protocolVersion does not match this turn" }
  }
  if (bound.request.productionId !== route.productionId) {
    return { ok: false, reason: "Task envelope productionId does not match this turn" }
  }
  if (!route.allowedCommands.includes(bound.command)) {
    return { ok: false, reason: "Task envelope command is unavailable in this turn" }
  }
  let trustedRequest: unknown = bound.request
  let needsAttachmentPreparation = false
  if (bound.command === "bug.create" && route.attachmentPolicy === "bug-upload") {
    const input = bound.request.input as Record<string, unknown>
    const supplied = input["attachmentTokens"]
    if (supplied !== undefined) {
      return { ok: false, reason: "bug.create attachmentTokens must be omitted and bound by Synapse for this turn" }
    }
    if (!preparedAttachmentTokens) {
      needsAttachmentPreparation = true
    } else {
      trustedRequest = {
        ...bound.request,
        input: { ...input, attachmentTokens: [...preparedAttachmentTokens] },
      }
    }
  }
  if (bound.command === "requirement.create" && route.attachmentPolicy === "requirement-empty-check") {
    const input = bound.request.input as Record<string, unknown>
    if (input["attachmentTokens"] !== undefined) {
      return { ok: false, reason: "requirement.create does not accept attachmentTokens" }
    }
    if (!preparedAttachmentTokens) {
      needsAttachmentPreparation = true
    }
    if (preparedAttachmentTokens && preparedAttachmentTokens.length > 0) {
      return { ok: false, reason: "requirement.create does not support current-turn attachments" }
    }
  }
  return {
    ok: true,
    request: trustedRequest,
    command: bound.command,
    completesRoute: route.completionCommands.includes(bound.command),
    needsAttachmentPreparation,
  }
}

function bindTaskRouteInput(raw: unknown, route: TaskTurnRoutePolicy): unknown {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return raw
  const request = raw as Record<string, unknown>
  const command = request["command"]
  if (typeof command !== "string") return raw
  const input = route.boundInputByCommand?.[command]
  return input ? { ...request, input: { ...input } } : raw
}

function validTaskBoundInputs(route: TaskTurnRoutePolicy): boolean {
  return Object.entries(route.boundInputByCommand ?? {}).every(([command, input]) => (
    route.allowedCommands.includes(command)
      && input !== null
      && typeof input === "object"
      && !Array.isArray(input)
  ))
}

function sameStringArray(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index])
}

function agentExecuteReceiver(route: CapabilityTurnRoutePolicy): string {
  return `${route.launcher} agent execute --stdin --turn-token ${quoteAgentCommandArgForLauncher(route.routeToken, route.launcher)}`
}

function taskExecuteReceiver(route: TaskTurnRoutePolicy): string {
  return agentExecuteReceiver(route)
}

function isAuthorizedTaskDescribeCommand(command: string, route: TaskTurnRoutePolicy): boolean {
  const value = command.trim()
  if (!value) return false
  return route.allowedCommands.some((capability) => sameSafeCommand(value, [
    route.launcher,
    "agent describe --task-only --json --production-id",
    quoteAgentCommandArgForLauncher(route.productionId, route.launcher),
    "--capability",
    quoteAgentCommandArgForLauncher(capability, route.launcher),
  ].join(" "), route.launcher))
}

function sameSafeCommand(actual: string, expected: string, launcher: string): boolean {
  const powershell = inferAgentCommandShell(launcher) === "powershell"
  const actualWords = parseSafeCommandWords(actual, powershell)
  const expectedWords = parseSafeCommandWords(expected, powershell)
  return Boolean(
    actualWords
      && expectedWords
      && actualWords.length === expectedWords.length
      && actualWords.every((word, index) => word === expectedWords[index]),
  )
}

function parseJsonPipeline(command: string): { payload: unknown; receiver: string } | undefined {
  return parseSafeJsonPipeline(command)
}

type AgentJsonArgvPayload =
  | { matched: false }
  | { matched: true; ready: true; value: unknown }
  | { matched: true; ready: false; valid: true }
  | { matched: true; ready: false; valid: false; reason: string }

function parseAgentJsonArgvExecute(
  command: string,
  route: CapabilityTurnRoutePolicy,
): AgentJsonArgvPayload {
  const powershell = inferAgentCommandShell(route.launcher) === "powershell"
  const words = parseSafeCommandWords(command, powershell)
  const launcherWords = parseSafeCommandWords(route.launcher, powershell)
  if (!words || !launcherWords || !startsWithWords(words, launcherWords)) return { matched: false }
  const args = words.slice(launcherWords.length)
  if (args[0] !== "agent" || args[1] !== "execute") return { matched: false }

  const fail = (reason: string): AgentJsonArgvPayload => ({
    matched: true,
    ready: false,
    valid: false,
    reason,
  })
  const token = args.at(-2) === "--turn-token" ? args.at(-1) : undefined
  if (token !== route.routeToken) return fail("agent execute argv transport has an invalid or missing turn token")
  const transport = args.slice(2, -2)

  if (transport.length === 2 && transport[0] === "--json-base64url") {
    try {
      const value = JSON.parse(decodeAgentJsonBase64Url(transport[1])) as unknown
      if (!value || typeof value !== "object" || Array.isArray(value)) {
        return fail("agent execute --json-base64url must contain one JSON object")
      }
      return { matched: true, ready: true, value }
    } catch (error) {
      return fail(`agent execute --json-base64url is invalid: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  if (transport[0] === "--json-chunk") {
    if (transport.length !== 8
      || transport[2] !== "--transfer-id"
      || transport[4] !== "--chunk-index"
      || transport[6] !== "--chunk-count") {
      return fail("agent execute --json-chunk transport shape is invalid")
    }
    const chunkCount = parseCanonicalNonNegativeInteger(transport[7])
    const chunkIndex = parseCanonicalNonNegativeInteger(transport[5])
    if (!validTransferId(transport[3])
      || chunkCount === undefined || chunkCount < 1 || chunkCount > AGENT_JSON_TRANSFER_MAX_CHUNKS
      || chunkIndex === undefined || chunkIndex >= chunkCount) {
      return fail("agent execute --json-chunk metadata is invalid")
    }
    const maxChunkBytes = Math.min(
      AGENT_JSON_CHUNK_MAX_BYTES,
      Math.floor(AGENT_JSON_TRANSFER_MAX_BYTES / chunkCount),
    )
    if (!validCanonicalBase64UrlChunk(transport[1], maxChunkBytes)) {
      return fail("agent execute --json-chunk payload is invalid")
    }
    return { matched: true, ready: false, valid: true }
  }

  if (transport[0] === "--json-finalize") {
    if (transport.length !== 5
      || transport[1] !== "--transfer-id"
      || transport[3] !== "--chunk-count") {
      return fail("agent execute --json-finalize transport shape is invalid")
    }
    const chunkCount = parseCanonicalNonNegativeInteger(transport[4])
    if (!validTransferId(transport[2])
      || chunkCount === undefined || chunkCount < 1 || chunkCount > AGENT_JSON_TRANSFER_MAX_CHUNKS) {
      return fail("agent execute --json-finalize metadata is invalid")
    }
    return { matched: true, ready: false, valid: true }
  }

  return fail("agent execute argv transport mode is invalid")
}

function startsWithWords(words: readonly string[], prefix: readonly string[]): boolean {
  return words.length >= prefix.length
    && prefix.every((word, index) => words[index] === word)
}

function parseCanonicalNonNegativeInteger(value: string | undefined): number | undefined {
  if (!value || !/^(?:0|[1-9]\d*)$/.test(value)) return undefined
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) ? parsed : undefined
}

function validTransferId(value: string | undefined): boolean {
  return Boolean(value && /^[A-Za-z0-9_-]{16,128}$/.test(value))
}

function validCanonicalBase64UrlChunk(value: string | undefined, maxBytes: number): boolean {
  if (!value || value.length > AGENT_JSON_CHUNK_MAX_CHARS || !/^[A-Za-z0-9_-]+$/.test(value)) return false
  const decoded = Buffer.from(value, "base64url")
  return decoded.length > 0
    && decoded.length <= maxBytes
    && decoded.toString("base64url") === value
}

function deny(reason: string): GuardResult {
  return { allow: false, reason, enforcement: "enforced" }
}
