#!/usr/bin/env node
/**
 * scripts/git-safety-gateway.mjs — Synapse Git 确定性安全网关（全平台 .mjs 实现）
 *
 * ADR: git-safety-gateway（.sh → .mjs 全平台统一迁移）
 *
 * 退出码契约（确定性，调用方按退出码分支，不解析 stderr）：
 *   0  — 通过（所有检查均无异常）
 *   1  — 敏感信息检测（credential/key/secret 等 pattern 命中）
 *   2  — 大文件超阈值（>lfsThresholdMB，建议走 LFS）
 *   3  — main 分支直接提交（阻止，引导新建分支）
 *   4  — 高危命令（reset --hard / push --force / push --force-with-lease / branch -D / clean -fd / rm -rf .git 等）
 *   5  — commit-required 模式下的「环境层」失败（非 git 仓库 / 顶层未捕获错误
 *         等无法安全继续的根设施问题）。仅在 `--mode commit-required` 下出现；
 *         default 模式仍保持 fail-safe exit 0（向后兼容）。
 *         ADR: git-safety-gateway-runtime-enforcement §Decision 3 (Phase 2a)
 *   11 — 大文件未走 LFS（命中已知大文件类型但未在 .gitattributes 配置 LFS）
 *
 * 子命令：
 *   check-sensitive [file...]  — 两层检测暂存区敏感信息 (exits 0/1)：
 *                                层 A 文件名（.env/.env.* 等环境文件泄漏）+ 层 B 内容行（赋值/精确 pattern）
 *                                ADR: gateway-two-layer-sensitive-detection
 *   check-large-files          — 检测暂存区文件大小是否超阈值 (exits 0/2/11)
 *   check-branch               — 检测当前分支是否为受保护分支 (exits 0/3)
 *   check-dangerous <cmd>      — 检测命令字符串是否含高危操作 (exits 0/4)
 *   check-push-status          — 检测 HEAD 是否已推送到 remote (exits 3=已push/4=未push)
 *   repo-hash                  — 输出 repoHash（--git-common-dir+realpath+sha256前16位）
 *   all                        — 运行所有检查（check-branch + check-sensitive + check-large-files）
 *
 * CLI flag（Phase 2a 新增）：
 *   --mode <mode>   可选值：default（默认） / commit-required
 *                   default 模式：环境层错误 fail-safe exit 0（兼容老行为）
 *                   commit-required 模式：环境层错误 fail-closed exit 5
 *                   注意：「逻辑层」错误（如 check-push-status 无 upstream → exit 4，
 *                         或子命令内部 git diff 失败 → exit 0 降级）两种模式行为一致，
 *                         本 flag 只切换「环境层」分支。
 *
 * 🔴 fail-safe 原则：脚本内部 error 时，打印警告到 stderr 并以 exit 0 降级（不静默放行、有警告）。
 *    例外：check-push-status 无 upstream / tracking 未找到 → 显式 exit 4，绝不落顶层 fail-safe（exit 0）。
 *    例外：--mode commit-required 时「环境层」错误 fail-closed → exit 5（Phase 2a）。
 * 🔴 危险逻辑全在此脚本内部执行，绝不需要调用方在命令行拼危险字符串。
 *
 * 使用示例：
 *   node git-safety-gateway.mjs check-branch
 *   node git-safety-gateway.mjs check-sensitive
 *   node git-safety-gateway.mjs check-dangerous "git reset --hard"
 *   node git-safety-gateway.mjs repo-hash
 *   node git-safety-gateway.mjs all
 *   node git-safety-gateway.mjs --mode commit-required all   # Phase 2a fail-closed
 *
 * 脚本随 `@andyqiu/synapse` 包发布，由 daemon 或 pre-commit hook 从包内路径调用。
 */
// ADR:git-safety-gateway
// ADR:git-safety-gateway-runtime-enforcement

import { execSync } from "node:child_process"
import { statSync } from "node:fs"
import { fileURLToPath } from "node:url"
import { realpathSync } from "node:fs"
import { computeRepoHash } from "./repo-hash.mjs"
import { readRulesField } from "./read-git-rules.mjs"
import { isProtectedBranch, readBranchState } from "./branch-protection.mjs"
import { matchDangerousCommand } from "./dangerous-command.mjs"
import { resolveGlobalGitRulesPath, resolveProjectGitRulesPath } from "./rules-paths.mjs"

// ────────────────────────────────────────────────────────────────────────────
// 工具函数
// ────────────────────────────────────────────────────────────────────────────

function warnStderr(msg) {
  process.stderr.write(`[synapse-gateway] WARNING: ${msg}\n`)
}

// ────────────────────────────────────────────────────────────────────────────
// 运行模式（Phase 2a）
//   default          老行为，环境层错误 fail-safe exit 0
//   commit-required  Phase 2a 新模式，环境层错误 fail-closed exit 5
//
// 重要不变量：
//   1. 「逻辑层」错误（子命令内部 git 操作失败、check-push-status 无 upstream 等）
//      在两种模式下退出码完全相同（exit 0/3/4）——本变量是 ADR Decision 3 + Supplement
//      不变量 1 的核心保证，不允许 mode 影响。
//   2. default 模式整体行为与 Phase 1 之前完全一致（向后兼容硬约束）。
//   3. exit 5 仅由 commit-required 模式 + 环境层错误产生，不会和 0/1/2/3/4/11 冲突。
// ────────────────────────────────────────────────────────────────────────────
let runtimeMode = "default"

function isCommitRequiredMode() {
  return runtimeMode === "commit-required"
}

/**
 * 环境层失败：脚本/依赖根本不在、非 git 仓库、顶层未捕获错误。
 *   - default 模式：fail-safe exit 0（兼容旧行为）
 *   - commit-required 模式：fail-closed exit 5（Phase 2a 新分支）
 *
 * stderr 必须写清楚原因 + 模式，方便 plugin / CLI 分流处理。
 */
function envFailure(reason) {
  if (isCommitRequiredMode()) {
    process.stderr.write(
      `[synapse-gateway] commit-required mode: environment failure: ${reason}\n`
    )
    process.exit(5)
  }
  warnStderr(`内部错误，降级通过（fail-safe）: ${reason}`)
  process.exit(0)
}

/**
 * fail-safe 降级：子命令内部「逻辑层」错误（如 git diff cached 失败）。
 * 🔴 不被 --mode 影响（不变量 1）：commit-required 模式仍 exit 0，
 *    因为这类错误是子命令业务异常，不是脚本/依赖根本不在；
 *    新模式只切环境层分支，不应误伤逻辑层。
 */
function failSafeWarn(msg) {
  warnStderr(`内部错误，降级通过（fail-safe）: ${msg}`)
  process.exit(0)
}

/** 执行 git 命令，返回 trim 后 stdout；失败抛错（由调用方决定 fail-safe 还是退出码） */
function git(args) {
  return execSync(`git ${args}`, { stdio: ["pipe", "pipe", "pipe"] })
    .toString()
    .trim()
}

/** 执行 git 命令，失败返回空串（不抛错） */
function gitSafe(args) {
  try {
    return git(args)
  } catch {
    return ""
  }
}

// ────────────────────────────────────────────────────────────────────────────
// 读取 lfsThresholdMB（项目级 .synapse/git-rules.json → 内置默认 10）
// ────────────────────────────────────────────────────────────────────────────
function getLfsThresholdMb() {
  const projectRoot = gitSafe("rev-parse --show-toplevel")
  if (!projectRoot) return 10
  const rulesFile = resolveProjectGitRulesPath(projectRoot).path
  try {
    statSync(rulesFile)
  } catch {
    return 10
  }
  // 直接 import readRulesField，零子进程开销，行为与旧 read-git-rules.mjs CLI 1:1
  const val = readRulesField(rulesFile, "lfsThreshold")
  return Number.isFinite(val) && val > 0 ? val : 10
}

// ────────────────────────────────────────────────────────────────────────────
// 读取敏感模式：分两层
//   ADR: gateway-two-layer-sensitive-detection（refines gateway-sensitive-pattern-allowlist）
//
//   层 A 文件名检测 getSensitiveFilePatterns()：对暂存文件名匹配，builtin 锚定
//       basename（(^|/)\.env$ / (^|/)\.env\.），避免误伤 vite.env.d.ts 等合法文件；
//       项目级/全局 sensitiveFilePatterns 追加；不引入 ignores（YAGNI）。
//   层 B 内容检测 getSensitiveContentPatterns()：对 diff `+` 行匹配，builtin 收窄为
//       12 条赋值/精确形式（移除 \.env$ / \.env\.，迁至层 A）；沿用 sensitivePatterns
//       追加 + sensitivePatternIgnores 精确字面剔除（非正则、不做转换）。
//
//   两层共享 collectLayered() 收集「全局 ~/.config/synapse/git-rules.json ∪
//   项目级 <root>/.synapse/git-rules.json」的 extra patterns 与（可选）ignores（Set 去重）。
//   fail-safe：文件不存在静默跳过；读取/解析失败 warnStderr 留痕后跳过该层，绝不抛错。
//
// ⚠️ test-only export（test-visible），非稳定公开 API：仅供测试断言生效集合用，后续重构可改签名。
// ────────────────────────────────────────────────────────────────────────────

/**
 * 共享：从全局层 + 项目级层收集某字段的 extra patterns 与（可选）ignores。
 * @param {string} extraField 追加字段名（如 sensitivePatterns / sensitiveFilePatterns）
 * @param {string|null} ignoreField 剔除字段名（如 sensitivePatternIgnores），null 表示该层无 ignore
 */
function collectLayered(extraField, ignoreField) {
  const extraPatterns = []
  const ignores = new Set()

  const collectFrom = (rulesFile) => {
    try {
      statSync(rulesFile)
    } catch {
      return // 文件不存在 → 静默跳过（正常情况，非错误）
    }
    try {
      const extra = readRulesField(rulesFile, extraField)
      if (Array.isArray(extra)) {
        for (const p of extra) {
          if (typeof p === "string" && p) extraPatterns.push(p)
        }
      }
      const ig = ignoreField ? readRulesField(rulesFile, ignoreField) : []
      if (Array.isArray(ig)) {
        for (const p of ig) {
          if (typeof p === "string" && p) ignores.add(p)
        }
      }
    } catch (e) {
      warnStderr(`读取敏感模式配置失败（跳过该层）: ${e?.message ?? e}`) // fail-safe 留痕
    }
  }

  // 全局层
  collectFrom(resolveGlobalGitRulesPath().path)
  // 项目级层
  const projectRoot = gitSafe("rev-parse --show-toplevel")
  if (projectRoot) {
    collectFrom(resolveProjectGitRulesPath(projectRoot).path)
  }

  return { extraPatterns, ignores }
}

/**
 * 层 B：内容行敏感检测 pattern（收窄后 12 条 builtin，移除 \.env$ / \.env\.）。
 * 最终返回 (builtin ∪ extra) − ignores（生效真源，loader 不承担 enforcement）。
 */
export function getSensitiveContentPatterns() {
  const builtins = [
    "AWS_SECRET_ACCESS_KEY",
    "AWS_ACCESS_KEY_ID",
    "PRIVATE_KEY",
    "BEGIN RSA PRIVATE KEY",
    "BEGIN EC PRIVATE KEY",
    "BEGIN OPENSSH PRIVATE KEY",
    "password=",
    "passwd=",
    "secret=",
    "token=",
    "api_key=",
    "apikey=",
  ]
  const { extraPatterns, ignores } = collectLayered(
    "sensitivePatterns",
    "sensitivePatternIgnores",
  )
  // extraPatterns 去重后并入 builtin，再剔除 ignores（生效真源）
  const merged = Array.from(new Set([...builtins, ...extraPatterns]))
  return merged.filter((p) => !ignores.has(p))
}

/**
 * 层 A：文件名敏感检测 pattern（builtin 锚定 basename，见 ADR Options B）。
 * 最终返回 builtin ∪ extra（不引入 ignores，YAGNI）。
 */
export function getSensitiveFilePatterns() {
  const builtins = [
    "(^|/)\\.env$", // 文件名正好是 .env（含子目录 path/.env）
    // .env.production / .env.local 等；负向先行断言放行 .env.example / .env.sample / .env.template
    // 及其 .* 派生（示例模板，非密钥）。
    // ⚠️ (\.|$) 必须在断言内部：外移为消费组会放行 .env.local 等真 env 文件（致命 bug）。
    // ADR: gateway-layer-a-env-example-allowance（.env.example 误报修复，refines gateway-two-layer-sensitive-detection）
    // ADR: gateway-template-file-allowance（扩展放行 .env.sample / .env.template，层 A/B 跨层对齐）
    "(^|/)\\.env\\.(?!(?:example|sample|template)(\\.|$))",
  ]
  const { extraPatterns } = collectLayered("sensitiveFilePatterns", null)
  return Array.from(new Set([...builtins, ...extraPatterns]))
}

// ────────────────────────────────────────────────────────────────────────────
// 层 B 内容扫描：diff 分段 + 来源豁免 + 占位符 value 放行
//   ADR: gateway-template-file-allowance（跨层对齐：层 A 文件名 + 层 B 内容）
//
// ⚠️ test-only export（test-visible），非稳定公开 API：仅供测试断言用，后续重构可改签名。
// ────────────────────────────────────────────────────────────────────────────

/**
 * 把 `git diff --cached` 文本按 `diff --git` 主锚分段，返回 [{ path, plusLines }]。
 *   - 文件段边界主锚：`diff --git a/<x> b/<y>` 行（每遇即开新段）。
 *   - 路径提取优先级：① 段内 `+++ b/<path>`；② 回退解析 `diff --git` 行 b/ 侧。
 *   - rename/copy：取 b/ 侧新名（`+++ b/` 优先；纯重命名无 `+` 行则 plusLines=[]）。
 *   - `/dev/null` 删除段（`+++ /dev/null`）：path=null（已知=删除，不误扫被删内容），plusLines=[]。
 *   - binary 段（`Binary files ... differ`）：无 `+` 文本行，plusLines=[]。
 *   - 含引号路径（quoted-path，以 `"` 开头）：v1 不去引号，path=null（解析不确定）→ 调用方不豁免、全量扫。
 *   - 行筛选：每段只收 `^+` 开头且非 `+++` 头的行。
 *
 * @param {string} diff `git diff --cached --diff-filter=ACMR -U0` 的完整输出
 * @returns {{ path: string|null, plusLines: string[] }[]}
 */
export function splitDiffByFile(diff) {
  const segments = []
  if (typeof diff !== "string" || !diff) return segments

  const lines = diff.split("\n")
  let cur = null // { path, plusLines, sawPlusPlusPlus }

  const flush = () => {
    if (cur) {
      segments.push({ path: cur.path, plusLines: cur.plusLines })
      cur = null
    }
  }

  // 从 `diff --git a/<x> b/<y>` 行解析 b/ 侧路径（回退用）。
  // quoted-path（b/ 后以 " 开头）→ 返回 null（解析不确定）。
  const parseGitHeaderPath = (line) => {
    // 取末尾 ` b/...` 段；rename/copy 时 b/ 即新名。
    const idx = line.indexOf(" b/")
    if (idx === -1) return null
    const raw = line.slice(idx + 3) // 去 " b/"
    if (!raw || raw.startsWith('"')) return null // quoted → 不确定
    return raw
  }

  for (const line of lines) {
    if (line.startsWith("diff --git ")) {
      flush()
      cur = {
        path: parseGitHeaderPath(line),
        plusLines: [],
        sawPlusPlusPlus: false,
      }
      continue
    }
    if (!cur) continue // diff 头之前的行（理论上不存在），忽略

    if (line.startsWith("+++ ")) {
      cur.sawPlusPlusPlus = true
      const target = line.slice(4).trim() // 去 "+++ "
      if (target === "/dev/null") {
        cur.path = null // 删除段，不误扫
      } else if (target.startsWith('"')) {
        cur.path = null // quoted-path → 不确定
      } else if (target.startsWith("b/")) {
        cur.path = target.slice(2)
      } else {
        // 非 b/ 前缀的罕见形态 → 解析不确定
        cur.path = null
      }
      continue
    }

    // 只收新增内容行：^+ 开头且非 +++ 头
    if (line.startsWith("+") && !line.startsWith("+++")) {
      cur.plusLines.push(line)
    }
  }
  flush()
  return segments
}

/**
 * 判断某文件路径是否属于「内容扫描豁免来源」（大小写不敏感）：
 *   - 模板 env：.env.example / .env.sample / .env.template（及其 .* 派生），与层 A 放行集对齐
 *   - fixtures：路径含 tests/fixtures/ 或 __fixtures__/
 *   - 测试文件：basename 匹配 *.test.* / *.spec.*
 * path 为 null/空（解析不确定）→ 返回 false（不豁免，调用方全量扫）。
 *
 * @param {string|null} path
 * @returns {boolean}
 */
export function isExemptContentSourceFile(path) {
  if (typeof path !== "string" || !path) return false
  // 模板 env（与扩展后层 A 放行集对齐）
  if (/(^|\/)\.env\.(example|sample|template)(\.|$)/i.test(path)) return true
  // fixtures 目录
  if (/(^|\/)(tests\/fixtures|__fixtures__)\//i.test(path)) return true
  // 测试 / spec 文件（basename）
  if (/(^|\/)[^/]*\.(test|spec)\.[a-z0-9]+$/i.test(path)) return true
  return false
}

/**
 * 判断某 `+` 行是否为「占位符 value」（命中则放行，不视为真敏感）。
 *   - 仅支持 key=value：按第一个 `=` 切分（保证多 `=` value 如 token=abc==base64 完整）。
 *   - value 去首尾空白 → 去成对包裹引号（' / " / 反引号）。
 *   - value 整体锚定匹配占位符正则（关键防误放真密钥）。
 *   - 无 `=` 行（BEGIN RSA PRIVATE KEY、裸 AWS_SECRET_ACCESS_KEY）→ false（维持拦截）。
 *   - YAML(key: value) / JSON / 注释形态不识别（保守，维持拦截）。
 *
 * @param {string} line 含前导 `+` 的 diff 行（或纯内容行均可）
 * @returns {boolean}
 */
export function isPlaceholderValueLine(line) {
  if (typeof line !== "string") return false
  // 去前导单个 `+`（diff 行），保留其余内容
  let content = line.startsWith("+") ? line.slice(1) : line
  const eq = content.indexOf("=")
  if (eq === -1) return false // 无 = → 不走 placeholder 放行
  let value = content.slice(eq + 1).trim()
  // 去成对包裹引号（仅成对）
  if (value.length >= 2) {
    const q = value[0]
    if ((q === '"' || q === "'" || q === "`") && value[value.length - 1] === q) {
      value = value.slice(1, -1)
    }
  }
  const placeholderRe =
    /^(?:your[_-][a-z0-9_]+(?:[_-]here)?|[a-z0-9_]+_placeholder|<[^>]+>|example|changeme|xxx+|todo|placeholder|\.\.\.)$/i
  return placeholderRe.test(value)
}

// ────────────────────────────────────────────────────────────────────────────
// 已知大文件类型（建议 LFS，退出码 11）
// ────────────────────────────────────────────────────────────────────────────
const KNOWN_LARGE_EXTENSIONS = [
  ".psd", ".ai", ".psb",           // Photoshop / Illustrator
  ".fbx", ".obj", ".3ds", ".blend", // 3D models
  ".unitypackage", ".unity",        // Unity assets
  ".uasset", ".umap",              // Unreal assets
  ".pab", ".mp4", ".mov", ".avi", ".mkv", // Video
  ".wav", ".aif", ".aiff", ".flac",       // Audio (lossless)
  ".iso", ".dmg", ".pkg",          // Disk images
  ".zip", ".tar", ".gz", ".7z",    // Archives (large)
]

function isKnownLargeExtension(filename) {
  const lower = filename.toLowerCase()
  return KNOWN_LARGE_EXTENSIONS.some((ext) => lower.endsWith(ext))
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：check-sensitive
// ────────────────────────────────────────────────────────────────────────────
function cmdCheckSensitive() {
  // ── 层 A：文件名检测（ADR: gateway-two-layer-sensitive-detection）──
  // 对暂存文件名匹配 getSensitiveFilePatterns()，拦截 .env / .env.* 等环境文件泄漏。
  // 🔴 不变量：层 A 无命中（含 stagedFiles 为空）时必须继续层 B，绝不在此 exit 0。
  const filePatterns = getSensitiveFilePatterns()
  let stagedFiles
  try {
    stagedFiles = git("diff --cached --name-only --diff-filter=ACMR")
  } catch {
    failSafeWarn("git diff --cached --name-only 失败")
    return
  }
  if (stagedFiles) {
    const files = stagedFiles.split("\n").filter(Boolean)
    for (const pattern of filePatterns) {
      let re
      try {
        re = new RegExp(pattern, "i")
      } catch {
        // pattern 不是合法正则 → 降级为字面（大小写不敏感）子串匹配
        const lowerP = pattern.toLowerCase()
        const hit = files.find((f) => f.toLowerCase().includes(lowerP))
        if (hit) {
          process.stderr.write(
            `[synapse-gateway] SENSITIVE_FILE_DETECTED: pattern="${pattern}" file="${hit}"\n`,
          )
          process.exit(1)
        }
        continue
      }
      const hit = files.find((f) => re.test(f))
      if (hit) {
        process.stderr.write(
          `[synapse-gateway] SENSITIVE_FILE_DETECTED: pattern="${pattern}" file="${hit}"\n`,
        )
        process.exit(1)
      }
    }
  }

  // ── 层 B：内容行检测（patterns 换 getSensitiveContentPatterns）──
  // ADR: gateway-template-file-allowance（按 diff 分段 → 来源豁免 → 占位符 value 放行）
  const patterns = getSensitiveContentPatterns()

  // 收集暂存区内容（diff --cached --diff-filter=ACMR 只看新增/修改）
  let stagedContent
  try {
    stagedContent = git("diff --cached --diff-filter=ACMR -U0")
  } catch {
    failSafeWarn("git diff --cached 失败")
    return
  }

  if (!stagedContent) {
    // 暂存区无内容，跳过
    process.exit(0)
  }

  // 预编译 pattern（regex 优先，非法正则降级字面子串）。
  const compiled = patterns.map((pattern) => {
    let re = null
    try {
      re = new RegExp(pattern, "i")
    } catch {
      re = null
    }
    return { pattern, re, lowerP: pattern.toLowerCase() }
  })

  const matchLine = (l) => {
    for (const { pattern, re, lowerP } of compiled) {
      const hit = re ? re.test(l) : l.toLowerCase().includes(lowerP)
      if (hit) return pattern
    }
    return ""
  }

  // 按 diff --git 主锚分段（含 rename/copy/dev-null/binary/quoted-path 处理）。
  const segments = splitDiffByFile(stagedContent)

  let foundPattern = ""
  let foundLine = ""
  outer: for (const seg of segments) {
    // 来源豁免：.env 模板 / fixtures / test 文件整段跳过（path 解析不确定时 isExempt=false → 全量扫，保守）
    if (isExemptContentSourceFile(seg.path)) continue
    for (const l of seg.plusLines) {
      const pattern = matchLine(l)
      if (!pattern) continue
      // 占位符 value 放行（仅 key=value、锚定占位符正则）：非豁免来源命中行兜底
      if (isPlaceholderValueLine(l)) continue
      foundPattern = pattern
      foundLine = l
      break outer
    }
  }

  if (foundPattern) {
    process.stderr.write(
      `[synapse-gateway] SENSITIVE_PATTERN_DETECTED: pattern="${foundPattern}"\n`
    )
    process.stderr.write(`[synapse-gateway] MATCH_LINE: ${foundLine}\n`)
    process.exit(1)
  }

  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：check-large-files
// ────────────────────────────────────────────────────────────────────────────
function cmdCheckLargeFiles() {
  const thresholdMb = getLfsThresholdMb()
  const thresholdBytes = thresholdMb * 1024 * 1024

  let stagedFiles
  try {
    stagedFiles = git("diff --cached --name-only --diff-filter=ACMR")
  } catch {
    failSafeWarn("git diff --cached 失败")
    return
  }

  if (!stagedFiles) {
    process.exit(0)
  }

  let lfsNeededFile = "" // 已知大文件类型（退出码11）
  let oversizeFile = "" // 超阈值（退出码2）
  let oversizeSize = 0

  for (const file of stagedFiles.split("\n")) {
    if (!file) continue
    let fileSize = 0
    try {
      fileSize = statSync(file).size
    } catch {
      // 文件不存在（如已删除）→ 跳过，对齐旧 .sh `[[ ! -f ]] continue`
      continue
    }

    if (fileSize > thresholdBytes) {
      if (isKnownLargeExtension(file)) {
        lfsNeededFile = file
      } else {
        oversizeFile = file
        oversizeSize = fileSize
      }
    } else if (isKnownLargeExtension(file)) {
      // 已知大文件类型即使未超阈值也建议 LFS（>1MB）
      const minArtBytes = 1 * 1024 * 1024
      if (fileSize > minArtBytes) {
        lfsNeededFile = file
      }
    }
  }

  // 已知大文件类型优先返回（退出码11）
  if (lfsNeededFile) {
    process.stderr.write(
      `[synapse-gateway] LFS_RECOMMENDED: file="${lfsNeededFile}" (known large file type, should use git-lfs)\n`
    )
    process.exit(11)
  }

  // 超阈值（退出码2）
  if (oversizeFile) {
    const fileSizeMb = (oversizeSize / 1048576).toFixed(1)
    process.stderr.write(
      `[synapse-gateway] LARGE_FILE: file="${oversizeFile}" size=${fileSizeMb}MB threshold=${thresholdMb}MB\n`
    )
    process.exit(2)
  }

  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：check-branch
// ────────────────────────────────────────────────────────────────────────────
function cmdCheckBranch() {
  const branchState = readBranchState(process.cwd())
  if (branchState.state === "error" || branchState.state === "not-repo") {
    failSafeWarn(
      branchState.state === "error"
        ? `获取当前分支失败: ${branchState.message}`
        : "获取当前分支失败: not a git repository",
    )
    return
  }
  if (branchState.state === "branch" && isProtectedBranch(branchState.branch)) {
    process.stderr.write(
      `[synapse-gateway] PROTECTED_BRANCH: branch="${branchState.branch}" (direct commit blocked)\n`
    )
    process.exit(3)
  }

  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：check-dangerous <cmd_string>
// 🔴 命令字符串由调用方传入参数，网关内部判断，不执行任何危险命令
// ────────────────────────────────────────────────────────────────────────────
function cmdCheckDangerous(cmdString) {
  const match = matchDangerousCommand(cmdString)
  if (match) {
    process.stderr.write(
      `[synapse-gateway] DANGEROUS_COMMAND: pattern="${match.pattern}" cmd="${cmdString}"\n`
    )
    process.exit(4)
  }

  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：check-push-status
// 退出码语义（与 M2-2 不变式 4 对齐）：
//   3 = HEAD 已 push 到 remote（对应 R17 场景，需用 git revert）
//   4 = HEAD 未 push 到 remote（对应 CP4 场景，可用 git reset，但仍需过三守卫）
//
// 🔴 无 upstream / tracking 未找到 → 显式 exit 4，单独处理，绝不落顶层 fail-safe（exit 0）。
//    若误落顶层 catch → exit 0（误判为已推送/安全），与契约相反，agent 按码分支会误判。
// ────────────────────────────────────────────────────────────────────────────
function cmdCheckPushStatus() {
  let currentBranch
  try {
    currentBranch = git("branch --show-current")
  } catch {
    failSafeWarn("获取当前分支失败")
    return
  }

  // 获取对应的 remote tracking branch（无 upstream 是正常情况，不抛错，单独 exit 4）
  let tracking = ""
  try {
    tracking = git(`rev-parse --abbrev-ref ${currentBranch}@{upstream}`)
  } catch {
    // 无 upstream（无 remote tracking branch）
    tracking = ""
  }

  if (!tracking) {
    // 无 upstream，视为未 push（exit 4）—— 显式退出，不落顶层 fail-safe
    process.stderr.write(
      `[synapse-gateway] PUSH_STATUS: no_upstream branch="${currentBranch}" → unpushed\n`
    )
    process.exit(4)
  }

  // 检查 HEAD 是否已在 remote
  let remoteSha = ""
  try {
    git("rev-parse HEAD")
  } catch {
    failSafeWarn("git rev-parse HEAD 失败")
    return
  }
  try {
    remoteSha = git(`rev-parse ${tracking}`)
  } catch {
    // tracking branch 不存在或 fetch 未更新，视为未 push（exit 4，显式不落顶层）
    process.stderr.write(
      `[synapse-gateway] PUSH_STATUS: tracking_not_found=${tracking} → unpushed\n`
    )
    process.exit(4)
  }
  void remoteSha

  // 检查 local HEAD 是否已出现在 remote 历史中
  let isAncestor = false
  try {
    execSync(`git merge-base --is-ancestor HEAD ${tracking}`, {
      stdio: ["pipe", "pipe", "pipe"],
    })
    isAncestor = true
  } catch {
    isAncestor = false
  }

  if (isAncestor) {
    process.stderr.write(
      `[synapse-gateway] PUSH_STATUS: HEAD_already_in_remote branch="${currentBranch}" tracking="${tracking}" → pushed\n`
    )
    process.exit(3)
  } else {
    process.stderr.write(
      `[synapse-gateway] PUSH_STATUS: HEAD_not_in_remote branch="${currentBranch}" tracking="${tracking}" → unpushed\n`
    )
    process.exit(4)
  }
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：repo-hash
// 🔴 算法由公共 repo-hash.mjs 的 computeRepoHash() 提供
// ────────────────────────────────────────────────────────────────────────────
function cmdRepoHash() {
  const repoHash = computeRepoHash()
  if (!repoHash) {
    warnStderr("无法计算 repoHash（需要 sha256，非 git 仓库）")
    process.exit(1)
  }
  process.stdout.write(repoHash + "\n")
  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// 子命令：all（运行 check-branch + check-sensitive + check-large-files）
// 顺序：分支 → 敏感 → 大文件（对齐旧 .sh cmd_all 实际执行顺序，碰到阻断立即返回）
// 🔴 改为本进程函数直调（旧 .sh 是 re-exec 自身，.mjs 直调更高效）。
//    各子命令本身会 process.exit；为实现「任一非 0 立即退出该码」，
//    用子进程跑各子命令并读其退出码（保持与旧 .sh 退出码语义完全一致）。
// ────────────────────────────────────────────────────────────────────────────
function runSubInProcess(sub) {
  // 各子命令内部直接 process.exit，无法在同进程内串联多个（第一个就退出整进程）。
  // 故 all 用子进程方式逐个跑，捕获退出码，对齐旧 .sh `bash $0 sub; ec=$?` 语义。
  // 🔴 Phase 2a：必须透传当前 runtimeMode 到子进程，否则 commit-required 模式下
  //    子进程的环境层错误（spawn ENOENT 等）会按 default 模式 fail-safe，导致 cmdAll
  //    永远不会 return exit 5（破坏不变量 3）。
  const selfPath = fileURLToPath(import.meta.url)
  const modeArg = isCommitRequiredMode() ? " --mode commit-required" : ""
  try {
    execSync(`node ${JSON.stringify(selfPath)}${modeArg} ${sub}`, {
      stdio: ["pipe", "inherit", "inherit"],
    })
    return 0
  } catch (err) {
    // execSync 抛错时 err.status 是子进程退出码（包含新的 exit 5）
    return typeof err.status === "number" ? err.status : 1
  }
}

function cmdAll() {
  // 检查分支（阻断性最高：main 保护）
  let ec = runSubInProcess("check-branch")
  if (ec !== 0) process.exit(ec)

  // 检查敏感信息
  ec = runSubInProcess("check-sensitive")
  if (ec !== 0) process.exit(ec)

  // 检查大文件
  ec = runSubInProcess("check-large-files")
  if (ec !== 0) process.exit(ec)

  process.exit(0)
}

// ────────────────────────────────────────────────────────────────────────────
// CLI 入口判定
// ────────────────────────────────────────────────────────────────────────────
const isMain = (() => {
  try {
    return (
      process.argv[1] &&
      fileURLToPath(import.meta.url) === realpathSync(process.argv[1])
    )
  } catch {
    return fileURLToPath(import.meta.url) === process.argv[1]
  }
})()

// ────────────────────────────────────────────────────────────────────────────
// CLI argparse（轻量自实现，铁律：不引入新 npm 依赖）
//
// 支持：
//   --mode <mode>         可选 default / commit-required
//   --mode=<mode>         合并 = 形式
// 解析顺序：从 argv[2..] 起线性扫描，识别 --mode 后剩下的 token 序列即子命令 + 子命令参数。
// 未识别的 --xxx flag 透传给子命令（当前所有子命令都不吃 - 开头参数，错位即 default 子命令）。
// ────────────────────────────────────────────────────────────────────────────
function parseCli(argv) {
  const out = { mode: "default", positional: [] }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === "--mode") {
      const v = argv[i + 1]
      if (typeof v !== "string" || v.startsWith("-")) {
        warnStderr(`--mode 需要值（default / commit-required）`)
        process.exit(1)
      }
      out.mode = v
      i++
      continue
    }
    if (a.startsWith("--mode=")) {
      out.mode = a.slice("--mode=".length)
      continue
    }
    out.positional.push(a)
  }
  if (out.mode !== "default" && out.mode !== "commit-required") {
    warnStderr(`未知 --mode 值: ${out.mode}（合法值: default / commit-required）`)
    process.exit(1)
  }
  return out
}

if (isMain) {
  // 解析 --mode 必须在任何子命令调用之前，因为 envFailure 行为依赖 runtimeMode
  const parsed = parseCli(process.argv.slice(2))
  runtimeMode = parsed.mode

  try {
    // 非 git 仓库 = 「环境层」失败：
    //   default → fail-safe exit 0（兼容老行为）
    //   commit-required → fail-closed exit 5（Phase 2a 新分支）
    // repo-hash 子命令不依赖「当前是 git 仓库」之外的东西，但旧 .sh 也先做了这层 git-dir 检测，
    // 这里保持一致（repo-hash 在非 git 仓库本就返回空 → 由 cmdRepoHash 自己 exit 1）。
    let isGitRepo = true
    try {
      execSync("git rev-parse --git-dir", {
        stdio: ["pipe", "pipe", "pipe"],
      })
    } catch {
      isGitRepo = false
    }
    if (!isGitRepo) {
      envFailure("当前目录不是 git 仓库")
    }

    const subcommand = parsed.positional[0] ?? "all"
    switch (subcommand) {
      case "check-sensitive":
        cmdCheckSensitive()
        break
      case "check-large-files":
        cmdCheckLargeFiles()
        break
      case "check-branch":
        cmdCheckBranch()
        break
      case "check-dangerous":
        cmdCheckDangerous(parsed.positional[1] ?? "")
        break
      case "check-push-status":
        cmdCheckPushStatus()
        break
      case "repo-hash":
        cmdRepoHash()
        break
      case "all":
        cmdAll()
        break
      default:
        warnStderr(
          `未知子命令: ${subcommand}（合法值: check-sensitive / check-large-files / check-branch / check-dangerous / check-push-status / repo-hash / all）`
        )
        process.exit(1)
    }
  } catch (err) {
    // 顶层未捕获错误 = 「环境层」失败：
    //   default → fail-safe exit 0（兼容老行为）
    //   commit-required → fail-closed exit 5（Phase 2a 新分支）
    // 🔴 注意：check-push-status 的无 upstream 路径已在子命令内显式 process.exit(4)，
    //    不会走到这里（process.exit 立即终止，不抛错），故契约 exit 4 不受 commit-required mode 影响。
    envFailure(`未捕获错误: ${err?.message ?? err}`)
  }
}
