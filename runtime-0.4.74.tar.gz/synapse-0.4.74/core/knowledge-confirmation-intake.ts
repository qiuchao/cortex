import { randomUUID } from "node:crypto"
import {
  KnowledgeAgentExecuteRequestSchema,
  KnowledgeAgentExecuteResponseSchema,
  type KnowledgeAgentExecuteRequest,
  type KnowledgeAgentExecuteResponse,
  type KnowledgeCapabilityName,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import { knowledgeConfirmationPath } from "../transport/discovery.ts"
import { loadSessionState, persistSessionState } from "./session-store.ts"

type ConfirmationRequiredResponse = Extract<KnowledgeAgentExecuteResponse, { status: "confirmation_required" }>

export interface KnowledgeConfirmationPendingResponse {
  protocolVersion: string
  capability: KnowledgeCapabilityName
  status: "confirmation_required"
  operationId: string
  confirmationExpiresAt: string
  summary: string
  confirmationPrompt: string
  cancellationPrompt: string
}

export type KnowledgeConfirmationExecutionResult =
  | { ok: true; response: unknown }
  | { ok: false; reason: string; message: string; httpStatus?: number }

export interface KnowledgeConfirmationCapture {
  operationId: string
  publicResponse: KnowledgeConfirmationPendingResponse
  confirmedRequest?: KnowledgeAgentExecuteRequest
}

export interface KnowledgeConfirmationIntake {
  capture(
    request: KnowledgeAgentExecuteRequest,
    response: ConfirmationRequiredResponse,
    userInput?: string,
  ): KnowledgeConfirmationCapture
  updateReceipt(operationId: string, response: ConfirmationRequiredResponse): KnowledgeConfirmationPendingResponse | undefined
  complete(operationId: string): void
  handleTurn(
    request: InjectRequest,
    execute: (request: KnowledgeAgentExecuteRequest) => Promise<KnowledgeConfirmationExecutionResult>,
  ): Promise<string | undefined>
}

export interface KnowledgeConfirmationIntakeDeps {
  path?: string
  now?: () => number
  randomId?: () => string
  maxEntries?: number
}

interface StoredPendingKnowledgeConfirmation {
  operationId: string
  request: KnowledgeAgentExecuteRequest
  confirmationToken: string
  expiresAt: string
  createdAt: string
}

interface StoredKnowledgeConfirmationState {
  version: 1
  pending: Record<string, StoredPendingKnowledgeConfirmation>
}

interface KnowledgeConfirmationAction {
  action: "confirm" | "cancel"
  operationId: string
}

const ACTION = /^(确认|取消)\s*知识\s*操作\s*[：:]?\s*(KOP-[0-9A-F]{8})[。！!]*$/i
const OPERATION_ID = /^KOP-[0-9A-F]{8}$/
const DEFAULT_MAX_ENTRIES = 256

export function isKnowledgeConfirmationActionText(input: string): boolean {
  return ACTION.test(input.trim())
}

export function createKnowledgeConfirmationIntake(
  env: NodeJS.ProcessEnv = process.env,
  deps: KnowledgeConfirmationIntakeDeps = {},
): KnowledgeConfirmationIntake {
  const path = deps.path ?? knowledgeConfirmationPath(env)
  const now = deps.now ?? Date.now
  const createId = deps.randomId ?? randomUUID
  const maxEntries = deps.maxEntries ?? DEFAULT_MAX_ENTRIES
  const loaded = loadSessionState(path, emptyState, (value) => parseState(value, now()))
  const pending = new Map(Object.entries(loaded.pending))
  const acting = new Set<string>()

  const save = (): void => {
    persistSessionState(path, {
      version: 1,
      pending: Object.fromEntries(pending),
    } satisfies StoredKnowledgeConfirmationState)
  }
  const prune = (): boolean => {
    const current = now()
    let changed = false
    for (const [operationId, entry] of pending) {
      if (Date.parse(entry.expiresAt) <= current) {
        pending.delete(operationId)
        changed = true
      }
    }
    return changed
  }
  const persistBestEffort = (): void => {
    try { save() } catch { /* The daemon's in-memory binding remains authoritative. */ }
  }
  const removeSessionPending = (client: string, sessionId: string, except?: string): boolean => {
    let changed = false
    for (const [operationId, entry] of pending) {
      if (operationId !== except && entry.request.client === client && entry.request.sessionId === sessionId) {
        pending.delete(operationId)
        changed = true
      }
    }
    return changed
  }
  const publicResponse = (entry: StoredPendingKnowledgeConfirmation): KnowledgeConfirmationPendingResponse => ({
    protocolVersion: entry.request.protocolVersion,
    capability: entry.request.capability,
    status: "confirmation_required",
    operationId: entry.operationId,
    confirmationExpiresAt: entry.expiresAt,
    summary: `${entry.request.capability} 尚未执行，等待用户确认知识操作 ${entry.operationId}`,
    confirmationPrompt: actionText("confirm", entry.operationId),
    cancellationPrompt: actionText("cancel", entry.operationId),
  })

  return {
    capture(request, response, userInput) {
      prune()
      const parsedRequest = KnowledgeAgentExecuteRequestSchema.parse(request)
      if (parsedRequest.confirmation) throw new Error("a model-supplied Knowledge confirmation cannot be captured")
      if (response.capability !== parsedRequest.capability) {
        throw new Error("Knowledge confirmation capability does not match the request")
      }
      const expiresAtMs = Date.parse(response.confirmationExpiresAt)
      if (!Number.isFinite(expiresAtMs) || expiresAtMs <= now()) {
        throw new Error("Knowledge confirmation receipt is already expired")
      }
      removeSessionPending(parsedRequest.client, parsedRequest.sessionId)
      let operationId = ""
      for (let attempts = 0; attempts < 8; attempts++) {
        operationId = `KOP-${createId().replace(/-/g, "").slice(0, 8).toUpperCase()}`
        if (OPERATION_ID.test(operationId) && !pending.has(operationId)) break
        operationId = ""
      }
      if (!operationId) throw new Error("unable to allocate a unique Knowledge operation ID")
      const entry: StoredPendingKnowledgeConfirmation = {
        operationId,
        request: parsedRequest,
        confirmationToken: response.confirmationToken,
        expiresAt: response.confirmationExpiresAt,
        createdAt: new Date(now()).toISOString(),
      }
      pending.set(operationId, entry)
      while (pending.size > maxEntries) pending.delete(pending.keys().next().value!)
      persistBestEffort()
      return {
        operationId,
        publicResponse: publicResponse(entry),
        ...(userInput && hasExactInlineConfirmation(userInput, parsedRequest)
          ? { confirmedRequest: withConfirmation(entry) }
          : {}),
      }
    },

    updateReceipt(operationId, response) {
      const entry = pending.get(operationId)
      if (!entry || response.capability !== entry.request.capability) return undefined
      const expiresAtMs = Date.parse(response.confirmationExpiresAt)
      if (!Number.isFinite(expiresAtMs) || expiresAtMs <= now()) return undefined
      entry.confirmationToken = response.confirmationToken
      entry.expiresAt = response.confirmationExpiresAt
      persistBestEffort()
      return publicResponse(entry)
    },

    complete(operationId) {
      if (pending.delete(operationId)) persistBestEffort()
    },

    async handleTurn(request, execute) {
      const changed = prune()
      const action = parseAction(request.user_input)
      if (!action) {
        if (removeSessionPending(request.client, request.session_id) || changed) persistBestEffort()
        return undefined
      }
      const entry = pending.get(action.operationId)
      if (!entry || entry.request.client !== request.client || entry.request.sessionId !== request.session_id) {
        if (changed) persistBestEffort()
        return `[Synapse] 本会话没有可处理的知识操作 ${action.operationId}；该操作可能已完成、取消或过期。`
      }
      if (action.action === "cancel") {
        pending.delete(action.operationId)
        persistBestEffort()
        return `[Synapse] 已取消知识操作 ${action.operationId}；未执行新的知识写入。`
      }
      if (acting.has(action.operationId)) {
        return `[Synapse] 知识操作 ${action.operationId} 正在确认中，请等待当前结果。`
      }
      acting.add(action.operationId)
      try {
        const result = await execute(withConfirmation(entry))
        if (!result.ok) {
          return `[Synapse] 知识操作 ${action.operationId} 的确认结果暂时不可用（${result.reason}: ${result.message}）；操作引用已保留，请重试“${actionText("confirm", action.operationId)}”或取消。`
        }
        const parsed = KnowledgeAgentExecuteResponseSchema.safeParse(result.response)
        if (!parsed.success || parsed.data.capability !== entry.request.capability) {
          return `[Synapse] 知识操作 ${action.operationId} 返回了不匹配的响应；未将其视为成功，操作引用已保留。`
        }
        if (parsed.data.status === "confirmation_required") {
          entry.confirmationToken = parsed.data.confirmationToken
          entry.expiresAt = parsed.data.confirmationExpiresAt
          persistBestEffort()
          return `[Synapse] 知识操作 ${action.operationId} 仍需确认；请重试“${actionText("confirm", action.operationId)}”。`
        }
        pending.delete(action.operationId)
        persistBestEffort()
        return renderTerminalResult(action.operationId, parsed.data)
      } finally {
        acting.delete(action.operationId)
      }
    },
  }
}

function withConfirmation(entry: StoredPendingKnowledgeConfirmation): KnowledgeAgentExecuteRequest {
  return {
    ...entry.request,
    confirmation: { token: entry.confirmationToken },
  }
}

function parseAction(input: string): KnowledgeConfirmationAction | undefined {
  const match = input.trim().match(ACTION)
  return match
    ? { action: match[1] === "确认" ? "confirm" : "cancel", operationId: match[2]!.toUpperCase() }
    : undefined
}

function actionText(action: KnowledgeConfirmationAction["action"], operationId: string): string {
  return `${action === "confirm" ? "确认" : "取消"}知识操作 ${operationId}`
}

function hasExactInlineConfirmation(userInput: string, request: KnowledgeAgentExecuteRequest): boolean {
  const action = request.capability === "delete_knowledge"
    ? "(?:删除|delete)"
    : request.capability === "promote_knowledge"
      ? "(?:提升|升级|promote)"
      : request.capability === "demote_knowledge"
        ? "(?:降级|降到|demote)"
        : undefined
  if (!action) return false
  const denied = new RegExp(String.raw`(?:不|未|没有|拒绝|取消|别|不要|请勿|禁止)\s*[^。！？!?;；\n]{0,32}${action}|\b(?:do\s+not|don't|dont|never|refuse\s+to|cancel)\b[^.!?;\n]{0,32}${action}`, "i")
    .test(userInput)
  if (denied) return false
  const confirmed = new RegExp(
    String.raw`(?:我\s*)?(?:明确\s*)?(?:确认|同意)(?:执行|进行)?[^。！？!?;；\n]{0,32}${action}|\b(?:I\s+(?:explicitly\s+)?confirm|confirm(?:ed)?)\b[^.!?;\n]{0,32}${action}`,
    "i",
  ).test(userInput)
  if (!confirmed) return false
  const requiredTargets = [
    request.args.knowledgeId,
    request.capability === "promote_knowledge" || request.capability === "demote_knowledge"
      ? request.args.targetOwnerType
      : undefined,
    request.capability === "promote_knowledge" || request.capability === "demote_knowledge"
      ? request.args.targetOwnerId
      : undefined,
  ].filter((value): value is string => typeof value === "string" && value.trim() !== "")
  return requiredTargets.every((target) => userInput.toLocaleLowerCase().includes(target.toLocaleLowerCase()))
}

function renderTerminalResult(operationId: string, response: Exclude<KnowledgeAgentExecuteResponse, { status: "confirmation_required" }>): string {
  if (response.status === "executed") {
    return [
      `[Synapse] 知识操作 ${operationId} 已确认并执行完成。`,
      `knowledge_result_json=${JSON.stringify(response)}`,
      "请按普通产品语言向用户报告结果；不要展示内部 confirmation receipt。",
    ].join("\n")
  }
  return `[Synapse] 知识操作 ${operationId} 未执行（${response.code}: ${response.message}）。`
}

function emptyState(): StoredKnowledgeConfirmationState {
  return { version: 1, pending: {} }
}

function parseState(value: unknown, now: number): StoredKnowledgeConfirmationState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return emptyState()
  const state = value as { version?: unknown; pending?: unknown }
  if (state.version !== 1 || !state.pending || typeof state.pending !== "object" || Array.isArray(state.pending)) {
    return emptyState()
  }
  const pending = Object.fromEntries(Object.entries(state.pending).flatMap(([key, raw]) => {
    if (!OPERATION_ID.test(key) || !raw || typeof raw !== "object" || Array.isArray(raw)) return []
    const entry = raw as Partial<StoredPendingKnowledgeConfirmation>
    const request = KnowledgeAgentExecuteRequestSchema.safeParse(entry.request)
    const expiresAt = typeof entry.expiresAt === "string" ? Date.parse(entry.expiresAt) : Number.NaN
    if (!request.success || request.data.confirmation || entry.operationId !== key
      || typeof entry.confirmationToken !== "string" || entry.confirmationToken.length < 16
      || !Number.isFinite(expiresAt) || expiresAt <= now
      || typeof entry.createdAt !== "string" || !Number.isFinite(Date.parse(entry.createdAt))) return []
    return [[key, {
      operationId: key,
      request: request.data,
      confirmationToken: entry.confirmationToken,
      expiresAt: entry.expiresAt!,
      createdAt: entry.createdAt,
    } satisfies StoredPendingKnowledgeConfirmation]]
  }))
  return { version: 1, pending }
}
