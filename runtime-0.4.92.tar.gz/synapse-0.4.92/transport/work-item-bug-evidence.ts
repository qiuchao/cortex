import { isAbsolute } from "node:path"
import { z } from "zod"
import { BugAttachmentSchema, BugHistoryResponseSchema, TASK_CAPABILITY_PROTOCOL_VERSION, type TaskCapabilityExecuteRequest } from "@cerebro/wire"
import { executeTaskCapabilityRequest } from "./brain-contract-align.ts"
import type { TaskAttachmentMaterializationLimits } from "./task-attachment-materializer.ts"

export const BUG_EVIDENCE_LIMITS = { activityPages: 20, activityPageSize: 25, activityChars: 24_000, images: 5, imageBytes: 10 * 1024 * 1024, totalImageBytes: 30 * 1024 * 1024 } as const
const IMAGE_MIME_TYPES = ["image/png", "image/jpeg", "image/gif"] as const
const AttachmentListSchema = z.object({ items: z.array(BugAttachmentSchema) })

export interface BugEvidenceError {
  scope: "activities" | "attachments" | "attachment"
  code: string
  message: string
  attachmentId?: string
}

export interface BugEvidenceAttachment {
  metadata: z.infer<typeof BugAttachmentSchema>
  status: "materialized" | "metadata_only" | "unavailable"
  localPath?: string
  error?: BugEvidenceError
}

export interface WorkItemBugEvidence {
  publicId: string
  productionId: string
  activities: {
    items: z.infer<typeof BugHistoryResponseSchema>["items"]
    nextCursor: string | null
    complete: boolean
    truncationReason?: string
  }
  attachments: { items: BugEvidenceAttachment[]; complete: boolean }
  errors: BugEvidenceError[]
  complete: boolean
  budgetUsage?: { imageAttempts: number; imageBytes: number }
}

export interface BugEvidenceScope {
  publicId: string
  productionId: string
  maxActivityChars?: number
  maxImages?: number
  maxImageBytes?: number
}

/** Read evidence through the same authenticated capability API as explicit tools.
 * `complete` covers activity history and eligible screenshots, not metadata-only files. */
export async function loadWorkItemBugEvidence(
  scope: BugEvidenceScope,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
  dependencies: { execute?: typeof executeTaskCapabilityRequest } = {},
): Promise<WorkItemBugEvidence> {
  const execute = dependencies.execute ?? executeTaskCapabilityRequest
  const evidence: WorkItemBugEvidence = {
    publicId: scope.publicId, productionId: scope.productionId,
    activities: { items: [], nextCursor: null, complete: false },
    attachments: { items: [], complete: false }, errors: [], complete: false,
    budgetUsage: { imageAttempts: 0, imageBytes: 0 },
  }
  const addError = (error: BugEvidenceError) => { evidence.errors.push(error); return error }
  const request = async (command: "bug.activity" | "bug.attachment.list" | "bug.attachment.get", input: Record<string, unknown>, errorScope: BugEvidenceError["scope"], limits?: TaskAttachmentMaterializationLimits): Promise<{ value: unknown } | { error: BugEvidenceError }> => {
    try {
      signal?.throwIfAborted()
      const result = await execute({ protocolVersion: TASK_CAPABILITY_PROTOCOL_VERSION, productionId: scope.productionId, command, input: { bugId: scope.publicId, ...input } } as TaskCapabilityExecuteRequest, env, signal, limits)
      signal?.throwIfAborted()
      if (!result.ok) return { error: addError({ scope: errorScope, code: result.reason, message: `${command} failed (${result.reason})`, ...(typeof input.attachmentId === "string" ? { attachmentId: input.attachmentId } : {}) }) }
      if (result.response.kind !== "result" || result.response.command !== command) throw new Error("Unexpected capability response")
      return { value: result.response.result }
    } catch {
      return { error: addError({ scope: errorScope, code: signal?.aborted ? "aborted" : "request_failed", message: signal?.aborted ? "Evidence loading was cancelled" : `${command} did not return usable evidence`, ...(typeof input.attachmentId === "string" ? { attachmentId: input.attachmentId } : {}) }) }
    }
  }

  let activityChars = 0
  const activityBudget = boundedBudget(scope.maxActivityChars, BUG_EVIDENCE_LIMITS.activityChars)
  const seenCursors = new Set<string>()
  for (let page = 0; page < BUG_EVIDENCE_LIMITS.activityPages; page++) {
    if (activityChars >= activityBudget) { evidence.activities.truncationReason = "activity_character_budget"; break }
    const response = await request("bug.activity", { limit: BUG_EVIDENCE_LIMITS.activityPageSize, ...(evidence.activities.nextCursor ? { cursor: evidence.activities.nextCursor } : {}) }, "activities")
    if ("error" in response) break
    const parsed = BugHistoryResponseSchema.safeParse(response.value)
    if (!parsed.success) { addError({ scope: "activities", code: "invalid_response", message: "Bug activity response failed schema validation" }); break }
    const chars = JSON.stringify(parsed.data.items).length
    if (activityChars + chars > activityBudget) { evidence.activities.truncationReason = "activity_character_budget"; break }
    evidence.activities.items.push(...parsed.data.items)
    activityChars += chars
    evidence.activities.nextCursor = parsed.data.nextCursor ?? null
    if (!evidence.activities.nextCursor) { evidence.activities.complete = true; break }
    if (seenCursors.has(evidence.activities.nextCursor)) { evidence.activities.truncationReason = "repeated_activity_cursor"; break }
    seenCursors.add(evidence.activities.nextCursor)
    if (page + 1 === BUG_EVIDENCE_LIMITS.activityPages) evidence.activities.truncationReason = "activity_page_budget"
  }
  if (evidence.activities.truncationReason) addError({ scope: "activities", code: evidence.activities.truncationReason, message: "Bug activity history is partial; continue from nextCursor (null means the first page)" })

  const listed = await request("bug.attachment.list", {}, "attachments")
  if (!("error" in listed)) {
    const parsed = AttachmentListSchema.safeParse(listed.value)
    if (!parsed.success) addError({ scope: "attachments", code: "invalid_response", message: "Bug attachment list failed schema validation" })
    else {
      evidence.attachments.complete = true
      let imageCount = 0
      let imageBytes = 0
      const imageBudget = boundedBudget(scope.maxImages, BUG_EVIDENCE_LIMITS.images)
      const byteBudget = boundedBudget(scope.maxImageBytes, BUG_EVIDENCE_LIMITS.totalImageBytes)
      for (const metadata of parsed.data.items) {
        const attachment: BugEvidenceAttachment = { metadata, status: "metadata_only" }
        evidence.attachments.items.push(attachment)
        if (metadata.kind !== "screenshot") continue
        const unavailable = (code: string, message: string) => {
          attachment.status = "unavailable"
          attachment.error = addError({ scope: "attachment", code, message, attachmentId: metadata.id })
          evidence.attachments.complete = false
        }
        if (metadata.processingStatus !== "ready") { unavailable("attachment_not_ready", "Screenshot is not ready"); continue }
        if (!(IMAGE_MIME_TYPES as readonly string[]).includes(metadata.storedMimeType)) { unavailable("unsupported_image", "Screenshot MIME type is not supported for automatic reading"); continue }
        if (metadata.storedByteSize <= 0 || metadata.storedByteSize > BUG_EVIDENCE_LIMITS.imageBytes) { unavailable("image_size_budget", "Screenshot exceeds the automatic per-image size budget or has no content"); continue }
        if (imageCount >= imageBudget || imageBytes + metadata.storedByteSize > byteBudget) { unavailable("image_total_budget", "Screenshot was not downloaded because the automatic image budget was reached"); continue }
        // Reserve attempts, including failed transfers, so failures cannot expand the budget.
        imageCount++
        imageBytes += metadata.storedByteSize
        evidence.budgetUsage = { imageAttempts: imageCount, imageBytes }
        const downloaded = await request("bug.attachment.get", { attachmentId: metadata.id }, "attachment", { maxBytes: metadata.storedByteSize, allowedMimeTypes: IMAGE_MIME_TYPES })
        if ("error" in downloaded) { attachment.status = "unavailable"; attachment.error = downloaded.error; evidence.attachments.complete = false; continue }
        const materialized = downloaded.value as { localPath?: unknown; attachment?: unknown } | null
        const returnedMetadata = BugAttachmentSchema.safeParse(materialized?.attachment)
        if (typeof materialized?.localPath !== "string" || !isAbsolute(materialized.localPath) || !returnedMetadata.success || returnedMetadata.data.id !== metadata.id || returnedMetadata.data.productionId !== metadata.productionId || returnedMetadata.data.bugId !== metadata.bugId || returnedMetadata.data.checksum !== metadata.checksum || returnedMetadata.data.storedByteSize !== metadata.storedByteSize || returnedMetadata.data.storedMimeType !== metadata.storedMimeType) {
          unavailable("invalid_materialized_attachment", "Downloaded screenshot did not match its listed metadata")
          continue
        }
        attachment.status = "materialized"
        attachment.localPath = materialized.localPath
      }
    }
  }
  evidence.complete = evidence.activities.complete && evidence.attachments.complete
  return evidence
}

function boundedBudget(value: number | undefined, maximum: number): number {
  return value === undefined ? maximum : Number.isFinite(value) ? Math.max(0, Math.min(maximum, Math.floor(value))) : 0
}
