/**
 * lib/git-rules-loader.ts — 读取 git-rules.json，三层加载（内置 → 全局 → 项目级）
 *
 * 新写（Phase 1.1 线 A）。
 *
 * 覆盖 PRD v0.2 §4.3 R11/R12：
 *   - R11: Synapse 定义 .synapse/git-rules.json schema
 *   - R12: Git policy 启动时必须读此文件；不存在走默认值；解析失败 fail-safe 走默认值并 warn
 *
 * 三层加载（优先级高 → 低）：
 *   1. 项目级：<project-root>/.synapse/git-rules.json
 *   2. 全局级：~/.config/synapse/git-rules.json
 *   3. 内置默认值
 *
 * 使用方式：
 *   const rules = loadGitRules()  // 默认从 process.cwd()/.synapse/git-rules.json 读
 *   const rules = loadGitRules('/path/to/project')  // 指定项目根
 */

import { readFileSync, existsSync } from "node:fs"
import {
  resolveGlobalGitRulesPath,
  resolveProjectGitRulesPath,
} from "./git/rules-paths.mjs"

// ────────────────────────────────────────────────────────────────────
// Schema 定义
// ────────────────────────────────────────────────────────────────────

/** .synapse/git-rules.json 的完整 schema */
export interface GitRules {
  /**
   * 允许的分支前缀（如 ["feat/", "fix/", "docs/", "art/", "design/"]）
   * Synapse Git policy 创建分支时必须遵守此列表
   */
  branchPrefixes: string[]

  /**
   * commit message 风格：
   *   - "conventional"：程序员风格，格式 `feat(scope): message`
   *   - "narrative"：叙述式，无 `feat:` 前缀，适合策划/美术
   */
  messageStyle: "conventional" | "narrative"

  /**
   * commit message 语言：
   *   - "zh"：中文
   *   - "en"：英文
   *   - "auto"：根据上下文自动选择
   */
  messageLanguage: "zh" | "en" | "auto"

  /**
   * 单次 commit 最大文件数（超过提示拆分）
   * 默认 20
   */
  maxFilesPerCommit: number

  /**
   * 敏感信息额外 regex 列表（项目可补充，Synapse Git policy 会追加到内置列表）
   * 内置列表包含：AWS_KEY/PRIVATE_KEY/password=/token=/.env 等
   */
  sensitivePatterns: string[]

  /**
   * 敏感模式 allowlist：从「内置 14 条 + sensitivePatterns 追加」的生效集合中
   * 精确剔除的 pattern 源字符串（字面匹配，非正则）。典型："\\.env\\."。
   * 注意：builtin 列表与「剔除应用」只存在于 git-safety-gateway.mjs，本字段在 loader 侧仅作 schema 承载，
   * 实际剔除发生在 gateway（最终生效集合以 gateway 为准）。默认 []。
   * ADR: gateway-sensitive-pattern-allowlist
   */
  sensitivePatternIgnores?: string[]

  /**
   * 敏感文件名 regex 列表（追加到层 A 文件名检测；如 "(^|/)id_rsa$"、"\\.pem$"）。
   * 内置层 A builtin（"(^|/)\\.env$" / "(^|/)\\.env\\."）只在 gateway，loader 仅承载 schema +
   * 跨层并集去重，实际 enforcement 在 git-safety-gateway.mjs。默认 []。
   * ADR: gateway-two-layer-sensitive-detection
   */
  sensitiveFilePatterns?: string[]

  /**
   * 大文件阈值（MB）；超过此值时 Synapse Git policy 会拒绝直接提交，引导 LFS
   * 默认 10
   */
  lfsThresholdMB: number

  // ── v2 扩展字段（可选，ADR: git-rules-loader-v2 extends project-level-config-schema）

  /**
   * 触发双向同步（cherry-pick 回主干）的分支名 regex 列表。
   * 若当前分支名命中任意 pattern，提交后自动提议同步到主干。
   * 默认：["^branch/release\\d+(/|$)"]
   * 可选，不传则用默认值。每个 pattern 会做 new RegExp 合法性校验。
   */
  dualSyncPatterns?: string[]

  /**
   * 是否追踪父分支关系（branch-parent.json）。
   * true：Synapse Git policy 新建分支时记录父分支，用于后续同步目标判断。
   * false：禁用父分支追踪。
   * 默认：true
   */
  parentBranchTracking?: boolean
}

// ────────────────────────────────────────────────────────────────────
// 内置默认值
// ────────────────────────────────────────────────────────────────────

export const DEFAULT_GIT_RULES: Readonly<GitRules> = {
  branchPrefixes: ["feat/", "fix/", "docs/", "art/", "design/", "refactor/", "chore/"],
  messageStyle: "conventional",
  messageLanguage: "auto",
  maxFilesPerCommit: 20,
  sensitivePatterns: [],
  // ADR: gateway-sensitive-pattern-allowlist — 默认空数组，向后兼容（缺失=行为不变）
  sensitivePatternIgnores: [],
  // ADR: gateway-two-layer-sensitive-detection — 文件名层追加项，默认空数组
  sensitiveFilePatterns: [],
  lfsThresholdMB: 10,
  // v2 扩展默认值（ADR: git-rules-loader-v2）
  dualSyncPatterns: ["^branch/release\\d+(/|$)"],
  parentBranchTracking: true,
} as const

// ────────────────────────────────────────────────────────────────────
// 加载函数
// ────────────────────────────────────────────────────────────────────

/**
 * 三层加载 git-rules（内置 → 全局 → 项目级），浅合并，优先级高的覆盖低的。
 *
 * @param projectRoot 项目根目录，默认 process.cwd()
 * @returns 合并后的 GitRules
 */
export function loadGitRules(projectRoot?: string): GitRules {
  const root = projectRoot ?? process.cwd()

  // 层 1：内置默认值（基准）
  const base = { ...DEFAULT_GIT_RULES }

  // 层 2：全局配置（~/.config/synapse/git-rules.json）
  const globalLocation = resolveGlobalGitRulesPath()
  const globalRules = tryLoadRulesFile(
    globalLocation.path,
    globalLocation.retired ? "全局旧版路径" : "全局",
  )
  const withGlobal = globalRules ? mergeRules(base, globalRules) : base

  // 层 3：项目级配置（<project>/.synapse/git-rules.json）
  const projectLocation = resolveProjectGitRulesPath(root)
  const projectRules = tryLoadRulesFile(
    projectLocation.path,
    projectLocation.retired ? "项目级旧版路径" : "项目级",
  )
  const withProject = projectRules ? mergeRules(withGlobal, projectRules) : withGlobal

  return withProject
}

// ────────────────────────────────────────────────────────────────────
// 私有工具函数
// ────────────────────────────────────────────────────────────────────

/**
 * 尝试读取并解析一个 git-rules JSON 文件。
 * 文件不存在返回 null；解析失败 warn + 返回 null。
 */
function tryLoadRulesFile(filePath: string, label: string): Partial<GitRules> | null {
  if (!existsSync(filePath)) {
    return null
  }

  let raw: string
  try {
    raw = readFileSync(filePath, "utf8")
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn(
      `[synapse] 读取 ${label} git-rules.json 失败：${errorMessage(err)}，已跳过`,
    )
    return null
  }

  // BOM 兼容
  if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1)

  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn(
      `[synapse] ${label} git-rules.json 解析失败：${errorMessage(err)}，已跳过`,
    )
    return null
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    // eslint-disable-next-line no-console
    console.warn(`[synapse] ${label} git-rules.json 格式错误（不是对象），已跳过`)
    return null
  }

  const user = parsed as Record<string, unknown>

  // 提取已知字段（仅覆盖 override 中存在的字段）
  const result: Partial<GitRules> = {}
  const bp = asStringArray(user["branchPrefixes"])
  if (bp !== undefined) result.branchPrefixes = bp
  const ms = asMessageStyle(user["messageStyle"])
  if (ms !== undefined) result.messageStyle = ms
  const ml = asMessageLanguage(user["messageLanguage"])
  if (ml !== undefined) result.messageLanguage = ml
  const mf = asPositiveInt(user["maxFilesPerCommit"])
  if (mf !== undefined) result.maxFilesPerCommit = mf
  const sp = asStringArray(user["sensitivePatterns"])
  if (sp !== undefined) result.sensitivePatterns = sp
  // ADR: gateway-sensitive-pattern-allowlist
  const spi = asStringArray(user["sensitivePatternIgnores"])
  if (spi !== undefined) result.sensitivePatternIgnores = spi
  // ADR: gateway-two-layer-sensitive-detection
  const sfp = asStringArray(user["sensitiveFilePatterns"])
  if (sfp !== undefined) result.sensitiveFilePatterns = sfp
  const lfs = asPositiveInt(user["lfsThresholdMB"])
  if (lfs !== undefined) result.lfsThresholdMB = lfs

  // v2 扩展字段（ADR: git-rules-loader-v2）
  const dsp = asStringArrayWithRegexValidation(user["dualSyncPatterns"])
  if (dsp !== undefined) result.dualSyncPatterns = dsp

  const pbt = asBoolean(user["parentBranchTracking"])
  if (pbt !== undefined) result.parentBranchTracking = pbt

  return result
}

/**
 * 跨层合并：override 中存在的字段覆盖 base，其余保留 base 值。
 *
 * 例外（ADR: gateway-sensitive-pattern-allowlist，Option A；
 *        ADR: gateway-two-layer-sensitive-detection 追加 sensitiveFilePatterns）：
 *   sensitivePatterns / sensitivePatternIgnores / sensitiveFilePatterns 为「敏感相关数组字段」，
 *   跨层取**并集去重**，而非覆盖——禁止项目级以覆盖方式削弱全局级敏感检测（安全降级 footgun）。
 *   与 gateway collectFrom 的「全局+项目级追加」语义对齐。
 *   注：builtin 与剔除应用只在 gateway 发生（最终生效集合以 gateway 为准），
 *   loader 此处仅承载 schema 合并，不做 enforcement。
 */
function mergeRules(base: GitRules, override: Partial<GitRules>): GitRules {
  const merged = { ...base, ...override }
  for (const field of [
    "sensitivePatterns",
    "sensitivePatternIgnores",
    "sensitiveFilePatterns",
  ] as const) {
    if (override[field] !== undefined) {
      merged[field] = Array.from(
        new Set([...(base[field] ?? []), ...(override[field] ?? [])]),
      )
    }
  }
  return merged
}

function asStringArray(v: unknown): string[] | undefined {
  if (!Array.isArray(v)) return undefined
  if (v.every((x) => typeof x === "string")) return v as string[]
  return undefined
}

/**
 * 与 asStringArray 同，但额外做 new RegExp 合法性校验（ADR: git-rules-loader-v2）。
 * 非法 pattern 逐条 warn + 跳过（fail-safe，不整体放弃）。
 */
function asStringArrayWithRegexValidation(v: unknown): string[] | undefined {
  const arr = asStringArray(v)
  if (arr === undefined) return undefined
  const valid: string[] = []
  for (const pattern of arr) {
    try {
      new RegExp(pattern)  // 校验合法性
      valid.push(pattern)
    } catch {
      // eslint-disable-next-line no-console
      console.warn(`[synapse] dualSyncPatterns: 非法 regex "${pattern}"，已跳过`)
    }
  }
  return valid
}

/**
 * 提取 boolean 值（ADR: git-rules-loader-v2）。
 * 非 boolean 值 warn + 返回 undefined。
 */
function asBoolean(v: unknown): boolean | undefined {
  if (typeof v === "boolean") return v
  if (v !== undefined && v !== null) {
    // eslint-disable-next-line no-console
    console.warn(`[synapse] parentBranchTracking: 期望 boolean，得到 ${typeof v}，已忽略`)
  }
  return undefined
}

function asMessageStyle(v: unknown): GitRules["messageStyle"] | undefined {
  if (v === "conventional" || v === "narrative") return v
  return undefined
}

function asMessageLanguage(v: unknown): GitRules["messageLanguage"] | undefined {
  if (v === "zh" || v === "en" || v === "auto") return v
  return undefined
}

function asPositiveInt(v: unknown): number | undefined {
  if (typeof v !== "number" || !Number.isFinite(v)) return undefined
  const n = Math.floor(v)
  return n > 0 ? n : undefined
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}
