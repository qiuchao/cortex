// Handle-bound Windows spool I/O. The only ACL policy for both cold and warm paths.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;

public sealed class IterationPrivateFiles : IDisposable {
  const uint Read = 0x80000000, Write = 0x40000000, Delete = 0x10000, Control = 0x20000;
  const uint Open = 3, New = 1, DirectoryFlag = 0x02000000, ReparseFlag = 0x00200000, DeleteOnClose = 0x04000000;
  const int MaxBytes = 16384;
  readonly string root, sid;
  readonly List<SafeFileHandle> directories = new List<SafeFileHandle>();
  readonly Dictionary<string, Info> published = new Dictionary<string, Info>();
  readonly Dictionary<string, SafeFileHandle> prepared = new Dictionary<string, SafeFileHandle>();
  SafeFileHandle directory;
  [StructLayout(LayoutKind.Sequential)] struct Attributes { public int Length; public IntPtr Descriptor; [MarshalAs(UnmanagedType.Bool)] public bool Inherit; }
  [StructLayout(LayoutKind.Sequential)] struct Info { public uint Attributes; public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write; public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow; }
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] static extern bool CreateDirectory(string name, ref Attributes attributes);
  [DllImport("kernel32.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] static extern bool GetFileInformationByHandle(SafeFileHandle file, out Info info);
  [DllImport("kernel32.dll", SetLastError=true)] [return: MarshalAs(UnmanagedType.Bool)] static extern bool SetFileInformationByHandle(SafeFileHandle file, int kind, IntPtr data, uint size);
  [DllImport("advapi32.dll")] static extern uint GetSecurityInfo(SafeFileHandle handle, int kind, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
  [DllImport("advapi32.dll")] static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr pointer);
  static void Require(bool ok) { if (!ok) throw new IOException("private iteration object unavailable"); }
  static Info Inspect(SafeFileHandle handle, bool dir) {
    Info info; Require(GetFileInformationByHandle(handle, out info));
    Require((info.Attributes & 0x400) == 0 && ((info.Attributes & 0x10) != 0) == dir && (dir || info.Links == 1));
    return info;
  }
  static bool Same(Info a, Info b) { return a.Volume == b.Volume && a.IndexHigh == b.IndexHigh && a.IndexLow == b.IndexLow; }
  SafeFileHandle OpenPath(string path, uint access, bool dir, uint creation = Open, bool temporary = false, uint sharing = 3, bool publicationPending = false) {
    // No FILE_SHARE_DELETE: a pinned directory/file cannot be renamed or replaced.
    var handle = CreateFile(path, access | Control, sharing, IntPtr.Zero, creation, ReparseFlag | (dir ? DirectoryFlag : 0) | (temporary ? DeleteOnClose : 0), IntPtr.Zero);
    if (handle.IsInvalid) {
      int error = Marshal.GetLastWin32Error(); handle.Dispose();
      // Only the reader's first open can overlap Rename -> writer Dispose.
      // Never relax the writer lock or turn later ACL/identity failures into polling.
      if (publicationPending && (error == 2 || error == 32)) return null;
      throw new IOException("private iteration open failed");
    }
    try { Inspect(handle, dir); return handle; } catch { handle.Dispose(); throw; }
  }
  void CheckAcl(SafeFileHandle handle) {
    IntPtr owner, group, dacl, sacl, pointer;
    Require(GetSecurityInfo(handle, 1, 5, out owner, out group, out dacl, out sacl, out pointer) == 0);
    try {
      var bytes = new byte[GetSecurityDescriptorLength(pointer)]; Marshal.Copy(pointer, bytes, 0, bytes.Length);
      var security = new RawSecurityDescriptor(bytes, 0);
      Require(security.Owner != null && security.Owner.Value == sid && security.DiscretionaryAcl != null);
      foreach (GenericAce entry in security.DiscretionaryAcl) {
        var ace = entry as QualifiedAce;
        Require(ace != null && !ace.IsCallback && (ace.AceQualifier == AceQualifier.AccessAllowed || ace.AceQualifier == AceQualifier.AccessDenied));
        if (ace.AceQualifier == AceQualifier.AccessAllowed)
          Require(ace.SecurityIdentifier.Value == sid || ace.SecurityIdentifier.Value == "S-1-5-18");
      }
    } finally { LocalFree(pointer); }
  }
  void CreateRoot() {
    if (System.IO.Directory.Exists(root) || File.Exists(root)) return;
    var security = new RawSecurityDescriptor("O:" + sid + "D:P(A;OICI;FA;;;" + sid + ")(A;OICI;FA;;;SY)");
    var bytes = new byte[security.BinaryLength]; security.GetBinaryForm(bytes, 0);
    IntPtr pointer = Marshal.AllocHGlobal(bytes.Length);
    try {
      Marshal.Copy(bytes, 0, pointer, bytes.Length);
      var attributes = new Attributes { Length = Marshal.SizeOf(typeof(Attributes)), Descriptor = pointer };
      Require(CreateDirectory(root, ref attributes));
    } finally { Marshal.FreeHGlobal(pointer); }
  }
  public IterationPrivateFiles(string path, bool initialize) {
    root = Path.GetFullPath(path); sid = WindowsIdentity.GetCurrent().User.Value;
    Require(Path.GetFileName(root) == "iteration-delivery" && !root.StartsWith("\\\\", StringComparison.Ordinal));
    try {
      // Pin all ancestors, rejecting reparse points, before touching private data.
      string part = Path.GetPathRoot(root);
      foreach (string component in root.Substring(part.Length).Split(Path.DirectorySeparatorChar)) {
        if (component.Length == 0) continue;
        directories.Add(OpenPath(part, Read, true)); part = Path.Combine(part, component);
      }
      if (initialize) CreateRoot();
      directory = OpenPath(root, Read, true); directories.Add(directory); CurrentDirectory();
      if (initialize) CleanupStartup();
    } catch { Dispose(); throw; }
  }
  void CurrentDirectory() {
    CheckAcl(directory);
    using (var current = OpenPath(root, Read, true)) {
      Require(Same(Inspect(directory, true), Inspect(current, true))); CheckAcl(current);
    }
  }
  static void Id(string id) { Require(id != null && Regex.IsMatch(id, "\\A[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\\z")); }
  string Name(string id, bool temp) { Id(id); return Path.Combine(root, (temp ? ".response-" : "response-") + id + (temp ? ".tmp" : ".json")); }
  void CurrentFile(string path, SafeFileHandle file, uint access) {
    CurrentDirectory(); CheckAcl(file);
    using (var current = OpenPath(path, access, false, Open, false, 7)) { Require(Same(Inspect(file, false), Inspect(current, false))); CheckAcl(current); }
  }
  void CleanupStartup() {
    foreach (string path in System.IO.Directory.GetFileSystemEntries(root)) {
      string name = Path.GetFileName(path);
      Require(Regex.IsMatch(name, "\\A(?:response-[a-f0-9-]{36}\\.json|\\.response-[a-f0-9-]{36}\\.tmp)\\z"));
      using (var file = OpenPath(path, Read | Delete, false)) { CurrentFile(path, file, Read); SetInfo(file, 4, new byte[] { 1 }); }
    }
  }
  public void Check(string id) {
    CurrentDirectory();
    if (id != "") using (var file = OpenPath(Name(id, false), Read, false)) { CurrentFile(Name(id, false), file, Read); }
  }
  public void Prepare(string id) {
    Id(id); CurrentDirectory(); Require(prepared.Count < 64 && !prepared.ContainsKey(id));
    var file = OpenPath(Name(id, true), Read | Write | Delete, false, New, true);
    try { CurrentFile(Name(id, true), file, Write); prepared.Add(id, file); }
    catch { file.Dispose(); throw; }
  }
  static long Now() { return DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(); }
  static void SetInfo(SafeFileHandle handle, int kind, byte[] bytes) {
    IntPtr pointer = Marshal.AllocHGlobal(bytes.Length);
    try { Marshal.Copy(bytes, 0, pointer, bytes.Length); Require(SetFileInformationByHandle(handle, kind, pointer, (uint)bytes.Length)); }
    finally { Marshal.FreeHGlobal(pointer); }
  }
  static void DeleteWhenClosed(SafeFileHandle handle, bool delete) {
    // FileDispositionInfoEx: ON_CLOSE sets or clears the per-handle close state.
    SetInfo(handle, 21, BitConverter.GetBytes(delete ? 9 : 8));
  }
  void Rename(SafeFileHandle file, string target) {
    byte[] name = Encoding.Unicode.GetBytes(target);
    int offset = IntPtr.Size == 8 ? 20 : 12;
    byte[] info = new byte[offset + name.Length + 2];
    Buffer.BlockCopy(BitConverter.GetBytes(name.Length), 0, info, offset - 4, 4);
    Buffer.BlockCopy(name, 0, info, offset, name.Length);
    SetInfo(file, 3, info); // FILE_RENAME_INFO, ReplaceIfExists=false, RootDirectory=NULL.
  }
  public void Commit(string id, string base64, long deadline) {
    Id(id); SafeFileHandle file; Require(prepared.TryGetValue(id, out file));
    try {
      byte[] bytes = Convert.FromBase64String(base64); Require(published.Count < 256 && bytes.Length <= MaxBytes && deadline > Now());
      CurrentFile(Name(id, true), file, Write);
      // FileStream owns neither the held native handle nor the helper lifetime.
      using (var alias = new SafeFileHandle(file.DangerousGetHandle(), false))
      using (var stream = new FileStream(alias, FileAccess.Write)) { stream.Write(bytes, 0, bytes.Length); stream.Flush(); }
      CurrentFile(Name(id, true), file, Write); Require(deadline > Now());
      Rename(file, Name(id, false));
      // A failure before this last step leaves delete-on-close enabled.
      Require(deadline > Now()); DeleteWhenClosed(file, false);
      published[id] = Inspect(file, false);
    } finally { prepared.Remove(id); file.Dispose(); }
  }
  public string ReadResult(string id) {
    string path = Name(id, false); CurrentDirectory();
    using (var file = OpenPath(path, Read | Delete, false, Open, false, 3, true)) {
      if (file == null) return null;
      CurrentFile(path, file, Read);
      var info = Inspect(file, false); Require(info.SizeHigh == 0 && info.SizeLow <= MaxBytes);
      byte[] bytes = new byte[info.SizeLow];
      using (var alias = new SafeFileHandle(file.DangerousGetHandle(), false))
      using (var stream = new FileStream(alias, FileAccess.Read)) {
        int count = 0; while (count < bytes.Length) { int n = stream.Read(bytes, count, bytes.Length-count); Require(n > 0); count += n; }
        Require(stream.ReadByte() == -1);
      }
      CurrentFile(path, file, Read); SetInfo(file, 4, new byte[] { 1 });
      return Convert.ToBase64String(bytes);
    }
  }
  public void Remove(string id) {
    Id(id); CurrentDirectory(); Info expected;
    if (!published.TryGetValue(id, out expected)) throw new IOException("unknown published response");
    string path = Name(id, false);
    {
      // Missing after reader consumption is normal. Any other failure is closed.
      var file = CreateFile(path, Read | Delete | Control, 3, IntPtr.Zero, Open, ReparseFlag, IntPtr.Zero);
      if (file.IsInvalid) {
        int error = Marshal.GetLastWin32Error(); file.Dispose();
        if (error == 2 || error == 3) { published.Remove(id); return; }
        throw new IOException("published result cleanup failed");
      }
      using (file) {
        Require(Same(expected, Inspect(file, false))); CurrentFile(path, file, Read);
        SetInfo(file, 4, new byte[] { 1 });
      }
      published.Remove(id);
    }
  }
  public void Abort(string id) {
    Id(id); SafeFileHandle file;
    if (prepared.TryGetValue(id, out file)) { prepared.Remove(id); file.Dispose(); }
  }
  public static string ReadMessage() {
    var value = new StringBuilder();
    for (;;) { int c = Console.In.Read(); if (c == -1) { Require(value.Length == 0); return null; } if (c == 10) return value.ToString(); Require(value.Length < 32768); value.Append((char)c); }
  }
  public void Dispose() {
    foreach (var file in prepared.Values) file.Dispose(); prepared.Clear();
    for (int i = directories.Count-1; i >= 0; i--) directories[i].Dispose(); directories.Clear();
  }
}
