import { isDeepStrictEqual } from "node:util"
import { parseTaskCapabilityResponse } from "../core/task-capability-result.ts"
import {
  TaskCapabilityExecuteRequestSchema,
  TaskCapabilityReadCommandSchema,
  KnowledgeAgentExecuteRequestSchema,
  KnowledgeAgentExecuteResponseSchema,
} from "@cerebro/wire"
import type { TaskTurnExecutionAuthorization, TaskTurnGuardRegistry } from "../core/task-turn-guard.ts"
import type {
  KnowledgeConfirmationIntake,
  KnowledgeConfirmationPendingResponse,
  KnowledgeInlineConfirmationDecisionRequest,
  KnowledgeInlineConfirmationDecision,
} from "../core/knowledge-confirmation-intake.ts"
import type { AgentCapabilityBroker, AgentExecutionResult } from "./agent-capability-broker.ts"
import { isCapabilityRouteTerminalResponse } from "./task-route-execution.ts"

export type SettledCapabilityExecutionResult = AgentExecutionResult | { ok: true; response: unknown }

export async function settleCapabilityRouteExecution(input: {
  broker: AgentCapabilityBroker
  confirmationIntake?: KnowledgeConfirmationIntake
  guards?: TaskTurnGuardRegistry
  routeToken?: string
  authorization: TaskTurnExecutionAuthorization
  request: unknown
  authorizationRequest?: unknown
  result: AgentExecutionResult
  signal?: AbortSignal
  decideInlineConfirmation?: (request: KnowledgeInlineConfirmationDecisionRequest) => Promise<KnowledgeInlineConfirmationDecision>
}): Promise<SettledCapabilityExecutionResult> {
  if (input.signal?.aborted) return {
    ok: false, reason: "transport_unavailable", message: "Capability request was cancelled", httpStatus: 409,
  }
  if (!input.result.ok) return input.result
  const task = TaskCapabilityExecuteRequestSchema.safeParse(input.request)
  if (task.success && TaskCapabilityReadCommandSchema.safeParse(task.data.command).success) {
    try { parseTaskCapabilityResponse(task.data, input.result.response) } catch {
      return { ok: false, reason: "kh_returned_error", message: "Task response failed shared schema, command or request binding validation" }
    }
  }
  const confirmation = KnowledgeAgentExecuteResponseSchema.safeParse(input.result.response)
  // A reply may arrive after the user has replaced or revoked this turn.
  // Recheck before capturing a receipt that could trigger a confirmed write.
  const current = input.authorization.tracked && input.guards && input.routeToken
    ? input.guards.authorizeExecution(input.routeToken, input.authorizationRequest ?? input.request)
    : undefined
  if (input.authorization.tracked && (!current?.allowed
    || !isDeepStrictEqual(current.request, input.authorization.request))) {
    return {
      ok: false,
      reason: "turn_scope_denied",
      message: "Capability response belongs to a turn that is no longer authorized",
      httpStatus: 409,
    }
  }
  if (confirmation.success && confirmation.data.status === "confirmation_required") {
    const request = KnowledgeAgentExecuteRequestSchema.safeParse(input.request)
    if (!request.success || request.data.confirmation || !input.confirmationIntake) {
      return {
        ok: false,
        reason: "turn_scope_denied",
        message: "Knowledge confirmation could not be bound to a trusted user turn",
        httpStatus: 409,
      }
    }
    const captured = input.confirmationIntake.capture(
      request.data,
      confirmation.data,
    )
    const confirmedRequest = input.authorization.knowledgeUserInput && input.decideInlineConfirmation
      ? await input.confirmationIntake.confirmInline(captured.operationId, input.authorization.knowledgeUserInput, input.decideInlineConfirmation)
      : undefined
    if (input.signal?.aborted) return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    const confirmationAuthorization = input.authorization.tracked && input.guards && input.routeToken
      ? input.guards.authorizeExecution(input.routeToken, input.authorizationRequest ?? input.request)
      : undefined
    if (input.authorization.tracked && (!confirmationAuthorization?.allowed
      || !isDeepStrictEqual(confirmationAuthorization.request, input.authorization.request))) {
      return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    }
    if (!confirmedRequest) {
      markRouteComplete(input)
      return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
    }

    const intake = input.confirmationIntake
    const settled = await intake.executeInline(captured.operationId, confirmedRequest, async confirmedRequest => {
      const confirmed = input.signal
        ? await input.broker.execute(confirmedRequest, input.signal)
        : await input.broker.execute(confirmedRequest)
      if (!confirmed.ok) return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
      const repeated = KnowledgeAgentExecuteResponseSchema.safeParse(confirmed.response)
      if (!repeated.success || repeated.data.capability !== request.data.capability) {
        return pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
      }
      if (repeated.data.status === "confirmation_required") {
        const publicResponse = intake.updateReceipt(captured.operationId, repeated.data)
        return publicResponse
          ? { ok: true, response: publicResponse }
          : pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
      }
      markRouteComplete(input)
      intake.complete(captured.operationId)
      return { ok: true, response: repeated.data }
    })
    return settled ?? pendingAfterAutomaticConfirmationFailure(captured.publicResponse)
  }

  if (isCapabilityRouteTerminalResponse(input.result.response)) markRouteComplete(input)
  return input.result
}

function pendingAfterAutomaticConfirmationFailure(
  response: KnowledgeConfirmationPendingResponse,
): SettledCapabilityExecutionResult {
  return {
    ok: true,
    response: {
      ...response,
      summary: `${response.capability} 自动确认尚未完成；请先核对当前操作状态。如操作仍待确认，可在新消息中重试“${response.confirmationPrompt}”或取消；已提交的执行不会被取消撤销。`,
    },
  }
}

function markRouteComplete(input: {
  guards?: TaskTurnGuardRegistry
  routeToken?: string
  authorization: TaskTurnExecutionAuthorization
}): void {
  if (input.authorization.tracked && input.authorization.completesRoute
    && input.guards && input.routeToken && input.authorization.command) {
    input.guards.markRouted(input.routeToken, input.authorization.command)
  }
}
