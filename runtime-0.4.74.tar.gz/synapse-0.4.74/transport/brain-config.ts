/**
 * transport/brain-config.ts — Cerebro 主脑连接配置读取
 *
 * 从环境变量 + 本机 config.json 读取 brain base URL + machine token。
 * 设计原则：
 *   · machine_token 优先读 0600 文件(daemon 常驻需自启可读),回落 env CEREBRO_MACHINE_TOKEN；
 *     0600 文件权限与 unix socket 认证同级 fs 权限保护(见 DECISIONS.md D8)。
 *   · brain url 优先 env CEREBRO_BRAIN_URL,回落 config.json 的 brain_url——两源对称补齐:
 *     token 早就有「文件+env」双源热加载,但 url 原来只认 env。若 daemon 在登录前/未带 env
 *     启动(app 未注入 CEREBRO_BRAIN_URL),url 恒缺失 → KH/上报永久降级,且改不了 token 那样
 *     热加载。加 config.json 回落后:`synapse set-config --brain-url` 落盘的 url 被直接读到,
 *     daemon 无需重启即可恢复(每次调用重读,不缓存)。env 仍优先,app 注入的 url 不受影响。
 *   · 每次调用重读文件(不缓存)——热加载:daemon 跑着时更新 token/url 无需重启即生效。
 *   · 无配置时降级（uploadReports 返回 {uploaded:0}），不抛异常
 *
 * 环境变量：
 *   CEREBRO_BRAIN_URL      — brain base URL（如 https://cerebro.example 或 http://127.0.0.1:8920）;缺失时回落 config.json
 *   CEREBRO_ALLOW_INSECURE_HTTP — 显式设为 1 时允许非 loopback HTTP（受控 LAN dev 兼容）
 *   CEREBRO_MACHINE_TOKEN  — machine token（Bearer，per-user 绑 users.id）
 *                            仅在无 token 文件时使用(兼容/覆盖/测试)
 */
import { readToken } from "../core/token-store.ts"
import { readLocalConfig } from "../core/local-config.ts"
import { hasRetiredBrainPort } from "../core/brain-url-policy.ts"
import { isIP } from "node:net"

export interface BrainConfig {
  /** brain base URL，不含尾部斜杠（如 https://cerebro.example 或 http://127.0.0.1:8920） */
  brainBaseUrl: string
  /** machine token（Bearer），缺失时无法鉴权 */
  machineToken?: string
  /** 单次请求超时（ms），默认 8000 */
  timeoutMs: number
}

const DEFAULT_TIMEOUT_MS = 8_000

/**
 * 读取 brain 配置。每次调用重读 token 文件 + config.json(热加载,不缓存)。
 * url 缺失(env 与 config.json 都无)时返回 null（调用方按「未配置」降级处理）。
 *
 * url 来源优先级:
 *   1. env CEREBRO_BRAIN_URL —— app 注入 / 覆盖(仍最优先)
 *   2. config.json 的 brain_url —— `synapse set-config --brain-url` 落盘,daemon 无需重启即生效
 * token 来源优先级:
 *   1. tokenPath() 文件内容(0600)—— daemon 常驻场景,自启可读
 *   2. env CEREBRO_MACHINE_TOKEN —— 兼容/覆盖/测试
 */
export function getBrainConfig(env: NodeJS.ProcessEnv = process.env): BrainConfig | null {
  // url:env 优先,回落 config.json(对称补齐,见文件头注释)。持久化 HTTP
  // opt-in 只授权同一个已保存 URL，不能被另一个 env URL 借用。
  const local = readLocalConfig({ env })
  const envUrl = env['CEREBRO_BRAIN_URL']?.trim()
  const localUrl = local.brain_url?.trim()
  const rawUrl = envUrl || localUrl
  if (!rawUrl) return null
  const allowInsecureHttp =
    env['CEREBRO_ALLOW_INSECURE_HTTP'] === '1' ||
    (local.allow_insecure_http === true && !!localUrl && urlsEquivalent(rawUrl, localUrl))
  const brainBaseUrl = validateBrainBaseUrl(rawUrl, allowInsecureHttp)
  if (!brainBaseUrl) return null

  // 优先读 token 文件(热加载,每次重读);回落 env
  const fileToken = readToken({ env })
  const machineToken = fileToken ?? env['CEREBRO_MACHINE_TOKEN']?.trim() ?? undefined

  return {
    brainBaseUrl,
    machineToken: machineToken || undefined,
    timeoutMs: DEFAULT_TIMEOUT_MS,
  }
}

function validateBrainBaseUrl(rawUrl: string, allowInsecureHttp: boolean): string | null {
  let parsed: URL
  try {
    parsed = new URL(rawUrl)
  } catch {
    return null
  }

  if (hasRetiredBrainPort(rawUrl)) return null

  if (parsed.protocol === 'https:') return stripTrailingSlashes(parsed.toString())
  if (parsed.protocol !== 'http:') return null
  if (isLoopbackHost(parsed.hostname)) return stripTrailingSlashes(parsed.toString())
  if (allowInsecureHttp) return stripTrailingSlashes(parsed.toString())
  return null
}

/** `set-config --brain-url` 用它记录这次显式选择是否需要 LAN HTTP opt-in。 */
export function requiresInsecureHttpOptIn(rawUrl: string): boolean {
  let parsed: URL
  try {
    parsed = new URL(rawUrl)
  } catch {
    return false
  }
  return parsed.protocol === 'http:' && !isLoopbackHost(parsed.hostname)
}

function isLoopbackHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[(.*)\]$/, '$1')
  if (host === 'localhost' || host === '::1') return true
  return isIP(host) === 4 && host.startsWith('127.')
}

function stripTrailingSlashes(url: string): string {
  return url.replace(/\/+$/, '')
}

function urlsEquivalent(left: string, right: string): boolean {
  try {
    return stripTrailingSlashes(new URL(left).toString()) === stripTrailingSlashes(new URL(right).toString())
  } catch {
    return false
  }
}
