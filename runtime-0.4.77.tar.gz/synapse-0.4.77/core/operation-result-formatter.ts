/** Stable, client-neutral presentation of a Cerebro turn result. */
import type {
  OperationErrorResponse,
  OperationStatusResponse,
  OperationTurnResponse,
} from "../runtime/operation-turn-bridge.ts"

export type OperationCerebroResult = OperationTurnResponse | OperationStatusResponse | OperationErrorResponse | string

export interface OperationResultBlocksInput {
  cerebro?: OperationCerebroResult
  codex?: string
}

/** Format both result channels for a single conversation turn. */
export function formatOperationResultBlocks(input: OperationResultBlocksInput): string {
  const blocks: string[] = []
  if (input.cerebro !== undefined) blocks.push(formatCerebroBlock(input.cerebro))
  if (input.codex?.trim()) blocks.push(formatCodexBlock(input.codex))
  return blocks.join("\n\n")
}

export function formatCerebroBlock(response: OperationCerebroResult): string {
  const text = typeof response === "string" ? response.trim() : renderResponse(response)
  return `[Cerebro]\n${text || "主脑没有返回结果。"}`
}

export function formatCodexBlock(text: string): string {
  return `[Codex]\n${text.trim()}`
}

function renderResponse(response: Exclude<OperationCerebroResult, string>): string {
  if (isOperationErrorResponse(response)) return renderTransportError(response)
  if (isOperationStatusResponse(response)) return renderStatusResponse(response)
  return renderTurnResponse(response)
}

function renderTurnResponse(response: OperationTurnResponse): string {
  const meta = renderTurnMetadata(response)
  if (response.decision === "ordinary") {
    return joinLines("无需主脑操作。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "clarify") {
    return joinLines(response.clarification?.question?.trim() || "主脑需要补充信息。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "unsupported") {
    return joinLines(response.unsupported?.message?.trim() || "该主脑操作暂不支持。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "unavailable") {
    return joinLines(
      response.unavailable?.message?.trim() || "Cerebro 暂时不可用。",
      renderUnavailableDetails(response.unavailable),
      renderOrdinaryProjection(response),
      meta,
    )
  }

  const operations = (response.operations ?? []).map(renderOperation).filter(Boolean)
  return joinLines(...operations, renderOrdinaryProjection(response), meta) || "主脑操作没有返回结果。"
}

function renderStatusResponse(response: OperationStatusResponse): string {
  return joinLines(
    `状态查询：${renderOperation(response.operation) || "主脑操作状态未知。"}`,
    renderStatusMetadata(response),
  )
}

function renderTransportError(response: OperationErrorResponse): string {
  const code = response.code?.trim()
  const message = response.message?.trim() || "主脑请求失败。"
  return joinLines(
    `请求失败${code ? `（${code}）` : ""}：${message}`,
    renderRetryDetails(response),
    response.operationId ? `operationId=${response.operationId}` : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
  )
}

function renderOperation(operation: Record<string, unknown>): string {
  const operationId = typeof operation.operationId === "string" ? operation.operationId : ""
  const targetId = typeof operation.targetId === "string" ? operation.targetId : ""
  const resource = typeof operation.resource === "string" ? operation.resource : "operation"
  const action = typeof operation.action === "string" ? operation.action : ""
  const label = [resource, action].filter(Boolean).join(".") || "operation"
  const suffixItems = [
    operationId ? `operationId=${operationId}` : "",
    targetId ? `targetId=${targetId}` : "",
  ].filter(Boolean)
  const suffix = suffixItems.length ? `（${suffixItems.join("，")}）` : ""
  const status = operation.status
  if (status === "executed") return `${label} 已完成${suffix}${renderValue(operation.result)}`
  if (status === "in_progress") {
    return `${label} 执行中${suffix}${stringValue(operation.progressMessage)}${renderProgressDetails(operation)}`
  }
  if (status === "clarify") return `${label} 需要澄清${suffix}：${stringValue(operation.clarification) || "请补充信息。"}`
  if (status === "unsupported") return `${label} 暂不支持${suffix}：${stringValue(operation.reason) || "该操作暂不支持。"}`
  if (status === "failed") {
    const error = isRecord(operation.error) ? operation.error : undefined
    const code = error ? stringValue(error.code) : ""
    const message = error ? stringValue(error.message) : ""
    const retryable = error && typeof error.retryable === "boolean" ? `；retryable=${String(error.retryable)}` : ""
    return `${label} 执行失败${suffix}${code ? `（${code}）` : ""}：${message || "主脑操作失败。"}${retryable}`
  }
  return `${label} 返回未知状态${suffix}。`
}

function renderOrdinaryProjection(response: OperationTurnResponse): string {
  const ordinary = response.ordinary
  if (!ordinary) return ""
  if (ordinary.dependency === "none") return ""
  if (ordinary.dependency === "operation_result") {
    const dependsOn = ordinary.dependsOn?.length ? `（dependsOn=${ordinary.dependsOn.join(",")}）` : ""
    return `普通任务可基于以上主脑结果继续${dependsOn}。`
  }
  if (ordinary.dependency === "blocked") {
    const reason = ordinary.blockedReason?.message?.trim() || "依赖的主脑操作未完成，普通任务不能继续。"
    const code = ordinary.blockedReason?.code?.trim()
    const retryable = typeof ordinary.blockedReason?.retryable === "boolean"
      ? `；retryable=${String(ordinary.blockedReason.retryable)}`
      : ""
    return `普通任务已阻断${code ? `（${code}）` : ""}：${reason}${retryable}`
  }
  return ""
}

function renderTurnMetadata(response: OperationTurnResponse): string {
  const admission = isRecord(response.admission) ? response.admission : undefined
  return joinLines(
    response.replayed === true ? "幂等重放：是" : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
    admission ? renderAdmission(admission) : "",
  )
}

function renderStatusMetadata(response: OperationStatusResponse): string {
  return joinLines(
    response.replayed === true ? "幂等重放：是" : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
  )
}

function renderAdmission(admission: Record<string, unknown>): string {
  const source = stringValue(admission.source)
  const elapsed = typeof admission.elapsedMs === "number" ? `elapsedMs=${admission.elapsedMs}` : ""
  const budget = typeof admission.budgetMs === "number" ? `budgetMs=${admission.budgetMs}` : ""
  return ["admission", source, elapsed, budget].filter(Boolean).join(" ")
}

function renderUnavailableDetails(value: unknown): string {
  if (!isRecord(value)) return ""
  return joinParts(
    stringValue(value.reason) ? `reason=${stringValue(value.reason)}` : "",
    typeof value.retryable === "boolean" ? `retryable=${String(value.retryable)}` : "",
  )
}

function renderRetryDetails(value: OperationErrorResponse): string {
  return joinParts(
    typeof value.retryable === "boolean" ? `retryable=${String(value.retryable)}` : "",
    typeof value.retryAfterMs === "number" ? `retryAfterMs=${value.retryAfterMs}` : "",
  )
}

function renderProgressDetails(operation: Record<string, unknown>): string {
  return joinInline(
    stringValue(operation.acceptedAt) ? `acceptedAt=${stringValue(operation.acceptedAt)}` : "",
    typeof operation.queryAfterMs === "number" ? `queryAfterMs=${operation.queryAfterMs}` : "",
  )
}

function renderValue(value: unknown): string {
  if (value === undefined) return ""
  if (typeof value === "string") return value.trim() ? `：${value.trim()}` : ""
  try {
    const encoded = JSON.stringify(value, null, 2)
    if (!encoded) return ""
    const bounded = encoded.length > 8_000 ? `${encoded.slice(0, 8_000)}\n…（结果过长，已截断）` : encoded
    return `：${bounded}`
  } catch {
    return ""
  }
}

function stringValue(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

function isOperationStatusResponse(value: Record<string, unknown>): value is OperationStatusResponse {
  return isRecord(value.operation) && !("decision" in value)
}

function isOperationErrorResponse(value: Record<string, unknown>): value is OperationErrorResponse {
  return value.status === "error"
}

function joinLines(...values: string[]): string {
  return values.map((value) => value.trim()).filter(Boolean).join("\n")
}

function joinInline(...values: string[]): string {
  const text = values.map((value) => value.trim()).filter(Boolean).join("；")
  return text ? `；${text}` : ""
}

function joinParts(...values: string[]): string {
  return values.map((value) => value.trim()).filter(Boolean).join("；")
}
