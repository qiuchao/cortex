# transport/ — 本地 IPC 传输层(信任边界)

> 本层是 **信任边界**:它手握团队 `KNOWLEDGE_API_KEY` bearer,且能触发不可逆 PII 上传。
> 因此从 **Phase 1 起强制认证**,先于任何能力骑在它上面(方案 §1 原则 6 / 风险 A / D6)。

## R1/R4a 抽象决策(在写任何具体 socket 代码之前记录)

**一套架构,两种鉴权派生。socket/pipe 类型藏在 transport interface 后,不泄漏到 `inject`/`report` verb 之上。**

| 平台 | 传输 | 鉴权 |
|---|---|---|
| POSIX(Linux/mac/WSL2)★首选 | unix domain socket | 目录 `0700` + socket `0600` = 文件权限即鉴权(auth-for-free) |
| Windows(box A 就位再做) | named pipe | ACL / SID 鉴权(per-OS TODO) |
| fallback(仅当上面都不可用) | loopback TCP | **强制 `0600` bearer token 文件**;token-less loopback **禁止** |

**为什么 unix socket 而非 loopback TCP 默认**:端点是信任边界,unix socket 的 fs 权限提供免费鉴权;token-less loopback 任何同机进程可 `curl` 到,会被 rogue npm postinstall / 同租户用户利用做不可逆 PII 外泄(方案 pre-mortem A)。

## 接口契约

- 上层只见 `inject` / `report` / `GET /health` 三个 HTTP 端点(见 `contract.ts`),**不见** socket 还是 pipe。
- server 用 Node 内置 `node:http` 挂在 `node:net` 的 socket/pipe 上,**不引 Express/Fastify**(最小依赖 = 减小攻击面)。
- 薄壳发现运行时:发现文件 `~/.cache/synapse/runtime.json` `{socket_path|port, pid, started_at}`;薄壳按固定路径/env 找 socket。

## 落地阶段

- Phase 0(本阶段):只定 `contract.ts` 类型 + 本决策文档。**无具体 socket 代码。**
- Phase 1:`socket.ts`(POSIX 实现)+ `auth.ts` + `discovery.ts`;端点拒绝未认证调用(出口 gate)。
