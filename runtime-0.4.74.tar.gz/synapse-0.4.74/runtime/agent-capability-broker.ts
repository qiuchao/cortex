import { existsSync } from "node:fs"
import { createHash } from "node:crypto"
import { fileURLToPath } from "node:url"
import type {
  KnowledgeAgentExecuteRequest,
  KnowledgeAgentExecuteResponse,
  KnowledgeCapabilityCatalog,
  KnowledgeCapabilityBoundArgs,
  KnowledgeCapabilityName,
  TaskCapabilityCatalogue,
  TaskCapabilityCommand,
  TaskCapabilityReadCommand,
  TaskCapabilityExecuteRequest,
  TaskCapabilityExecuteResponse,
  TaskOperationId,
} from "@cerebro/wire"
import {
  KNOWLEDGE_AGENT_PROTOCOL_VERSION,
  KnowledgeAgentExecuteRequestSchema,
  TaskCapabilityExecuteRequestSchema,
  TaskCapabilityWriteInputSchemas,
  TaskCapabilityWriteCommandSchema,
  WORK_ITEM_AUTOMATIC_CONTEXT_PATH,
  WORK_ITEM_AUTOMATIC_CONTEXT_TITLE,
  hasWorkItemWriteAuthorizationIntentText,
  isWorkItemAutomaticContextPath,
  toTaskOperationId,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import type { KhDegraded } from "../transport/kh-types.ts"
import { resolveAgentCommandShell, type AgentCommandShell } from "../core/windows-shell.ts"
import {
  executeKnowledgeAgentRequest,
  fetchKnowledgeCapabilityCatalog,
  executeTaskCapabilityRequest,
  fetchTaskCapabilityCatalogue,
  taskDraftContextEchoMatches,
  type TaskCatalogueScope,
} from "../transport/brain-contract-align.ts"
import { stableFallbackTurnId } from "../core/parsers/util.ts"
import {
  agentCommandShell,
  quoteAgentCommandArgForLauncher,
  renderAgentLauncher,
} from "../core/agent-command-line.ts"
import type {
  TaskCapabilityDraftResource,
  TaskDraftContextBinding,
  TaskDraftRequestAuthorization,
} from "../core/task-capability-draft-intake.ts"
import { renderCompactCapabilityIndex, renderFullCapabilityIndex } from "./capability-index.ts"
import {
  AGENT_JSON_CHUNK_MAX_BYTES,
  AGENT_JSON_GIT_BASH_CHUNK_MAX_BYTES,
} from "./agent-json-transfer.ts"

export type AgentCapabilityCatalogue = KnowledgeCapabilityCatalog & {
  taskCatalogue?: TaskCapabilityCatalogue
}

export type AgentTaskControlCatalogue = { taskCatalogue?: TaskCapabilityCatalogue }
export type AgentControlCatalogue = AgentCapabilityCatalogue | AgentTaskControlCatalogue

export type AgentTaskCatalogResult =
  | { ok: true; catalogue: TaskCapabilityCatalogue }
  | KhDegraded

export type AgentCatalogResult =
  | { ok: true; catalogue: AgentCapabilityCatalogue }
  | KhDegraded

export type AgentTaskDraftResponse = Omit<Extract<TaskCapabilityExecuteResponse, { kind: "draft" }>, "draftId"> & {
  operationId: TaskOperationId
}

export type AgentExecutionResult =
  | { ok: true; response: KnowledgeAgentExecuteResponse | Exclude<TaskCapabilityExecuteResponse, { kind: "draft" }> | AgentTaskDraftResponse }
  | KhDegraded

export interface AgentCapabilityBroker {
  describe(options?: { refresh?: boolean; productionId?: string; publicId?: string }): Promise<AgentCatalogResult>
  describeTask(scope: TaskCatalogueScope & { refresh?: boolean }, signal?: AbortSignal): Promise<AgentTaskCatalogResult>
  execute(request: unknown, signal?: AbortSignal): Promise<AgentExecutionResult>
  status(): AgentBrokerStatus
}

export interface AgentBrokerStatus {
  state: "not_loaded" | "ready" | "degraded"
  protocolVersion?: string
  capabilityCount?: number
  lastCheckedAt?: string
  message?: string
}

export interface AgentCapabilityBrokerDeps {
  fetchCatalogue?: () => Promise<AgentCatalogResult>
  executeRequest?: (request: KnowledgeAgentExecuteRequest) => Promise<AgentExecutionResult>
  fetchTaskCatalogue?: (scope: TaskCatalogueScope, signal?: AbortSignal) => Promise<{ ok: true; catalogue: TaskCapabilityCatalogue } | KhDegraded>
  executeTaskRequest?: (request: TaskCapabilityExecuteRequest, signal?: AbortSignal) => Promise<{ ok: true; response: TaskCapabilityExecuteResponse } | KhDegraded>
  authorizeTaskDraftRequest?: (
    requestId: string,
    productionId: string,
    request: { command: string; input: Record<string, unknown> },
  ) => TaskDraftRequestAuthorization | boolean
  rememberTaskDraft?: (ref: {
    draftId: string
    requestId: string
    productionId: string
    expiresAt: string
    resource: TaskCapabilityDraftResource
    command: string
    contextReceiptId?: string
    contextTargetPublicId?: string
  }) => void
  now?: () => number
  cacheTtlMs?: number
}

export interface AgentControlContextObservation {
  bytes: number
  estimatedTokens: number
  mode: "compact" | "full"
  compactFallback: boolean
}

export interface AgentControlContextOptions {
  env?: NodeJS.ProcessEnv
  platform?: NodeJS.Platform
  windowsShell?: AgentCommandShell
  renderCompactIndex?: typeof renderCompactCapabilityIndex
  taskDraftRequestId?: string
  attachmentHandle?: string
  bugRelationWriteContext?: {
    bugId: string
    relationSetVersion: number
    relations: Array<{ requirementId: string; relationId: string }>
  }
  workItemDocumentWriteContexts?: Array<{
    targetPublicId: string
    baseContextSnapshotId: string | null
    contextVersion: number
    documents: Array<{
      documentId: string
      sourcePublicId: string
      revision: number
      path: string
      title: string
      archivedAt: string | null
    }>
  }>
  workItemCommentWriteContexts?: Array<{
    targetPublicId: string
    sourcePublicId: string
    commentId: string
    body: string | null
    authorDisplayName: string | null
    canEdit: boolean
    canDelete: boolean
  }>
  workItemContextBlocked?: boolean
  workItemContextInjected?: boolean
  attachmentPolicy?: "bug-upload" | "requirement-empty-check"
  /** Opaque turn credential required by the injected Task execution receiver. */
  taskRouteToken?: string
  /** Opaque turn credential required by the injected Knowledge execution receiver. */
  knowledgeRouteToken?: string
  /** Losslessly parsed user arguments that the Knowledge turn guard will enforce. */
  knowledgeBoundArgsByCapability?: KnowledgeCapabilityBoundArgs
  /** Task turns omit Knowledge discovery and its envelope/policy text. */
  taskOnly?: boolean
  /** Deterministically selected by the shared work-item intent classifier. */
  preferredTaskCommand?: TaskCapabilityCommand
  /** Trusted fields already parsed losslessly from the user message. */
  preferredTaskInput?: Record<string, unknown>
  /** Complete read selected from an unambiguous current-turn request. */
  preferredTaskRead?: {
    command: TaskCapabilityReadCommand
    input: Readonly<Record<string, unknown>>
  }
}

export interface AgentLauncherSpec {
  command: string
  args: string[]
  rendered: string
  shell: "default" | "powershell"
}

export interface AgentLauncherOptions {
  execPath?: string
  execArgv?: readonly string[]
  binPath?: string
  client?: InjectRequest["client"]
  platform?: NodeJS.Platform
}

const DEFAULT_CATALOGUE_TTL_MS = 60_000
const USER_AUTHORIZED_RECEIPT_COMMANDS = new Set([
  "work_item.context.receipt.ignore",
  "work_item.context.receipt.supplement",
])
const USER_VISIBLE_KNOWLEDGE_POLICY =
  "User-facing: knowledge=>《title》, no ID unless asked/debug/API; injected facts=>append exactly 来源：主脑自动检索 (never mention Synapse in source labels)."
const AGENT_ENVELOPE_ROUTING_POLICY =
  "Envelope labels are examples, never JSON keys or command values. Send the shown object as the whole body: Knowledge uses capability/args; Task uses command/input."
const TASK_ENVELOPE_ROUTING_POLICY =
  "task_R_envelope/task_D_envelope are labels, never JSON keys or command values. Send the shown object as the whole body using command/input only."
const SINGLE_ENVELOPE_TRANSPORT_POLICY =
  "Pipe exactly one bare JSON object into execute_command. No JSON pipeline, array, wrapper, task_*_envelope command, empty launch, write_stdin, repository, or temporary file."
const INJECTED_WORK_ITEM_READ_POLICY =
  "The requested work items are already in requested_public_ids/complete_inventory_json. Use them directly; do not call requirement.detail or bug.detail for those IDs."

const STANDALONE_CREATE_CAPABILITIES = {
  requirement: new Set<TaskCapabilityCommand>([
    "member.list", "module.list", "requirement.list", "iteration.list", "requirement.create",
  ]),
  bug: new Set<TaskCapabilityCommand>(["member.list", "bug.create"]),
} as const

export function scopeTaskCatalogueForStandaloneCreate(
  catalogue: TaskCapabilityCatalogue,
  kind: "requirement" | "bug",
  options: { simple?: boolean } = {},
): TaskCapabilityCatalogue {
  const command = kind === "bug" ? "bug.create" : "requirement.create"
  const allowed = options.simple
    ? new Set<TaskCapabilityCommand>([command])
    : STANDALONE_CREATE_CAPABILITIES[kind]
  return scopeTaskCatalogueForCapabilities(catalogue, allowed)
}

export function scopeTaskCatalogueForCapabilities(
  catalogue: TaskCapabilityCatalogue,
  capabilities: Iterable<TaskCapabilityCommand>,
): TaskCapabilityCatalogue {
  const allowed = capabilities instanceof Set ? capabilities : new Set(capabilities)
  return {
    ...catalogue,
    capabilities: catalogue.capabilities.filter((entry) => allowed.has(entry.name)),
    availableCapabilities: catalogue.availableCapabilities.filter((name) => allowed.has(name)),
    unavailableCapabilities: catalogue.unavailableCapabilities.filter((entry) => allowed.has(entry.name)),
  }
}

export function scopeKnowledgeCatalogueForCapabilities(
  catalogue: KnowledgeCapabilityCatalog,
  capabilities: readonly KnowledgeCapabilityName[],
): KnowledgeCapabilityCatalog {
  const allowed = new Set<KnowledgeCapabilityName>(capabilities)
  return {
    ...catalogue,
    capabilities: catalogue.capabilities.filter((entry) => allowed.has(entry.name as KnowledgeCapabilityName)),
    availableCapabilities: catalogue.availableCapabilities.filter((name) => allowed.has(name)),
    unavailableCapabilities: catalogue.unavailableCapabilities.filter((entry) => allowed.has(entry.name)),
  }
}

export function createAgentCapabilityBroker(
  deps: AgentCapabilityBrokerDeps = {},
): AgentCapabilityBroker {
  const fetchCatalogue = deps.fetchCatalogue ?? (() => fetchKnowledgeCapabilityCatalog())
  const executeRequest = deps.executeRequest ?? ((request) => executeKnowledgeAgentRequest(request))
  const fetchTaskCatalogue = deps.fetchTaskCatalogue ?? ((scope, signal) => fetchTaskCapabilityCatalogue(scope, process.env, signal))
  const executeTaskRequest = deps.executeTaskRequest ?? ((request, signal) => executeTaskCapabilityRequest(request, process.env, signal))
  const authorizeTaskDraftRequest = deps.authorizeTaskDraftRequest
  const rememberTaskDraft = deps.rememberTaskDraft
  const now = deps.now ?? Date.now
  const cacheTtlMs = deps.cacheTtlMs ?? DEFAULT_CATALOGUE_TTL_MS
  let cached: { value: KnowledgeCapabilityCatalog; expiresAt: number } | null = null
  let inFlight: Promise<AgentCatalogResult> | null = null
  const taskCache = new Map<string, { value: TaskCapabilityCatalogue; expiresAt: number }>()
  const taskInFlight = new Map<string, Promise<{ ok: true; catalogue: TaskCapabilityCatalogue } | KhDegraded>>()
  let brokerStatus: AgentBrokerStatus = { state: "not_loaded" }

  async function describeKnowledge(options: { refresh?: boolean } = {}): Promise<AgentCatalogResult> {
    const current = now()
    if (!options.refresh && cached && current < cached.expiresAt) {
      return { ok: true, catalogue: cached.value }
    }
    if (!options.refresh && inFlight) return inFlight

    const pending = fetchCatalogue().then((result) => {
      const checkedAt = new Date(now()).toISOString()
      if (result.ok) {
        cached = { value: result.catalogue, expiresAt: now() + cacheTtlMs }
        brokerStatus = {
          state: "ready",
          protocolVersion: result.catalogue.protocolVersion,
          capabilityCount: result.catalogue.availableCapabilities.length,
          lastCheckedAt: checkedAt,
        }
      } else {
        cached = null
        brokerStatus = {
          state: "degraded",
          lastCheckedAt: checkedAt,
          message: result.message,
        }
      }
      return result
    }).finally(() => {
      inFlight = null
    })
    inFlight = pending
    return pending
  }

  async function describeTask(
    options: TaskCatalogueScope & { refresh?: boolean },
    signal?: AbortSignal,
  ): Promise<AgentTaskCatalogResult> {
    if (!options.productionId && !options.publicId) {
      return degraded("invalid_input", "task catalogue requires productionId or publicId")
    }
    const scope: TaskCatalogueScope = {
      ...(options.productionId ? { productionId: options.productionId } : {}),
      ...(options.publicId ? { publicId: options.publicId } : {}),
    }
    const cacheKey = options.productionId ? `production:${options.productionId}` : `public:${options.publicId}`
    const current = now()
    let taskResult: { ok: true; catalogue: TaskCapabilityCatalogue } | KhDegraded
    const taskCached = taskCache.get(cacheKey)
    if (!options.refresh && taskCached && current < taskCached.expiresAt) {
      taskResult = { ok: true, catalogue: taskCached.value }
    } else {
      // A caller-owned AbortSignal must not cancel a shared request that another
      // turn is awaiting. Signal-bound discovery is intentionally not coalesced.
      let pending = !signal && !options.refresh ? taskInFlight.get(cacheKey) : undefined
      if (!pending) {
        pending = (signal ? fetchTaskCatalogue(scope, signal) : fetchTaskCatalogue(scope)).then((result) => {
          if (result.ok) {
            const catalogue = agentTaskCatalogue(result.catalogue)
            const cachedValue = { value: catalogue, expiresAt: now() + cacheTtlMs }
            taskCache.set(cacheKey, cachedValue)
            taskCache.set(`production:${catalogue.productionId}`, cachedValue)
            return { ok: true as const, catalogue }
          }
          return result
        }).finally(() => {
          if (!signal) taskInFlight.delete(cacheKey)
        })
        if (!signal) taskInFlight.set(cacheKey, pending)
      }
      taskResult = await pending
    }
    if (!taskResult.ok) {
      brokerStatus = { ...brokerStatus, state: "degraded", message: taskResult.message }
      return taskResult
    }
    brokerStatus = {
      ...brokerStatus,
      state: "ready",
      protocolVersion: taskResult.catalogue.protocolVersion,
      capabilityCount: taskResult.catalogue.availableCapabilities.length,
    }
    return taskResult
  }

  async function describe(options: { refresh?: boolean; productionId?: string; publicId?: string } = {}): Promise<AgentCatalogResult> {
    const knowledge = await describeKnowledge(options)
    if (!knowledge.ok || (!options.productionId && !options.publicId)) return knowledge
    const task = await describeTask(options)
    if (!task.ok) return task
    return { ok: true, catalogue: { ...knowledge.catalogue, taskCatalogue: task.catalogue } }
  }

  async function execute(request: unknown, signal?: AbortSignal): Promise<AgentExecutionResult> {
    const parsed = KnowledgeAgentExecuteRequestSchema.safeParse(request)
    if (parsed.success) {
      const catalogueResult = await describe()
      if (!catalogueResult.ok) return catalogueResult
      const catalogue = catalogueResult.catalogue
      if (!catalogue.availableCapabilities.includes(parsed.data.capability)) {
        const unavailable = catalogue.unavailableCapabilities.find(
          (entry) => entry.name === parsed.data.capability,
        )
        return {
          ok: true,
          response: {
            protocolVersion: KNOWLEDGE_AGENT_PROTOCOL_VERSION,
            capability: parsed.data.capability,
            status: "denied",
            code: "capability_unavailable",
            message: unavailable?.reason ?? "capability is unavailable for the authenticated actor",
          },
        }
      }
      return executeRequest(parsed.data)
    }

    const rawWriteInputError = validateRawTaskWriteInput(request)
    if (rawWriteInputError) return degraded("validation_error", rawWriteInputError, 400)
    const preparedTask = prepareTaskCapabilityRequest(request, authorizeTaskDraftRequest)
    if (preparedTask.authorizationDenied) {
      return degraded(
        "turn_scope_denied",
        "当前用户消息没有授权这次任务写入；这不代表账号缺少产品权限。请让用户在新消息中明确要执行的操作。",
        403,
      )
    }
    const taskParsed = TaskCapabilityExecuteRequestSchema.safeParse(preparedTask.request)
    if (taskParsed.success) {
      if (USER_AUTHORIZED_RECEIPT_COMMANDS.has(taskParsed.data.command)) {
        return degraded(
          "permission_denied",
          "receipt ignore and supplement actions require exact authorization from the user's original message",
          403,
        )
      }
      const catalogueResult = await describeTask({ productionId: taskParsed.data.productionId }, signal)
      if (!catalogueResult.ok) return catalogueResult
      const taskCatalogue = catalogueResult.catalogue
      if (!taskCatalogue.availableCapabilities.includes(taskParsed.data.command)) {
        const unavailable = taskCatalogue.unavailableCapabilities.find((entry) => entry.name === taskParsed.data.command)
        return degraded("permission_denied", unavailable?.reason ?? "task capability is unavailable for the authenticated actor", 403)
      }
      const result = signal
        ? await executeTaskRequest(taskParsed.data, signal)
        : await executeTaskRequest(taskParsed.data)
      if (!result.ok) return result
      if (result.response.kind === "draft") {
        if (!("requestId" in taskParsed.data)) return degraded("invalid_input", "draft response is missing its request identity")
        if (result.response.command !== taskParsed.data.command) {
          return degraded("kh_returned_error", "task capability response command does not match the request")
        }
        if (!taskDraftContextEchoMatches(taskParsed.data, result.response)) {
          return degraded("kh_returned_error", "task capability draft context binding does not exactly echo the trusted request")
        }
        const resource = taskDraftConfirmationResource(
          result.response.command,
          taskCatalogue.capabilities.find((entry) => entry.name === result.response.command)?.resource,
        )
        if (resource !== "requirement" && resource !== "bug" && resource !== "iteration" && resource !== "work_item") {
          return degraded("invalid_input", "draft capability has no user-facing operation type")
        }
        rememberTaskDraft?.({
          draftId: result.response.draftId,
          requestId: taskParsed.data.requestId,
          productionId: taskParsed.data.productionId,
          expiresAt: result.response.expiresAt,
          resource,
          command: taskParsed.data.command,
          ...(preparedTask.binding ?? {}),
        })
        const { draftId, ...response } = result.response
        return { ok: true, response: { ...response, operationId: toTaskOperationId(draftId) } }
      }
      return { ok: true, response: result.response }
    }

    const requestRecord = request && typeof request === "object" && !Array.isArray(request)
      ? request as Record<string, unknown>
      : null
    const schemaIssues = requestRecord && "command" in requestRecord
      ? taskParsed.error.issues
      : requestRecord && "capability" in requestRecord
        ? parsed.error.issues
        : [...parsed.error.issues, ...taskParsed.error.issues]
    const protocolLabel = requestRecord && "command" in requestRecord
      ? "Task"
      : requestRecord && "capability" in requestRecord
        ? "Knowledge"
        : "Knowledge and Task shared wire"
    const issues = schemaIssues
        .slice(0, 6)
        .map((issue) => `${issue.path.join(".") || "request"}: ${issue.message}`)
        .join("; ")
    return degraded("validation_error", `agent execute request failed ${protocolLabel} schema validation: ${issues}`, 400)
  }

  return {
    describe,
    describeTask,
    execute,
    status: () => ({ ...brokerStatus }),
  }
}

function agentTaskCatalogue(catalogue: TaskCapabilityCatalogue): TaskCapabilityCatalogue {
  return {
    ...catalogue,
    capabilities: catalogue.capabilities.filter((entry) => !USER_AUTHORIZED_RECEIPT_COMMANDS.has(entry.name)),
    availableCapabilities: catalogue.availableCapabilities.filter((name) => !USER_AUTHORIZED_RECEIPT_COMMANDS.has(name)),
    unavailableCapabilities: catalogue.unavailableCapabilities.filter((entry) => !USER_AUTHORIZED_RECEIPT_COMMANDS.has(entry.name)),
  }
}

function validateRawTaskWriteInput(request: unknown): string | null {
  if (!request || typeof request !== "object" || Array.isArray(request)) return null
  const raw = request as Record<string, unknown>
  const command = TaskCapabilityWriteCommandSchema.safeParse(raw.command)
  if (!command.success || command.data !== "work_item.context.save"
    || !raw.input || typeof raw.input !== "object" || Array.isArray(raw.input)) return null
  const parsed = TaskCapabilityWriteInputSchemas[command.data].safeParse(raw.input)
  if (parsed.success) return null
  const issues = parsed.error.issues.slice(0, 8)
    .map((issue) => `${issue.path.join(".") || "input"}: ${issue.message}`)
    .join("; ")
  return `agent task draft input failed ${command.data} schema validation: ${issues}`
}

function taskDraftConfirmationResource(
  command: string,
  catalogueResource: TaskCapabilityDraftResource | "configuration" | undefined,
): TaskCapabilityDraftResource | undefined {
  if (command.startsWith("requirement.")) return "requirement"
  if (command.startsWith("bug.")) return "bug"
  if (command.startsWith("iteration.")) return "iteration"
  if (command.startsWith("work_item.")) return "work_item"
  return catalogueResource === "requirement"
    || catalogueResource === "bug"
    || catalogueResource === "iteration"
    || catalogueResource === "work_item"
    ? catalogueResource
    : undefined
}

function prepareTaskCapabilityRequest(
  request: unknown,
  authorize: AgentCapabilityBrokerDeps["authorizeTaskDraftRequest"],
): {
  request: unknown
  authorizationDenied: boolean
  binding?: TaskDraftContextBinding
} {
  if (!request || typeof request !== "object" || Array.isArray(request)) {
    return { request, authorizationDenied: false }
  }
  const raw = request as Record<string, unknown>
  if (typeof raw.command !== "string") return { request, authorizationDenied: false }
  if (!TaskCapabilityWriteCommandSchema.safeParse(raw.command).success) {
    return { request, authorizationDenied: false }
  }
  const {
    contextReceiptId: _untrustedReceipt,
    contextTargetPublicId: _untrustedTarget,
    sourceClient: _untrustedSourceClient,
    ...clean
  } = raw
  if (typeof clean.requestId !== "string" || typeof clean.productionId !== "string"
    || !clean.input || typeof clean.input !== "object" || Array.isArray(clean.input)) {
    return { request: clean, authorizationDenied: false }
  }
  const {
    contextReceiptId: _untrustedInputReceipt,
    contextTargetPublicId: _untrustedInputTarget,
    sourceClient: _untrustedInputSourceClient,
    ...input
  } = clean.input as Record<string, unknown>
  const decision = authorize?.(clean.requestId, clean.productionId, { ...clean, command: clean.command as string, input })
  const authorization = normalizeTaskDraftAuthorization(decision)
  if (!authorization.authorized) return { request: clean, authorizationDenied: true }
  if (!authorization.binding) {
    return {
      request: { ...clean, sourceClient: authorization.sourceClient, input },
      authorizationDenied: false,
    }
  }
  const binding = authorization.binding
  return {
    request: {
      ...clean,
      sourceClient: authorization.sourceClient,
      contextReceiptId: binding.contextReceiptId,
      contextTargetPublicId: binding.contextTargetPublicId,
      input,
    },
    authorizationDenied: false,
    binding,
  }
}

function normalizeTaskDraftAuthorization(
  value: TaskDraftRequestAuthorization | boolean | undefined,
): TaskDraftRequestAuthorization {
  if (typeof value === "boolean" || value === undefined) return { authorized: false }
  return value
}

const FORWARDED_NODE_ARGS = new Set(["--experimental-strip-types", "--no-warnings"])
const AGENT_JSON_PAYLOAD_PLACEHOLDER = "<payload-base64url>"

export function resolveAgentLauncherSpec(options: AgentLauncherOptions = {}): AgentLauncherSpec | null {
  const command = options.execPath ?? process.execPath
  const binPath = options.binPath ?? fileURLToPath(new URL("../bin/synapse.mjs", import.meta.url))
  if (!existsSync(command) || !existsSync(binPath)) return null
  const nodeArgs = (options.execArgv ?? process.execArgv).filter((arg) => FORWARDED_NODE_ARGS.has(arg))
  const args = [...nodeArgs, binPath]
  const platform = options.platform ?? process.platform
  const shell = agentCommandShell(platform, options.client)
  return {
    command,
    args,
    rendered: renderAgentLauncher(command, args, shell, platform),
    shell,
  }
}

export function resolveAgentLauncher(client?: InjectRequest["client"]): string | null {
  return resolveAgentLauncherSpec({ client })?.rendered ?? null
}

export function renderAgentStdinCommand(
  launcher: string,
  action: "execute" | "attachments",
  client: InjectRequest["client"],
  platform: NodeJS.Platform = process.platform,
  shell: AgentCommandShell = resolveAgentCommandShell(client, platform),
  routeToken?: string,
): string {
  const tokenArg = routeToken
    ? ` --turn-token ${quoteAgentCommandArgForLauncher(routeToken, launcher)}`
    : ""
  if (platform !== "win32") {
    return renderAgentInvocation(launcher, `${action} --stdin${tokenArg}`, platform, shell)
  }
  return renderAgentInvocation(
    launcher,
    `${action} --json-base64url ${AGENT_JSON_PAYLOAD_PLACEHOLDER}${tokenArg}`,
    platform,
    shell,
  )
}

export function renderAgentTaskDraftCommand(
  launcher: string,
  client: InjectRequest["client"],
  productionId: string,
  requestId: string,
  platform: NodeJS.Platform = process.platform,
  shell: AgentCommandShell = resolveAgentCommandShell(client, platform),
): string {
  const suffix = ` --production-id ${quoteCommandArg(productionId, platform)} --request-id ${quoteCommandArg(requestId, platform)}`
  const mode = platform === "win32"
    ? `--json-base64url ${AGENT_JSON_PAYLOAD_PLACEHOLDER}`
    : "--stdin"
  return renderAgentInvocation(launcher, `task-draft ${mode}${suffix}`, platform, shell)
}

function renderAgentInvocation(
  launcher: string,
  args: string,
  platform: NodeJS.Platform,
  shell: AgentCommandShell,
): string {
  const callPrefix = platform === "win32" && shell === "powershell" && !launcher.trimStart().startsWith("& ")
    ? "& "
    : ""
  return `${callPrefix}${launcher} agent ${args}`
}

export function renderAgentJsonPayloadCommand(
  receiverCommand: string,
  payload: string,
  platform: NodeJS.Platform = process.platform,
): string {
  if (platform === "win32") {
    if (!receiverCommand.includes(AGENT_JSON_PAYLOAD_PLACEHOLDER)) {
      throw new Error("Windows agent JSON command is missing its base64url payload placeholder")
    }
    return receiverCommand.replace(
      AGENT_JSON_PAYLOAD_PLACEHOLDER,
      Buffer.from(payload, "utf8").toString("base64url"),
    )
  }
  return `printf '%s' ${quoteCommandArg(payload, platform)} | ${receiverCommand}`
}

type PreferredTaskRead = NonNullable<AgentControlContextOptions["preferredTaskRead"]>

function availablePreferredTaskRead(
  catalogue: TaskCapabilityCatalogue | undefined,
  preferred: PreferredTaskRead | undefined,
): PreferredTaskRead | undefined {
  return preferred && catalogue?.availableCapabilities.includes(preferred.command)
    ? preferred
    : undefined
}

function taskReadEnvelope(
  catalogue: TaskCapabilityCatalogue,
  preferred: PreferredTaskRead,
): Record<string, unknown> {
  return {
    protocolVersion: catalogue.protocolVersion,
    productionId: catalogue.productionId,
    command: preferred.command,
    input: preferred.input,
  }
}

function renderPreferredTaskReadDirective(
  executeCommand: string,
  envelope: Record<string, unknown>,
  platform: NodeJS.Platform,
): string[] {
  return [
    "CURRENT TURN REQUIRED ACTION: Run COPY_THIS_EXACT_TASK_READ_COMMAND exactly once as the first and only tool call. Never call describe/help, guess fields, use another Task command, inspect repository files, or use browser/desktop UI. After the result, answer the user directly without another tool call.",
    `COPY_THIS_EXACT_TASK_READ_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, JSON.stringify(envelope), platform)}`,
  ]
}

function windowsAgentTransferContext(shell: AgentCommandShell): string[] {
  const chunkSizeKb = (shell === "posix"
    ? AGENT_JSON_GIT_BASH_CHUNK_MAX_BYTES
    : AGENT_JSON_CHUNK_MAX_BYTES) / 1024
  return [
    `win_json=UTF-8 encode one complete JSON object. <=${chunkSizeKb}KB: base64url(no padding), replace <payload-base64url>. Larger: split UTF-8 BYTES into <=${chunkSizeKb}KB chunks; base64url each. Per chunk replace ONLY the two tokens --json-base64url <payload-base64url> with --json-chunk <chunk-base64url> --transfer-id <same random 22+ char base64url id> --chunk-index <0-based> --chunk-count <total>. Preserve every other command token in place, especially --turn-token. The value after --json-chunk is data, never an index; omit --json-base64url. Require each chunk_accepted. Finalize by replacing ONLY those same two tokens with --json-finalize --transfer-id <same id> --chunk-count <total>, preserving all other tokens. Run the shown executable directly; no temp/envelope file, nested shell, stdin/raw JSON pipe. Only finalize executes.`,
  ]
}

export function renderAgentControlContext(
  catalogue: AgentControlCatalogue,
  request: InjectRequest,
  launcher = resolveAgentLauncher(request.client),
  observe?: (observation: AgentControlContextObservation) => void,
  options: AgentControlContextOptions = {},
): string {
  if (!launcher) return ""
  catalogue = catalogue.taskCatalogue
    ? { ...catalogue, taskCatalogue: agentTaskCatalogue(catalogue.taskCatalogue) }
    : catalogue
  const taskOnly = options.taskOnly === true
  const platform = options.platform ?? process.platform
  const shell = options.windowsShell ?? resolveAgentCommandShell(request.client, platform)
  const knowledgeCatalogue = "knowledgeIntentContractVersion" in catalogue ? catalogue : undefined
  const turnId = resolveAgentControlTurnId(request)
  const knowledgeCapabilityNames = new Set(knowledgeCatalogue?.capabilities.map((entry) => entry.name) ?? [])
  const turnRouteToken = taskOnly ? options.taskRouteToken : options.knowledgeRouteToken
  const executeCommand = renderAgentStdinCommand(
    launcher,
    "execute",
    request.client,
    platform,
    shell,
    turnRouteToken,
  )
  const requestKeyDigest = createHash("sha256").update([
    request.client,
    request.session_id || "unknown-session",
    turnId,
  ].join("\n")).digest()
  const fullRequestKeyPrefix = requestKeyDigest.toString("hex")
  const compactRequestKeyPrefix = requestKeyDigest.toString("base64url").slice(0, 22)
  const knowledgeEnvelope = renderKnowledgeEnvelopeTemplate(
    knowledgeCatalogue,
    request,
    turnId,
    fullRequestKeyPrefix,
    options.knowledgeBoundArgsByCapability,
  )
  const executionPolicy = {
    explicitUserRequest: "execute_immediately",
    operationIdentity: "one_user_request_plus_capability_plus_target",
    idempotencyKey: "create_once_before_first_call_and_never_change_for_that_operation",
    confirmationRequired: "synapse_returns_a_user_facing_operation_id_and_only_a_new_exact_user_confirmation_may_continue",
    terminalStatuses: ["executed", "replayed", "denied"],
    terminalAction: "stop_calling_that_mutating_capability",
    verification: "use_a_read_capability_never_repeat_the_mutation",
    verificationReadLimitPerMutation: 1,
    successfulReceiptIsAuthoritative: true,
  }
  const taskCatalogue = catalogue.taskCatalogue
  const describeCommand = renderAgentInvocation(launcher, "describe --json", platform, shell)
  const preferredTaskCommand = options.preferredTaskCommand
  const preferredTaskInput = options.preferredTaskInput ?? {}
  const preferredTaskInputExact = Boolean(preferredTaskCommand && Object.keys(preferredTaskInput).length > 0)
  const preferredTaskRead = availablePreferredTaskRead(taskCatalogue, options.preferredTaskRead)
  const preferredTaskReadEnvelope = preferredTaskRead && taskCatalogue
    ? taskReadEnvelope(taskCatalogue, preferredTaskRead)
    : undefined
  const preferredTaskReadDirective = preferredTaskReadEnvelope
    ? renderPreferredTaskReadDirective(executeCommand, preferredTaskReadEnvelope, platform)
    : []
  const availableTaskCapabilities = taskCatalogue
    ? new Set<string>(taskCatalogue.availableCapabilities)
    : new Set<string>()
  const taskCapabilities = taskCatalogue?.capabilities
    .filter((entry) => availableTaskCapabilities.has(entry.name)) ?? []
  const commentWriteBlock = currentTurnCommentWriteBlock(request, options.workItemCommentWriteContexts)
  const documentMutationBlock = currentTurnDocumentMutationBlock(request, options.workItemDocumentWriteContexts)
  const includeWorkItemContextPolicy = needsWorkItemContextPolicy(request, preferredTaskCommand)

  const fullContext = () => [
    "[Synapse · trusted agent control]",
    "executor_status=available",
    taskOnly
      ? taskCatalogue
        ? `task_protocol_version=${taskCatalogue.protocolVersion}`
        : "task_protocol_status=unavailable"
      : `protocol_version=${knowledgeCatalogue?.protocolVersion ?? "unavailable"}`,
    ...(!taskOnly ? [
      `knowledge_execute_endpoint=${knowledgeCatalogue?.executePath ?? "unavailable"}`,
      `describe_command=${describeCommand}`,
    ] : []),
    `execute_command=${executeCommand}`,
    ...preferredTaskReadDirective,
    ...(platform === "win32"
      ? windowsAgentTransferContext(shell)
      : [SINGLE_ENVELOPE_TRANSPORT_POLICY]),
    "When the user explicitly requests an available Cerebro operation, invoke execute_command immediately; do not explain how to call it, ask the user to run it, or use legacy per-capability CLI commands.",
    taskOnly
      ? "The only authorized Task execution path is execute_command with this turn token. Never use a browser, desktop client, UI automation, or a legacy Task tool."
      : "The only authorized Knowledge execution path is execute_command with this turn token. Never call legacy tools whose names match a capability; they bypass trusted turn scope.",
    taskOnly ? TASK_ENVELOPE_ROUTING_POLICY : AGENT_ENVELOPE_ROUTING_POLICY,
    ...(!taskOnly ? [
      ...(knowledgeCapabilityNames.has("smart_search") ? [
        "For smart_search, put the complete requested text or unique identifier in args.query; a unique identifier does not require a separate get-by-id capability.",
      ] : []),
      ...(knowledgeCapabilityNames.has("save_chat_insight") ? [
        "For save_chat_insight, put the complete requested content in args.insight and use args.captureMode=explicit. Do not ask for optional fields omitted by the user.",
      ] : []),
      USER_VISIBLE_KNOWLEDGE_POLICY,
      "Required Knowledge envelope fields: protocolVersion, client, sessionId, turnId, capability, args, requestIdempotencyKey. Never include confirmation: Synapse owns confirmation receipts and binds them only to an explicit user confirmation.",
      `identity_json=${JSON.stringify({
        client: request.client,
        sessionId: request.session_id || "unknown-session",
        turnId,
        requestIdempotencyKeyPrefix: fullRequestKeyPrefix,
      })}`,
      `capabilities_json=${renderFullCapabilityIndex(knowledgeCatalogue!)}`,
      `knowledge_envelope=${JSON.stringify(knowledgeEnvelope)}`,
      ...renderKnowledgeBoundArgsPolicy(options.knowledgeBoundArgsByCapability),
    ] : []),
    ...(taskCatalogue ? [
      ...(!preferredTaskRead && !preferredTaskInputExact ? [
        `task_describe_command=${renderAgentInvocation(launcher, `describe --task-only --json --production-id ${quoteCommandArg(taskCatalogue.productionId, platform)}`, platform, shell)}`,
        `task_capability_describe_template=${renderAgentInvocation(launcher, `describe --task-only --json --production-id ${quoteCommandArg(taskCatalogue.productionId, platform)} --capability ${quoteCommandArg("<name>", platform)}`, platform, shell)}`,
      ] : []),
      `task_execute_endpoint=${taskCatalogue.executePath}`,
      `task_contract_json=${JSON.stringify({ protocolVersion: taskCatalogue.protocolVersion, productionId: taskCatalogue.productionId })}`,
      `task_capabilities_json=${JSON.stringify(taskCapabilities)}`,
      ...(taskCatalogue.unavailableCapabilities.length
        ? [`task_unavailable_json=${JSON.stringify(taskCatalogue.unavailableCapabilities)}`]
        : []),
      `task_read_envelope_template=${JSON.stringify(preferredTaskReadEnvelope ?? { protocolVersion: taskCatalogue.protocolVersion, productionId: taskCatalogue.productionId, command: "<available-read-name>", input: {} })}`,
      `task_draft_envelope_template=${JSON.stringify({ protocolVersion: taskCatalogue.protocolVersion, productionId: taskCatalogue.productionId, command: preferredTaskCommand ?? "<available-draft-name>", input: preferredTaskInput })}`,
      ...(includeWorkItemContextPolicy
        ? [`work_item_context_save_input_guide=${WORK_ITEM_CONTEXT_SAVE_INPUT_GUIDE}`]
        : []),
      ...attachmentPreparationContext(options.attachmentHandle, options.attachmentPolicy),
      "User-facing work items are requirements and Bugs. Map 需求/需求单 to requirement, and Bug/bug/缺陷 to bug. For creation, obey trusted task_scope.createIntentKind: requirement uses requirement.create, bug uses bug.create, and ambiguous requires asking the user to choose before any draft call. Treat 任务 as a generic synonym and infer it only from trusted scope or an explicit public ID.",
      "Every Task envelope uses only protocolVersion, productionId, command and input, and every read or draft goes through execute_command. Never include requestId: Synapse binds its internal idempotency identity from the trusted turn token. Omit top-level contextReceiptId and contextTargetPublicId: Synapse binds both from trusted turn scope. Replace every placeholder before execution. A response with kind=draft means no work item was written yet. Use only response.operationId in the confirmation text: requirement.* asks `确认需求操作 <operationId>` or `取消需求操作 <operationId>`; bug.* asks `确认Bug操作 <operationId>` or `取消Bug操作 <operationId>`; iteration.* asks `确认迭代操作 <operationId>` or `取消迭代操作 <operationId>`; work_item.* asks `确认工作项操作 <operationId>` or `取消工作项操作 <operationId>`. Never expose internal request IDs, command-draft UUIDs, or the term task draft, and never report a draft as executed.",
      "Commands beginning member., module., requirement., bug., iteration., or work_item. are Task commands. Natural requests such as 先让我确认/确认后再保存 mean create the Task draft now through execute_command and return its OP confirmation phrase.",
      "When work_item context is blocked or partial, explain in ordinary language which work item and which kind of material was unavailable. Never show context_receipt_id, context_missing_json keys, internal UUIDs, or ask the user to repeat them. If the user already said add/save/update/delete, never claim write authorization is missing. The user may naturally retry, ignore that missing material, or provide the missing facts; Synapse binds the exact item within the same session.",
      "When presenting a requirement, Bug, or iteration operation for confirmation, repeat the selected product from the trusted task_scope context so the user can verify the target product before confirming.",
      ...(options.workItemContextInjected
        ? [INJECTED_WORK_ITEM_READ_POLICY]
        : ["For a public work-item ID, use requirement.detail or bug.detail first so the response includes the work item, comments, activity, hierarchy/links, attachment metadata, and timestamps."]),
      "Use bug.attachment.get with bugId+attachmentId only when attachment content must be inspected; then inspect the returned localPath with the client's native image/file tool. Never access Cerebro storage or databases directly.",
      ...(includeWorkItemContextPolicy ? [
        "work_item.context.save is reserved for creating or updating the one fixed AI conversation context described by work_item_context_save_input_guide. Document history and diff remain read-only operations.",
        "Uploaded or manually maintained context materials are read-only to AI clients. Never draft move, rename, archive, delete, restore, restore-version, or metadata-only changes for them; tell the user to manage those materials in Cortex.",
        "For work_item.context.save, DO NOT run describe or inspect files: work_item_context_save_input_guide in THIS message is complete. Write a self-contained Markdown conversation summary rather than raw conversation, derive metadata, and preserve fields not changed. Cortex is authoritative: never create or edit repository/Git files as fallback.",
      ] : []),
      "Resolve natural-language assignee and module names through member.list and module.list. Resolve Bug state labels through bug.workflow.list. Resolve iteration names through iteration.list. Never guess opaque IDs or workflow state keys.",
      ...(!preferredTaskRead && !preferredTaskInputExact
        ? ["For a non-context-save task command with optional or unfamiliar input, run task_capability_describe_template once; do not guess nested fields. Encode task datetimes as ISO 8601 UTC ending in Z."]
        : []),
    ] : taskOnly ? [
      "No Task envelope is available until trusted task_scope selects one product. Ask the user to choose from task_scope_required; do not invoke execute_command, use a browser, or simulate the desktop UI.",
    ] : []),
    ...(!taskOnly ? [
      `execution_policy_json=${JSON.stringify(executionPolicy)}`,
      "For one user-requested capability and target, create exactly one idempotency key derived from requestIdempotencyKeyPrefix before the first call. Never change that key for errors or retries in the same turn.",
      "On confirmation_required, never retry and never expose its token. Synapse returns a Knowledge operation ID; report that it is not executed, ask the user to send exactly `确认知识操作 <operationId>` or `取消知识操作 <operationId>`, and stop. On executed, replayed, or denied, stop invoking that mutating capability. A successful receipt is authoritative: perform at most one read verification and stop.",
    ] : []),
    commentWriteBlock || documentMutationBlock || currentTurnWriteDirective(
      request,
      executeCommand,
      taskCatalogue?.protocolVersion,
      taskCatalogue?.productionId,
      platform,
      preferredTaskCommand,
      preferredTaskInput,
    ),
    currentTurnCommentHistoryDirective(request, taskCatalogue?.protocolVersion, taskCatalogue?.productionId, executeCommand),
    currentTurnBugRelationDirective(request, executeCommand, taskCatalogue?.protocolVersion, taskCatalogue?.productionId, options.bugRelationWriteContext, platform),
    currentTurnDocumentHistoryDirective(request, taskCatalogue?.protocolVersion, taskCatalogue?.productionId, executeCommand, options.workItemDocumentWriteContexts),
    currentTurnMultipleWorkItemWriteDirective(request),
    currentTurnBlockedWorkItemDirective(options.workItemContextBlocked),
  ].join("\n")
  let rendered: string
  let mode: AgentControlContextObservation["mode"] = "full"
  let compactFallback = false
  if (isCompactInjectionEnabled(options.env)) {
    try {
      rendered = renderCompactAgentControlContext(
        catalogue,
        request,
        launcher,
        turnId,
        compactRequestKeyPrefix,
        options.renderCompactIndex ?? renderCompactCapabilityIndex,
        options,
      )
      mode = "compact"
    } catch {
      rendered = fullContext()
      compactFallback = true
    }
  } else {
    rendered = fullContext()
  }
  const bytes = Buffer.byteLength(rendered, "utf8")
  observe?.({ bytes, estimatedTokens: Math.ceil(bytes / 4), mode, compactFallback })
  return rendered
}

export function isCompactInjectionEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return !["0", "false", "off"].includes(env["SYNAPSE_COMPACT_INJECTION"]?.trim().toLowerCase() ?? "")
}

export function renderAgentControlDegradedContext(result: KhDegraded): string {
  return `[Synapse]\nagent_control_degraded=${JSON.stringify(result)}`
}

function renderCompactAgentControlContext(
  catalogue: AgentControlCatalogue,
  request: InjectRequest,
  launcher: string,
  turnId: string,
  requestKeyPrefix: string,
  renderIndex: typeof renderCompactCapabilityIndex,
  options: AgentControlContextOptions,
): string {
  const taskOnly = options.taskOnly === true
  const preferredTaskCommand = options.preferredTaskCommand
  const preferredTaskInput = options.preferredTaskInput ?? {}
  const preferredTaskInputExact = Boolean(preferredTaskCommand && Object.keys(preferredTaskInput).length > 0)
  const knowledgeCatalogue = "knowledgeIntentContractVersion" in catalogue ? catalogue : undefined
  const platform = options.platform ?? process.platform
  const shell = options.windowsShell ?? resolveAgentCommandShell(request.client, platform)
  const executeCommand = renderAgentStdinCommand(
    launcher,
    "execute",
    request.client,
    platform,
    shell,
    taskOnly ? options.taskRouteToken : options.knowledgeRouteToken,
  )
  const taskCatalogue = catalogue.taskCatalogue
  const preferredTaskRead = availablePreferredTaskRead(taskCatalogue, options.preferredTaskRead)
  const preferredTaskReadEnvelope = preferredTaskRead && taskCatalogue
    ? taskReadEnvelope(taskCatalogue, preferredTaskRead)
    : undefined
  const commentWriteBlock = currentTurnCommentWriteBlock(request, options.workItemCommentWriteContexts)
  const documentMutationBlock = currentTurnDocumentMutationBlock(request, options.workItemDocumentWriteContexts)
  const includeWorkItemContextPolicy = needsWorkItemContextPolicy(request, preferredTaskCommand)
  const knowledgeEnvelope = renderKnowledgeEnvelopeTemplate(
    knowledgeCatalogue,
    request,
    turnId,
    requestKeyPrefix,
    options.knowledgeBoundArgsByCapability,
  )
  const compactArgsSchema = renderCompactKnowledgeArgsSchema(knowledgeCatalogue)
  return [
    "[Synapse control]",
    `execute_command=${executeCommand}`,
    ...(preferredTaskReadEnvelope
      ? renderPreferredTaskReadDirective(executeCommand, preferredTaskReadEnvelope, platform)
      : []),
    ...(platform === "win32"
      ? windowsAgentTransferContext(shell)
      : [SINGLE_ENVELOPE_TRANSPORT_POLICY, "Do not use a browser, desktop UI, or legacy tool."]),
    taskOnly ? TASK_ENVELOPE_ROUTING_POLICY : AGENT_ENVELOPE_ROUTING_POLICY,
    ...(catalogue.taskCatalogue ? [
      taskOnly
        ? `task_route=${catalogue.taskCatalogue.executePath}`
        : `routes=k:${knowledgeCatalogue?.executePath ?? "unavailable"},t:${catalogue.taskCatalogue.executePath}`,
      `task_R_envelope=${JSON.stringify(preferredTaskReadEnvelope ?? { protocolVersion: catalogue.taskCatalogue.protocolVersion, productionId: catalogue.taskCatalogue.productionId, command: "<R-name>", input: {} })}`,
      `task_D_envelope=${JSON.stringify({ protocolVersion: catalogue.taskCatalogue.protocolVersion, productionId: catalogue.taskCatalogue.productionId, command: preferredTaskCommand ?? "<D-name>", input: preferredTaskInput })}`,
      commentWriteBlock || documentMutationBlock || currentTurnWriteDirective(
        request,
        executeCommand,
        catalogue.taskCatalogue.protocolVersion,
        catalogue.taskCatalogue.productionId,
        platform,
        preferredTaskCommand,
        preferredTaskInput,
      ),
      currentTurnCommentHistoryDirective(request, catalogue.taskCatalogue.protocolVersion, catalogue.taskCatalogue.productionId, executeCommand),
      currentTurnBugRelationDirective(request, executeCommand, catalogue.taskCatalogue.protocolVersion, catalogue.taskCatalogue.productionId, options.bugRelationWriteContext, platform),
      currentTurnDocumentHistoryDirective(request, catalogue.taskCatalogue.protocolVersion, catalogue.taskCatalogue.productionId, executeCommand, options.workItemDocumentWriteContexts),
      currentTurnMultipleWorkItemWriteDirective(request),
      currentTurnBlockedWorkItemDirective(options.workItemContextBlocked),
      ...(includeWorkItemContextPolicy
        ? [`work_item_context_save_input_guide=${WORK_ITEM_CONTEXT_SAVE_INPUT_GUIDE}`]
        : []),
      ...attachmentPreparationContext(options.attachmentHandle, options.attachmentPolicy),
      ...(!preferredTaskRead && !preferredTaskInputExact
        ? [`task_describe_one=${renderAgentInvocation(launcher, `describe --task-only --json --production-id ${quoteCommandArg(catalogue.taskCatalogue.productionId, platform)} --capability ${quoteCommandArg("<name>", platform)}`, platform, shell)}`]
        : []),
      "User terms: 需求/需求单=>requirement; Bug/bug/缺陷=>bug. Creation MUST obey trusted task_scope.createIntentKind: requirement=>requirement.create, bug=>bug.create, ambiguous=>ask before any draft. 任务=>infer only from trusted scope/ID.",
      "Task R and D both use their complete protocolVersion/productionId/command/input envelope through execute_command. Omit requestId/contextReceiptId/contextTargetPublicId; Synapse binds them from the turn token. Replace placeholders. Use only response.operationId: requirement.*=>`确认需求操作 <operationId>`/`取消需求操作 <operationId>`; bug.*=>`确认Bug操作 <operationId>`/`取消Bug操作 <operationId>`; iteration.*=>`确认迭代操作 <operationId>`/`取消迭代操作 <operationId>`; work_item.*=>`确认工作项操作 <operationId>`/`取消工作项操作 <operationId>`. Never expose internal IDs or report a draft as executed.",
      "先让我确认/确认后再保存 => create the Task draft NOW through execute_command and return its OP phrase.",
      "Blocked/partial work_item context: explain unavailable material in ordinary language. Never expose context_receipt_id, context_missing_json keys, or internal UUIDs; the user can naturally retry, ignore, or supply facts in the same session.",
      "For operation confirmation, repeat the product from trusted task_scope.",
      ...(options.workItemContextInjected
        ? [INJECTED_WORK_ITEM_READ_POLICY]
        : ["Public ID view: call requirement.detail or bug.detail."]),
      "For attachment content call bug.attachment.get, then inspect result.localPath with the native image/file tool. Never access server storage/database directly.",
      ...(includeWorkItemContextPolicy ? [
        "work_item.context.save only creates or updates the fixed AI conversation context in work_item_context_save_input_guide; document history and diff are read-only. Uploaded or manually maintained context materials are read-only to AI clients: never draft move, rename, archive, delete, restore, restore-version, or metadata-only changes; direct those changes to Cortex. DO NOT run describe or inspect files; save a self-contained Markdown conversation summary, preserve unchanged metadata, and never fall back to repo/Git files.",
      ] : []),
      "Resolve names before drafts: member.list for assignees, module.list for modules, iteration.list for iterations, bug.workflow.list for Bug states. Never guess IDs/state keys.",
      ...(!preferredTaskRead && !preferredTaskInputExact
        ? ["For optional or unfamiliar task input, run task_describe_one for only that command; never guess nested fields. Task datetimes must be ISO 8601 UTC ending in Z."]
        : []),
    ] : taskOnly ? ["No Task envelope until task_scope selects one product. Ask the user; no execute/browser/desktop UI."] : []),
    renderIndex(catalogue, { taskOnly }),
    ...(!taskOnly ? [
      `knowledge_envelope=${JSON.stringify(knowledgeEnvelope)}`,
      ...(compactArgsSchema
        ? [`args_schema_json=${compactArgsSchema}`, ...renderKnowledgeBoundArgsPolicy(options.knowledgeBoundArgsByCapability)]
        : []),
      ...(knowledgeCatalogue?.capabilities.some((entry) => entry.name === "save_chat_insight")
        ? ['save_chat_insight: insight=complete content; captureMode="explicit".']
        : []),
      USER_VISIBLE_KNOWLEDGE_POLICY,
      `Keep requestIdempotencyKey; omit confirmation; verify=${requestKeyPrefix}:verify.`,
      "confirmation_required != success: no retry/token. Ask exact `确认知识操作 <operationId>` or `取消知识操作 <operationId>`; stop. executed/replayed/denied=>stop. Receipt wins; max 1 read verify.",
    ] : []),
  ].join("\n")
}

function renderKnowledgeEnvelopeTemplate(
  catalogue: KnowledgeCapabilityCatalog | undefined,
  request: InjectRequest,
  turnId: string,
  requestIdempotencyKey: string,
  boundArgsByCapability: KnowledgeCapabilityBoundArgs | undefined,
): Record<string, unknown> {
  const available = new Set(catalogue?.availableCapabilities ?? [])
  const capabilities = catalogue?.capabilities
    .map((entry) => entry.name as KnowledgeCapabilityName)
    .filter((name) => available.has(name)) ?? []
  const selectedCapability = capabilities.length === 1 ? capabilities[0] : undefined
  const args = selectedCapability
    ? { ...(boundArgsByCapability?.[selectedCapability] ?? {}) }
    : {}
  return {
    protocolVersion: catalogue?.protocolVersion,
    client: request.client,
    sessionId: request.session_id || "unknown-session",
    turnId,
    capability: selectedCapability ?? "<name>",
    args,
    requestIdempotencyKey,
  }
}

function renderCompactKnowledgeArgsSchema(
  catalogue: KnowledgeCapabilityCatalog | undefined,
): string | undefined {
  if (!catalogue) return undefined
  const available = new Set(catalogue.availableCapabilities)
  const capabilities = catalogue.capabilities.filter((entry) => (
    available.has(entry.name as KnowledgeCapabilityName)
  ))
  if (capabilities.length < 1 || capabilities.length > 2) return undefined
  return JSON.stringify(Object.fromEntries(capabilities.map((entry) => [
    entry.name,
    {
      required: entry.args.required,
      optional: entry.args.optional,
      fields: Object.fromEntries(Object.entries(entry.args.fields).map(([name, field]) => [
        name,
        {
          type: field.type,
          ...(field.enum ? { enum: field.enum } : {}),
          ...(field.minimum !== undefined ? { minimum: field.minimum } : {}),
          ...(field.maximum !== undefined ? { maximum: field.maximum } : {}),
        },
      ])),
    },
  ])))
}

function renderKnowledgeBoundArgsPolicy(
  boundArgsByCapability: KnowledgeCapabilityBoundArgs | undefined,
): string[] {
  const entries = Object.entries(boundArgsByCapability ?? {})
  return [
    ...(entries.length > 0
      ? [`trusted_args_by_capability_json=${JSON.stringify(Object.fromEntries(entries))}`]
      : []),
    "Keep trusted args exactly. Fill only missing required fields and optional fields explicitly requested by the user; omit other optional fields.",
  ]
}

export function resolveAgentControlTurnId(request: InjectRequest): string {
  return request.turn_id?.trim() || stableFallbackTurnId({
    client: request.client,
    sessionId: request.session_id,
    messageId: request.message_id,
    conversationId: request.conversation_id,
    currentText: request.user_input,
  })
}

function currentTurnCommentWriteBlock(
  request: InjectRequest,
  contexts: AgentControlContextOptions["workItemCommentWriteContexts"],
): string {
  if (!contexts?.length) return ""
  const deleting = /(?:删除|删掉|移除)/.test(request.user_input)
  const editing = /(?:修改|改成|更新|改为|改一下).{0,48}(?:评论|留言|评审意见|发布)|(?:评论|留言|评审意见).{0,48}(?:修改|改成|更新|改为|改一下)/.test(request.user_input)
    || /(?:把|将).{0,160}(?:发布的|留言|评论).{0,160}(?:改成|改为)/.test(request.user_input)
  if (!deleting && !editing) return ""
  const publicIds = [...request.user_input.matchAll(/[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi)]
    .map((match) => match[0]!.toUpperCase())
  const targetDescription = editing
    ? request.user_input.split(/(?:改成|改为|更新为)/, 1)[0]!
    : request.user_input
  const scoped = uniqueCommentWriteContexts(contexts.filter((comment) => (
    publicIds.length === 0 || publicIds.includes(comment.targetPublicId.toUpperCase())
  )))
  const bodyMatches = scoped.filter((comment) => comment.body && targetDescription.includes(comment.body))
  const authorMatches = scoped.filter((comment) => (
    comment.authorDisplayName && userIdentifiesCommentPublisher(targetDescription, comment.authorDisplayName)
  ))
  const candidates = bodyMatches.length > 0 ? bodyMatches : authorMatches
  if (candidates.length > 1) {
    return "CURRENT TURN REQUIRED ACTION: More than one comment matches the user's description. STOP without any command or draft. Ask the user in ordinary Chinese to quote or describe the specific comment. Never mention IDs or implementation details."
  }
  if (candidates.length !== 1) return ""
  const candidate = candidates[0]!
  const forbidden = deleting ? !candidate.canDelete : !candidate.canEdit
  if (!forbidden) return ""
  const publisher = candidate.authorDisplayName?.trim() || "原发布者"
  return `CURRENT TURN REQUIRED ACTION: The user cannot ${deleting ? "delete" : "edit"} the uniquely matched comment. STOP without any command or draft. Reply only in ordinary Chinese that this comment can only be ${deleting ? "删除" : "修改"} by its publisher ${publisher}, and that no change was made. Never mention permissions, capabilities, IDs, fields, or implementation details.`
}

function userIdentifiesCommentPublisher(input: string, displayName: string): boolean {
  const escapedName = displayName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  return new RegExp(`${escapedName}(?:本人)?(?:发布|写|留|说|提|的)[^。！？!?\\n]{0,24}(?:评论|留言|评审意见)|(?:评论|留言|评审意见)[^。！？!?\\n]{0,24}(?:由|是)?${escapedName}`).test(input)
}

function uniqueCommentWriteContexts(
  contexts: NonNullable<AgentControlContextOptions["workItemCommentWriteContexts"]>,
): NonNullable<AgentControlContextOptions["workItemCommentWriteContexts"]> {
  const unique = new Map<string, (typeof contexts)[number]>()
  for (const context of contexts) unique.set(`${context.sourcePublicId}\n${context.commentId}`, context)
  return [...unique.values()]
}

function currentTurnBlockedWorkItemDirective(blocked: boolean | undefined): string {
  if (!blocked) return ""
  return "CURRENT TURN REQUIRED ACTION: A necessary Cortex work-item material is currently unavailable. STOP without any command or draft. Explain only that the needed material could not be opened, so the requested work cannot continue reliably yet. Invite the user to retry, explicitly ignore it, or provide the missing business fact. NEVER mention authorization, permissions, receipts, missing keys, schemas, capabilities, protocols, internal IDs, or implementation details."
}

function currentTurnBugRelationDirective(
  request: InjectRequest,
  executeCommand: string,
  taskProtocolVersion: string | undefined,
  productionId: string | undefined,
  context: AgentControlContextOptions["bugRelationWriteContext"],
  platform: NodeJS.Platform = process.platform,
): string {
  if (!taskProtocolVersion || !productionId) return ""
  const publicIds = [...request.user_input.matchAll(/[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi)]
    .map((match) => match[0]!.toUpperCase())
  const bugId = publicIds.find((value) => value.includes("-B"))
  const requirementIds = [...new Set(publicIds.filter((value) => value.includes("-R")))]
  const requirementId = requirementIds[0]
  if (!bugId || !/(?:主要需求|关联|相关需求)/.test(request.user_input)) return ""
  if (requirementIds.length > 1) {
    return `CURRENT TURN REQUIRED ACTION: More than one requirement is named for this Bug relationship change. STOP without a command or draft and ask which requirement should be used: ${requirementIds.join("、")}。`
  }
  const relationSetVersion = context?.bugId === bugId ? context.relationSetVersion : undefined
  const relationId = context?.bugId === bugId
    ? context.relations.find((relation) => relation.requirementId === requirementId)?.relationId
    : undefined
  if (relationSetVersion === undefined) {
    return `CURRENT TURN REQUIRED ACTION: The trusted Bug relationship inventory for ${bugId} is unavailable. STOP without a command or draft and ask the user in ordinary Chinese to reload the Bug before changing its requirement associations. Never invent a relation version.`
  }
  let body: Record<string, unknown>
  if (/(?:取消|清除|去掉).{0,24}主要需求|主要需求.{0,24}(?:取消|清除|去掉)/.test(request.user_input)) {
    body = { command: "requirement.bug.primary.clear", input: { bugId, expectedRelationSetVersion: relationSetVersion } }
  } else if (requirementId && /(?:设为|作为|改成|恢复为|重新设为).{0,24}主要需求|主要需求.{0,24}(?:设为|作为|改成|恢复)/.test(request.user_input)) {
    if (!relationId) {
      return `CURRENT TURN REQUIRED ACTION: ${requirementId} is not present in the trusted relation inventory for ${bugId}. STOP without a command or draft. Explain in ordinary Chinese that it must be associated with the Bug before it can become the primary requirement.`
    }
    body = { command: "requirement.bug.primary.set", input: { bugId, relationId, expectedRelationSetVersion: relationSetVersion } }
  } else if (requirementId && /(?:不再关联|解除关联|取消关联|移除关联)/.test(request.user_input)) {
    if (!relationId) {
      return `CURRENT TURN REQUIRED ACTION: No trusted existing relation from ${bugId} to ${requirementId} was found. STOP without a command or draft and explain in ordinary Chinese that there is no matching association to remove.`
    }
    body = { command: "requirement.bug.unlink", input: { bugId, relationId, expectedRelationSetVersion: relationSetVersion } }
  } else if (requirementId && /(?:重新关联|恢复关联|关联回来|关联到)/.test(request.user_input)) {
    body = { command: "requirement.bug.link", input: { requirementId, bugId, expectedRelationSetVersion: relationSetVersion } }
  } else return ""
  const payload = JSON.stringify({ protocolVersion: taskProtocolVersion, productionId, ...body })
  return `CURRENT TURN REQUIRED ACTION: This is a Bug/requirement relationship write. Run COPY_THIS_EXACT_RELATION_DRAFT_COMMAND exactly once. Keep command and field names byte-for-byte; never expose relation IDs or versions. Then show exactly 确认需求操作 <returned operationId> and wait; NEVER say 确认工作项操作.\nCOPY_THIS_EXACT_RELATION_DRAFT_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, payload, platform)}`
}

function currentTurnMultipleWorkItemWriteDirective(request: InjectRequest): string {
  const ids = [...new Set([...request.user_input.matchAll(/[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi)]
    .map((match) => match[0]!.toUpperCase()))]
  if (ids.length < 2 || !/(?:保存|写入|新增|补充|修改|更新|删除|留言|评论|调整)/.test(request.user_input)) return ""
  const relationship = ids.some((id) => id.includes("-B")) && ids.some((id) => id.includes("-R"))
    && /(?:主要需求|不再关联|解除关联|重新关联|关联回来|关联到)/.test(request.user_input)
  if (relationship) return ""
  return `CURRENT TURN REQUIRED ACTION: This message names multiple work items but does not select one write target. Do not create a draft or discuss authorization. Ask only which one should receive the change: ${ids.join("、")}。`
}

function currentTurnDocumentMutationBlock(
  request: InjectRequest,
  contexts: AgentControlContextOptions["workItemDocumentWriteContexts"],
): string {
  if (!contexts?.length || !/(?:移动|移到|挪到|调整位置|改名|重命名|归档|存档|删除|删掉|恢复|还原)/.test(request.user_input)) return ""
  const targetId = [...request.user_input.matchAll(/[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi)]
    .map((match) => match[0]!.toUpperCase())
    .find((publicId) => contexts.some((context) => context.targetPublicId === publicId))
  const context = contexts.find((candidate) => candidate.targetPublicId === targetId)
  if (!context) return ""
  const named = context.documents.filter((document) => request.user_input.includes(document.title))
  const candidates = named.length > 0 ? named : context.documents.filter((document) => document.archivedAt !== null)
  if (candidates.length !== 1) return ""
  const document = candidates[0]!
  return isWorkItemAutomaticContextPath(document.path)
    ? "CURRENT TURN REQUIRED ACTION: AI conversation context cannot be moved, renamed, archived, deleted, or restored. STOP without a command or draft. Explain in ordinary language that the user can correct its current Markdown in Cortex."
    : "CURRENT TURN REQUIRED ACTION: Uploaded and manually maintained context materials are read-only to AI clients. STOP without a command or draft. Explain in ordinary language that this document change must be made in Cortex."
}

function currentTurnDocumentHistoryDirective(
  request: InjectRequest,
  taskProtocolVersion: string | undefined,
  productionId: string | undefined,
  executeCommand: string,
  contexts: AgentControlContextOptions["workItemDocumentWriteContexts"],
): string {
  if (!taskProtocolVersion || !productionId || !contexts?.length) return ""
  const asksDiff = /(?:比较|对比).{0,40}(?:最早|最初|第一版).{0,40}(?:现在|当前)/.test(request.user_input)
  const asksHistory = /(?:改过几次|修改历史|变更记录)|(?:资料|文档|总览).{0,40}(?:之前|以前|历史).{0,24}(?:改过|修改|变更)/.test(request.user_input)
  if (!asksDiff && !asksHistory) return ""
  const targetId = [...request.user_input.matchAll(/[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi)]
    .map((match) => match[0]!.toUpperCase())
    .find((publicId) => contexts.some((context) => context.targetPublicId === publicId))
  const context = contexts.find((candidate) => candidate.targetPublicId === targetId)
  const named = context?.documents.filter((document) => request.user_input.includes(document.title)) ?? []
  if (!context || named.length !== 1) return ""
  const document = named[0]!
  const command = asksDiff ? "work_item.context.document.diff" : "work_item.context.document.history"
  const input = asksDiff
    ? { targetPublicId: context.targetPublicId, sourcePublicId: document.sourcePublicId, documentId: document.documentId, fromRevision: 1, toRevision: document.revision }
    : { targetPublicId: context.targetPublicId, sourcePublicId: document.sourcePublicId, documentId: document.documentId, limit: 50 }
  const envelope = JSON.stringify({ protocolVersion: taskProtocolVersion, productionId, command, input })
  return `CURRENT TURN REQUIRED ACTION: Run COPY_THIS_EXACT_DOCUMENT_HISTORY_COMMAND exactly once. NEVER use Knowledge search, describe, help, or repository files. Answer only in ordinary product language and never expose paths, IDs, revisions, or protocol fields.\nCOPY_THIS_EXACT_DOCUMENT_HISTORY_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, envelope)}`
}

function currentTurnCommentHistoryDirective(
  request: InjectRequest,
  taskProtocolVersion: string | undefined,
  productionId: string | undefined,
  executeCommand: string,
): string {
  if (!/(?:评论|留言|评审意见)/.test(request.user_input) || !taskProtocolVersion || !productionId) return ""
  const deletedHistory = /(?:(?:刚|已|被).{0,8}(?:删除|删掉)|(?:什么时候|何时).{0,8}(?:删除|删掉)|(?:删除|删掉).{0,8}(?:时间|记录|历史)|(?:删除|删掉)(?:前|之前))/.test(request.user_input)
  const activeHistory = /(?:改过什么|改动记录|修改历史|变更历史|改过几次)/.test(request.user_input)
  if (!deletedHistory && !activeHistory) return ""
  if (deletedHistory) {
    return "CURRENT TURN REQUIRED ACTION: The user asks about a deleted comment. Do not run any command. Use only tombstone facts and clearly say deleted content and edit history are not viewable. Never infer or reveal deleted wording."
  }
  const envelope = JSON.stringify({
    protocolVersion: taskProtocolVersion,
    productionId,
    command: "work_item.comment.history",
    input: { targetPublicId: "<candidate.targetPublicId>", sourcePublicId: "<candidate.sourcePublicId>", commentId: "<candidate.commentId>", limit: 50 },
  })
  return `CURRENT TURN REQUIRED ACTION: Match one active comment through comment_history_candidates_json and ordinary body/author evidence. Replace only the three candidate placeholders in COPY_THIS_EXACT_COMMENT_HISTORY_COMMAND and run it once. NEVER invent work_item.comment.list, work_item.activity.list, knowledge search, or a second command. Do not expose internal IDs or version numbers.\nCOPY_THIS_EXACT_COMMENT_HISTORY_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, envelope)}`
}

function needsWorkItemContextPolicy(
  request: InjectRequest,
  preferredTaskCommand?: TaskCapabilityCommand,
): boolean {
  return preferredTaskCommand === "work_item.context.save"
    || /(?:上下文|对话摘要|交接(?:资料|文档|材料)?|\b(?:context|handoff)\b)/i.test(request.user_input)
}

function currentTurnWriteDirective(
  request: InjectRequest,
  executeCommand: string,
  taskProtocolVersion: string | undefined,
  productionId: string | undefined,
  platform: NodeJS.Platform = process.platform,
  preferredTaskCommand?: TaskCapabilityCommand,
  preferredTaskInput: Record<string, unknown> = {},
): string {
  if (!taskProtocolVersion || !productionId || !hasWorkItemWriteAuthorizationIntentText(request.user_input)) return ""
  const preferredWriteCommand = TaskCapabilityWriteCommandSchema.safeParse(preferredTaskCommand)
  const exact = preferredWriteCommand.success
  const payload = JSON.stringify({
    protocolVersion: taskProtocolVersion,
    productionId,
    command: exact ? preferredWriteCommand.data : "<real D name>",
    input: exact ? preferredTaskInput : {},
  })
  const action = platform === "win32"
    ? exact
      ? "Encode the complete task_D_envelope exactly as win_json requires, then run execute_command once"
      : "Replace <real D name> and input in task_D_envelope, encode that complete JSON exactly as win_json requires, then run execute_command once"
    : exact
      ? `Run COPY_THIS_EXACT_TASK_DRAFT_COMMAND exactly once\nCOPY_THIS_EXACT_TASK_DRAFT_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, payload, platform)}`
      : `Replace <real D name> and input in COPY_THIS_EXACT_TASK_DRAFT_COMMAND, then run that command once\nCOPY_THIS_EXACT_TASK_DRAFT_COMMAND=${renderAgentJsonPayloadCommand(executeCommand, payload, platform)}`
  const contextPolicy = needsWorkItemContextPolicy(request, preferredTaskCommand)
    ? " work_item.context.save may only create or update the fixed AI conversation context and requires targetPublicId,baseContextSnapshotId,contextVersion,changes[],pathExpectations,summary plus complete merged Markdown. Never draft move, rename, archive, delete, restore, restore-version, or metadata-only changes for uploaded or manually maintained context materials; direct those changes to Cortex."
    : ""
  return `CURRENT TURN REQUIRED ACTION: This work-item write needs a real OP now. ${action} and show its OP phrase. Copy command names exactly. work_item.* uses 确认工作项操作 OP-XXXXXXXX. Context comments use exact create/update/delete inputs.${contextPolicy} Never expose internal paths. Text-only preview, generic confirmation, missing-authorization claims, self-confirmation, browser/desktop UI, or reading repository/session files is a test failure.`
}

const WORK_ITEM_CONTEXT_SAVE_INPUT_GUIDE = [
  "input={targetPublicId,baseContextSnapshotId,contextVersion,changes,pathExpectations,summary}.",
  `AI conversation context is exactly one work-item-owned internal document: path=${WORK_ITEM_AUTOMATIC_CONTEXT_PATH} and title=${WORK_ITEM_AUTOMATIC_CONTEXT_TITLE}; it is unrelated to repository files.`,
  "Take snapshot/version and any existing fixed document identity from complete_inventory_json. Its absence is normal and must not be reported as an error.",
  `When absent use create={kind,changeId,targetPath:'${WORK_ITEM_AUTOMATIC_CONTEXT_PATH}',markdown,metadata?} with pathExpectations=[{path:'${WORK_ITEM_AUTOMATIC_CONTEXT_PATH}',documentId:null}].`,
  "When present use only an in-place update={kind,changeId,documentId,expectedRevision,expectedPath,markdown,metadata?} and the matching existing-document path expectation.",
  "Never create another path or use targetPath on update, move, archive, restore, restore_revision, or metadata-only changes.",
  "metadata={title,summary,scope,keywords,feature,isCritical,relations}; derive only supported values from the Markdown and trusted inventory.",
  "For every update, markdown is the complete merged conversation context and omitted metadata stays unchanged.",
].join(" ")

function attachmentPreparationContext(
  handle?: string,
  policy?: "bug-upload" | "requirement-empty-check",
): string[] {
  if (!handle || !policy) return []
  return [
    policy === "bug-upload"
      ? "Current-turn Bug attachments are bound and uploaded by Synapse inside the same execute_command call. Omit input.attachmentTokens; never read transcript/server storage or invent attachment tokens."
      : "Synapse verifies that this delayed-source turn has no attachments inside the same requirement.create execute_command call. On verification failure, report it and stop; never silently discard current-turn files.",
  ]
}

function degraded(
  reason: KhDegraded["reason"],
  message: string,
  httpStatus?: number,
): KhDegraded {
  return { ok: false, reason, message, httpStatus }
}

function quoteCommandArg(value: string, platform: NodeJS.Platform = process.platform): string {
  if (platform === "win32") return `"${value.replace(/"/g, '""')}"`
  return `'${value.replace(/'/g, `'"'"'`)}'`
}
