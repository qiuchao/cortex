import { Worker } from "node:worker_threads"
import type { BuildDirectoryManifestOptions, DirectoryManifestBuildResult } from "./directories.ts"
import type { ScanOptions, ScanResult } from "./scanner.ts"
import type {
  ScanWorkerRequest,
  ScanWorkerMessage,
  ScanWorkerResponse,
  SerializableManifestResult,
  SerializableScanUploadResult,
} from "./scan-worker-contract.ts"

export interface TranscriptScanPort {
  buildManifest: (opts: BuildDirectoryManifestOptions) => Promise<DirectoryManifestBuildResult>
  scan: (opts: ScanOptions) => Promise<ScanResult>
  scanAndUpload?: (opts: ScanOptions, env: NodeJS.ProcessEnv) => Promise<SerializableScanUploadResult>
  stop: () => void
}

type Pending = {
  resolve: (response: ScanWorkerResponse) => void
  reject: (error: Error) => void
  timer: ReturnType<typeof setTimeout> | null
  timeoutMs: number
}

export interface TranscriptScanWorkerOptions {
  requestTimeoutMs?: number | ((kind: ScanWorkerRequest["kind"]) => number)
}

export function createTranscriptScanWorker(
  options: TranscriptScanWorkerOptions = {},
): TranscriptScanPort {
  const requestTimeoutMs = options.requestTimeoutMs ?? 120_000
  let worker: Worker | null = null
  let stopped = false
  let nextId = 1
  const pending = new Map<number, Pending>()

  const rejectPending = (error: Error) => {
    for (const item of pending.values()) {
      if (item.timer) clearTimeout(item.timer)
      item.reject(error)
    }
    pending.clear()
  }

  const ensureWorker = (): Worker => {
    if (stopped) throw new Error("transcript scan worker stopped")
    if (worker) return worker

    const current = new Worker(new URL("./scan-worker.ts", import.meta.url), {
      name: "synapse-transcript-scan",
    })
    current.unref()
    current.on("message", (response: ScanWorkerMessage) => {
      const item = pending.get(response.id)
      if (!item) return
      if ("kind" in response && response.kind === "progress") {
        armDeadline(response.id, item)
        return
      }
      pending.delete(response.id)
      if (item.timer) clearTimeout(item.timer)
      item.resolve(response)
    })
    current.on("error", (error) => {
      if (worker !== current) return
      worker = null
      rejectPending(error instanceof Error ? error : new Error(String(error)))
    })
    current.on("exit", (code) => {
      if (worker !== current) return
      worker = null
      if (!stopped) rejectPending(new Error(`transcript scan worker exited with code ${code}`))
    })
    worker = current
    return current
  }

  const request = (message: Omit<ScanWorkerRequest, "id">): Promise<ScanWorkerResponse> => {
    const id = nextId++
    return new Promise((resolve, reject) => {
      const timeoutMs = typeof requestTimeoutMs === "function"
        ? requestTimeoutMs(message.kind)
        : requestTimeoutMs
      const item: Pending = { resolve, reject, timer: null, timeoutMs }
      pending.set(id, item)
      armDeadline(id, item)
      try {
        ensureWorker().postMessage({ ...message, id } as ScanWorkerRequest)
      } catch (error) {
        pending.delete(id)
        if (item.timer) clearTimeout(item.timer)
        reject(error instanceof Error ? error : new Error(String(error)))
      }
    })
  }

  function armDeadline(id: number, item: Pending): void {
    if (item.timer) clearTimeout(item.timer)
    item.timer = setTimeout(() => {
      if (!pending.has(id)) return
      const current = worker
      worker = null
      rejectPending(new Error(`transcript scan worker timed out after ${item.timeoutMs}ms without progress`))
      if (current) void current.terminate()
    }, item.timeoutMs)
    if (typeof item.timer === "object" && "unref" in item.timer) item.timer.unref()
  }

  return {
    async buildManifest(opts) {
      const response = await request({ kind: "manifest", payload: opts })
      if (!response.ok) throw new Error(response.error)
      if (response.kind !== "manifest") throw new Error("unexpected transcript worker response")
      const result: SerializableManifestResult = response.result
      return {
        ...result,
        projectPathByFile: new Map(result.projectPathByFile),
      }
    },
    async scan(opts) {
      const response = await request({
        kind: "scan",
        payload: serializeScanOptions(opts),
      })
      if (!response.ok) throw new Error(response.error)
      if (response.kind !== "scan") throw new Error("unexpected transcript worker response")
      return response.result
    },
    async scanAndUpload(opts, env) {
      const response = await request({
        kind: "scan-upload",
        payload: { ...serializeScanOptions(opts), env },
      })
      if (!response.ok) throw new Error(response.error)
      if (response.kind !== "scan-upload") throw new Error("unexpected transcript worker response")
      return response.result
    },
    stop() {
      stopped = true
      const current = worker
      worker = null
      rejectPending(new Error("transcript scan worker stopped"))
      if (current) void current.terminate()
    },
  }

  function serializeScanOptions(opts: ScanOptions) {
    return {
      configs: opts.configs,
      cursors: opts.cursors.all(),
      userId: opts.userId,
      minAgeMs: opts.minAgeMs,
      allowlist: opts.allowlist,
      enabledProjectPaths: opts.enabledProjectPaths
        ? [...opts.enabledProjectPaths]
        : undefined,
      projectPathByFile: opts.projectPathByFile
        ? [...opts.projectPathByFile.entries()]
        : undefined,
      stageCursorUpdates: opts.stageCursorUpdates,
      nowMs: opts.now?.() ?? Date.now(),
    }
  }
}
