@echo off
if not defined SYNAPSE_BIN set "SYNAPSE_BIN=synapse.exe"
"%SYNAPSE_BIN%" agent report --client codex
