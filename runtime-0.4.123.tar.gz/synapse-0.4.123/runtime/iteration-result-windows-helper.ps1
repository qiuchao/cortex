param([Parameter(Mandatory=$true)][string]$RootBase64, [string]$Once = '', [string]$Id = '', [string]$NativeSource = (Join-Path $PSScriptRoot 'iteration-result-windows-native.cs'))
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::InputEncoding = New-Object Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
Add-Type -Path $NativeSource
$root = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($RootBase64))
$files = $null
try {
  if ($Once -ne '' -and $Once -ne 'init' -and $Once -ne 'check') { throw 'invalid operation' }
  $files = New-Object IterationPrivateFiles($root, ($Once -eq 'init'))
  if ($Once -ne '') { $files.Check($Id); exit 0 }
  [Console]::WriteLine('{"ready":true}')
  $sequence = 0
  while ($null -ne ($line = [IterationPrivateFiles]::ReadMessage())) {
    $request = ConvertFrom-Json $line
    $fields = @($request.PSObject.Properties.Name)
    if (($request.seq -isnot [int] -and $request.seq -isnot [long]) -or $request -is [Array] -or ($fields | Where-Object { $_ -cnotin @('op','id','seq','data','deadline') }) -or $request.seq -ne ($sequence + 1)) { throw 'invalid message' }
    if ($request.op -cnotin @('prepare','commit','abort','read','remove') -or $request.op -isnot [string] -or $request.id -isnot [string] -or $request.id -notmatch '\A[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}\z') { throw 'invalid identity' }
    $sequence++
    $data = ''
    switch ($request.op) {
      'prepare' { if ($fields.Count -ne 3) { throw 'invalid prepare' }; $files.Prepare($request.id) }
      'commit' { if ($fields.Count -ne 5 -or $request.data -isnot [string] -or $request.deadline -isnot [long] -and $request.deadline -isnot [int]) { throw 'invalid commit' }; $files.Commit($request.id,$request.data,[long]$request.deadline) }
      'remove' { if ($fields.Count -ne 3) { throw 'invalid remove' }; $files.Remove($request.id) }
      'abort' { if ($fields.Count -ne 3) { throw 'invalid abort' }; $files.Abort($request.id) }
      'read' { if ($fields.Count -ne 3) { throw 'invalid read' }; $data = $files.ReadResult($request.id) }
      default { throw 'invalid operation' }
    }
    if ($request.op -eq 'read' -and $null -eq $data) {
      [Console]::WriteLine((@{seq=$sequence;id=$request.id;pending=$true} | ConvertTo-Json -Compress))
    } else {
      [Console]::WriteLine((@{seq=$sequence;id=$request.id;ok=$true;data=$data} | ConvertTo-Json -Compress))
    }
  }
} catch { [Console]::Error.WriteLine('private iteration helper failed'); exit 1 }
finally { if ($null -ne $files) { $files.Dispose() } }
