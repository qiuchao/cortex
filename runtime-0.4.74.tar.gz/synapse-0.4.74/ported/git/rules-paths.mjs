import { existsSync } from "node:fs"
import { homedir } from "node:os"
import { join } from "node:path"

const CURRENT_DIR = "synapse"
const RETIRED_DIR = ["team", "kit"].join("")

function selectRulesPath(currentPath, retiredPath) {
  if (existsSync(currentPath) || !existsSync(retiredPath)) {
    return { path: currentPath, retired: false }
  }
  return { path: retiredPath, retired: true }
}

export function resolveGlobalGitRulesPath(home = homedir()) {
  return selectRulesPath(
    join(home, ".config", CURRENT_DIR, "git-rules.json"),
    join(home, ".config", RETIRED_DIR, "git-rules.json"),
  )
}

export function resolveProjectGitRulesPath(projectRoot) {
  return selectRulesPath(
    join(projectRoot, `.${CURRENT_DIR}`, "git-rules.json"),
    join(projectRoot, `.${RETIRED_DIR}`, "git-rules.json"),
  )
}
