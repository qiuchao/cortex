import { loadSessionState, persistSessionState } from "./session-store.ts"
import {
  TaskCapabilitySourceClientSchema,
  TaskCapabilityWriteCommandSchema,
  WorkItemPublicIdSchema,
  type TaskCapabilitySourceClient,
  type TaskCapabilityWriteCommand,
} from "@cerebro/wire"
import type { TaskCommandDraftRecord } from "../transport/brain-contract-align.ts"
import type { TaskDraftCleanupRef, TaskDraftLifecycle } from "./task-draft-lifecycle.ts"

export interface TaskIntakeDraftTrust {
  requestId: string
  command: TaskCapabilityWriteCommand
  contextReceiptId: string | null
  contextTargetPublicId: string | null
  sourceClient: TaskCapabilitySourceClient
}

export interface StoredTaskIntakeRef extends TaskIntakeDraftTrust {
  draftId?: string
  productionId: string
  attempted: boolean
  blockedReason?: string
  cleanupDraftIds?: TaskDraftCleanupRef[]
}

export class TaskIntakeRefInvalidError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "TaskIntakeRefInvalidError"
  }
}

interface StoredTaskIntakeState {
  version: 1
  sessions: Record<string, StoredTaskIntakeRef>
}

export function isStoredTaskIntakeRef(value: unknown): value is StoredTaskIntakeRef {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false
  const ref = value as Record<string, unknown>
  if ((ref.draftId !== undefined && (typeof ref.draftId !== "string" || !ref.draftId)) || typeof ref.productionId !== "string" || !ref.productionId || typeof ref.attempted !== "boolean") return false
  if (typeof ref.requestId !== "string" || !ref.requestId || !TaskCapabilityWriteCommandSchema.safeParse(ref.command).success) return false
  if (!TaskCapabilitySourceClientSchema.safeParse(ref.sourceClient).success) return false
  if (!validStoredBinding(ref.contextReceiptId, ref.contextTargetPublicId)) return false
  if (ref.blockedReason !== undefined && (typeof ref.blockedReason !== "string" || !ref.blockedReason)) return false
  if (ref.cleanupDraftIds !== undefined && (!Array.isArray(ref.cleanupDraftIds) || ref.cleanupDraftIds.some((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return true
    const cleanup = item as Record<string, unknown>
    return typeof cleanup.draftId !== "string" || typeof cleanup.productionId !== "string"
      || !Object.keys(cleanup).every((key) => key === "draftId" || key === "productionId")
  }))) return false
  return Object.keys(ref).every((key) => ["draftId", "productionId", "requestId", "command", "contextReceiptId", "contextTargetPublicId", "sourceClient", "attempted", "blockedReason", "cleanupDraftIds"].includes(key))
}

export function taskIntakeDraftTrust(
  input: Parameters<TaskDraftLifecycle["create"]>[0],
): TaskIntakeDraftTrust {
  const contextReceiptId = input.contextReceiptId ?? null
  const contextTargetPublicId = input.contextTargetPublicId ?? null
  if (!validStoredBinding(contextReceiptId, contextTargetPublicId)) {
    throw new TaskIntakeRefInvalidError("操作上下文绑定无效")
  }
  const sourceClient = TaskCapabilitySourceClientSchema.safeParse(input.sourceClient)
  if (!sourceClient.success) throw new TaskIntakeRefInvalidError("操作缺少可信 Harness 客户端")
  return { requestId: input.requestId, command: input.command, contextReceiptId, contextTargetPublicId, sourceClient: sourceClient.data }
}

export function assertTaskIntakeDraftMatches(
  record: TaskCommandDraftRecord,
  expected: TaskIntakeDraftTrust & { productionId: string; draftId?: string },
): void {
  if ((expected.draftId && record.id !== expected.draftId)
    || record.productionId !== expected.productionId
    || record.requestId !== expected.requestId
    || record.command !== expected.command
    || record.sourceClient !== expected.sourceClient
    || record.contextReceiptId !== expected.contextReceiptId
    || record.contextTargetPublicId !== expected.contextTargetPublicId) {
    throw new TaskIntakeRefInvalidError("服务端操作与本地可信引用不一致")
  }
}

export function loadTaskIntakeSessions(path: string): Record<string, StoredTaskIntakeRef> {
  return loadSessionState(path, () => ({}), (value) => {
    const state = value as Partial<StoredTaskIntakeState>
    if (state.version !== 1 || !state.sessions || typeof state.sessions !== "object" || Array.isArray(state.sessions)) return {}
    return Object.fromEntries(Object.entries(state.sessions).filter((entry): entry is [string, StoredTaskIntakeRef] => isStoredTaskIntakeRef(entry[1])))
  })
}

export function persistTaskIntakeSessions<T>(
  path: string,
  sessions: Record<string, T | StoredTaskIntakeRef>,
  project: (value: T) => StoredTaskIntakeRef | undefined,
): void {
  const refs = Object.entries(sessions).flatMap(([key, value]) => {
    const ref = isStoredTaskIntakeRef(value) ? value : project(value as T)
    return ref ? [[key, ref] as const] : []
  })
  persistSessionState(path, { version: 1, sessions: Object.fromEntries(refs) } satisfies StoredTaskIntakeState)
}

function validStoredBinding(receipt: unknown, target: unknown): boolean {
  if (receipt === null && target === null) return true
  return typeof receipt === "string"
    && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(receipt)
    && WorkItemPublicIdSchema.safeParse(target).success
}
