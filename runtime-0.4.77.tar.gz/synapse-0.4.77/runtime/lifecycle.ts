/**
 * runtime/lifecycle.ts —— 常驻运行时生命周期:单实例保证 + socket 监听 + 发现文件 +
 *                          stale-socket 清理(方案 R4c)。
 *
 * 单实例(R4c):pidfile + 幂等 ensure-running(OS 自启与工作台都调它,已在跑则 no-op)
 *              + stale-socket 清理(死 pid → unlink socket + rebind)。
 * 生命周期独立于 GUI(spec §61/§103):这是普通后台进程,不寄生工作台。
 */
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync, chmodSync } from "node:fs"
import type { AddressInfo } from "node:net"
import { dirname, join } from "node:path"
import type http from "node:http"
import { createServer, createMetrics, type Metrics } from "./server.ts"
import { startSyncLoop, type SyncLoopHandle } from "./sync.ts"
import { startWarmup, type WarmupHandle } from "./warmup.ts"
import { createReportState } from "../core/report.ts"
import { createSyncPriorityQueue } from "../core/handlers/nudge-sync.ts"
import { loadCursorStore } from "../transcript/cursor.ts"
import { startTranscriptLoop, type TranscriptLoopHandle } from "../transcript/loop.ts"
import { resolveUserId } from "../core/user-id.ts"
import { ensureMachineId } from "../core/token-store.ts"
import { createHttpDirectorySync } from "../transcript/directories.ts"
import { ensureRuntimeDir, ensureToken } from "../transport/auth.ts"
import { brainSyncPort } from "../transport/brain-contract-align.ts"
import { getRuntimeVersion } from "./version.ts"
import { createAgentCapabilityBroker } from "./agent-capability-broker.ts"
import { startAgentFileBridge } from "./agent-file-bridge.ts"
import { createAgentAttachmentIntake } from "../core/agent-attachments.ts"
import { createTaskCapabilityDraftIntake } from "../core/task-capability-draft-intake.ts"
import { createKnowledgeConfirmationIntake } from "../core/knowledge-confirmation-intake.ts"
import { startTaskAttachmentCacheMaintenance, type TaskAttachmentCacheMaintenance } from "../transport/task-attachment-materializer.ts"
import { isGitGuardEnabled } from "../core/guard.ts"
import { createTaskTurnGuardRegistry } from "../core/task-turn-guard.ts"
import { createOperationTurnBridge } from "./operation-turn-bridge.ts"
import { readRuntimeProvenance } from "./provenance.ts"
import {
  socketPath,
  pidfilePath,
  discoveryPath,
  cacheDir,
  runtimeEnvPath,
  loopbackTokenPath,
  shouldUseLoopbackTcp,
  createAgentSpoolDir,
  type DiscoveryInfo,
} from "../transport/discovery.ts"

/** loopback TCP 环回地址:只绑 127.0.0.1,绝不 0.0.0.0(信任边界)。 */
const LOOPBACK_HOST = "127.0.0.1"

export interface RunningRuntime {
  server: http.Server
  metrics: Metrics
  socket: string
  startedAt: string
  stop: () => Promise<void>
}

export type DiscoveryReadResult =
  | { state: "available"; discovery: DiscoveryInfo }
  | { state: "absent" }
  | { state: "invalid"; message: string }

export interface RuntimeLifecycleOperations {
  writeDiscovery?: (env: NodeJS.ProcessEnv, info: DiscoveryInfo) => void
  writeRuntimeEnv?: (env: NodeJS.ProcessEnv, info: RuntimeEnvInfo) => void
  startSyncLoop?: typeof startSyncLoop
  startWarmup?: typeof startWarmup
  startTranscriptLoop?: typeof startTranscriptLoop
  assertReady?: () => void
}

interface RuntimeResources {
  syncLoop?: SyncLoopHandle
  warmup?: WarmupHandle
  transcriptLoop?: TranscriptLoopHandle
  agentFileBridge?: ReturnType<typeof startAgentFileBridge>
  taskAttachmentMaintenance?: TaskAttachmentCacheMaintenance
  server?: http.Server
}

/** 判断一个 pid 是否存活(signal 0 探测)。 */
export function isPidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0)
    return true
  } catch (e) {
    // ESRCH = 不存在;EPERM = 存在但无权(视为存活)
    return (e as NodeJS.ErrnoException).code === "EPERM"
  }
}

/** 读取 pidfile 里的 pid;无/非法返回 null。 */
export function readPid(env: NodeJS.ProcessEnv = process.env): number | null {
  try {
    const n = parseInt(readFileSync(pidfilePath(env), "utf8").trim(), 10)
    return Number.isFinite(n) && n > 0 ? n : null
  } catch {
    return null
  }
}

/** 运行时是否已在跑(pidfile 指向的进程存活)。 */
export function isRunning(env: NodeJS.ProcessEnv = process.env): boolean {
  const pid = readPid(env)
  return pid !== null && isPidAlive(pid)
}

/**
 * 幂等启动运行时。已在跑 → 抛 AlreadyRunningError(调用方决定 no-op)。
 * 否则清理 stale socket、监听、写 pidfile + 发现文件。
 */
export class AlreadyRunningError extends Error {
  // 注意:不用 TS parameter property(`constructor(public pid)`)——Node 的
  // 类型擦除模式(strip-only)不支持它。运行时代码必须能被 Node 直接跑,
  // 只用"纯擦除即可"的 TS 语法(禁 parameter property / enum / namespace)。
  readonly pid: number
  constructor(pid: number) {
    super(`synapse runtime already running (pid ${pid})`)
    this.name = "AlreadyRunningError"
    this.pid = pid
  }
}

export async function startRuntime(
  env: NodeJS.ProcessEnv = process.env,
  operations: RuntimeLifecycleOperations = {},
): Promise<RunningRuntime> {
  // 单实例:已在跑则拒绝重复启动
  const existing = readPid(env)
  if (existing !== null && isPidAlive(existing)) {
    throw new AlreadyRunningError(existing)
  }

  ensureRuntimeDir(env)
  const useTcp = shouldUseLoopbackTcp(env)
  const sock = socketPath(env)
  const gitGuardEnabled = isGitGuardEnabled(env)

  // stale-socket 清理:上次崩溃可能留下死 socket 文件,先 unlink 再 bind(仅 unix socket 通路)
  if (!useTcp && process.platform !== "win32" && existsSync(sock)) {
    try {
      unlinkSync(sock)
    } catch {
      /* best-effort */
    }
  }

  const metrics = createMetrics()
  const startedAt = new Date().toISOString()
  const bundleProvenance = readRuntimeProvenance()
  // 共享 ReportState:server 的 nudge_sync 往 syncQueue 里写,transcript loop 从中消费。
  const reportState = createReportState(createSyncPriorityQueue())
  const resources: RuntimeResources = {}

  try {
    // loopback-tcp:生成 0600 token(强制鉴权;token-less loopback 红线),server 校验 Bearer。
    const loopbackToken = useTcp ? ensureToken(env) : undefined
    const taskCapabilityDraftIntake = createTaskCapabilityDraftIntake(env)
    const knowledgeConfirmationIntake = createKnowledgeConfirmationIntake(env)
    const taskTurnGuards = createTaskTurnGuardRegistry()
    const agentAttachmentIntake = createAgentAttachmentIntake(env)
    const agentBroker = createAgentCapabilityBroker({
      env,
      rememberTaskDraft: (ref) => taskCapabilityDraftIntake.remember(ref),
      authorizeTaskDraftRequest: (requestId, productionId, request) => (
        taskCapabilityDraftIntake.authorizeRequest?.(requestId, productionId, request) ?? { authorized: false }
      ),
    })
    void agentBroker.describe().catch(() => undefined)
    const spoolPath = createAgentSpoolDir(env)
    resources.agentFileBridge = startAgentFileBridge(agentBroker, {
      ...env,
      SYNAPSE_AGENT_SPOOL_DIR: spoolPath,
    }, taskTurnGuards, agentAttachmentIntake, knowledgeConfirmationIntake)
    resources.taskAttachmentMaintenance = startTaskAttachmentCacheMaintenance(env)
    await resources.taskAttachmentMaintenance.ready
    const server = createServer({
      env,
      // unix socket / named pipe:连上即认证(fs 权限/ACL 把关)。
      // loopback-tcp:强制 Bearer token(authenticate() 校验 expectedToken)。
      auth: useTcp
        ? { mode: "loopback-tcp", expectedToken: loopbackToken }
        : { mode: process.platform === "win32" ? "named-pipe" : "unix-socket" },
      metrics,
      startedAt,
      reportState,
      agentBroker,
      taskCapabilityDraftIntake,
      knowledgeConfirmationIntake,
      taskTurnGuards,
      agentAttachmentIntake,
      guardDeps: { enabled: gitGuardEnabled },
      operationTurnBridge: createOperationTurnBridge({ env }),
      unifiedOperationTurn: env.SYNAPSE_UNIFIED_OPERATION_TURN !== "0",
    })
    resources.server = server

    // listen:TCP 绑 127.0.0.1(端口固定 SYNAPSE_PORT 或系统分配),否则 bind unix socket。
    let boundPort: number | undefined
    const requestedPort = useTcp ? parseInt(env["SYNAPSE_PORT"]?.trim() || "0", 10) : 0
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject)
      const onListening = () => {
        server.removeListener("error", reject)
        if (useTcp) {
          const addr = server.address() as AddressInfo | null
          boundPort = addr?.port
        }
        resolve()
      }
      if (useTcp) {
        // 只绑环回,绝不 0.0.0.0(否则同网段可达 → 不可逆 PII 外泄面)
        server.listen(Number.isFinite(requestedPort) ? requestedPort : 0, LOOPBACK_HOST, onListening)
      } else {
        server.listen(sock, onListening)
      }
    })

    // unix socket:显式收紧到 0600(server.listen 按 umask 建 socket,通常 0755 —— 不够)。
    // 目录 0700 已挡住外人,但 socket 本身 0600 = 纵深防御(方案 D6:0700 dir + 0600 socket)。
    if (!useTcp && process.platform !== "win32") {
      try {
        chmodSync(sock, 0o600)
      } catch {
        /* best-effort */
      }
    }

    // 写 pidfile + 发现文件(JSON + sh 友好的 runtime.env)
    writeFileSync(pidfilePath(env), String(process.pid), { mode: 0o600 })
    const transport: DiscoveryInfo["transport"] = useTcp
      ? "loopback-tcp"
      : process.platform === "win32"
        ? "named-pipe"
        : "unix-socket"
    const writeDiscoveryOperation = operations.writeDiscovery ?? writeDiscovery
    const writeRuntimeEnvOperation = operations.writeRuntimeEnv ?? writeRuntimeEnv
    writeDiscoveryOperation(env, {
      socket_path: sock,
      pid: process.pid,
      started_at: startedAt,
      version: getRuntimeVersion(),
      port: boundPort,
      transport,
      agent_spool_path: spoolPath,
      git_guard_enabled: gitGuardEnabled,
      bundle: bundleProvenance,
    })
    writeRuntimeEnvOperation(env, { useTcp, port: boundPort, sock, gitGuardEnabled })

    // 周期同步(默认 60s):上报上行 + 稳定上下文下行,不拉任务。
    // 注入 brainSyncPort(实接 uploadReports + downloadStableContext);
    // brain-config 缺失时端口内部降级(返回 0,不崩),合规「缺 config 不崩」。
    resources.syncLoop = (operations.startSyncLoop ?? startSyncLoop)(brainSyncPort, 60_000)

    // 启动持续保温(消除空闲后的冷尖峰):等 brain 配置就绪 → 立刻检索并低频重复,
    // 保持连接 + 服务端 embedding 温热。best-effort,失败静默。见 runtime/warmup.ts 时序说明
    // (工作台先起 daemon 再 set-token,故预热轮询等配置就绪而非启动即打)。
    resources.warmup = (operations.startWarmup ?? startWarmup)({ env })

    // 训练语料流(默认 30s):扫本地会话文件 → 上传到主脑 POST /brain/transcripts。
    // 注入 httpUploader(实接 brain):brain config 缺失时 uploader 内部降级返回 ok:false,
    // loop.ts 保守不推进游标(下轮重试),符合「缺配置不丢数据」语义。
    // 稳态 mtime-age gate 生效;user_id 无权威来源时本轮跳过。
    const cursors = loadCursorStore(join(cacheDir(env), "transcript-cursor.json"))
    resources.transcriptLoop = (operations.startTranscriptLoop ?? startTranscriptLoop)(
      {
        cursors,
        home: env["HOME"] ?? env["USERPROFILE"],
        codexHome: env["CODEX_HOME"],
        resolveUserId: () => resolveUserId({ env }),
        resolveMachineId: () => ensureMachineId({ env }),
        directorySync: createHttpDirectorySync(env),
        workerUploadEnv: env,
        syncQueue: reportState.syncQueue,
      },
      30_000,
    )
    operations.assertReady?.()

    const stop = async (): Promise<void> => {
      await cleanupRuntime(resources, env, useTcp, sock)
    }

    return { server, metrics, socket: sock, startedAt, stop }
  } catch (error) {
    await cleanupRuntime(resources, env, useTcp, sock)
    throw error
  }
}

async function cleanupRuntime(
  resources: RuntimeResources,
  env: NodeJS.ProcessEnv,
  useTcp: boolean,
  sock: string,
): Promise<void> {
  resources.transcriptLoop?.stop()
  resources.warmup?.stop()
  resources.syncLoop?.stop()
  resources.taskAttachmentMaintenance?.stop()
  await resources.agentFileBridge?.stop()
  if (resources.server?.listening) {
    await new Promise<void>((resolve) => resources.server!.close(() => resolve()))
  }

  const toClean = [pidfilePath(env), discoveryPath(env), runtimeEnvPath(env)]
  if (useTcp) toClean.push(loopbackTokenPath(env))
  for (const p of toClean) {
    try {
      if (existsSync(p)) unlinkSync(p)
    } catch {
      /* best-effort */
    }
  }
  if (!useTcp && process.platform !== "win32" && existsSync(sock)) {
    try {
      unlinkSync(sock)
    } catch {
      /* best-effort */
    }
  }
}

/**
 * 写 sh 薄壳友好的 runtime.env(纯 KEY=VALUE,可 `.` source)。
 * - TCP 模式:SYNAPSE_PORT + SYNAPSE_TOKEN_FILE(薄壳读 token 文件内容做 Bearer)。
 * - unix 模式:SYNAPSE_SOCK(薄壳走 --unix-socket)。
 * 薄壳「绝不用 Node」→ 读这个纯文本,不解析 JSON。
 */
interface RuntimeEnvInfo {
  useTcp: boolean
  port?: number
  sock: string
  gitGuardEnabled: boolean
}

function writeRuntimeEnv(
  env: NodeJS.ProcessEnv,
  info: RuntimeEnvInfo,
): void {
  const p = runtimeEnvPath(env)
  mkdirSync(dirname(p), { recursive: true })
  // 值加单引号:薄壳用 `. runtime.env` source,路径含空格/shell 元字符时不加引号会被拆词/执行。
  const lines = [`SYNAPSE_GIT_GUARD_ENABLED=${shellQuoteEnv(info.gitGuardEnabled ? "true" : "false")}`]
  if (info.useTcp && info.port) {
    lines.push(`SYNAPSE_PORT=${shellQuoteEnv(String(info.port))}`)
    lines.push(`SYNAPSE_TOKEN_FILE=${shellQuoteEnv(loopbackTokenPath(env))}`)
  } else {
    lines.push(`SYNAPSE_SOCK=${shellQuoteEnv(info.sock)}`)
  }
  writeFileSync(p, lines.join("\n") + "\n", { mode: 0o600 })
}

function shellQuoteEnv(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`
}

function writeDiscovery(env: NodeJS.ProcessEnv, info: DiscoveryInfo): void {
  const p = discoveryPath(env)
  mkdirSync(dirname(p), { recursive: true })
  mkdirSync(cacheDir(env), { recursive: true })
  writeFileSync(p, JSON.stringify(info, null, 2))
}

/** 读发现文件(薄壳/CLI/doctor 用)。 */
export function readDiscovery(env: NodeJS.ProcessEnv = process.env): DiscoveryInfo | null {
  const result = readDiscoveryDetailed(env)
  return result.state === "available" ? result.discovery : null
}

/** 区分发现文件不存在与内容损坏，供 CLI 输出准确诊断。 */
export function readDiscoveryDetailed(env: NodeJS.ProcessEnv = process.env): DiscoveryReadResult {
  const path = discoveryPath(env)
  try {
    const value = JSON.parse(readFileSync(path, "utf8")) as unknown
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return { state: "invalid", message: "discovery file must contain a JSON object" }
    }
    const discovery = value as Partial<DiscoveryInfo>
    if (!Number.isInteger(discovery.pid) || Number(discovery.pid) <= 0) {
      return { state: "invalid", message: "discovery file has an invalid pid" }
    }
    if (typeof discovery.started_at !== "string" || !discovery.started_at) {
      return { state: "invalid", message: "discovery file is missing started_at" }
    }
    if (typeof discovery.version !== "string" || !discovery.version) {
      return { state: "invalid", message: "discovery file is missing version" }
    }
    const transport = discovery.transport ?? "unix-socket"
    if (transport === "loopback-tcp") {
      if (!Number.isInteger(discovery.port) || Number(discovery.port) <= 0 || Number(discovery.port) > 65535) {
        return { state: "invalid", message: "loopback-tcp discovery file has an invalid port" }
      }
    } else if (typeof discovery.socket_path !== "string" || !discovery.socket_path) {
      return { state: "invalid", message: "socket discovery file is missing socket_path" }
    }
    return { state: "available", discovery: discovery as DiscoveryInfo }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return { state: "absent" }
    const message = error instanceof Error ? error.message : String(error)
    return { state: "invalid", message: `failed to read discovery file: ${message}` }
  }
}
