/** Transport-only metadata for a turn-scoped typed capability execution. */
export const SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER = "x-synapse-turn-token" as const

/** @deprecated Use SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER. */
export const SYNAPSE_TASK_TURN_TOKEN_HEADER = SYNAPSE_CAPABILITY_TURN_TOKEN_HEADER
