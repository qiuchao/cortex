import {
  extractWorkItemPublicIds,
  hasWorkItemWriteAuthorizationIntentText,
  hasWorkItemWriteIntentText,
  isWorkItemIntentText,
} from "@cerebro/wire"

export interface TaskCapabilityIntent {
  requested: boolean
  /** Public IDs explicitly present in this turn, in first-seen order. */
  publicIds: string[]
  /** Convenience only for the common single-ID case. */
  publicId?: string
  /** Informational only. Cross-product reads are valid and must not fail closed. */
  multipleProducts: boolean
}

export interface WorkItemWriteTargetResolution {
  targets: string[]
  explicit: boolean
}

export interface TaskProductionCandidate {
  id: string
  name: string
  workItemKey?: string | null
}

export interface TaskProductionSelection {
  product?: TaskProductionCandidate
  explicit: boolean
  ambiguous: boolean
}

export interface TaskProductionScope {
  productionId?: string
  conflict: boolean
}

/**
 * Task capabilities are discovered only for task turns. Public IDs are the
 * strongest signal and also let Cerebro resolve the authoritative product.
 */
export function detectTaskCapabilityIntent(text: string): TaskCapabilityIntent {
  const value = text ?? ""
  const requested = isWorkItemIntentText(value)
  const ids = requested ? extractWorkItemPublicIds(value) : []
  const keys = new Set(ids.map((item) => item.workItemKey))
  if (ids.length > 0) {
    const publicIds = ids.map((item) => item.publicId)
    return {
      requested: true,
      publicIds,
      ...(publicIds.length === 1 ? { publicId: publicIds[0] } : {}),
      multipleProducts: keys.size > 1,
    }
  }
  return {
    requested,
    publicIds: [],
    multipleProducts: false,
  }
}

/**
 * Resolve only deterministic write targeting signals from the current turn.
 * A single ID is unambiguous. With multiple IDs, exactly one ID must be scoped
 * to the write verb; bulk writes must be split into separately confirmable operations.
 */
export function resolveExplicitWorkItemWriteTargets(
  text: string,
  publicIds = extractWorkItemPublicIds(text).map((item) => item.publicId),
): WorkItemWriteTargetResolution {
  const ids = [...new Set(publicIds.map((value) => value.toUpperCase()))]
  if (ids.length === 0) return { targets: [], explicit: false }
  if (ids.length === 1) return { targets: ids, explicit: true }

  const relationshipTarget = resolveRelationshipWriteTarget(text, ids)
  if (relationshipTarget) return { targets: [relationshipTarget], explicit: true }

  const labeledTargets = extractLabeledWriteTargets(text).filter((publicId) => ids.includes(publicId))
  if (labeledTargets.length === 1) {
    const [labeledTarget] = labeledTargets
    const conflictingTargets = new Set<string>()
    for (const clause of splitClauses(text)) {
      const intent = stripLabeledWriteTarget(clause)
      if (!hasWorkItemWriteIntentText(intent)) continue
      for (const item of extractWorkItemPublicIds(intent)) {
        if (item.publicId === labeledTarget || isRelationshipOperand(intent, item.publicId)) continue
        conflictingTargets.add(item.publicId)
      }
    }
    return conflictingTargets.size === 0
      ? { targets: labeledTargets, explicit: true }
      : { targets: [], explicit: false }
  }

  const scoped = new Set<string>()
  for (const clause of splitClauses(text)) {
    if (!hasWorkItemWriteIntentText(clause)) continue
    for (const item of extractWorkItemPublicIds(clause)) scoped.add(item.publicId)
  }
  return scoped.size === 1
    ? { targets: [...scoped], explicit: true }
    : { targets: [], explicit: false }
}

function resolveRelationshipWriteTarget(text: string, publicIds: readonly string[]): string | undefined {
  const bugIds = publicIds.filter((publicId) => /-B\d{4,}$/i.test(publicId))
  const requirementIds = publicIds.filter((publicId) => /-R\d{4,}$/i.test(publicId))
  if (bugIds.length !== 1 || requirementIds.length < 1) return undefined
  const bug = escapeRegExp(bugIds[0]!)
  const requirements = requirementIds.map(escapeRegExp).join("|")
  const directed = new RegExp(
    `(?:把\\s*(?:${requirements}).{0,24}(?:设为|设置为|作为|改为).{0,16}(?:${bug}).{0,12}(?:主要需求|主关联)|(?:${bug}).{0,24}(?:不再关联|解除关联|取消关联).{0,16}(?:${requirements})|把\\s*(?:${requirements}).{0,24}(?:重新关联|关联)(?:到|至|给)\\s*(?:${bug}))`,
    "i",
  )
  return directed.test(text) ? bugIds[0] : undefined
}

function extractLabeledWriteTargets(text: string): string[] {
  const targets = new Set<string>()
  const label = /(?:写入|修改|操作)(?:的)?目标(?:单|工作项)?\s*(?:为|是|[:：])\s*([A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,})/gi
  for (const match of text.matchAll(label)) targets.add(match[1]!.toUpperCase())
  return [...targets]
}

function stripLabeledWriteTarget(text: string): string {
  return text.replace(/(?:写入|修改|操作)(?:的)?目标(?:单|工作项)?\s*(?:为|是|[:：])\s*[A-Za-z][A-Za-z0-9]{0,15}-(?:R|B)\d{4,}/gi, "")
}

function isRelationshipOperand(text: string, publicId: string): boolean {
  const id = escapeRegExp(publicId)
  return new RegExp(`(?:关联需求\\s*${id}(?:.{0,24}(?:设为|设置为|作为|改为).{0,12}(?:主关联|次关联)|.{0,24}(?:主关联|次关联))|(?:解除|取消).{0,12}(?:与\\s*)?需求\\s*${id}.{0,12}关联|(?:重新|新增|建立)\\s*关联需求\\s*${id})`, "i").test(text)
}

export function hasWorkItemWriteIntent(text: string): boolean {
  return hasWorkItemWriteIntentText(text)
}

/**
 * A trusted draft identity is issued only when this turn asks to perform work.
 * Read-only discussion and explicit deferrals remain useful context-loading
 * turns, but must not authorize a later model-generated mutation.
 */
export function hasWorkItemWriteAuthorizationIntent(text: string): boolean {
  return hasWorkItemWriteAuthorizationIntentText(text)
}

/** Select only from the authenticated user's visible products. */
export function selectTaskProductionFromText(
  text: string,
  products: readonly TaskProductionCandidate[],
): TaskProductionSelection {
  const normalized = text.trim()
  const matches = products.filter((product) => matchesProductReference(normalized, product))
  if (matches.length > 0) {
    return { ...(matches.length === 1 ? { product: matches[0] } : {}), explicit: true, ambiguous: matches.length > 1 }
  }
  const explicit = hasUnknownExplicitProductReference(normalized)
  return {
    ...(!explicit && products.length === 1 ? { product: products[0] } : {}),
    explicit,
    ambiguous: false,
  }
}

export function resolveTaskProductionScope(
  workspaceProductionId: string | undefined,
  selection: TaskProductionSelection,
): TaskProductionScope {
  const conflict = Boolean(selection.explicit && selection.product && workspaceProductionId && selection.product.id !== workspaceProductionId)
  if (conflict || selection.ambiguous || (selection.explicit && !selection.product)) return { conflict }
  return {
    productionId: selection.explicit ? selection.product?.id : workspaceProductionId ?? selection.product?.id,
    conflict: false,
  }
}

function matchesProductReference(text: string, product: TaskProductionCandidate): boolean {
  if (containsBounded(text, product.id)) return true
  if (/[^\x00-\x7f]/.test(product.name) ? text.includes(product.name) : containsLabeledProduct(text, product.name)) return true
  const key = product.workItemKey?.trim()
  if (!key) return false
  return containsLabeledProduct(text, key)
}

function containsLabeledProduct(text: string, value: string): boolean {
  const escaped = escapeRegExp(value.trim())
  return Boolean(escaped) && new RegExp(`(?:产品(?:编码)?|product(?:\\s+code)?)\\s*[：:]?\\s*${escaped}(?![A-Za-z0-9_-])|(?<![A-Za-z0-9_-])${escaped}\\s*(?:产品|product)`, "i").test(text)
}

function containsBounded(text: string, value: string): boolean {
  const normalized = value.trim()
  if (!normalized) return false
  if (/[^\x00-\x7f]/.test(normalized)) return text.includes(normalized)
  return new RegExp(`(?<![A-Za-z0-9_-])${escapeRegExp(normalized)}(?![A-Za-z0-9_-])`, "i").test(text)
}

function hasUnknownExplicitProductReference(text: string): boolean {
  return /(?:产品(?:线|编码)?|product(?:\s+code)?)\s*[：:]\s*(?!(?:当前|这个|该)\b)\S+/i.test(text)
    || /(?:在|切换到)\s*(?!(?:当前|这个|该)产品)\S{1,64}\s*产品/i.test(text)
}

function splitClauses(text: string): string[] {
  return text.split(/[。！？!?;；\n]+|(?<=[,，])\s*(?=(?:然后|再|同时|并且|但|参考|对照|根据|using|while|then)\b)/i)
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}
