/**
 * transcript/parsers/copilot.ts —— VS Code Copilot 会话文件解析。
 *
 * 文件格式(workspaceStorage/{hash}/chatSessions/{sessionId}.jsonl):
 *   - 第一行 kind:0 是完整快照,其 v.requests[] 持有整段对话;
 *   - kind:1 / kind:2 是增量 patch(应用在快照上的变更)。
 *
 * 读取策略(torn-read 安全,与 opencode 相同):
 *   整文件 mtime+size 游标 —— 文件内容变了才重新读。
 *   parse 失败 = torn write → 跳过 + 下 tick 重试,不推进游标。
 *
 * 映射规则(返回 TranscriptRecord 兼容的 messages 数组,raw 层):
 *   每个 request 条目对应一轮对话(user + assistant)。
 *   原始数据保持完整放进 messages[],归一化由主脑负责。
 */

/** Copilot kind:0 快照的顶层结构 */
export interface CopilotSnapshot {
  v: {
    sessionId?: string
    customTitle?: string
    requests?: CopilotRequest[]
  }
}

/** 单条 request(一问一答) */
export interface CopilotRequest {
  requestId?: string
  modelId?: string
  timestamp?: number
  message?: {
    text?: string
    parts?: unknown[]
  }
  response?: Array<{
    value?: string
    markdown?: string
    [key: string]: unknown
  }>
  completionTokens?: number
  [key: string]: unknown
}

export interface CopilotParseResult {
  ok: boolean
  /** Copilot 会话 id(fallback 到文件名) */
  sessionId: string
  title?: string
  requests: CopilotRequest[]
  /** parse 失败时为 true,调用方应下 tick 重试 */
  retry: boolean
}

/**
 * 解析一个 Copilot .jsonl 文件的完整内容(整文件读取)。
 * 只读第一行 kind:0 快照;kind:1/kind:2 patch 在增量场景需要才应用,
 * 当前实现取快照即可(主脑 4-tuple 幂等键保证重传去重)。
 *
 * ⚠️ 关键假设（尚未真机验证，open question from reviewer-synapse）：
 *   VS Code Copilot 在每次对话轮次结束后**重写整个 kind:0 快照**（v.requests[] 累积全部轮次），
 *   而不是只追加 kind:1/2 patch。若此假设成立：
 *     - 文件 mtime+size 每轮都变 → 触发重读 → 快照含最新全量对话 → 正常采集。
 *   若假设**不成立**（VS Code 只追加 patch，不重写快照）：
 *     - mtime+size 变 → 重读 → 但 kind:0 仍是旧快照 → 新轮次被漏采。
 *     - 修复路径：实现 kind:1/2 patch replay，把 patch 应用到 kind:0 上得到最新全量对话。
 *   当前证据：真机 chatSessions/*.jsonl 样本未能获取（WSL 无法访问宿主 Windows 的 Code 数据目录），
 *   无法确认写入节奏。测试 fixture 是手工构造，不代表真实写入行为。
 *   **风险**：若 VS Code 只追加 patch，此版本会漏采 Copilot 会话中后期的轮次，但不会出现数据损坏
 *   或错误上传（快照中已有的对话仍正常上传，主脑幂等键去重）。
 *   **下一步**：在 Windows/Mac 真机取样一个 chatSessions/*.jsonl 文件，确认 kind:0 是否随每轮更新；
 *   若仅追加 patch，补实现 patch replay（工作量约 1-2h）。
 *
 * @param content 文件完整内容(utf8 字符串)
 * @param fallbackSessionId 文件名(不含扩展名)作为 sessionId 兜底
 */
export function parseCopilotFile(
  content: string,
  fallbackSessionId: string,
): CopilotParseResult {
  const trimmed = content.trim()
  if (!trimmed) return { ok: false, sessionId: fallbackSessionId, requests: [], retry: true }

  // 取第一行
  const firstLine = trimmed.split('\n')[0]?.trim()
  if (!firstLine) return { ok: false, sessionId: fallbackSessionId, requests: [], retry: true }

  let parsed: unknown
  try {
    parsed = JSON.parse(firstLine)
  } catch {
    // JSON 解析失败 = 可能正在写(torn write)→ 跳过
    return { ok: false, sessionId: fallbackSessionId, requests: [], retry: true }
  }

  // 验证 kind:0 快照结构
  if (
    typeof parsed !== 'object' ||
    parsed === null ||
    (parsed as Record<string, unknown>)['kind'] !== 0
  ) {
    // 第一行不是 kind:0 快照 → 格式不符,跳过(不重试)
    return { ok: false, sessionId: fallbackSessionId, requests: [], retry: false }
  }

  const snap = parsed as { v?: CopilotSnapshot['v']; kind: number }
  const v = snap.v ?? {}
  const sessionId = (typeof v.sessionId === 'string' && v.sessionId) || fallbackSessionId
  const title = typeof v.customTitle === 'string' && v.customTitle ? v.customTitle : undefined
  const requests = Array.isArray(v.requests) ? (v.requests as CopilotRequest[]) : []

  return { ok: true, sessionId, title, requests, retry: false }
}
