/** Stable, client-neutral presentation of a Cerebro turn result. */
import { isQueryResultMissing, QUERY_RESULT_MISSING_NOTICE } from "./operation-query-result.ts"
import type {
  OperationErrorResponse,
  OperationStatusResponse,
  OperationTurnResponse,
} from "../runtime/operation-turn-bridge.ts"
import {
  UnifiedOperationResultProjectionSchema,
  UNIFIED_OPERATION_RESULT_MAX_CHARS,
  renderQueryFacts,
  type UnifiedOperationResultProjection,
} from "@cerebro/wire"

/**
 * Keep the result payload bounded for hook clients.  Projection items are
 * added one at a time below this limit so a JSON object is never cut in the
 * middle.  The projection metadata is always retained, even when no item
 * fits in the remaining budget.
 */
export const OPERATION_RESULT_MAX_CHARS = UNIFIED_OPERATION_RESULT_MAX_CHARS

export type OperationCerebroResult = OperationTurnResponse | OperationStatusResponse | OperationErrorResponse | string

export interface OperationResultBlocksInput {
  cerebro?: OperationCerebroResult
  codex?: string
}

/** Format both result channels for a single conversation turn. */
export function formatOperationResultBlocks(input: OperationResultBlocksInput): string {
  const blocks: string[] = []
  if (input.cerebro !== undefined) blocks.push(formatCerebroBlock(input.cerebro))
  if (input.codex?.trim()) blocks.push(formatCodexBlock(input.codex))
  return blocks.join("\n\n")
}

export function formatCerebroBlock(response: OperationCerebroResult): string {
  const text = typeof response === "string" ? response.trim() : renderResponse(response)
  return `[Cerebro]\n${text || "主脑没有返回结果。"}`
}

export function formatCodexBlock(text: string): string {
  return `[Codex]\n${text.trim()}`
}

function renderResponse(response: Exclude<OperationCerebroResult, string>): string {
  if (isOperationErrorResponse(response)) return renderTransportError(response)
  if (isOperationStatusResponse(response)) return renderStatusResponse(response)
  return renderTurnResponse(response)
}

function renderTurnResponse(response: OperationTurnResponse): string {
  const meta = renderTurnMetadata(response)
  if (response.decision === "ordinary") {
    return joinLines("无需主脑操作。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "clarify") {
    return joinLines(response.clarification?.question?.trim() || "主脑需要补充信息。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "unsupported") {
    return joinLines(response.unsupported?.message?.trim() || "该主脑操作暂不支持。", renderOrdinaryProjection(response), meta)
  }
  if (response.decision === "unavailable") {
    return joinLines(
      response.unavailable?.message?.trim() || "Cerebro 暂时不可用。",
      renderUnavailableDetails(response.unavailable),
      renderOrdinaryProjection(response),
      meta,
    )
  }

  const operations = (response.operations ?? []).map(renderOperation).filter(Boolean)
  return joinLines(...operations, renderOrdinaryProjection(response), meta) || "主脑操作没有返回结果。"
}

function renderStatusResponse(response: OperationStatusResponse): string {
  return joinLines(
    `状态查询：${renderOperation(response.operation) || "主脑操作状态未知。"}`,
    renderStatusMetadata(response),
  )
}

function renderTransportError(response: OperationErrorResponse): string {
  const code = response.code?.trim()
  const message = response.message?.trim() || "主脑请求失败。"
  return joinLines(
    `请求失败${code ? `（${code}）` : ""}：${message}`,
    renderRetryDetails(response),
    response.operationId ? `operationId=${response.operationId}` : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
  )
}

function renderOperation(operation: Record<string, unknown>): string {
  const operationId = typeof operation.operationId === "string" ? operation.operationId : ""
  const targetId = typeof operation.targetId === "string" ? operation.targetId : ""
  const resource = typeof operation.resource === "string" ? operation.resource : "operation"
  const action = typeof operation.action === "string" ? operation.action : ""
  const label = [resource, action].filter(Boolean).join(".") || "operation"
  const suffixItems = [
    operationId ? `operationId=${operationId}` : "",
    targetId ? `targetId=${targetId}` : "",
  ].filter(Boolean)
  const suffix = suffixItems.length ? `（${suffixItems.join("，")}）` : ""
  const status = operation.status
  if (status === "executed") {
    if (isQueryResultMissing(operation)) {
      return joinLines(operationId ? `operationId=${operationId}` : "", QUERY_RESULT_MISSING_NOTICE)
    }
    // A result projection is Cerebro's complete, trusted presentation
    // contract.  Never append the raw result as well: it may contain a
    // duplicate query payload or an independently truncated JSON value.
    if (Object.prototype.hasOwnProperty.call(operation, "resultProjection")) {
      const projection = parseResultProjection(operation.resultProjection)
      if (projection?.range) return joinLines(operationId ? `operationId=${operationId}` : "", renderResultProjection(projection))
      return `${label} 已完成${suffix}${projection ? `：${renderResultProjection(projection)}` : "：查询结果投影无效，未展示原始结果。"}`
    }
    const production = inspectProductionFact(operation)
    const result = production.invalid ? withoutProductionFact(operation.result) : operation.result
    const productionText = production.fact ? renderProductionFact(production.fact) : ""
    return `${label} 已完成${suffix}${productionText}${renderValue(result)}`
  }
  if (status === "in_progress") {
    return `${label} 执行中${suffix}${stringValue(operation.progressMessage)}${renderProgressDetails(operation)}`
  }
  if (status === "clarify") return `${label} 需要澄清${suffix}：${stringValue(operation.clarification) || "请补充信息。"}`
  if (status === "unsupported") return `${label} 暂不支持${suffix}：${stringValue(operation.reason) || "该操作暂不支持。"}`
  if (status === "failed") {
    const error = isRecord(operation.error) ? operation.error : undefined
    const code = error ? stringValue(error.code) : ""
    const message = error ? stringValue(error.message) : ""
    const retryable = error && typeof error.retryable === "boolean" ? `；retryable=${String(error.retryable)}` : ""
    return `${label} 执行失败${suffix}${code ? `（${code}）` : ""}：${message || "主脑操作失败。"}${retryable}`
  }
  return `${label} 返回未知状态${suffix}。`
}

interface ProductionFact {
  productionId: string
  productionName?: string
}

interface ProductionFactInspection {
  fact?: ProductionFact
  invalid: boolean
}

/**
 * Consume Cerebro's trusted result.production without treating arbitrary
 * result text as a product identity.  Existing associated production IDs are
 * used only as a consistency check; the client never resolves or guesses a
 * product from cwd, brand text, or an ID prefix.
 */
function inspectProductionFact(operation: Record<string, unknown>): ProductionFactInspection {
  if (!Object.prototype.hasOwnProperty.call(operation, "result")) return { invalid: false }
  const result = operation.result
  if (!isRecord(result) || !Object.prototype.hasOwnProperty.call(result, "production")) return { invalid: false }
  const production = result.production
  if (!isRecord(production)) return { invalid: true }
  const productionId = stringValue(production.productionId)
  if (!productionId) return { invalid: true }
  const rawName = production.productionName
  if (rawName !== undefined && rawName !== null && typeof rawName !== "string") return { invalid: true }
  const productionName = stringValue(rawName)
  const associatedIds = new Set<string>()
  for (const value of [operation.productionId, isRecord(operation.input) ? operation.input.productionId : undefined, isRecord(operation.productionContext) ? operation.productionContext.productionId : undefined]) {
    const id = stringValue(value)
    if (id) associatedIds.add(id)
  }
  collectResultProductionIds(result, associatedIds)
  if ([...associatedIds].some((id) => id !== productionId)) return { invalid: true }
  return {
    fact: { productionId, ...(productionName ? { productionName } : {}) },
    invalid: false,
  }
}

function collectResultProductionIds(value: unknown, ids: Set<string>, seen = new WeakSet<object>()): void {
  if (Array.isArray(value)) {
    if (seen.has(value)) return
    seen.add(value)
    for (const entry of value) collectResultProductionIds(entry, ids, seen)
    return
  }
  if (!isRecord(value)) return
  if (seen.has(value)) return
  seen.add(value)
  const directId = stringValue(value.productionId)
  if (directId) ids.add(directId)
  for (const [key, nested] of Object.entries(value)) {
    if (key === "production") continue
    collectResultProductionIds(nested, ids, seen)
  }
}

function renderProductionFact(fact: ProductionFact): string {
  return `\n已执行产品：${fact.productionName ? fact.productionName : "无法确认产品名称"}（productionId=${fact.productionId}）`
}

function withoutProductionFact(value: unknown): unknown {
  if (!isRecord(value) || !Object.prototype.hasOwnProperty.call(value, "production")) return value
  const { production: _discarded, ...rest } = value
  return rest
}

function renderOrdinaryProjection(response: OperationTurnResponse): string {
  const ordinary = response.ordinary
  if (!ordinary) return ""
  if (ordinary.dependency === "none") return ""
  if (ordinary.dependency === "operation_result") {
    if (response.operations?.some(isQueryResultMissing)) return "普通任务缺少依赖的可信查询结果，不能基于本次回执继续分析。"
    const dependsOn = ordinary.dependsOn?.length ? `（dependsOn=${ordinary.dependsOn.join(",")}）` : ""
    return `普通任务可基于以上主脑结果继续${dependsOn}。`
  }
  if (ordinary.dependency === "blocked") {
    const reason = ordinary.blockedReason?.message?.trim() || "依赖的主脑操作未完成，普通任务不能继续。"
    const code = ordinary.blockedReason?.code?.trim()
    const retryable = typeof ordinary.blockedReason?.retryable === "boolean"
      ? `；retryable=${String(ordinary.blockedReason.retryable)}`
      : ""
    return `普通任务已阻断${code ? `（${code}）` : ""}：${reason}${retryable}`
  }
  return ""
}

function renderTurnMetadata(response: OperationTurnResponse): string {
  const admission = isRecord(response.admission) ? response.admission : undefined
  return joinLines(
    response.replayed === true ? "幂等重放：是" : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
    admission ? renderAdmission(admission) : "",
  )
}

function renderStatusMetadata(response: OperationStatusResponse): string {
  return joinLines(
    response.replayed === true ? "幂等重放：是" : "",
    response.idempotencyKey ? `idempotencyKey=${response.idempotencyKey}` : "",
  )
}

function renderAdmission(admission: Record<string, unknown>): string {
  const source = stringValue(admission.source)
  const elapsed = typeof admission.elapsedMs === "number" ? `elapsedMs=${admission.elapsedMs}` : ""
  const budget = typeof admission.budgetMs === "number" ? `budgetMs=${admission.budgetMs}` : ""
  return ["admission", source, elapsed, budget].filter(Boolean).join(" ")
}

function renderUnavailableDetails(value: unknown): string {
  if (!isRecord(value)) return ""
  return joinParts(
    stringValue(value.reason) ? `reason=${stringValue(value.reason)}` : "",
    typeof value.retryable === "boolean" ? `retryable=${String(value.retryable)}` : "",
  )
}

function renderRetryDetails(value: OperationErrorResponse): string {
  return joinParts(
    typeof value.retryable === "boolean" ? `retryable=${String(value.retryable)}` : "",
    typeof value.retryAfterMs === "number" ? `retryAfterMs=${value.retryAfterMs}` : "",
  )
}

function renderProgressDetails(operation: Record<string, unknown>): string {
  return joinInline(
    stringValue(operation.acceptedAt) ? `acceptedAt=${stringValue(operation.acceptedAt)}` : "",
    typeof operation.queryAfterMs === "number" ? `queryAfterMs=${operation.queryAfterMs}` : "",
  )
}

function renderValue(value: unknown): string {
  if (value === undefined) return ""
  try {
    const encoded = typeof value === "string" ? value.trim() : JSON.stringify(value, null, 2)
    if (!encoded) return ""
    const bounded = encoded.length > OPERATION_RESULT_MAX_CHARS ? "结果过长，已完整省略 result；请通过 operation status 读取原始结果。" : encoded
    return `：${bounded}`
  } catch {
    return ""
  }
}

function parseResultProjection(value: unknown): UnifiedOperationResultProjection | undefined {
  const parsed = UnifiedOperationResultProjectionSchema.safeParse(value)
  return parsed.success ? parsed.data : undefined
}

/**
 * Render only the fields Cerebro explicitly projected for a query page.
 * Metadata is emitted before entries and is never dropped when the item body
 * exceeds the hook budget.  Entries are serialized independently, allowing us
 * to stop between complete JSON objects and report exactly what was omitted
 * by this formatter.
 */
function renderResultProjection(projection: UnifiedOperationResultProjection): string {
  // Cerebro bounds the combined structured receipt and human presentation.
  // Preserve every field (including the opaque cursor) without a client trim.
  // Only the human fact/table lines need to be copied into the final answer.
  if (projection.range) return `resultProjection=${JSON.stringify(projection)}\n${renderQueryFacts(projection)}`
  // Schema already bounds this exact serialization. At the envelope limit,
  // prefer the whole canonical payload to adding metadata that exceeds it.
  if (renderProjectionBody(projection, []).length > OPERATION_RESULT_MAX_CHARS) return JSON.stringify(projection)
  const itemLines: string[] = []
  for (const item of projection.page.items) {
    const line = JSON.stringify(item)
    const candidate = renderProjectionBody(projection, [...itemLines, line])
    if (candidate.length > OPERATION_RESULT_MAX_CHARS) break
    itemLines.push(line)
  }
  return renderProjectionBody(projection, itemLines)
}

function renderProjectionBody(
  projection: UnifiedOperationResultProjection,
  itemLines: readonly string[],
): string {
  const { scope, page, facts } = projection
  const omittedCount = page.items.length - itemLines.length
  const outputComplete = page.complete && omittedCount === 0
  const outputOmitted = page.omitted || omittedCount > 0
  const metadata = [
    `resultProjection kind=${projection.kind} resource=${projection.resource}`,
    `scope=${JSON.stringify(scope)}`,
    `page returned=${page.returned} total=${page.total ?? "unavailable"} nextCursor=${page.nextCursor === undefined ? "unavailable" : JSON.stringify(page.nextCursor)} hasMore=${String(page.hasMore)} complete=${String(outputComplete)} omitted=${String(outputOmitted)}`,
    `fetched=${page.fetched ?? "unavailable"} displayed=${itemLines.length} outputOmittedItems=${omittedCount} sourceComplete=${String(page.complete)} sourceOmitted=${String(page.omitted)}`,
    facts ? `facts=${JSON.stringify(facts)}` : "",
    "统计仅适用于 Cerebro 指明的当前读取范围，不代表全量；不得把开放式主题查询解释为精确排名。",
    "items:",
  ].filter(Boolean).join("\n")
  const body = [metadata, ...itemLines].join("\n")
  if (!outputOmitted) return body
  const marker = omittedCount > 0
    ? `…（输出长度受限，已省略 ${omittedCount} 个完整条目；本次展示不完整。请通过 operation status 读取原始结果；nextCursor 仅用于下一页，不能恢复本页省略项。）`
    : "…（Cerebro 已省略部分条目；本次展示不完整。）"
  return `${body}\n${marker}`
}

function stringValue(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
}

function isOperationStatusResponse(value: Record<string, unknown>): value is OperationStatusResponse {
  return isRecord(value.operation) && !("decision" in value)
}

function isOperationErrorResponse(value: Record<string, unknown>): value is OperationErrorResponse {
  return value.status === "error"
}

function joinLines(...values: string[]): string {
  return values.map((value) => value.trim()).filter(Boolean).join("\n")
}

function joinInline(...values: string[]): string {
  const text = values.map((value) => value.trim()).filter(Boolean).join("；")
  return text ? `；${text}` : ""
}

function joinParts(...values: string[]): string {
  return values.map((value) => value.trim()).filter(Boolean).join("；")
}
