import { extractCommand } from "./guard.ts"
import { quoteAgentCommandArg } from "./agent-command-line.ts"

export interface HookTool {
  name: string
  kind: "shell" | "file-write" | "local-read" | "unknown"
  command?: string
  error?: string
  powershell?: boolean
}

// Names come from client hook metadata, never from tool arguments. Existing
// adapters forward tool_name/tool_input (OpenCode maps tool/args).
const SHELL_TOOLS = new Set(["bash", "exec_command", "shell_command", "run_shell_command", "shell"])
const FILE_TOOLS = new Set(["apply_patch", "patch", "edit", "write", "multiedit", "notebookedit", "write_file", "replace"])
const READ_TOOLS = new Set(["read", "glob", "grep", "view_image", "list_directory", "read_file", "grep_search"])

function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown> : undefined
}

export function readHookTool(raw: unknown): HookTool {
  const envelope = record(raw)
  const name = typeof envelope?.["tool_name"] === "string" ? envelope["tool_name"]
    : typeof envelope?.["toolName"] === "string" ? envelope["toolName"] : ""
  const normalized = name.toLowerCase()
  const kind = SHELL_TOOLS.has(normalized) ? "shell"
    : FILE_TOOLS.has(normalized) ? "file-write"
    : READ_TOOLS.has(normalized) ? "local-read" : "unknown"
  const tool: HookTool = { name, kind }
  if (kind !== "shell" || !envelope) return tool

  // Native input has priority. Neither a decorative top-level command nor a
  // nested tool_name can override the actual client tool invocation.
  const input = record(envelope["tool_input"]) ?? record(envelope["input"]) ?? envelope
  if (typeof input["shell"] === "string") {
    tool.powershell = /(?:^|[\\/])(?:powershell|pwsh)(?:\.exe)?$/i.test(input["shell"])
  }
  const values = [input["command"], input["cmd"]].filter((value) => value !== undefined)
  if (values.length !== 1) return { ...tool, error: "Shell tool has missing or ambiguous command fields." }
  const value = values[0]
  if (typeof value === "string") {
    return { ...tool, command: extractCommand({ tool_input: { command: value } }) }
  }
  if (Array.isArray(value) && value.length > 0 && value.every((part) => typeof part === "string")) {
    // Keep literal argv boundaries instead of manufacturing shell syntax.
    return { ...tool, powershell: false, command: value.map((part) => quoteAgentCommandArg(part, "default", "linux")).join(" ") }
  }
  return { ...tool, error: "Shell tool command must be a string or a string argv array." }
}
