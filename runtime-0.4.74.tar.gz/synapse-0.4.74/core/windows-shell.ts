import { existsSync } from "node:fs"
import { homedir } from "node:os"
import { join } from "node:path"
import type { ClientId } from "../transport/contract.ts"

export type AgentCommandShell = "powershell" | "posix"

export interface WindowsGitBashDetectionOptions {
  platform?: NodeJS.Platform
  homeDir?: string
  env?: NodeJS.ProcessEnv
  pathExists?: (path: string) => boolean
}

export function detectWindowsGitBash(options: WindowsGitBashDetectionOptions = {}): boolean {
  if ((options.platform ?? process.platform) !== "win32") return false
  const env = options.env ?? process.env
  const home = options.homeDir ?? homedir()
  const pathExists = options.pathExists ?? existsSync
  const configuredPath = env["CLAUDE_CODE_GIT_BASH_PATH"]?.trim()
  // Claude Code treats its explicit Git Bash path as authoritative. Matching
  // that behavior also prevents Synapse from selecting a different shell.
  if (configuredPath) return pathExists(configuredPath)
  const candidates = [
    "C:\\Program Files\\Git\\bin\\bash.exe",
    "C:\\Program Files (x86)\\Git\\bin\\bash.exe",
    join(home, "AppData", "Local", "Programs", "Git", "bin", "bash.exe"),
    join(home, "scoop", "apps", "git", "current", "bin", "bash.exe"),
  ].filter((path): path is string => Boolean(path))
  return candidates.some(pathExists)
}

export function resolveAgentCommandShell(
  client: ClientId,
  platform: NodeJS.Platform = process.platform,
  gitBashPresent = detectWindowsGitBash({ platform }),
): AgentCommandShell {
  if (platform !== "win32") return "posix"
  if (client === "kimi-code") return "posix"
  if (client === "claude-code" && gitBashPresent) return "posix"
  return "powershell"
}
