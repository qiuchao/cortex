import type { AgentAttachmentIntake } from "../core/agent-attachments.ts"
import type {
  TaskTurnExecutionAuthorization,
  TaskTurnGuardRegistry,
} from "../core/task-turn-guard.ts"

export type CapabilityRouteExecutionAuthorization =
  | { ok: true; authorization: TaskTurnExecutionAuthorization }
  | { ok: false; status: number; reason: string; message: string }

/** Resolve turn-bound attachments inside the same typed Task execution call. */
export async function authorizeCapabilityRouteExecution(
  taskTurnGuards: TaskTurnGuardRegistry | undefined,
  agentAttachmentIntake: AgentAttachmentIntake | undefined,
  routeToken: string | undefined,
  body: unknown,
): Promise<CapabilityRouteExecutionAuthorization> {
  let authorization = taskTurnGuards?.authorizeExecution(routeToken, body)
    ?? { tracked: false, allowed: true }
  if (!authorization.allowed) {
    return {
      ok: false,
      status: 403,
      reason: "turn_scope_denied",
      message: authorization.reason ?? "Capability turn is not authorized",
    }
  }
  const preparation = authorization.attachmentPreparation
  if (!preparation) return { ok: true, authorization }
  if (!agentAttachmentIntake || !taskTurnGuards) {
    return {
      ok: false,
      status: 409,
      reason: "attachment_resolution_failed",
      message: "current-turn attachment preparation is unavailable",
    }
  }

  const prepared = await agentAttachmentIntake.prepare({ handle: preparation.handle })
  if (!prepared.ok) {
    return {
      ok: false,
      status: prepared.httpStatus,
      reason: prepared.reason,
      message: prepared.message,
    }
  }
  if (!taskTurnGuards.markAttachmentsPrepared(preparation.handle, prepared.attachmentTokens)) {
    return {
      ok: false,
      status: 409,
      reason: "attachment_resolution_failed",
      message: "attachment handle is no longer bound to the active Task turn; retry the request",
    }
  }
  authorization = taskTurnGuards.authorizeExecution(routeToken, body)
  if (!authorization.allowed || authorization.attachmentPreparation) {
    return {
      ok: false,
      status: authorization.allowed ? 409 : 403,
      reason: authorization.allowed ? "attachment_resolution_failed" : "turn_scope_denied",
      message: authorization.reason ?? "current-turn attachment preparation did not complete",
    }
  }
  return { ok: true, authorization }
}

export function isCapabilityRouteTerminalResponse(response: unknown): boolean {
  if (!response || typeof response !== "object" || Array.isArray(response)) return false
  const value = response as Record<string, unknown>
  if (typeof value.status === "string") {
    return ["executed", "denied", "deferred", "failed"].includes(value.status)
  }
  return value.kind === "result" || value.kind === "draft"
}

/** @deprecated Use authorizeCapabilityRouteExecution. */
export const authorizeTaskRouteExecution = authorizeCapabilityRouteExecution
/** @deprecated Use CapabilityRouteExecutionAuthorization. */
export type TaskRouteExecutionAuthorization = CapabilityRouteExecutionAuthorization
