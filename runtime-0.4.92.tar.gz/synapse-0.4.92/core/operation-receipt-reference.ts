/** Durable native transcript identity, separate from human receipt prose. */
import { OperationTurnResponseSchema } from "@cerebro/wire"

export const OPERATION_RECEIPT_REFERENCE_PREFIX = "cerebroOperationReceipt="
const MAX_REFERENCE_CHARS = 16_000

export function renderOperationReceiptReference(response: unknown): string | undefined {
  const parsed = OperationTurnResponseSchema.safeParse(response)
  if (!parsed.success) return undefined
  const value = parsed.data
  // Results already have their own bounded presentation. Keep only the
  // contract-validated receipt identity/status here, never duplicate payloads.
  const reference = {
    ...value,
    operations: value.operations.map(operation => {
      const { result, resultProjection, input, queryContinuation, ...identity } = operation as typeof operation & {
        result?: unknown; resultProjection?: unknown; input?: unknown; queryContinuation?: unknown
      }
      return identity
    }),
    ...("ordinary" in value && value.ordinary ? { ordinary: { ...value.ordinary, result: undefined } } : {}),
  }
  const json = JSON.stringify(reference)
  return json.length <= MAX_REFERENCE_CHARS ? `${OPERATION_RECEIPT_REFERENCE_PREFIX}${json}` : undefined
}

export function parseOperationReceiptReference(
  text: string,
  identity: { sessionId: string; turnId?: string },
): string[] {
  if (!identity.turnId) return []
  const lines = text.split(/\r?\n/).filter(line => line.startsWith(OPERATION_RECEIPT_REFERENCE_PREFIX))
  // Conflicting or repeated metadata is not a uniquely bound receipt.
  if (lines.length !== 1) return []
  const json = lines[0]!.slice(OPERATION_RECEIPT_REFERENCE_PREFIX.length)
  if (json.length > MAX_REFERENCE_CHARS) return []
  try {
    const parsed = OperationTurnResponseSchema.safeParse(JSON.parse(json))
    if (!parsed.success || parsed.data.client !== "codex"
      || parsed.data.sessionId !== identity.sessionId || parsed.data.turnId !== identity.turnId) return []
    return [...new Set(parsed.data.operations.map(operation => operation.operationId))].slice(0, 16)
  } catch {
    return []
  }
}

/** Preserve candidate receipts before optional prose within the shared limit. */
export function boundReceiptContext<T extends { source?: string }>(entries: readonly T[]): T[] {
  const receipts = entries.filter(entry => entry.source === "cerebro_receipt").slice(-32)
  const remaining = 32 - receipts.length
  const prose = remaining > 0 ? entries.filter(entry => entry.source !== "cerebro_receipt").slice(-remaining) : []
  const selected = new Set([...receipts, ...prose])
  return entries.filter(entry => selected.has(entry))
}
