const MAX_SESSION_TITLE_LENGTH = 512

const DIRECT_TITLE_KEYS = [
  "title",
  "customTitle",
  "custom_title",
  "displayName",
  "display_name",
] as const

const ALIAS_TITLE_KEYS = [
  "name",
  "summary",
  "subject",
] as const

const SESSION_CONTAINER_KEYS = ["session", "conversation", "metadata", "meta", "info"] as const

export function normalizeSessionTitle(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined
  const normalized = value.trim().replace(/\s+/g, " ")
  return normalized ? normalized.slice(0, MAX_SESSION_TITLE_LENGTH) : undefined
}

function titleFromRecord(value: unknown, allowAliases = false): string | undefined {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return undefined
  const record = value as Record<string, unknown>

  for (const key of DIRECT_TITLE_KEYS) {
    const title = normalizeSessionTitle(record[key])
    if (title) return title
  }
  if (allowAliases) {
    for (const key of ALIAS_TITLE_KEYS) {
      const title = normalizeSessionTitle(record[key])
      if (title) return title
    }
  }

  for (const key of SESSION_CONTAINER_KEYS) {
    const nested = record[key]
    if (nested === null || typeof nested !== "object" || Array.isArray(nested)) continue
    const nestedRecord = nested as Record<string, unknown>
    for (const titleKey of DIRECT_TITLE_KEYS) {
      const title = normalizeSessionTitle(nestedRecord[titleKey])
      if (title) return title
    }
    for (const titleKey of ALIAS_TITLE_KEYS) {
      const title = normalizeSessionTitle(nestedRecord[titleKey])
      if (title) return title
    }
  }
  return undefined
}

function jsonlEventTitle(client: string, value: unknown): string | undefined {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return undefined
  const record = value as Record<string, unknown>
  const eventType = typeof record["type"] === "string" ? record["type"] : ""

  if (client === "claude-code" && (eventType === "custom-title" || eventType === "ai-title")) {
    return normalizeSessionTitle(
      record["customTitle"] ?? record["custom_title"] ?? record["aiTitle"] ?? record["ai_title"],
    )
  }

  if (["session_meta", "session-metadata", "session_metadata", "session-title", "title"].includes(eventType)) {
    return titleFromRecord(record["payload"] ?? record, true)
  }
  return undefined
}

/** 只提取客户端明确的会话元数据；消息文本回退由 Cerebro 统一派生。 */
export function extractSessionTitle(client: string, value: unknown): string | undefined {
  if (Array.isArray(value)) {
    for (let i = value.length - 1; i >= 0; i--) {
      const title = jsonlEventTitle(client, value[i])
      if (title) return title
    }
    return undefined
  }
  if (value === null || typeof value !== "object") return undefined
  const record = value as Record<string, unknown>
  return titleFromRecord(value, Array.isArray(record["messages"]))
}
