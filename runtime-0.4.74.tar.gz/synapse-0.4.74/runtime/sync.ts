/**
 * runtime/sync.ts —— 周期同步(默认 60s):上报上行 + 稳定上下文下行,**不拉任务**。
 *
 * 方案 §3 Phase 6 / spec §87:同步只做两件事——
 *   ① 上传累积 reports（状态/经验/过程摘要的批量兜底）；
 *   ② 下行稳定上下文(项目规范/约定/项目地图),本地缓存供会话级注入。
 * 🔴 **绝不拉任务、不存任务队列**(任务只在主脑;spec §89 任务查询按需经 inject 意图识别)。
 *
 * daemon→brain 协议 out of scope(可逆);这里定义可注入的 sync 端口 + 一个断言"零 task-pull"
 * 的护栏(任何 sync 实现都不得触碰 task 端点)。
 */

/** 一次同步周期做的动作(可注入实现;默认 no-op)。 */
export interface SyncPort {
  /** 上传累积的 reports(批量兜底) */
  uploadReports?: () => Promise<{ uploaded: number }>
  /** 下行稳定上下文并写本地缓存 */
  downloadStableContext?: () => Promise<{ bytes: number }>
}

export interface SyncResult {
  uploadedReports: number
  stableContextBytes: number
  /** 护栏:本周期是否触碰过任务端点(必须恒为 false) */
  taskPullAttempted: false
}

/**
 * 跑一次同步周期。**结构上不可能拉任务**:SyncPort 根本没有 task 相关方法。
 * taskPullAttempted 恒 false 是可断言的架构不变量(spec §87 no-task-pull)。
 */
export async function runSyncCycle(port: SyncPort = {}): Promise<SyncResult> {
  let uploadedReports = 0
  let stableContextBytes = 0

  try {
    if (port.uploadReports) uploadedReports = (await port.uploadReports()).uploaded
  } catch {
    /* 同步失败不阻断;下周期重试 */
  }
  try {
    if (port.downloadStableContext) stableContextBytes = (await port.downloadStableContext()).bytes
  } catch {
    /* 同上 */
  }

  return { uploadedReports, stableContextBytes, taskPullAttempted: false }
}

export interface SyncLoopHandle {
  stop: () => void
}

/** 启动周期同步定时器(运行时内部定时任务,非外部 cron;spec §62)。默认 60s。 */
export function startSyncLoop(port: SyncPort = {}, intervalMs = 60_000): SyncLoopHandle {
  const timer = setInterval(() => {
    void runSyncCycle(port)
  }, intervalMs)
  if (typeof timer === "object" && "unref" in timer) (timer as { unref: () => void }).unref()
  return { stop: () => clearInterval(timer) }
}
