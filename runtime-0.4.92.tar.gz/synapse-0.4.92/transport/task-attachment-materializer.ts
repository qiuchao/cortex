import { createHash } from "node:crypto"
import { chmod, lstat, mkdir, mkdtemp, open, readdir, rm, stat } from "node:fs/promises"
import { basename, join } from "node:path"
import type { TaskCapabilityExecuteResponse } from "@cerebro/wire"
import type { BrainConfig } from "./brain-config.ts"
import { cacheDir } from "./discovery.ts"

const MAX_BYTES = 500 * 1024 * 1024
const MAX_CACHE_BYTES = 1024 * 1024 * 1024
const MAX_CACHE_ENTRIES = 100
const RETENTION_MS = 24 * 60 * 60_000
const MAINTENANCE_INTERVAL_MS = 60 * 60_000
let cacheQueue: Promise<void> = Promise.resolve()

export interface TaskAttachmentCacheMaintenance {
  ready: Promise<void>
  stop(): void
}

export interface TaskAttachmentMaterializationLimits {
  maxBytes?: number
  allowedMimeTypes?: readonly string[]
}

export async function materializeTaskAttachment(
  response: Extract<TaskCapabilityExecuteResponse, { kind: "result" }>,
  cfg: BrainConfig,
  env: NodeJS.ProcessEnv,
  signal?: AbortSignal,
  limits: TaskAttachmentMaterializationLimits = {},
): Promise<TaskCapabilityExecuteResponse> {
  signal?.throwIfAborted()
  const result = response.result as { attachment?: Record<string, unknown>; download?: Record<string, unknown> }
  const attachment = result?.attachment
  const download = result?.download
  const fileName = typeof attachment?.fileName === "string" ? attachment.fileName : ""
  const mimeType = typeof attachment?.storedMimeType === "string" ? attachment.storedMimeType : ""
  const checksum = typeof attachment?.checksum === "string" ? attachment.checksum.toLowerCase() : ""
  const byteSize = attachment?.storedByteSize
  const downloadPath = typeof download?.path === "string" ? download.path : ""
  if (!fileName || basename(fileName) !== fileName || /[\\/\u0000-\u001f]/.test(fileName)) throw new Error("invalid attachment file name")
  if (!/^(?:image\/(?:jpeg|png|gif)|video\/mp4|text\/(?:plain|markdown)|application\/octet-stream)$/.test(mimeType)) throw new Error("unsupported attachment MIME type")
  if (!/^[a-f0-9]{64}$/.test(checksum)) throw new Error("invalid attachment checksum")
  if (typeof byteSize !== "number" || !Number.isSafeInteger(byteSize) || byteSize <= 0 || byteSize > MAX_BYTES) throw new Error("invalid attachment byte size")
  if (limits.maxBytes !== undefined && (!Number.isSafeInteger(limits.maxBytes) || limits.maxBytes < 0 || byteSize > limits.maxBytes)) throw new Error("attachment exceeds download budget")
  if (limits.allowedMimeTypes && !limits.allowedMimeTypes.includes(mimeType)) throw new Error("attachment MIME type is outside download policy")
  if (!/^\/brain\/bug-attachment-media\/[A-Za-z0-9._~-]+$/.test(downloadPath)) throw new Error("invalid attachment download path")

  return withCacheLock(async () => {
    signal?.throwIfAborted()
    const root = join(cacheDir(env), "task-attachments")
    await preparePrivateRoot(root)
    await cleanupExpired(root)
    await enforceCacheBudget(root, byteSize)
    const directory = await mkdtemp(join(root, "view-"))
    const target = join(directory, fileName)
    const handle = await open(target, "wx", 0o600)
    let completed = false
    let downloaded: Response | undefined
    try {
      signal?.throwIfAborted()
      downloaded = await fetch(`${cfg.brainBaseUrl}${downloadPath}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${cfg.machineToken}` },
        redirect: "error",
        signal: AbortSignal.any([AbortSignal.timeout(Math.max(cfg.timeoutMs, 60_000)), ...(signal ? [signal] : [])]),
      })
      if (!downloaded.ok || !downloaded.body) throw new Error(`download HTTP ${downloaded.status}`)
      const responseMime = downloaded.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase()
      if (responseMime !== mimeType.toLowerCase()) throw new Error("download MIME type mismatch")
      const declaredLength = downloaded.headers.get("content-length")
      if (declaredLength !== null && Number(declaredLength) !== byteSize) throw new Error("download byte size mismatch")
      const hash = createHash("sha256")
      let written = 0
      for await (const chunk of downloaded.body) {
        signal?.throwIfAborted()
        const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
        written += data.length
        if (written > byteSize) throw new Error("download exceeded declared byte size")
        hash.update(data)
        await writeAll(handle, data)
      }
      if (written !== byteSize || (await handle.stat()).size !== byteSize) throw new Error("download byte size mismatch")
      if (hash.digest("hex") !== checksum) throw new Error("download checksum mismatch")
      signal?.throwIfAborted()
      completed = true
    } finally {
      if (!completed && downloaded?.body && !downloaded.body.locked) await downloaded.body.cancel().catch(() => undefined)
      await handle.close()
      if (!completed) await rm(directory, { recursive: true, force: true })
    }
    return {
      ...response,
      result: { attachment, localPath: target, materializedAt: new Date().toISOString() },
    }
  }, signal)
}

export function startTaskAttachmentCacheMaintenance(
  env: NodeJS.ProcessEnv = process.env,
): TaskAttachmentCacheMaintenance {
  const maintain = () => withCacheLock(async () => {
    const root = join(cacheDir(env), "task-attachments")
    await preparePrivateRoot(root)
    await cleanupExpired(root)
    await enforceCacheBudget(root, 0)
  })
  const ready = maintain()
  const timer = setInterval(() => { void maintain().catch(() => undefined) }, MAINTENANCE_INTERVAL_MS)
  timer.unref()
  return { ready, stop: () => clearInterval(timer) }
}

async function preparePrivateRoot(root: string): Promise<void> {
  await mkdir(root, { recursive: true, mode: 0o700 })
  const info = await lstat(root)
  if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("attachment cache root must be a real directory")
  if (typeof process.getuid === "function" && info.uid !== process.getuid()) throw new Error("attachment cache root must be owned by the current user")
  if (process.platform !== "win32") await chmod(root, 0o700)
}

async function cleanupExpired(root: string): Promise<void> {
  const entries = await readdir(root, { withFileTypes: true })
  const cutoff = Date.now() - RETENTION_MS
  await Promise.all(entries.filter((entry) => entry.isDirectory() && entry.name.startsWith("view-")).map(async (entry) => {
    const path = join(root, entry.name)
    const info = await stat(path).catch(() => null)
    if (info && info.mtimeMs < cutoff) await rm(path, { recursive: true, force: true })
  }))
}

async function enforceCacheBudget(root: string, incomingBytes: number): Promise<void> {
  const entries = (await Promise.all((await readdir(root, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory() && entry.name.startsWith("view-"))
    .map(async (entry) => cacheEntry(join(root, entry.name)))))
    .filter((entry): entry is { path: string; bytes: number; mtimeMs: number } => entry !== null)
    .sort((left, right) => left.mtimeMs - right.mtimeMs)
  let totalBytes = entries.reduce((sum, entry) => sum + entry.bytes, 0)
  const incomingEntries = incomingBytes > 0 ? 1 : 0
  while (entries.length > 0 && (entries.length + incomingEntries > MAX_CACHE_ENTRIES || totalBytes + incomingBytes > MAX_CACHE_BYTES)) {
    const oldest = entries.shift()!
    await rm(oldest.path, { recursive: true, force: true })
    totalBytes -= oldest.bytes
  }
  if (totalBytes + incomingBytes > MAX_CACHE_BYTES) throw new Error("attachment cache capacity exceeded")
}

async function cacheEntry(path: string): Promise<{ path: string; bytes: number; mtimeMs: number } | null> {
  const directory = await lstat(path).catch(() => null)
  if (!directory?.isDirectory() || directory.isSymbolicLink()) return null
  let bytes = 0
  for (const child of await readdir(path, { withFileTypes: true })) {
    if (!child.isFile() || child.isSymbolicLink()) continue
    bytes += (await lstat(join(path, child.name))).size
  }
  return { path, bytes, mtimeMs: directory.mtimeMs }
}

async function writeAll(handle: Awaited<ReturnType<typeof open>>, data: Buffer): Promise<void> {
  let offset = 0
  while (offset < data.length) {
    const { bytesWritten } = await handle.write(data, offset, data.length - offset)
    if (bytesWritten <= 0) throw new Error("attachment file write made no progress")
    offset += bytesWritten
  }
}

function withCacheLock<T>(operation: () => Promise<T>, signal?: AbortSignal): Promise<T> {
  let started = false
  const run = () => { started = true; return operation() }
  const result = cacheQueue.then(run, run)
  cacheQueue = result.then(() => undefined, () => undefined)
  if (!signal) return result
  let onAbort: () => void
  const cancelled = new Promise<never>((_resolve, reject) => {
    // Queued work has nothing to clean up; active transfers await their cleanup.
    onAbort = () => { if (!started) reject(signal.reason ?? new DOMException("Aborted", "AbortError")) }
    signal.addEventListener("abort", onAbort, { once: true })
    if (signal.aborted) onAbort()
  })
  return Promise.race([result, cancelled]).finally(() => signal.removeEventListener("abort", onAbort))
}
