/**
 * core/handlers/nudge-sync.ts —— report 的 IO handler(**detached**,绝不阻塞 Stop)。
 *
 * 方案 R3 / spec §261:回合/会话结束时,把刚结束的 session 提优先给训练语料流
 * (transcript scanner)。**不新增 hook** —— 只是给已有的 report 加一个优先级信号。
 *
 * Phase 2:先落一个进程内优先级队列信号(transcript scanner 在 Phase 5 消费它)。
 */

/** 进程内的"待优先同步 session"集合。Phase 5 的 scanner 会读它、清它。 */
export interface SyncPriorityQueue {
  mark: (sessionId: string) => void
  /** 只消费已等待到 transcript mtime 安全窗的 session；默认立即消费保持调用兼容。 */
  drain: (minAgeMs?: number, nowMs?: number) => string[]
  /** 下一项达到安全窗前还需等待的毫秒数；空队列返回 null。 */
  nextReadyIn: (minAgeMs?: number, nowMs?: number) => number | null
  has: (sessionId: string) => boolean
  subscribe?: (listener: () => void) => () => void
}

export function createSyncPriorityQueue(): SyncPriorityQueue {
  const pending = new Map<string, number>()
  const listeners = new Set<() => void>()
  return {
    mark: (s) => {
      if (!s) return
      pending.set(s, Date.now())
      for (const listener of listeners) listener()
    },
    drain: (minAgeMs = 0, nowMs = Date.now()) => {
      const out: string[] = []
      for (const [sessionId, markedAt] of pending) {
        if (nowMs - markedAt < minAgeMs) continue
        out.push(sessionId)
        pending.delete(sessionId)
      }
      return out
    },
    nextReadyIn: (minAgeMs = 0, nowMs = Date.now()) => {
      let waitMs: number | null = null
      for (const markedAt of pending.values()) {
        const candidate = Math.max(0, markedAt + minAgeMs - nowMs)
        waitMs = waitMs === null ? candidate : Math.min(waitMs, candidate)
      }
      return waitMs
    },
    has: (s) => pending.has(s),
    subscribe: (listener) => {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },
  }
}

export interface NudgeSyncResult {
  synced: boolean
  reason: "queued" | "empty"
}

export function handleNudgeSync(sessionId: string, queue: SyncPriorityQueue): NudgeSyncResult {
  if (!sessionId) return { synced: false, reason: "empty" }
  queue.mark(sessionId)
  return { synced: true, reason: "queued" }
}
