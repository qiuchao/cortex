import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs"
import { dirname } from "node:path"

export function sessionKey(request: { client: string; session_id: string }): string {
  return `${request.client}\n${request.session_id}`
}

export function loadSessionState<T>(path: string, fallback: () => T, validate: (value: unknown) => T): T {
  try {
    return validate(JSON.parse(readFileSync(path, "utf8")))
  } catch {
    return fallback()
  }
}

export function persistSessionState(path: string, state: unknown): void {
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
  const temp = `${path}.${process.pid}.tmp`
  writeFileSync(temp, JSON.stringify(state, null, 2) + "\n", { mode: 0o600 })
  renameSync(temp, path)
  if (existsSync(path)) chmodSync(path, 0o600)
}
