/** Configured clone probing shares the same binding checks as cwd context resolution. */
export { probeConfiguredRepoClones, repoBaseName, joinConfiguredPath, buildConfiguredCloneCandidates } from "../transport/repo-clone-binding.ts"
export type { ConfigRepo, ProbeHttpConfig, ProbeRepoClonesOptions, CloneBindingProbe, ProbeRepoClonesResult } from "../transport/repo-clone-binding.ts"
