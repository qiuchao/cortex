/**
 * core/parsers/index.ts —— 运行时侧 per-client parser 注册表(唯一的 client 注册点)。
 *
 * 加一个客户端 = 新增 core/parsers/<client>.ts + 在此 map 加一行 + 写 shims/<client>/。
 * **runtime/ 与 core/ 根目录零改动**(方案 Phase 3 零 diff 承诺;parsers 目录是隔离的注册区)。
 *
 * 每个 parser 把该 client 的 hook 原始 stdin(薄壳只转发)解析成规范 Inject/ReportRequest。
 */
import type { ClientId, InjectRequest, ReportRequest } from "../../transport/contract.ts"

import * as claudeCode from "./claude-code.ts"
import * as codex from "./codex.ts"
import * as opencode from "./opencode.ts"
import * as geminiCli from "./gemini-cli.ts"
import * as kimiCode from "./kimi-code.ts"
// antigravity 暂缓接入(当前无成员使用);复活时加回 import + 下方 map 一行 + shim。见 docs/DECISIONS.md。

export interface ClientParser {
  parseInject: (raw: unknown) => InjectRequest
  parseReport: (raw: unknown) => ReportRequest
  /** Client-internal callback that must not start or replace a user turn. */
  isInternalInject?: (raw: unknown) => boolean
}

export const PARSERS: Record<ClientId, ClientParser> = {
  "claude-code": claudeCode,
  codex,
  opencode,
  "gemini-cli": geminiCli,
  "kimi-code": kimiCode,
}

export function getParser(client: string): ClientParser | undefined {
  return PARSERS[client as ClientId]
}
