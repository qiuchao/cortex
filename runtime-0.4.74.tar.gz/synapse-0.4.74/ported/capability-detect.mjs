#!/usr/bin/env node
/**
 * scripts/capability-detect.mjs — Synapse OpenCode 薄壳安装前能力探测
 *
 * 探测 5 个功能下限（ADR: opencode-version-compatibility §Decision §1）：
 *   1. plugin 加载机制（@opencode-ai/plugin 包存在 或 opencode.json plugins[] 可读）
 *   2. ctx 上下文对象至少 1 个字段可访问
 *   3. opencode 配置可读写（dry-run，不实际写）
 *   4. AGENTS.md 全局路径可写（~/.config/opencode/AGENTS.md）
 *   5. experimental.session.compacting hook 可被识别
 *
 * 退出码：
 *   0 = 全部必需能力通过
 *   1 = 任意必需能力失败
 *
 * ADR: opencode-version-compatibility
 */

import { readFileSync, existsSync, constants as fsConstants } from "node:fs"
import { access } from "node:fs/promises"
import { join } from "node:path"
import { homedir } from "node:os"
import { execSync } from "node:child_process"
import { createRequire } from "node:module"
import process from "node:process"
import { fileURLToPath } from "node:url"

const HOME = homedir()
const OPENCODE_CONFIG_DIR = join(HOME, ".config", "opencode")
const OPENCODE_JSON_PATH = join(OPENCODE_CONFIG_DIR, "opencode.json")
const AGENTS_MD_PATH = join(OPENCODE_CONFIG_DIR, "AGENTS.md")
const require = createRequire(import.meta.url)

const results = {
  pluginLoad:       { ok: false, label: "plugin 加载机制（@opencode-ai/plugin 或 opencode.json plugins[]）" },
  ctxObject:        { ok: false, label: "ctx 上下文对象可访问（@opencode-ai/plugin API）" },
  configReadWrite:  { ok: false, label: "opencode 配置可读写（~/.config/opencode/opencode.json）" },
  agentsMd:         { ok: false, label: "AGENTS.md 全局路径可写（~/.config/opencode/AGENTS.md）" },
  sessionCompacting:{ ok: false, label: "experimental.session.compacting hook 可被识别" },
}

const warnings = []

// ─── 探测 1：plugin 加载机制 ─────────────────────────────────────────────────
function detectPluginLoad() {
  // 优先：@opencode-ai/plugin 包可解析
  try {
    require.resolve("@opencode-ai/plugin")
    results.pluginLoad.ok = true
    return
  } catch { /* 继续 fallback */ }

  // Fallback 1：opencode.json 存在且有 plugin/plugins 数组
  try {
    if (existsSync(OPENCODE_JSON_PATH)) {
      const raw = JSON.parse(readFileSync(OPENCODE_JSON_PATH, "utf8"))
      if (Array.isArray(raw?.plugin) || Array.isArray(raw?.plugins)) {
        results.pluginLoad.ok = true
        return
      }
    }
  } catch { /* 失败 */ }

  // Fallback 2：opencode CLI 存在即乐观通过（新用户首装场景）
  // synapse install 后续会安装全局 plugin，此时配置文件可能尚不存在
  try {
    execSync('opencode --version', { timeout: 5000, stdio: 'ignore' })
    warnings.push("⚠️  plugin 加载机制：opencode 存在，乐观通过（首装场景）")
    results.pluginLoad.ok = true
    return
  } catch { /* opencode 不存在 */ }
}

// ─── 探测 2：ctx 上下文对象 ──────────────────────────────────────────────────
function detectCtxObject() {
  try {
    const mod = require("@opencode-ai/plugin")
    if (mod && typeof mod === "object" && Object.keys(mod).length > 0) {
      results.ctxObject.ok = true
      return
    }
  } catch { /* 包不存在 */ }

  // Phase 1 MVP：包不存在时乐观通过
  results.ctxObject.ok = true
}

// ─── 探测 3：opencode 配置可读写 ─────────────────────────────────────────────
async function detectConfigReadWrite() {
  // 逐层向上找可写祖先目录
  const candidates = [
    OPENCODE_CONFIG_DIR,
    join(HOME, ".config"),
    HOME,
  ]
  for (const dir of candidates) {
    if (!existsSync(dir)) continue
    try {
      await access(dir, fsConstants.W_OK | fsConstants.R_OK)
      results.configReadWrite.ok = true
      return
    } catch { /* 继续上一层 */ }
  }
}

// ─── 探测 4：AGENTS.md 全局路径可写 ─────────────────────────────────────────
async function detectAgentsMd() {
  if (existsSync(AGENTS_MD_PATH)) {
    try {
      await access(AGENTS_MD_PATH, fsConstants.W_OK)
      results.agentsMd.ok = true
      return
    } catch { return }
  }

  // 文件不存在 → 检测父目录
  const candidates = [
    OPENCODE_CONFIG_DIR,
    join(HOME, ".config"),
    HOME,
  ]
  for (const dir of candidates) {
    if (!existsSync(dir)) continue
    try {
      await access(dir, fsConstants.W_OK)
      results.agentsMd.ok = true
      return
    } catch { /* 继续 */ }
  }
}

// ─── 探测 5：experimental.session.compacting hook ────────────────────────────
// REQUIRED — hard fail（ADR: opencode-version-compatibility §Decision §4）
//
// 虚采纳-4 修正（Phase 1.2）：
//   之前：依赖 @opencode-ai/plugin npm 包字段探测（在 file:// 部署模式下失效——
//         opencode 通过 `plugin` key + file:// URI 加载插件，不通过 npm 包；
//         因此 @opencode-ai/plugin 不存在于 node_modules，任何正常安装环境都会 exit(1)）
//   probe plugin 方案局限：opencode run 无 --plugin CLI flag（仅有 --pure），
//         无法在 capability-detect 中用 `opencode run --pure --plugin file://... "probe"` 单次运行；
//         probe plugin 仍作为 T4/T5 验收测试 fixture 保留（tests/fixtures/probe-compacting-plugin.js）
//   现在：版本检查方案——opencode >= 1.x 均支持 experimental.session.compacting；
//         通过 `opencode --version` 判断主版本号，>= 1 则通过
async function detectSessionCompacting() {
  // 版本检查：opencode >= 1.x 均支持 session.compacting（ADR: opencode-version-compatibility）
  try {
    const ver = execSync("opencode --version", { timeout: 5000 }).toString().trim()
    const major = parseInt(ver.split(".")[0], 10)
    if (!isNaN(major) && major >= 1) {
      results.sessionCompacting.ok = true
      return
    }
    // 版本号 < 1（如 0.x）→ hard fail
    results.sessionCompacting.ok = false
    return
  } catch {
    // opencode CLI 不可用 → 无法确认 hook 支持 → hard fail
    results.sessionCompacting.ok = false
  }
}

// ─── 可选能力探测 ─────────────────────────────────────────────────────────────
function detectOptionalCapabilities() {
  try {
    const mod = require("@opencode-ai/plugin")

    if (!mod?.workingMemory && !mod?.WorkingMemory && !mod?.working_memory) {
      warnings.push("⚠️  可选能力缺失：working_memory API（M1 KH 注入将降级）")
    }

    const hookNames = mod?.HOOK_NAMES ?? mod?.SUPPORTED_HOOKS ?? mod?.hookNames ?? []
    if (Array.isArray(hookNames) && !hookNames.includes("session.end")) {
      warnings.push("⚠️  可选能力缺失：session.end hook（auto-learning 将降级）")
    }
  } catch {
    // @opencode-ai/plugin 不存在，跳过可选探测
  }
}

// ─── 主流程 ───────────────────────────────────────────────────────────────────
async function main() {

  detectPluginLoad()
  detectCtxObject()
  await detectSessionCompacting()
  detectOptionalCapabilities()
  await detectConfigReadWrite()
  await detectAgentsMd()

  for (const w of warnings) {
    console.warn(w)
  }

  const failures = Object.entries(results).filter(([, v]) => !v.ok)

  if (failures.length === 0) {
    process.exit(0)
  }

  process.stderr.write("\n❌ synapse: 以下必需能力不可用：\n\n")

  for (const [key, v] of failures) {
    process.stderr.write(`  ✗ ${v.label}\n`)

    if (key === "sessionCompacting") {
      // ADR: opencode-version-compatibility §Decision §4
      process.stderr.write(
        "\n" +
        "  ⚠️  experimental.session.compacting hook 不可用！\n" +
        "  此 hook 是 Synapse 长对话上下文保护的核心依赖。\n" +
        "  请升级 OpenCode 至支持 experimental.session.compacting hook 的版本。\n" +
        "  参考：docs/compatibility.md\n\n"
      )
    }
  }

  process.stderr.write(
    "安装已中止。请修复上述问题后重新运行 `synapse install opencode`\n" +
    "运行 `synapse doctor` 获取详细诊断信息\n"
  )
  process.exit(1)
}

main().catch((err) => {
  process.stderr.write(`capability-detect 内部错误: ${err.message}\n`)
  process.exit(1)
})
