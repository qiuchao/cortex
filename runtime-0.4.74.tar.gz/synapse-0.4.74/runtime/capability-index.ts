import type { KnowledgeCapabilityCatalog, TaskCapabilityCatalogue } from "@cerebro/wire"

export interface CapabilityIndexEntry {
  name: KnowledgeCapabilityCatalog["capabilities"][number]["name"]
  risk: KnowledgeCapabilityCatalog["capabilities"][number]["access"]["risk"]
  required: readonly string[]
  optional: readonly string[]
  fields: KnowledgeCapabilityCatalog["capabilities"][number]["args"]["fields"]
  available: boolean
}

export type CapabilityIndexCatalogue =
  | (KnowledgeCapabilityCatalog & { taskCatalogue?: TaskCapabilityCatalogue })
  | { taskCatalogue?: TaskCapabilityCatalogue }

export function buildCapabilityIndex(
  catalogue: KnowledgeCapabilityCatalog,
): CapabilityIndexEntry[] {
  const availableCapabilities = new Set<string>(catalogue.availableCapabilities)
  return catalogue.capabilities.map((entry) => ({
    name: entry.name,
    risk: entry.access.risk,
    required: entry.args.required,
    optional: entry.args.optional,
    fields: entry.args.fields,
    available: availableCapabilities.has(entry.name),
  }))
}

export function renderFullCapabilityIndex(
  catalogue: KnowledgeCapabilityCatalog,
): string {
  return JSON.stringify(buildCapabilityIndex(catalogue))
}

export function renderCompactCapabilityIndex(
  catalogue: CapabilityIndexCatalogue,
  options: { taskOnly?: boolean } = {},
): string {
  const knowledge = "knowledgeIntentContractVersion" in catalogue ? catalogue : undefined
  if (!options.taskOnly && !knowledge) throw new Error("Knowledge catalogue is required outside task-only mode")
  const availableCapabilities = new Set<string>(knowledge?.availableCapabilities ?? [])
  const entries = options.taskOnly ? [] : knowledge!.capabilities.map((entry) => {
    const required = entry.args.required.length > 0 ? entry.args.required.join(",") : "-"
    const optional = entry.args.optional.length > 0 ? entry.args.optional.join(",") : "-"
    const risk = entry.access.risk === "read" ? "R" : entry.access.risk === "write" ? "W" : "D"
    const unavailable = availableCapabilities.has(entry.name) ? "" : " unavailable"
    const warning = entry.access.risk === "destructive" ? "⚠" : ""
    return `${warning}${entry.name}|${risk}|${required}|${optional}${unavailable}`
  })
  const availableTasks = new Set<string>(catalogue.taskCatalogue?.availableCapabilities ?? [])
  const tasks = catalogue.taskCatalogue?.capabilities
    .filter((entry) => availableTasks.has(entry.name))
    .map((entry) => `${entry.name}|${entry.mode === "read" ? "R" : "D"}|${entry.input.required.join(",") || "-"}|${entry.input.optional.join(",") || "-"}`) ?? []
  return ["name|r|req|opt", ...entries, ...tasks].join("\n")
}
