#!/usr/bin/env node
/**
 * scripts/branch-parent-helper.mjs — branch-parent.json 读写辅助脚本
 *
 * 通过 process.argv 接收参数，避免 shell 命令行内嵌 `node -e "..."` 的
 * 单双引号转义地狱（与 stash-track-helper.mjs / read-git-rules.mjs 保持同一风格）。
 *
 * 用法（第一个参数是文件完整路径，由 bash 计算后传入）：
 *   node branch-parent-helper.mjs <file-path> set <branch> <parent> <createdFromSha> <createdBy>
 *   node branch-parent-helper.mjs <file-path> get <branch>     → 输出 parent 字符串或空行（exit 0）
 *   node branch-parent-helper.mjs <file-path> list             → 输出所有 branches 记录 JSON
 *   node branch-parent-helper.mjs <file-path> delete <branch>  → 删除记录
 *
 * 文件路径由 bash 传入（$(git rev-parse --show-toplevel)/.synapse/branch-parent.json），
 * 与 read-git-rules.mjs 风格一致，mjs 本身不再做路径查找。
 *
 * 文件存放：<project-root>/.synapse/branch-parent.json（进 git，团队共享）
 * 与 stash-tracking.json（运行时数据，~/.cache/synapse/）完全分离。
 *
 * schema（data.branches 包裹）：
 *   {
 *     "branches": {
 *       "<branch>": { "parent", "createdAt", "createdFromSha", "createdBy" }
 *     }
 *   }
 *
 * fail-safe：任何读取/解析失败一律降级（不崩溃）。
 * JSON 损坏 → 重置为 { branches: {} }（失败安全）。
 *
 * ADR: branch-parent-tracking
 */

import { readFileSync, writeFileSync, mkdirSync } from "node:fs"
import { dirname } from "node:path"
import { fileURLToPath } from "node:url"

// ── 纯函数导出（供测试 import）──────────────────────────────────────────────

/**
 * 将英文功能名规范化为 kebab-case（供测试导入）
 * 规则：英文/缩写保留；空格/下划线 → 连字符；全小写；去除非 ascii
 *
 * 注意：此函数处理「已是英文但格式不规范」的情况。
 * 中文→英文翻译由 LLM 在 S2b-4 完成，这里只做后处理。
 */
export function toKebabCase(input) {
  return input
    .trim()
    .toLowerCase()
    .replace(/[\s_]+/g, "-") // 空格/下划线 → 连字符
    .replace(/[^a-z0-9-]/g, "") // 去除非 ascii 字符（中文会变空，实际翻译由 LLM 做）
    .replace(/-+/g, "-") // 合并连续连字符
    .replace(/^-|-$/g, "") // 去首尾连字符
}

/**
 * 构造分支名：feature/<username>/<kebab>
 */
export function buildBranchName(username, kebabFeature) {
  const safeUser = username
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
  return `feature/${safeUser}/${kebabFeature}`
}

/**
 * R11 父分支推断（按命名规则，当 branch-parent.json 无记录时使用）
 */
export function inferParentBranch(branchName) {
  if (/^feature\//.test(branchName)) {
    return "main"
  }
  if (/^branch\/release\d+\/.+/.test(branchName)) {
    // branch/releaseN/xxx → branch/releaseN
    return branchName.replace(/\/[^/]*$/, "")
  }
  // branch/releaseN 本身（最上层 release），父分支是 main
  return "main"
}

// ── 读/写工具函数（接收文件路径参数）──────────────────────────────────────

/**
 * 读取 branch-parent.json，JSON 损坏时 fail-safe 返回 { branches: {} }
 */
function readData(filePath) {
  try {
    let raw = readFileSync(filePath, "utf8")
    if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1) // BOM
    const parsed = JSON.parse(raw)
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return { branches: {} }
    }
    // 兼容旧格式（扁平 key 直接是分支名，无 branches 包裹）
    if (!parsed.branches) {
      return { branches: {} }
    }
    return parsed
  } catch {
    return { branches: {} }
  }
}

/**
 * 写入 branch-parent.json，目录不存在时自动 mkdir -p
 */
function writeData(filePath, data) {
  try {
    mkdirSync(dirname(filePath), { recursive: true })
    writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n", "utf8")
  } catch (err) {
    process.stderr.write(`[branch-parent-helper] 写入失败: ${err.message}\n`)
  }
}

// ── CLI 入口（仅在直接运行时执行，import 时跳过）──────────────────────────

const __filename = fileURLToPath(import.meta.url)
const isDirectRun =
  process.argv[1] === __filename ||
  process.argv[1]?.endsWith("branch-parent-helper.mjs")

if (isDirectRun) {
  // argv: [node, script, <file-path>, <op>, ...args]
  const [, , filePath, op, ...args] = process.argv

  if (!filePath || !op) {
    process.stderr.write(
      "Usage:\n" +
        "  node branch-parent-helper.mjs <file-path> set <branch> <parent> <createdFromSha> <createdBy>\n" +
        "  node branch-parent-helper.mjs <file-path> get <branch>\n" +
        "  node branch-parent-helper.mjs <file-path> list\n" +
        "  node branch-parent-helper.mjs <file-path> delete <branch>\n"
    )
    process.exit(1)
  }

  switch (op) {
    case "set": {
      const [branch, parent, createdFromSha, createdBy] = args
      if (!branch || !parent || !createdFromSha || !createdBy) {
        process.stderr.write(
          "set requires: <branch> <parent> <createdFromSha> <createdBy>\n"
        )
        process.exit(1)
      }
      const data = readData(filePath)
      // preserve 已有记录的 createdAt（重复 set 同分支不刷新原始创建时间）
      const existingCreatedAt = data.branches[branch]?.createdAt
      // 四字段 schema，绝不存 stash 字段
      data.branches[branch] = {
        parent,
        createdAt: existingCreatedAt ?? new Date().toISOString(),
        createdFromSha,
        createdBy,
      }
      writeData(filePath, data)
      break
    }

    case "get": {
      const [branch] = args
      if (!branch) {
        process.stderr.write("get requires: <branch>\n")
        process.exit(1)
      }
      const data = readData(filePath)
      const record = data.branches[branch]
      if (!record || typeof record !== "object" || !record.parent) {
        process.stdout.write("\n") // 空行（exit 0）
      } else {
        process.stdout.write(record.parent + "\n")
      }
      break
    }

    case "list": {
      const data = readData(filePath)
      process.stdout.write(JSON.stringify(data.branches, null, 2) + "\n")
      break
    }

    case "delete": {
      const [branch] = args
      if (!branch) {
        process.stderr.write("delete requires: <branch>\n")
        process.exit(1)
      }
      const data = readData(filePath)
      delete data.branches[branch]
      writeData(filePath, data)
      break
    }

    default: {
      process.stderr.write(
        `未知 op: ${op}（合法值: set / get / list / delete）\n`
      )
      process.exit(1)
    }
  }
} // end if (isDirectRun)
