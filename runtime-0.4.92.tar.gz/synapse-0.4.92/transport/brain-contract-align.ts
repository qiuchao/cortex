/**
 * transport/brain-contract-align.ts — @cerebro/wire 契约类型对齐
 *
 * P7 实接（downloadStableContext / brainTaskFetcher）：
 *   · downloadStableContext: GET <brainBaseUrl>/brain/stable-context?since=<etag>，
 *     命中 etag 返 304（不重写缓存）；否则写本地缓存文件 + 记 etag，供会话级注入。
 *   · brainTaskFetcher: 查询当前产品的需求，返回可注入文本。
 *   两者均降级不抛（主脑不可达不阻断 Synapse）。
 *
 * 鉴权说明（骨架冻结）：
 *   · 机器（Synapse harness）：machine token，per-user 绑 users.id
 *   · 鉴权头：Authorization: Bearer <token>
 *   · 用户身份由 Cerebro 从机器令牌解析，Synapse 不伪造 assignee。
 *   参考：docs/adr/identity-authority-user-table.md
 *
 * 配置来源：transport/brain-config.ts（CEREBRO_BRAIN_URL + CEREBRO_MACHINE_TOKEN）
 * 降级策略：配置缺失 / 网络错误不阻断 Synapse。
 */

import { type RepoContext } from "./repo-clone-registry.ts"
import { resolveTrustedRepoCloneContext } from "./repo-clone-binding.ts"
import type {
  // 游标类型（骨架冻结：单调事件序号语义）
  Cursor,
  // /brain/stable-context
  StableContextResponse,
  KnowledgeCapabilityManifest,
  KnowledgeCapabilityManifestEntry,
  KnowledgeCapabilityName,
  KnowledgeCapabilityMethod,
  KnowledgeIntentRequest,
  KnowledgeIntentResponse as WireKnowledgeIntentResponse,
  KnowledgeIntentStatus,
  KnowledgeAgentExecuteRequest,
  KnowledgeAgentExecuteResponse,
  KnowledgeCapabilityCatalog,
  TaskCapabilityCatalogue,
  TaskCapabilityExecuteRequest,
  TaskCapabilityExecuteResponse,
  TaskCapabilitySourceClient,
  TaskCapabilityWriteCommand,
  WorkItemContextDocumentsReadInput,
  WorkItemContextDocumentsReadResponse,
  WorkItemContextReadInput,
  WorkItemContextReadResponse,
  WorkItemContextReceipt,
  WorkItemContextReceiptCreateInput,
  WorkItemContextReceiptIgnoreInput,
  WorkItemContextReceiptSupplementInput,
  WorkItemContextReceiptSupplementResponse,
  WorkItemContextReceiptValidateInput,
  WorkItemContextReceiptValidation,
} from '@cerebro/wire'
import {
  CAPABILITY_METHOD_BY_NAME,
  KNOWLEDGE_CAPABILITY_MANIFEST,
  KNOWLEDGE_CAPABILITY_METHODS,
  KNOWLEDGE_CAPABILITY_NAMES,
  KnowledgeCapabilityManifestSchema,
  KnowledgeIntentRequestSchema,
  KnowledgeIntentResponseSchema,
  KnowledgeIntentSurfaceSchema,
  KnowledgeAgentExecuteRequestSchema,
  KnowledgeAgentExecuteResponseSchema,
  KnowledgeCapabilityCatalogSchema,
  TASK_CAPABILITY_EXECUTE_PATH,
  TASK_CAPABILITY_EXECUTE_TIMEOUT_MS,
  TaskCapabilityCatalogueSchema,
  TaskCapabilityExecuteRequestSchema,
  TaskCapabilityExecuteResponseSchema,
  WORK_ITEM_CONTEXT_DOCUMENTS_READ_PATH,
  WORK_ITEM_CONTEXT_READ_PATH,
  WORK_ITEM_CONTEXT_RECEIPT_CREATE_PATH,
  WORK_ITEM_CONTEXT_RECEIPT_IGNORE_PATH,
  WORK_ITEM_CONTEXT_RECEIPT_SUPPLEMENT_PATH,
  WORK_ITEM_CONTEXT_RECEIPT_VALIDATE_PATH,
  WorkItemContextDocumentsReadInputSchema,
  WorkItemContextDocumentsReadResponseSchema,
  WorkItemContextReadInputSchema,
  WorkItemContextReadResponseSchema,
  WorkItemContextReceiptCreateInputSchema,
  WorkItemContextReceiptIgnoreInputSchema,
  WorkItemContextReceiptSupplementInputSchema,
  WorkItemContextReceiptSupplementResponseSchema,
  WorkItemContextReceiptValidateInputSchema,
  WorkItemContextReceiptValidationSchema,
  WorkItemContextReceiptSchema,
  isBugPublicId,
  isRequirementPublicId,
  parseWorkItemPublicId,
} from '@cerebro/wire'
import { stableFallbackTurnId } from '../core/parsers/util.ts'
import type { SyncPort } from '../runtime/sync.ts'
import type { TaskFetcher } from '../core/task-query.ts'
import type { KhSearchResult, KhDegraded, KhInsight } from './kh-types.ts'
import type { ClientId, InjectRequest } from './contract.ts'
import { getBrainConfig } from './brain-config.ts'
import { stableContextCachePath, stableContextEtagPath } from './discovery.ts'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { lstat, open, stat } from 'node:fs/promises'
import { basename, dirname } from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { materializeTaskAttachment, type TaskAttachmentMaterializationLimits } from './task-attachment-materializer.ts'

export {
  CAPABILITY_METHOD_BY_NAME,
  KNOWLEDGE_CAPABILITY_MANIFEST,
  KNOWLEDGE_CAPABILITY_METHODS,
  KNOWLEDGE_CAPABILITY_NAMES,
  KnowledgeCapabilityManifestSchema,
  KnowledgeIntentRequestSchema,
  KnowledgeIntentResponseSchema,
  KnowledgeIntentSurfaceSchema,
}

export type {
  KnowledgeCapabilityManifest,
  KnowledgeCapabilityManifestEntry,
  KnowledgeCapabilityName,
  KnowledgeCapabilityMethod,
  KnowledgeIntentRequest,
  WireKnowledgeIntentResponse,
  KnowledgeIntentStatus,
  KnowledgeAgentExecuteRequest,
  KnowledgeAgentExecuteResponse,
  KnowledgeCapabilityCatalog,
  TaskCapabilityCatalogue,
  TaskCapabilityExecuteRequest,
  TaskCapabilityExecuteResponse,
  WorkItemContextDocumentsReadInput,
  WorkItemContextDocumentsReadResponse,
  WorkItemContextReadInput,
  WorkItemContextReadResponse,
  WorkItemContextReceipt,
  WorkItemContextReceiptCreateInput,
  WorkItemContextReceiptIgnoreInput,
  WorkItemContextReceiptSupplementInput,
  WorkItemContextReceiptSupplementResponse,
  WorkItemContextReceiptValidateInput,
  WorkItemContextReceiptValidation,
}

export type { RepoContext } from "./repo-clone-registry.ts"

/** Resolve the current client cwd through Cerebro's registered clone map. */
export async function resolveRepoContext(
  cwd: string | undefined,
  machineId: string | undefined,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<RepoContext | null> {
  if (!cwd?.trim() || !machineId?.trim()) return null
  const cfg = getBrainConfig(env)
  if (!cfg?.machineToken) return null
  return resolveTrustedRepoCloneContext({ ...cfg, machineToken: cfg.machineToken }, cwd, machineId, signal)
}

// ── 1. downloadStableContext 实接（GET /brain/stable-context + 304 + 本地缓存） ──

/**
 * 下行稳定上下文并写本地缓存。
 *   · 带 since=<上次缓存的 etag> 发条件请求；主脑返 304 → 内容未变，跳过重写。
 *   · 200 → 写正文缓存 + etag 记录；返回写入字节数。
 *   · 未配置 / 网络错 / 非 2xx/304 → 降级 { bytes: 0 }，不抛。
 *
 * @param env 环境变量注入（便于测试 mock）
 */
export async function downloadStableContext(
  env: NodeJS.ProcessEnv = process.env,
): Promise<{ bytes: number; notModified?: boolean }> {
  const cfg = getBrainConfig(env)
  if (!cfg || !cfg.machineToken) {
    return { bytes: 0 }
  }

  // 读上次缓存的 etag(存在则做条件请求)
  let sinceEtag: string | undefined
  try {
    sinceEtag = readFileSync(stableContextEtagPath(env), 'utf8').trim() || undefined
  } catch {
    sinceEtag = undefined
  }

  const qs = sinceEtag ? `?since=${encodeURIComponent(sinceEtag)}` : ''
  const url = `${cfg.brainBaseUrl}/brain/stable-context${qs}`

  let resp: Response
  try {
    resp = await fetch(url, {
      method: 'GET',
      headers: { Authorization: `Bearer ${cfg.machineToken}` },
      signal: AbortSignal.timeout(cfg.timeoutMs),
    })
  } catch {
    return { bytes: 0 }
  }

  // 304 Not Modified：内容未变，保留现缓存
  if (resp.status === 304) {
    return { bytes: 0, notModified: true }
  }
  if (!resp.ok) {
    return { bytes: 0 }
  }

  let parsed: StableContextResponse
  try {
    parsed = (await resp.json()) as StableContextResponse
  } catch {
    return { bytes: 0 }
  }

  const content = typeof parsed.content === 'string' ? parsed.content : ''
  const etag = typeof parsed.etag === 'string' ? parsed.etag : ''

  // 写本地缓存(正文 + etag),供会话级注入 / 下次条件请求
  try {
    const cachePath = stableContextCachePath(env)
    mkdirSync(dirname(cachePath), { recursive: true })
    writeFileSync(cachePath, content, 'utf8')
    if (etag) writeFileSync(stableContextEtagPath(env), etag, 'utf8')
  } catch {
    // 缓存写失败不阻断(下周期重试)
    return { bytes: 0 }
  }

  return { bytes: Buffer.byteLength(content, 'utf8') }
}

/**
 * brainSyncPort — 周期同步端口实接。
 *
 * uploadReports：周期同步不写 report。存活性由 downloadStableContext 的只读请求证明。
 * downloadStableContext：GET /brain/stable-context + 304 + 本地缓存（只读探活 + 规范下行）。
 */
export const brainSyncPort: SyncPort = {
  uploadReports: async (): Promise<{ uploaded: number }> => {
    // 周期同步不主动写 report。
    return { uploaded: 0 }
  },

  downloadStableContext: async (): Promise<{ bytes: number }> => {
    const { bytes } = await downloadStableContext()
    return { bytes }
  },
}

export interface VisibleProduction {
  id: string
  name: string
  workItemKey?: string | null
}

export interface VisibleRequirement {
  id: string
  title: string
  status?: string
  productionId?: string | null
  productionName?: string | null
}

export interface VisibleUser {
  id: string
  name: string
}

export interface VisibleProductModule { id: string; name: string; productionId: string }
export interface VisibleProductIteration { id: string; name: string; productionId: string }

/** Full iteration read model returned by /brain/iterations. */
export interface ProductIteration {
  id: string
  productionId: string
  name: string
  code: string | null
  goal: string | null
  ownerUserId: string | null
  status: "planned" | "in_progress" | "closed"
  isRequirementPool: boolean
  version: number
  startsAt: string | null
  endsAt: string | null
  position: number
  createdBy: string | null
  createdAt: string
  updatedAt: string
  completedItems: number
  totalItems: number
  progressPercent: number
}

export class BrainHttpError extends Error {
  readonly path: string
  readonly status: number
  readonly reason?: string

  constructor(path: string, status: number, reason?: string, message?: string) {
    super(message?.trim() || reason?.trim() || `${path} HTTP ${status}`)
    this.name = "BrainHttpError"
    this.path = path
    this.status = status
    this.reason = reason
  }
}

export function readableBrainError(error: unknown): string {
  if (error instanceof BrainHttpError) {
    if (error.status === 401) return "身份认证失败，请重新连接 Cerebro"
    if (error.status === 403) return `当前身份无权执行此操作${error.message ? `：${error.message}` : ""}`
    if (error.status === 404) return `当前产品中未找到目标记录${error.message ? `：${error.message}` : ""}`
    if (error.status === 409) return `目标已变化或请求冲突${error.message ? `：${error.message}` : ""}`
    return `Cerebro 请求失败（HTTP ${error.status}）：${error.message}`
  }
  return error instanceof Error ? error.message : String(error)
}

export interface RequirementDraft {
  title: string
  description?: string | null
  parentId?: string | null
  assigneeUserId?: string | null
  priority?: "highest" | "high" | "normal" | "low"
  moduleId?: string | null
  iterationId?: string | null
  estimateDays?: number | null
  plannedStartAt?: string | null
  plannedEndAt?: string | null
}

export interface RequirementWorkItem {
  id: string
  publicId: string
  productionId: string
  parentId: string | null
  title: string
  description: string | null
  assigneeUserId: string
  priority: "highest" | "high" | "normal" | "low"
  status: "not_started" | "in_progress" | "done" | "suspended"
  iterationId: string | null
  moduleId: string | null
  estimateDays: number | null
  plannedStartAt: string | null
  plannedEndAt: string | null
  version: number
  createdAt: string
  updatedAt: string
  createdBy?: string | null
  updatedBy?: string | null
  effectiveLifecycle?: "active" | "locked"
}

export interface RequirementBugLink {
  relationId: string
  productionId: string
  requirementId: string
  bugId: string
  linkedBy: string
  linkedAt: string
  unlinkedAt: string | null
}

export interface BugWorkItem {
  id: string
  publicId: string
  productionId: string
  title: string
  description: string | null
  assigneeUserId: string
  currentState: string
  version: number
  createdAt: string
  updatedAt: string
  details: Record<string, unknown>
}

export interface RequirementActivityPage {
  items: unknown[]
  nextCursor?: string
}

/**
 * Requirement activity has two independent ordered streams.  The collection
 * union keeps compatibility with pre-pagination test doubles while the live
 * transport always returns `{ items, nextCursor? }` pages.
 */
export type RequirementActivityCollection = RequirementActivityPage | unknown[]

export interface RequirementActivityResult {
  comments: RequirementActivityCollection
  changes: RequirementActivityCollection
}

export interface RequirementActivityQueryOptions {
  kind?: "all" | "comments" | "changes"
  activityCursor?: string
  commentCursor?: string
  limit?: number
}

export type TaskDraftCommand = TaskCapabilityWriteCommand

export interface TaskCommandDraftRecord {
  id: string
  requestId: string
  productionId: string
  command: TaskDraftCommand
  status: "pending" | "confirmed" | "cancelled" | "expired" | "failed"
  expiresAt: string
  createdAt: string
  confirmedAt: string | null
  /** The immutable server payload, available from the draft GET endpoint. */
  payload?: Record<string, unknown>
  /** Server-persisted processing basis for context-derived work-item writes. */
  contextReceiptId: string | null
  contextTargetPublicId: string | null
  sourceClient?: TaskCapabilitySourceClient | null
  failedAt?: string | null
  errorSnapshot?: { code: string; message: string; name: string } | null
}

export interface TaskCommandReceipt {
  draft: TaskCommandDraftRecord
  result: unknown
  replayed: boolean
}

export async function fetchVisibleProductions(
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<VisibleProduction[]> {
  const cfg = getBrainConfig(env)
  if (!cfg?.machineToken) throw new Error("brain not configured")
  const response = await fetch(`${cfg.brainBaseUrl}/api/v1/org/productions`, {
    method: "GET",
    headers: { Authorization: `Bearer ${cfg.machineToken}` },
    signal: signal
      ? AbortSignal.any([AbortSignal.timeout(cfg.timeoutMs), signal])
      : AbortSignal.timeout(cfg.timeoutMs),
  })
  if (!response.ok) throw new Error(`productions HTTP ${response.status}`)
  const parsed = await response.json() as { productions?: unknown }
  if (!Array.isArray(parsed.productions)) throw new Error("invalid productions response")
  return parsed.productions.flatMap((production) => {
    const item = production as { id?: unknown; name?: unknown; workItemKey?: unknown }
    return typeof item.id === "string" && typeof item.name === "string"
      ? [{ id: item.id, name: item.name, workItemKey: typeof item.workItemKey === "string" ? item.workItemKey.toUpperCase() : null }]
      : []
  })
}

export async function fetchVisibleRequirements(
  productionIdOrEnv?: string | NodeJS.ProcessEnv,
  env: NodeJS.ProcessEnv = process.env,
): Promise<VisibleRequirement[]> {
  const productionId = typeof productionIdOrEnv === "string" ? productionIdOrEnv : undefined
  const runtimeEnv = typeof productionIdOrEnv === "string" ? env : (productionIdOrEnv ?? env)
  const products = productionId ? [{ id: productionId }] : await fetchVisibleProductions(runtimeEnv)
  const batches = await Promise.all(products.map(async (product) => {
    const items: unknown[] = []
    let cursor: string | undefined
    do {
      const params = new URLSearchParams({ productionId: product.id }); if (cursor) params.set("cursor", cursor)
      const parsed = await brainJson(`/brain/requirements?${params}`, { method: "GET" }, runtimeEnv) as { items?: unknown; nextCursor?: unknown }
      if (!Array.isArray(parsed.items)) throw new Error("invalid requirements response")
      items.push(...parsed.items)
      cursor = typeof parsed.nextCursor === "string" && parsed.nextCursor ? parsed.nextCursor : undefined
    } while (cursor)
    return items
  }))
  return batches.flatMap((items) => items).flatMap((value) => {
    const item = value as Record<string, unknown>
    return typeof item.id === "string" && typeof item.title === "string"
      ? [{
          id: item.id,
          title: item.title,
          status: typeof item.status === "string" ? item.status : undefined,
          productionId: typeof item.productionId === "string" ? item.productionId : null,
          productionName: typeof item.productionName === "string" ? item.productionName : null,
        }]
      : []
  })
}

async function fetchProductCatalog<T extends { id: string; name: string; productionId: string }>(
  productionId: string,
  kind: "modules" | "iterations",
  env: NodeJS.ProcessEnv,
): Promise<T[]> {
  const parsed = await brainJson(`/brain/task-config/${kind}?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env) as { items?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error(`invalid ${kind} response`)
  return parsed.items.flatMap((value) => {
    const item = value as Record<string, unknown>
    return typeof item.id === "string" && typeof item.name === "string" && item.productionId === productionId && item.enabled !== false
      ? [{ id: item.id, name: item.name, productionId } as T]
      : []
  })
}

export function fetchVisibleProductModules(productionId: string, env: NodeJS.ProcessEnv = process.env): Promise<VisibleProductModule[]> {
  return fetchProductCatalog(productionId, "modules", env)
}

export function fetchVisibleProductIterations(productionId: string, env: NodeJS.ProcessEnv = process.env): Promise<VisibleProductIteration[]> {
  return fetchProductCatalog(productionId, "iterations", env)
}

export async function fetchVisibleUsers(
  env: NodeJS.ProcessEnv = process.env,
): Promise<VisibleUser[]> {
  const parsed = await brainJson("/api/v1/org/users", { method: "GET" }, env) as { users?: unknown }
  if (!Array.isArray(parsed.users)) throw new Error("invalid users response")
  return parsed.users.flatMap((value) => {
    const user = value as Record<string, unknown>
    return typeof user.id === "string" && typeof user.name === "string" && user.status !== "disabled"
      ? [{ id: user.id, name: user.name }]
      : []
  })
}

/** Return only active members of the selected product for Bug assignee choices. */
export async function fetchVisibleProductMembers(
  productionId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<VisibleUser[]> {
  const parsed = await brainJson(`/brain/task-config/members?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env) as { items?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid product members response")
  return parsed.items.flatMap((value) => {
    const user = value as Record<string, unknown>
    return typeof user.id === "string" && typeof user.name === "string"
      ? [{ id: user.id, name: user.name }]
      : []
  })
}

export async function queryBug(productionId: string, bugId: string, env: NodeJS.ProcessEnv = process.env): Promise<BugWorkItem> {
  if (!isBugPublicId(bugId)) throw new Error("Bug ID 必须使用产品限定的公共 ID")
  const parsed = await brainJson(`/brain/bugs/${encodeURIComponent(bugId.toUpperCase())}?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env) as { bug?: unknown }
  return parseBugWorkItem(parsed.bug, productionId)
}

export interface BugListFilters {
  mine?: boolean
  priority?: "high" | "medium" | "low"
  state?: string
  iterationId?: string
  search?: string
  cursor?: string
  limit?: number
}

export interface BugListResult {
  items: BugWorkItem[]
  total: number
  nextCursor?: string
}

export async function queryBugs(productionId: string, filters: BugListFilters = {}, env: NodeJS.ProcessEnv = process.env): Promise<BugListResult> {
  const params = new URLSearchParams({ productionId })
  if (filters.cursor) params.set("cursor", filters.cursor)
  if (filters.limit !== undefined) params.set("limit", String(filters.limit))
  const path = filters.mine ? "/brain/bugs/my" : "/brain/bugs"
  if (!filters.mine) {
    const conditions: Array<Record<string, unknown>> = []
    if (filters.priority) conditions.push({ field: "priority", operator: "equals", value: filters.priority })
    if (filters.state) conditions.push({ field: "status", operator: "equals", value: filters.state })
    if (filters.iterationId) conditions.push({ field: "iterationId", operator: "equals", value: filters.iterationId })
    if (filters.search) conditions.push({ field: "title", operator: "contains", value: filters.search })
    if (conditions.length) params.set("expression", JSON.stringify({ version: 1, groups: [{ logic: "and", conditions }] }))
  }
  const parsed = await brainJson(`${path}?${params}`, { method: "GET" }, env) as { items?: unknown; total?: unknown; nextCursor?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid bugs response")
  const items = parsed.items.map((item) => parseBugWorkItem(item, productionId))
  return {
    items,
    total: typeof parsed.total === "number" ? parsed.total : items.length,
    ...(typeof parsed.nextCursor === "string" && parsed.nextCursor ? { nextCursor: parsed.nextCursor } : {}),
  }
}

export interface BugActivityQueryOptions { activityCursor?: string; limit?: number }
export interface BugActivityResult { comments: unknown[]; changes: RequirementActivityCollection }

export async function queryBugActivity(productionId: string, bugId: string, optionsOrEnv: BugActivityQueryOptions | NodeJS.ProcessEnv = {}, env: NodeJS.ProcessEnv = process.env): Promise<BugActivityResult> {
  if (!isBugPublicId(bugId)) throw new Error("Bug ID 必须使用产品限定的公共 ID")
  const options = isBugActivityQueryOptions(optionsOrEnv) ? optionsOrEnv : {}
  const runtimeEnv = isBugActivityQueryOptions(optionsOrEnv) ? env : optionsOrEnv
  const id = bugId.toUpperCase()
  const base = `/brain/bugs/${encodeURIComponent(id)}`
  const historyParams = new URLSearchParams({ productionId })
  if (options.activityCursor) historyParams.set("cursor", options.activityCursor)
  if (options.limit !== undefined) historyParams.set("limit", String(options.limit))
  const [comments, history] = await Promise.all([
    brainJson(`${base}/comments?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, runtimeEnv) as Promise<{ items?: unknown }>,
    brainJson(`${base}/history?${historyParams}`, { method: "GET" }, runtimeEnv) as Promise<{ items?: unknown; nextCursor?: unknown }>,
  ])
  if (!Array.isArray(comments.items) || !Array.isArray(history.items)) throw new Error("invalid bug activity response")
  return { comments: comments.items, changes: parseRequirementActivityPage(history) }
}

function isBugActivityQueryOptions(value: BugActivityQueryOptions | NodeJS.ProcessEnv): value is BugActivityQueryOptions {
  if (!value || typeof value !== "object") return false
  const record = value as Record<string, unknown>
  if (Object.prototype.hasOwnProperty.call(record, "CEREBRO_BRAIN_URL") || Object.prototype.hasOwnProperty.call(record, "CEREBRO_MACHINE_TOKEN")) return false
  return Object.keys(record).length === 0 || "activityCursor" in record || "limit" in record
}

function parseBugWorkItem(value: unknown, productionId: string): BugWorkItem {
  const bug = value as Record<string, unknown>
  if (!bug || typeof bug.id !== "string" || typeof bug.publicId !== "string" || !isBugPublicId(bug.publicId)
    || bug.productionId !== productionId || typeof bug.title !== "string" || typeof bug.assigneeUserId !== "string"
    || typeof bug.currentState !== "string" || typeof bug.version !== "number" || typeof bug.createdAt !== "string" || typeof bug.updatedAt !== "string") {
    throw new Error("invalid bug response")
  }
  return bug as unknown as BugWorkItem
}

export interface BugAttachmentFile {
  path: string
  fileName?: string
  mimeType?: string
}

const BUG_ATTACHMENT_PART_BYTES = 8 * 1024 * 1024
const BUG_ATTACHMENT_MIME_TYPES: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', mp4: 'video/mp4',
  log: 'text/plain', txt: 'text/plain', md: 'text/markdown',
}
const BUG_ATTACHMENT_MAX_BYTES: Record<string, number> = {
  jpg: 10 * 1024 * 1024, jpeg: 10 * 1024 * 1024, png: 10 * 1024 * 1024, gif: 10 * 1024 * 1024,
  mp4: 500 * 1024 * 1024, log: 20 * 1024 * 1024, txt: 20 * 1024 * 1024, md: 20 * 1024 * 1024,
}

function attachmentMime(fileName: string, explicit?: string): string {
  const extension = fileName.toLowerCase().split('.').pop() ?? ''
  const inferred = BUG_ATTACHMENT_MIME_TYPES[extension] ?? 'application/octet-stream'
  const supplied = explicit?.trim().toLowerCase().split(';', 1)[0]
  const aliases = extension === 'jpg' || extension === 'jpeg'
    ? ['image/jpeg', 'image/jpg']
    : extension === 'md'
      ? ['text/markdown', 'text/plain']
      : [inferred]
  if (supplied && !aliases.includes(supplied)) throw new Error(`attachment MIME does not match extension: ${fileName}`)
  return supplied ?? inferred
}

function attachmentFileName(file: BugAttachmentFile): string {
  const actualName = basename(file.path)
  const name = basename(file.fileName?.trim() || actualName)
  if (!name || name === '.' || name === '..') throw new Error('invalid attachment file name')
  if (name !== actualName) throw new Error('attachment file name must match its path')
  if (!/\.(?:jpe?g|png|gif|mp4|log|txt|md)$/i.test(name)) throw new Error(`unsupported attachment format: ${name}`)
  return name
}

export async function uploadBugAttachments(
  files: readonly BugAttachmentFile[],
  productionId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<string[]> {
  const tokens: string[] = []
  try {
    for (const file of files) tokens.push(await uploadBugAttachmentFile(file, productionId, env))
    return tokens
  } catch (error) {
    await Promise.all(tokens.map((token) => cancelBugAttachmentUpload(token, productionId, env).catch(() => undefined)))
    throw error
  }
}

async function uploadBugAttachmentFile(file: BugAttachmentFile, productionId: string, env: NodeJS.ProcessEnv): Promise<string> {
  const fileName = attachmentFileName(file)
  let cursor = file.path
  while (cursor !== dirname(cursor)) {
    if ((await lstat(cursor)).isSymbolicLink()) throw new Error(`attachment path cannot contain a symlink: ${file.path}`)
    cursor = dirname(cursor)
  }
  const info = await stat(file.path)
  if (!info.isFile() || info.size <= 0 || !Number.isSafeInteger(info.size)) throw new Error(`invalid attachment file: ${file.path}`)
  const extension = fileName.toLowerCase().split('.').pop() ?? ''
  if (info.size > (BUG_ATTACHMENT_MAX_BYTES[extension] ?? 0)) throw new Error(`attachment exceeds size limit: ${fileName}`)
  const mimeType = attachmentMime(fileName, file.mimeType)
  const isLog = /\.(?:log|txt|md)$/i.test(fileName)
  const created = await brainJson('/brain/bug-attachment-uploads', {
    method: 'POST',
    body: JSON.stringify({ requestId: stableAttachmentRequestId(), productionId, fileName, mimeType, byteSize: info.size, originalMimeType: mimeType, originalByteSize: info.size, compressionStatus: isLog ? 'not_applicable' : 'not_compressed' }),
  }, env) as { token?: unknown }
  if (typeof created.token !== 'string' || !created.token) throw new Error('invalid attachment upload response')
  const token = created.token
  const handle = await open(file.path, 'r')
  const checksum = createHash('sha256')
  try {
    let offset = 0
    let partNumber = 1
    while (offset < info.size) {
      const length = Math.min(BUG_ATTACHMENT_PART_BYTES, info.size - offset)
      const buffer = Buffer.allocUnsafe(length)
      let read = 0
      while (read < length) {
        const result = await handle.read(buffer, read, length - read, offset + read)
        if (result.bytesRead === 0) throw new Error('attachment file changed while reading')
        read += result.bytesRead
      }
      checksum.update(buffer)
      const partChecksum = createHash('sha256').update(buffer).digest('hex')
      let response: Response | undefined
      for (let attempt = 0; attempt < 3; attempt += 1) {
        response = await brainResponse(`/brain/bug-attachment-uploads/${encodeURIComponent(token)}/parts/${partNumber}?productionId=${encodeURIComponent(productionId)}`, {
          method: 'PUT', body: buffer, headers: { 'Content-Type': 'application/octet-stream', 'Content-Range': `bytes ${offset}-${offset + length - 1}/${info.size}`, 'X-Content-SHA256': partChecksum },
        }, env)
        await response.arrayBuffer()
        if (response.ok) break
      }
      if (!response?.ok) throw new Error(`attachment upload HTTP ${response?.status ?? 500}`)
      offset += length
      partNumber += 1
    }
    const completed = await brainJson(`/brain/bug-attachment-uploads/${encodeURIComponent(token)}/complete`, { method: 'POST', body: JSON.stringify({ productionId, checksum: checksum.digest('hex') }) }, env) as { kind?: unknown }
    if (typeof completed.kind !== 'string') throw new Error('invalid attachment completion response')
    return token
  } catch (error) {
    await cancelBugAttachmentUpload(token, productionId, env).catch(() => undefined)
    throw error
  } finally {
    await handle.close()
  }
}

function stableAttachmentRequestId(): string {
  return randomUUID()
}

export async function cancelBugAttachmentUpload(token: string, productionId: string, env: NodeJS.ProcessEnv = process.env): Promise<void> {
  const response = await brainResponse(`/brain/bug-attachment-uploads/${encodeURIComponent(token)}?productionId=${encodeURIComponent(productionId)}`, { method: 'DELETE' }, env)
  await response.arrayBuffer()
  if (!response.ok && response.status !== 404) throw new Error(`attachment cancellation HTTP ${response.status}`)
}

export async function bugAttachmentTokensReady(tokens: readonly string[], productionId: string, env: NodeJS.ProcessEnv = process.env): Promise<boolean> {
  if (tokens.length === 0) return false
  for (const token of tokens) {
    const response = await brainResponse(`/brain/bug-attachment-uploads/${encodeURIComponent(token)}?productionId=${encodeURIComponent(productionId)}`, { method: 'GET' }, env).catch(() => null)
    if (!response?.ok) return false
    const body = await response.json().catch(() => null) as { status?: unknown; expiresAt?: unknown } | null
    if (body?.status !== 'ready' || typeof body.expiresAt !== 'string' || Date.parse(body.expiresAt) <= Date.now()) return false
  }
  return true
}

async function brainJson(
  path: string,
  init: RequestInit,
  env: NodeJS.ProcessEnv,
): Promise<unknown> {
  const response = await brainResponse(path, init, env)
  if (!response.ok) throw await brainHttpError(path, response)
  return response.json()
}

async function brainHttpError(path: string, response: Response): Promise<BrainHttpError> {
  let reason: string | undefined
  let message: string | undefined
  try {
    const body = await response.json() as { reason?: unknown; code?: unknown; message?: unknown }
    reason = typeof body.reason === "string" ? body.reason : typeof body.code === "string" ? body.code : undefined
    message = typeof body.message === "string" ? body.message : undefined
  } catch {
    // Keep the status-only fallback for non-JSON gateways.
  }
  return new BrainHttpError(path, response.status, reason, message)
}

async function brainResponse(
  path: string,
  init: RequestInit,
  env: NodeJS.ProcessEnv,
): Promise<Response> {
  const cfg = getBrainConfig(env)
  if (!cfg?.machineToken) throw new Error("brain not configured")
  return fetch(`${cfg.brainBaseUrl}${path}`, {
    ...init,
    headers: {
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      Authorization: `Bearer ${cfg.machineToken}`,
      ...init.headers,
    },
    signal: AbortSignal.timeout(cfg.timeoutMs),
  })
}

function parseTaskDraft(value: unknown, productionId: string, command?: TaskDraftCommand): TaskCommandDraftRecord {
  const draft = value as Record<string, unknown>
  if (typeof draft.id !== "string" || typeof draft.requestId !== "string" || draft.productionId !== productionId
    || typeof draft.command !== "string" || !["pending", "confirmed", "cancelled", "expired", "failed"].includes(String(draft.status)) || typeof draft.expiresAt !== "string"
    || typeof draft.createdAt !== "string" || (command && draft.command !== command)) {
    throw new Error("invalid task command draft response")
  }
  if (draft.payload !== undefined && (!draft.payload || typeof draft.payload !== "object" || Array.isArray(draft.payload))) {
    throw new Error("invalid task command draft payload")
  }
  const hasReceipt = typeof draft.contextReceiptId === "string" && draft.contextReceiptId.length > 0
  const hasTarget = typeof draft.contextTargetPublicId === "string" && draft.contextTargetPublicId.length > 0
  const hasExplicitNullBinding = draft.contextReceiptId === null && draft.contextTargetPublicId === null
  if (!(hasExplicitNullBinding || (hasReceipt && hasTarget))) {
    throw new Error("invalid task command draft context binding")
  }
  return draft as unknown as TaskCommandDraftRecord
}

export async function createTaskCommandDraft(
  input: {
    requestId: string
    productionId: string
    command: TaskDraftCommand
    payload: Record<string, unknown>
    sourceClient?: TaskCapabilitySourceClient
    contextReceiptId?: string
    contextTargetPublicId?: string
  },
  env: NodeJS.ProcessEnv = process.env,
): Promise<TaskCommandDraftRecord> {
  const parsed = await brainJson("/brain/task-command-drafts", { method: "POST", body: JSON.stringify(input) }, env)
  return parseTaskDraft(parsed, input.productionId, input.command)
}

export async function getTaskCommandDraft(
  productionId: string,
  draftId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<TaskCommandDraftRecord> {
  const path = `/brain/task-command-drafts/${encodeURIComponent(draftId)}?productionId=${encodeURIComponent(productionId)}`
  const parsed = await brainJson(path, { method: "GET" }, env)
  return parseTaskDraft(parsed, productionId)
}

export async function findTaskCommandDraftByRequest(
  productionId: string,
  requestId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<TaskCommandDraftRecord> {
  const path = `/brain/task-command-drafts/by-request?productionId=${encodeURIComponent(productionId)}&requestId=${encodeURIComponent(requestId)}`
  const parsed = await brainJson(path, { method: "GET" }, env)
  return parseTaskDraft(parsed, productionId)
}

export async function cancelTaskCommandDraft(
  productionId: string,
  draftId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<TaskCommandDraftRecord> {
  const path = `/brain/task-command-drafts/${encodeURIComponent(draftId)}/cancel`
  const parsed = await brainJson(path, { method: "POST", body: JSON.stringify({ productionId }) }, env)
  return parseTaskDraft(parsed, productionId)
}

export async function confirmTaskCommandDraft(
  productionId: string,
  draftId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<TaskCommandReceipt> {
  const path = `/brain/task-command-drafts/${encodeURIComponent(draftId)}/confirm`
  const parsed = await brainJson(path, { method: "POST", body: JSON.stringify({ productionId }) }, env) as { draft?: unknown; result?: unknown; replayed?: unknown }
  return {
    draft: parseTaskDraft(parsed.draft, productionId),
    result: parsed.result,
    replayed: parsed.replayed === true,
  }
}

export async function queryRequirements(
  productionId: string,
  filters: { id?: string; mine?: boolean; assigneeUserId?: string; priority?: string; status?: string; iterationId?: string; search?: string; plannedOverdue?: boolean; plannedFrom?: string; plannedTo?: string; cursor?: string; limit?: number } = {},
  env: NodeJS.ProcessEnv = process.env,
): Promise<{ items: RequirementWorkItem[]; total: number; nextCursor?: string; evaluatedAt?: string }> {
  if (filters.id) {
    const parsed = await brainJson(`/brain/requirements/${encodeURIComponent(filters.id)}?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env)
    return { items: [parseRequirementWorkItem(parsed, productionId)], total: 1 }
  }
  const params = new URLSearchParams({ productionId })
  for (const [key, value] of Object.entries(filters)) if (value !== undefined) params.set(key, String(value))
  const parsed = await brainJson(`/brain/requirements?${params}`, { method: "GET" }, env) as { items?: unknown; total?: unknown; nextCursor?: unknown; evaluatedAt?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid requirements response")
  const items = parsed.items.map((item) => parseRequirementWorkItem(item, productionId))
  return {
    items,
    total: typeof parsed.total === "number" ? parsed.total : items.length,
    ...(typeof parsed.nextCursor === "string" && parsed.nextCursor ? { nextCursor: parsed.nextCursor } : {}),
    ...(typeof parsed.evaluatedAt === "string" ? { evaluatedAt: parsed.evaluatedAt } : {}),
  }
}

export async function queryRequirementActivity(
  productionId: string,
  requirementId: string,
  optionsOrEnv: RequirementActivityQueryOptions | NodeJS.ProcessEnv = {},
  env: NodeJS.ProcessEnv = process.env,
): Promise<RequirementActivityResult> {
  const options = isRequirementActivityQueryOptions(optionsOrEnv) ? optionsOrEnv : {}
  const runtimeEnv = isRequirementActivityQueryOptions(optionsOrEnv) ? env : optionsOrEnv
  const base = `/brain/requirements/${encodeURIComponent(requirementId)}`
  const activityParams = new URLSearchParams({ productionId })
  const commentParams = new URLSearchParams({ productionId })
  if (options.activityCursor) activityParams.set("cursor", options.activityCursor)
  if (options.commentCursor) commentParams.set("cursor", options.commentCursor)
  if (options.limit !== undefined) { activityParams.set("limit", String(options.limit)); commentParams.set("limit", String(options.limit)) }
  const [activity, comments] = await Promise.all([
    options.kind === "comments"
      ? Promise.resolve({ items: [] })
      : brainJson(`${base}/activity?${activityParams}`, { method: "GET" }, runtimeEnv) as Promise<{ items?: unknown; nextCursor?: unknown }>,
    options.kind === "changes"
      ? Promise.resolve({ items: [] })
      : brainJson(`${base}/comments?${commentParams}`, { method: "GET" }, runtimeEnv) as Promise<{ items?: unknown; nextCursor?: unknown }>,
  ])
  return { comments: parseRequirementActivityPage(comments), changes: parseRequirementActivityPage(activity) }
}

function isRequirementActivityQueryOptions(value: RequirementActivityQueryOptions | NodeJS.ProcessEnv): value is RequirementActivityQueryOptions {
  if (!value || typeof value !== "object") return false
  const record = value as Record<string, unknown>
  if (Object.prototype.hasOwnProperty.call(record, "CEREBRO_BRAIN_URL")
    || Object.prototype.hasOwnProperty.call(record, "CEREBRO_MACHINE_TOKEN")
    || Object.prototype.hasOwnProperty.call(record, "CEREBRO_ALLOW_INSECURE_HTTP")) return false
  return Object.keys(record).length === 0
    || Object.prototype.hasOwnProperty.call(record, "kind")
    || Object.prototype.hasOwnProperty.call(record, "activityCursor")
    || Object.prototype.hasOwnProperty.call(record, "commentCursor")
    || Object.prototype.hasOwnProperty.call(record, "limit")
}

function parseRequirementActivityPage(value: unknown): RequirementActivityPage {
  if (Array.isArray(value)) return { items: value }
  const page = value as { items?: unknown; nextCursor?: unknown }
  if (!page || !Array.isArray(page.items)) throw new Error("invalid requirement activity response")
  return {
    items: page.items,
    ...(typeof page.nextCursor === "string" && page.nextCursor ? { nextCursor: page.nextCursor } : {}),
  }
}

export async function queryRequirementTree(
  productionId: string,
  rootId?: string,
  depth?: number,
  env: NodeJS.ProcessEnv = process.env,
): Promise<RequirementWorkItem[]> {
  const params = new URLSearchParams({ productionId })
  if (rootId) params.set("rootId", rootId)
  if (depth !== undefined) params.set("depth", String(depth))
  const parsed = await brainJson(`/brain/requirements/tree?${params}`, { method: "GET" }, env) as { items?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid requirement tree response")
  return parsed.items.map((item) => parseRequirementWorkItem(item, productionId))
}

export async function queryRequirementLinks(
  productionId: string,
  requirementId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<RequirementBugLink[]> {
  if (!isRequirementPublicId(requirementId)) throw new Error("需求 ID 必须使用产品限定的公共 ID")
  const parsed = await brainJson(`/brain/requirements/${encodeURIComponent(requirementId.toUpperCase())}/bugs?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env) as { items?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid requirement links response")
  return parsed.items.flatMap((value) => {
    const item = value as Record<string, unknown>
    return typeof item.relationId === "string" && typeof item.requirementId === "string" && typeof item.bugId === "string" && typeof item.linkedAt === "string"
      ? [item as unknown as RequirementBugLink]
      : []
  })
}

/** Read the product iteration list through the dedicated wire contract. */
export async function queryIterations(
  productionId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<ProductIteration[]> {
  const parsed = await brainJson(`/brain/iterations?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env) as { items?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid iterations response")
  return parsed.items.map((item) => parseProductIteration(item, productionId))
}

export const listIterations = queryIterations

/** Read one iteration by its UUID. */
export async function queryIteration(
  productionId: string,
  iterationId: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<ProductIteration> {
  const parsed = await brainJson(`/brain/iterations/${encodeURIComponent(iterationId)}?productionId=${encodeURIComponent(productionId)}`, { method: "GET" }, env)
  return parseProductIteration(parsed, productionId)
}

export const getIteration = queryIteration

/** Read the append-only activity stream for one iteration. */
export async function queryIterationActivity(
  productionId: string,
  iterationId: string,
  optionsOrLimit: { cursor?: string; limit?: number } | number = {},
  env: NodeJS.ProcessEnv = process.env,
): Promise<{ items: unknown[]; nextCursor?: string }> {
  const options = typeof optionsOrLimit === "number" ? { limit: optionsOrLimit } : optionsOrLimit
  const params = new URLSearchParams({ productionId })
  if (options.cursor) params.set("cursor", options.cursor)
  if (options.limit !== undefined) params.set("limit", String(options.limit))
  const parsed = await brainJson(`/brain/iterations/${encodeURIComponent(iterationId)}/activity?${params}`, { method: "GET" }, env) as { items?: unknown; nextCursor?: unknown }
  if (!Array.isArray(parsed.items)) throw new Error("invalid iteration activity response")
  return { items: parsed.items, ...(typeof parsed.nextCursor === "string" && parsed.nextCursor ? { nextCursor: parsed.nextCursor } : {}) }
}

export const listIterationActivity = queryIterationActivity

function parseRequirementWorkItem(value: unknown, productionId: string): RequirementWorkItem {
  const item = value as Record<string, unknown>
  if (typeof item.id !== "string" || typeof item.publicId !== "string" || !isRequirementPublicId(item.publicId)
    || item.productionId !== productionId || typeof item.title !== "string" || typeof item.assigneeUserId !== "string"
    || typeof item.priority !== "string" || typeof item.status !== "string" || typeof item.version !== "number"
    || typeof item.createdAt !== "string" || typeof item.updatedAt !== "string") throw new Error("invalid requirement response")
  return item as unknown as RequirementWorkItem
}

function parseProductIteration(value: unknown, productionId: string): ProductIteration {
  const item = value as Record<string, unknown>
  const dateFields = ["createdAt", "updatedAt"]
  const nullableDateFields = ["startsAt", "endsAt"]
  const validDate = (field: string): boolean => typeof item[field] === "string" && !Number.isNaN(Date.parse(item[field] as string))
  if (!item || typeof item.id !== "string" || typeof item.productionId !== "string" || item.productionId !== productionId
    || typeof item.name !== "string" || (item.code !== null && typeof item.code !== "string")
    || (item.goal !== null && typeof item.goal !== "string") || (item.ownerUserId !== null && typeof item.ownerUserId !== "string")
    || !["planned", "in_progress", "closed"].includes(String(item.status)) || typeof item.isRequirementPool !== "boolean"
    || typeof item.version !== "number" || !Number.isInteger(item.version) || item.version < 1
    || (item.startsAt !== null && !validDate("startsAt")) || (item.endsAt !== null && !validDate("endsAt"))
    || typeof item.position !== "number" || !Number.isInteger(item.position)
    || (item.createdBy !== null && typeof item.createdBy !== "string")
    || dateFields.some((field) => !validDate(field)) || nullableDateFields.some((field) => item[field] !== null && !validDate(field))
    || typeof item.completedItems !== "number" || !Number.isInteger(item.completedItems) || item.completedItems < 0
    || typeof item.totalItems !== "number" || !Number.isInteger(item.totalItems) || item.totalItems < 0
    || typeof item.progressPercent !== "number" || !Number.isInteger(item.progressPercent) || item.progressPercent < 0 || item.progressPercent > 100) {
    throw new Error("invalid iteration response")
  }
  return item as unknown as ProductIteration
}

/** TaskFetcher 实接：需求查询走新的单一需求事实源。 */
export const brainTaskFetcher: TaskFetcher = async (context): Promise<string> => {
  const [productions, repoContext] = await Promise.all([
    fetchVisibleProductions(),
    resolveRepoContext(context.cwd, context.machineId),
  ])
  if (!repoContext) return "[Synapse] 当前目录未绑定产品，请在已登记的产品仓库目录中查询任务。"
  const production = productions.find((item) => item.id === repoContext.productionId)
  if (!production) return "[Synapse] 当前目录绑定的产品不可见，无法查询任务。"
  const result = await queryRequirements(production.id, context.kind === "my_tasks" ? { mine: true } : {})
  const items = result.items
  if (items.length === 0) return ""
  const lines = items.map((item) => {
    return `- ${item.publicId} ${item.title} · ${item.status} · ${item.priority} · 负责人 ${item.assigneeUserId} · 迭代 ${item.iterationId ?? "需求池"} · 工时 ${item.estimateDays ?? "未估"} 人/天 · 计划 ${item.plannedStartAt ?? "未定"} ~ ${item.plannedEndAt ?? "未定"} · 创建 ${item.createdAt} · 更新 ${item.updatedAt}`
  })
  return `${context.kind === "my_tasks" ? "我负责的需求" : "当前产品需求"}（共 ${result.total} 项）：\n${lines.join("\n")}${result.nextCursor ? `\n下一页游标：${result.nextCursor}` : ""}`
}

// ── 4. searchKnowledge：inject 每轮通过统一 REST 端点检索 ─────
// 返回结构映射成 KhSearchResult，core/inject.ts 下游保持稳定。
//
// 降级(fail-closed,绝不打生产):brain 未配置/无 token → transport_unavailable;
// 网络错/5xx/解析失败 → kh_returned_error，确定的 4xx 原样保留。均返回 KhDegraded,不抛(不阻断本轮)。

/** /api/v1/search 响应条目(取 inject 需要的字段;其余忽略)。 */
interface RestSearchItem {
  id?: unknown
  title?: unknown
  content?: unknown
  category?: unknown
  tags?: unknown
  confidence?: unknown
  matchSource?: unknown
  relevanceScore?: unknown
}
interface RestSearchResponse {
  results?: RestSearchItem[]
  totalFound?: number
}

/**
 * 每轮向量检索:POST <brainBaseUrl>/api/v1/knowledge/search + Bearer machine token。
 * 返回 KhSearchResult(ok:true, insights[]) 或 KhDegraded(ok:false)。
 *
 * @param query 用户本轮输入
 * @param limit top-k
 * @param env   环境变量注入(便于测试 mock)
 */
export async function searchKnowledge(
  query: string,
  limit: number,
  env: NodeJS.ProcessEnv = process.env,
): Promise<KhSearchResult | KhDegraded> {
  const q = (query ?? '').trim()
  if (!q) {
    return { ok: false, reason: 'invalid_input', message: 'empty query' }
  }

  const cfg = getBrainConfig(env)
  if (!cfg || !cfg.machineToken) {
    // 未配置 brain / 无 token → fail-closed 降级(绝不默认打生产)
    return { ok: false, reason: 'transport_unavailable', message: 'brain not configured' }
  }

  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/search`, {
    method: 'POST', body: JSON.stringify({ query: q, limit }),
  }, cfg)
  if (!('data' in r)) return r
  const parsed = r.data as RestSearchResponse

  const rawResults = Array.isArray(parsed.results) ? parsed.results : []
  const insights: KhInsight[] = rawResults.map((r) => ({
    id: typeof r.id === 'string' ? r.id : '',
    title: typeof r.title === 'string' ? r.title : '',
    content: typeof r.content === 'string' ? r.content : '',
    category: typeof r.category === 'string' ? r.category : '',
    scope: '', // REST /search 不返回 scope;inject 不用,留空
    confidence: typeof r.confidence === 'number' ? r.confidence : 0,
    tags: Array.isArray(r.tags) ? r.tags.filter((t): t is string => typeof t === 'string') : undefined,
    source: typeof r.matchSource === 'string' ? r.matchSource : undefined,
  }))

  return { ok: true, query: q, insights }
}

// ── 5. sedimentInsight：report 通过统一 REST 端点沉淀知识 ─────
// 主脑侧复用 insightExtraction 自动抽 title/tags、去重合并和写入。
//
// 降级(不阻断 report):brain 未配置/无 token/网络错/非 2xx → { ok:false }(不抛)。

export interface SedimentResult {
  ok: boolean
  /** 写入的 KH 条目 id(created/skipped 时有) */
  id?: string
  /** created / skipped(去重命中)/ failed */
  action?: 'created' | 'merged' | 'skipped' | 'failed'
  /** 主脑主动跳过时的原因；用于区分低价值拒绝与相似知识判重。 */
  skipReason?: string
  /** 失败时的结构化原因；确定性 4xx 会附带 httpStatus。 */
  reason?: KhDegraded['reason']
  message?: string
  httpStatus?: number
}

/**
 * 沉淀一条经验到主脑:POST <brainBaseUrl>/api/v1/knowledge/sediment + Bearer machine token。
 * @param insight    已总结的经验文本(问题→原因→方案)
 * @param category   分类提示(可选;主脑不认则自动分类)
 * @param cwd        Synapse daemon 工作目录(可选;主脑侧用于 repo 归属推断)
 * @param machineId  Cortex 独立 machineId(可选;与 per-user token 正交,用于 repo_clones 匹配)
 * @param captureMode 显式保存(explicit)或自动沉淀(automatic);调用方必须明确传入
 * @param env        环境变量注入(便于测试 mock)
 */
export async function sedimentInsight(
  insight: string,
  category: string | undefined,
  cwd: string | undefined,
  machineId: string | undefined,
  captureMode: 'explicit' | 'automatic',
  env: NodeJS.ProcessEnv = process.env,
): Promise<SedimentResult> {
  const text = (insight ?? '').trim()
  if (!text) return { ...degraded('invalid_input', 'empty insight'), action: 'failed' }

  const cfg = getBrainConfig(env)
  if (!cfg || !cfg.machineToken) {
    // 未配置 brain / 无 token → 降级(不阻断 report)
    return { ...degraded('transport_unavailable', 'brain not configured'), action: 'failed' }
  }

  // 构造请求体:insight + 可选 category/cwd/machineId
  const bodyObj: Record<string, string> = { insight: text, captureMode }
  if (category) bodyObj['category'] = category
  if (cwd) bodyObj['cwd'] = cwd
  if (machineId) bodyObj['machineId'] = machineId

  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/sediment`, {
    method: 'POST', body: JSON.stringify(bodyObj),
  }, cfg)
  if (!('data' in r)) return { ...r, action: 'failed' }
  const parsed = r.data as { ok?: unknown; id?: unknown; action?: unknown; reason?: unknown }

  const ok = parsed.ok === true
  const action =
    parsed.action === 'created' || parsed.action === 'merged' || parsed.action === 'skipped'
      ? parsed.action
      : ok ? 'created' : 'failed'
  return {
    ok,
    id: typeof parsed.id === 'string' ? parsed.id : undefined,
    action,
    skipReason: typeof parsed.reason === 'string' ? parsed.reason : undefined,
  }
}

// ── 6. 游标语义类型引用（不变） ─────────────────────────────────────

const _cursorSanityCheck: Cursor = 'cursor-is-string-monotonic-event-id'
void _cursorSanityCheck

// ── Phase 6: 补齐主动读写 12 工具 REST 客户端函数 ──────────────────
//
// 所有函数遵循同一降级约定:
//   · 未配置 brain / 无 token → KhDegraded(transport_unavailable)
//   · 网络错 / 非 2xx / 解析失败 → KhDegraded(kh_returned_error)
//   · 成功 → { ok: true, ... }
//
// 使用最终路径（Phase 5 重命名后）：
//   search    → POST /api/v1/knowledge/search    (已在 searchKnowledge 更新)
//   sediment  → POST /api/v1/knowledge/sediment  (已有 sedimentInsight)
//   新增:
//   recent    → GET  /api/v1/knowledge/recent
//   add       → POST /api/v1/knowledge
//   update    → PUT  /api/v1/knowledge/:id
//   flag      → POST /api/v1/knowledge/:id/deprecate
//   delete    → DELETE /api/v1/knowledge/:id
//   promote   → POST /api/v1/knowledge/:id/promote
//   demote    → POST /api/v1/knowledge/:id/demote
//   mem-get   → GET  /api/v1/me/working-memory
//   mem-set   → POST /api/v1/me/working-memory
//   pref-set  → PUT  /api/v1/me/preferences
//   context   → GET  /api/v1/me/context

import type { BrainConfig } from './brain-config.ts'

export const KNOWLEDGE_CAPABILITY_ALLOWLIST = KNOWLEDGE_CAPABILITY_NAMES
export type KnowledgeIntentResponse = WireKnowledgeIntentResponse

type KnowledgeIntentResponseConsumer = Pick<
  WireKnowledgeIntentResponse,
  keyof WireKnowledgeIntentResponse
> & Partial<Pick<
  Extract<WireKnowledgeIntentResponse, { operation: unknown }>,
  'selectedCapability' | 'operation'
>>

export type KnowledgeIntentResult = { ok: true; response: KnowledgeIntentResponseConsumer } | KhDegraded

/** 降级结果工具函数 */
function degraded(reason: KhDegraded['reason'], message: string): KhDegraded {
  return { ok: false, reason, message }
}

/** 从 getBrainConfig 取配置，缺失时返回 KhDegraded */
function requireCfg(env: NodeJS.ProcessEnv): BrainConfig | KhDegraded {
  const cfg = getBrainConfig(env)
  if (!cfg || !cfg.machineToken) {
    return degraded('transport_unavailable', 'brain not configured')
  }
  return cfg
}

/** 简化 fetch wrapper — 返回 parsed JSON 或 KhDegraded */
async function brainFetch(
  url: string,
  opts: RequestInit,
  cfg: BrainConfig,
  policy: { opaqueObjectAccess?: boolean; signal?: AbortSignal; timeoutMs?: number } = {},
): Promise<{ data: unknown } | KhDegraded> {
  let resp: Response
  const timeoutSignal = AbortSignal.timeout(policy.timeoutMs ?? cfg.timeoutMs)
  try {
    resp = await fetch(url, {
      ...opts,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.machineToken}`,
        ...(opts.headers as Record<string, string> ?? {}),
      },
      signal: policy.signal
        ? AbortSignal.any([timeoutSignal, policy.signal])
        : timeoutSignal,
    })
  } catch (err) {
    if (policy.signal?.aborted) throw policy.signal.reason ?? err
    return degraded('kh_returned_error', `fetch failed: ${err instanceof Error ? err.message : String(err)}`)
  }
  if (!resp.ok) {
    if (policy.opaqueObjectAccess && (resp.status === 403 || resp.status === 404)) {
      return { ...degraded('permission_denied', 'UNAVAILABLE'), httpStatus: resp.status }
    }
    let detail = ''
    try {
      const body = await resp.json() as { message?: unknown }
      if (typeof body.message === 'string' && body.message.trim()) detail = `: ${body.message}`
    } catch {
      // 非 JSON 错误页不改变确定的 HTTP 状态语义。
    }
    const reason = resp.status === 400 ? 'validation_error'
      : resp.status === 401 || resp.status === 403 ? 'permission_denied'
      : resp.status === 404 ? 'not_found'
      : 'kh_returned_error'
    return { ...degraded(reason, `HTTP ${resp.status}${detail}`), httpStatus: resp.status }
  }
  try {
    const data = await resp.json()
    return { data }
  } catch {
    return degraded('kh_returned_error', 'invalid JSON response')
  }
}

export function capabilityAllowlistHash(allowlist: readonly string[] = KNOWLEDGE_CAPABILITY_ALLOWLIST): string {
  return sha256(JSON.stringify([...allowlist]))
}

export function buildKnowledgeIntentRequest(req: InjectRequest): KnowledgeIntentRequest {
  const currentText = limitText(redactSecrets(normalizeIntentText(req.user_input)), CURRENT_TEXT_LIMIT)
  const allowlist = [...KNOWLEDGE_CAPABILITY_ALLOWLIST]
  const turnId = req.turn_id?.trim() || stableFallbackTurnId({
    client: req.client,
    sessionId: req.session_id,
    messageId: req.message_id,
    conversationId: req.conversation_id,
    currentText,
  })
  const surface = intentSurface(req.event)
  const requestIdempotencyKey = sha256([
    req.client,
    surface,
    req.session_id || 'unknown-session',
    turnId,
    currentText,
    capabilityAllowlistHash(allowlist),
  ].join('\n'))
  return {
    client: req.client,
    surface,
    sessionId: req.session_id || 'unknown-session',
    turnId,
    conversationId: req.conversation_id,
    currentText,
    transcriptTail: sanitizeTranscriptTail(req.transcript_tail),
    supportRails: sanitizeSupportRails(req.support_rails),
    capabilityAllowlist: allowlist,
    requestIdempotencyKey,
  }
}

export async function resolveKnowledgeIntent(
  request: KnowledgeIntentRequest,
  env: NodeJS.ProcessEnv = process.env,
): Promise<KnowledgeIntentResult> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/intents`, {
    method: 'POST',
    body: JSON.stringify(request),
  }, cfg)
  if (!('data' in r)) return r
  return parseKnowledgeIntentResponse(r.data)
}

export async function getKnowledgeIntent(
  id: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<KnowledgeIntentResult> {
  const intentId = id.trim()
  if (!intentId) return degraded('invalid_input', 'empty intent id')
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/intents/${encodeURIComponent(intentId)}`, {
    method: 'GET',
  }, cfg)
  if (!('data' in r)) return r
  return parseKnowledgeIntentResponse(r.data)
}

export async function fetchKnowledgeCapabilityCatalog(
  env: NodeJS.ProcessEnv = process.env,
): Promise<{ ok: true; catalogue: KnowledgeCapabilityCatalog } | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const result = await brainFetch(`${cfgOrErr.brainBaseUrl}/api/v1/knowledge/capabilities`, {
    method: 'GET',
  }, cfgOrErr)
  if (!('data' in result)) return result
  const parsed = KnowledgeCapabilityCatalogSchema.safeParse(result.data)
  return parsed.success
    ? { ok: true, catalogue: parsed.data }
    : degraded('kh_returned_error', 'capability catalogue failed shared wire schema validation')
}

export async function executeKnowledgeAgentRequest(
  request: KnowledgeAgentExecuteRequest,
  env: NodeJS.ProcessEnv = process.env,
): Promise<{ ok: true; response: KnowledgeAgentExecuteResponse } | KhDegraded> {
  const parsedRequest = KnowledgeAgentExecuteRequestSchema.safeParse(request)
  if (!parsedRequest.success) {
    return degraded('invalid_input', 'agent execute request failed shared wire schema validation')
  }
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const result = await brainFetch(`${cfgOrErr.brainBaseUrl}/api/v1/knowledge/execute`, {
    method: 'POST',
    body: JSON.stringify(parsedRequest.data),
  }, cfgOrErr)
  if (!('data' in result)) return result
  const parsedResponse = KnowledgeAgentExecuteResponseSchema.safeParse(result.data)
  return parsedResponse.success
    ? { ok: true, response: parsedResponse.data }
    : degraded('kh_returned_error', 'agent execute response failed shared wire schema validation')
}

export interface TaskCatalogueScope {
  productionId?: string
  publicId?: string
}

export async function fetchTaskCapabilityCatalogue(
  scopeOrProductionId: TaskCatalogueScope | string,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<{ ok: true; catalogue: TaskCapabilityCatalogue } | KhDegraded> {
  const scope = typeof scopeOrProductionId === 'string'
    ? { productionId: scopeOrProductionId }
    : scopeOrProductionId
  if (!scope.productionId && !scope.publicId) return degraded('invalid_input', 'task catalogue requires productionId or publicId')
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const params = new URLSearchParams()
  if (scope.productionId) params.set('productionId', scope.productionId)
  if (scope.publicId) params.set('publicId', scope.publicId)
  const result = await brainFetch(
    `${cfgOrErr.brainBaseUrl}/brain/task-capabilities?${params}`,
    { method: 'GET' },
    cfgOrErr,
    { signal },
  )
  if (!('data' in result)) return result
  const parsed = TaskCapabilityCatalogueSchema.safeParse(result.data)
  if (!parsed.success) return degraded('kh_returned_error', 'task capability catalogue failed shared wire schema validation')
  if (scope.productionId && parsed.data.productionId !== scope.productionId) {
    return degraded('kh_returned_error', 'task capability catalogue production does not match the requested product')
  }
  return { ok: true, catalogue: parsed.data }
}

export async function executeTaskCapabilityRequest(
  request: TaskCapabilityExecuteRequest,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
  materializationLimits?: TaskAttachmentMaterializationLimits,
): Promise<{ ok: true; response: TaskCapabilityExecuteResponse } | KhDegraded> {
  const parsedRequest = TaskCapabilityExecuteRequestSchema.safeParse(request)
  if (!parsedRequest.success) return degraded('invalid_input', 'task capability execute request failed shared wire schema validation')
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const result = await brainFetch(`${cfgOrErr.brainBaseUrl}${TASK_CAPABILITY_EXECUTE_PATH}`, {
    method: 'POST',
    body: JSON.stringify(parsedRequest.data),
  }, cfgOrErr, { timeoutMs: TASK_CAPABILITY_EXECUTE_TIMEOUT_MS, signal })
  if (!('data' in result)) return result
  const parsedResponse = TaskCapabilityExecuteResponseSchema.safeParse(result.data)
  if (!parsedResponse.success) return degraded('kh_returned_error', 'task capability execute response failed shared wire schema validation')
  if (parsedResponse.data.command !== parsedRequest.data.command) {
    return degraded('kh_returned_error', 'task capability response command does not match the request')
  }
  if (parsedResponse.data.kind === 'draft'
    && !taskDraftContextEchoMatches(parsedRequest.data, parsedResponse.data)) {
    return degraded('kh_returned_error', 'task capability draft context binding does not exactly echo the trusted request')
  }
  if (parsedResponse.data.kind === 'result' && parsedResponse.data.command === 'bug.attachment.get') {
    try {
      return { ok: true, response: await materializeTaskAttachment(parsedResponse.data, cfgOrErr, env, signal, materializationLimits) }
    } catch (error) {
      return degraded('kh_returned_error', `bug attachment materialization failed: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  return { ok: true, response: parsedResponse.data }
}

/** Require Cerebro to acknowledge every trusted draft field, including the
 * explicit null form used by legacy standalone creates and iteration writes. */
export function taskDraftContextEchoMatches(
  request: TaskCapabilityExecuteRequest,
  response: Extract<TaskCapabilityExecuteResponse, { kind: 'draft' }>,
): boolean {
  const requestRecord = request as TaskCapabilityExecuteRequest & {
    contextReceiptId?: string | null
    contextTargetPublicId?: string | null
    sourceClient?: TaskCapabilitySourceClient | null
  }
  return response.contextReceiptId === (requestRecord.contextReceiptId ?? null)
    && response.contextTargetPublicId === (requestRecord.contextTargetPublicId ?? null)
    && response.sourceClient === (requestRecord.sourceClient ?? null)
}

export type WorkItemContextTransportResult<T> = { ok: true; value: T } | KhDegraded

/** Read one or more work-item context pages using the frozen shared wire schema. */
export async function readWorkItemContextPage(
  input: WorkItemContextReadInput,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<WorkItemContextTransportResult<WorkItemContextReadResponse>> {
  return postWorkItemContext(
    WORK_ITEM_CONTEXT_READ_PATH,
    input,
    WorkItemContextReadInputSchema,
    WorkItemContextReadResponseSchema,
    "work item context read",
    env,
    signal,
  )
}

/** Read exact document revisions inside the fixed readSnapshotId returned by the inventory call. */
export async function readWorkItemContextDocuments(
  input: WorkItemContextDocumentsReadInput,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<WorkItemContextTransportResult<WorkItemContextDocumentsReadResponse>> {
  return postWorkItemContext(
    WORK_ITEM_CONTEXT_DOCUMENTS_READ_PATH,
    input,
    WorkItemContextDocumentsReadInputSchema,
    WorkItemContextDocumentsReadResponseSchema,
    "work item context document read",
    env,
    signal,
  )
}

/** Persist the server-owned processing receipt after the complete inventory and actual injection are known. */
export async function createWorkItemContextReceipt(
  input: WorkItemContextReceiptCreateInput,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<WorkItemContextTransportResult<WorkItemContextReceipt>> {
  return postWorkItemContext(
    WORK_ITEM_CONTEXT_RECEIPT_CREATE_PATH,
    input,
    WorkItemContextReceiptCreateInputSchema,
    WorkItemContextReceiptSchema,
    "work item context receipt create",
    env,
    signal,
  )
}

export async function ignoreWorkItemContextMissing(
  input: WorkItemContextReceiptIgnoreInput,
  env: NodeJS.ProcessEnv = process.env,
): Promise<WorkItemContextTransportResult<WorkItemContextReceipt>> {
  const result = await postWorkItemContext(
    bindContextReceiptPath(WORK_ITEM_CONTEXT_RECEIPT_IGNORE_PATH, input.contextReceiptId),
    input,
    WorkItemContextReceiptIgnoreInputSchema,
    WorkItemContextReceiptSchema,
    "work item context missing ignore",
    env,
  )
  if (result.ok && (result.value.contextReceiptId !== input.contextReceiptId
    || input.missingKeys.some((missingKey) => !result.value.ignoredMissing.some((ignored) => (
      ignored.targetPublicId === input.targetPublicId && ignored.missingKey === missingKey
    ))))) {
    return degraded("kh_returned_error", "work item context ignore response did not acknowledge the requested receipt and missing keys")
  }
  return result
}

export async function supplementWorkItemContextReceipt(
  input: WorkItemContextReceiptSupplementInput,
  env: NodeJS.ProcessEnv = process.env,
): Promise<WorkItemContextTransportResult<WorkItemContextReceipt>> {
  const parsedInput = WorkItemContextReceiptSupplementInputSchema.safeParse(input)
  if (!parsedInput.success) {
    return degraded("invalid_input", "work item context receipt supplement request failed shared wire schema validation")
  }
  const expected = parsedInput.data
  const result = await postWorkItemContext(
    bindContextReceiptPath(WORK_ITEM_CONTEXT_RECEIPT_SUPPLEMENT_PATH, expected.contextReceiptId),
    expected,
    WorkItemContextReceiptSupplementInputSchema,
    WorkItemContextReceiptSupplementResponseSchema,
    "work item context receipt supplement",
    env,
  )
  if (!result.ok) return result
  const { receipt, supplement } = result.value
  const acknowledged = receipt.contextReceiptId === expected.contextReceiptId
    && supplement.requestId === expected.requestId
    && supplement.targetPublicId === expected.targetPublicId
    && supplement.sourcePublicId === expected.sourcePublicId
    && sameStrings(supplement.replacesMissingKeys, expected.replacesMissingKeys)
    && supplement.contentHash.toLowerCase() === sha256(expected.content)
  return acknowledged
    ? { ok: true, value: receipt }
    : degraded("kh_returned_error", "work item context supplement response did not exactly acknowledge the requested receipt, target, source, missing keys, and content")
}

export async function validateWorkItemContextReceipt(
  input: WorkItemContextReceiptValidateInput,
  env: NodeJS.ProcessEnv = process.env,
  signal?: AbortSignal,
): Promise<WorkItemContextTransportResult<WorkItemContextReceiptValidation>> {
  const result = await postWorkItemContext(
    bindContextReceiptPath(WORK_ITEM_CONTEXT_RECEIPT_VALIDATE_PATH, input.contextReceiptId),
    input,
    WorkItemContextReceiptValidateInputSchema,
    WorkItemContextReceiptValidationSchema,
    "work item context receipt validate",
    env,
    signal,
  )
  return result.ok && result.value.contextReceiptId !== input.contextReceiptId
    ? degraded("kh_returned_error", "work item context validation response did not match the requested receipt")
    : result
}

function bindContextReceiptPath(path: string, contextReceiptId: string): string {
  return path.replace(":contextReceiptId", encodeURIComponent(contextReceiptId))
}

function sameStrings(actual: readonly string[], expected: readonly string[]): boolean {
  return actual.length === expected.length && actual.every((value, index) => value === expected[index])
}

async function postWorkItemContext<TInput, TOutput>(
  path: string,
  input: TInput,
  inputSchema: { safeParse(value: unknown): { success: true; data: TInput } | { success: false } },
  outputSchema: { safeParse(value: unknown): { success: true; data: TOutput } | { success: false } },
  operation: string,
  env: NodeJS.ProcessEnv,
  signal?: AbortSignal,
): Promise<WorkItemContextTransportResult<TOutput>> {
  const parsedInput = inputSchema.safeParse(input)
  if (!parsedInput.success) return degraded("invalid_input", `${operation} request failed shared wire schema validation`)
  const cfgOrErr = requireCfg(env)
  if (!("brainBaseUrl" in cfgOrErr)) return cfgOrErr
  const result = await brainFetch(`${cfgOrErr.brainBaseUrl}${path}`, {
    method: "POST",
    body: JSON.stringify(parsedInput.data),
  }, cfgOrErr, { opaqueObjectAccess: true, signal })
  if (!("data" in result)) return result
  const parsedOutput = outputSchema.safeParse(result.data)
  return parsedOutput.success
    ? { ok: true, value: parsedOutput.data }
    : degraded("kh_returned_error", `${operation} response failed shared wire schema validation`)
}

function parseKnowledgeIntentResponse(data: unknown): KnowledgeIntentResult {
  const parsed = KnowledgeIntentResponseSchema.safeParse(data)
  if (!parsed.success) {
    return degraded('kh_returned_error', 'intent response failed shared wire schema validation')
  }
  return { ok: true, response: parsed.data }
}

function normalizeIntentText(text: string): string {
  return (text ?? '').replace(/\s+/g, ' ').trim()
}

const CURRENT_TEXT_LIMIT = 16_000
const TRANSCRIPT_TEXT_LIMIT = 2_000
const TRANSCRIPT_TAIL_LIMIT = 8
const SUPPORT_RAILS_TEXT_LIMIT = 2_000
const SUPPORT_RAILS_ARRAY_LIMIT = 12
const SUPPORT_RAILS_DEPTH_LIMIT = 4
const SUPPORT_RAILS_KEYS = new Set([
  'constraints',
  'preferences',
  'workingMemory',
  'working_memory',
  'memory',
  'summary',
  'context',
  'injectContext',
  'inject_context',
])

function sanitizeTranscriptTail(
  tail: InjectRequest['transcript_tail'],
): KnowledgeIntentRequest['transcriptTail'] {
  if (!Array.isArray(tail)) return []
  return tail.slice(-TRANSCRIPT_TAIL_LIMIT).map((entry) => ({
    role: limitText(String(entry.role || 'unknown'), 64),
    text: limitText(redactSecrets(String(entry.text ?? '')), TRANSCRIPT_TEXT_LIMIT),
  }))
}

function sanitizeSupportRails(
  rails: InjectRequest['support_rails'],
): KnowledgeIntentRequest['supportRails'] {
  if (!rails || typeof rails !== 'object' || Array.isArray(rails)) return {}
  const sanitized: Record<string, unknown> = {}
  for (const key of Object.keys(rails).sort()) {
    if (!SUPPORT_RAILS_KEYS.has(key)) continue
    const value = sanitizeSupportRailValue(rails[key], 0)
    if (value !== undefined) sanitized[key] = value
  }
  return sanitized
}

function sanitizeSupportRailValue(value: unknown, depth: number): unknown {
  if (depth > SUPPORT_RAILS_DEPTH_LIMIT) return undefined
  if (typeof value === 'string') return limitText(redactSecrets(value), SUPPORT_RAILS_TEXT_LIMIT)
  if (typeof value === 'number' || typeof value === 'boolean' || value === null) return value
  if (Array.isArray(value)) {
    return value
      .slice(0, SUPPORT_RAILS_ARRAY_LIMIT)
      .map((item) => sanitizeSupportRailValue(item, depth + 1))
      .filter((item) => item !== undefined)
  }
  if (typeof value !== 'object') return undefined
  const out: Record<string, unknown> = {}
  for (const key of Object.keys(value as Record<string, unknown>).sort().slice(0, SUPPORT_RAILS_ARRAY_LIMIT)) {
    if (isSecretKey(key)) continue
    const child = sanitizeSupportRailValue((value as Record<string, unknown>)[key], depth + 1)
    if (child !== undefined) out[key] = child
  }
  return out
}

function limitText(text: string, max: number): string {
  return text.length > max ? text.slice(0, max) : text
}

function redactSecrets(text: string): string {
  return text
    .replace(/\b(Authorization\s*:\s*Bearer\s+)[^\s"'`]+/gi, '$1[REDACTED]')
    .replace(/\b(Bearer)\s+[A-Za-z0-9._~+/=-]{12,}/gi, '$1 [REDACTED]')
    .replace(/\b(api[_\s-]?key|token|password|passwd|pwd|secret)\s*(?:=|:|is)\s*["']?[^"'\s,;&}]+["']?/gi, '$1=[REDACTED]')
}

function isSecretKey(key: string): boolean {
  return /authorization|api[_-]?key|token|password|passwd|pwd|secret/i.test(key)
}

function intentSurface(event: string | undefined): KnowledgeIntentRequest['surface'] {
  const parsed = KnowledgeIntentSurfaceSchema.safeParse(event)
  return parsed.success ? parsed.data : 'UserPromptSubmit'
}

function sha256(text: string): string {
  return createHash('sha256').update(text).digest('hex')
}

// ─── 7. listRecent ──────────────────────────────────────────────────

export interface ListRecentResult {
  ok: true
  results: Array<{ id: string; title: string; category: string; updatedAt?: string }>
  total: number
}

/**
 * GET /api/v1/knowledge/recent — 最近知识列表。
 * @param days   最近几天（默认 7）
 * @param limit  条数上限（默认 10）
 */
export async function listRecent(
  days = 7,
  limit = 10,
  env: NodeJS.ProcessEnv = process.env,
): Promise<ListRecentResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const url = `${cfg.brainBaseUrl}/api/v1/knowledge/recent?days=${days}&limit=${limit}`
  const r = await brainFetch(url, { method: 'GET' }, cfg)
  if (!('data' in r)) return r
  const d = r.data as { results?: unknown[]; total?: number }
  return {
    ok: true,
    results: (Array.isArray(d.results) ? d.results : []).map((e: any) => ({
      id: String(e.id ?? ''), title: String(e.title ?? ''),
      category: String(e.category ?? ''), updatedAt: e.updatedAt,
    })),
    total: typeof d.total === 'number' ? d.total : 0,
  }
}

// ─── 8. addKnowledge ────────────────────────────────────────────────

export interface AddKnowledgeResult {
  ok: true
  id: string
  title: string
  category: string
  /** Present when cerebro returned status:'duplicate' — the entry was not created. */
  action?: 'created' | 'duplicate'
  /** id of the existing entry when action==='duplicate' */
  existingId?: string
  similarity?: number
}

/**
 * POST /api/v1/knowledge — 新增知识条目。
 */
export async function addKnowledge(
  params: { title: string; content: string; category?: string; tags?: string[]; preConfirmed?: boolean },
  env: NodeJS.ProcessEnv = process.env,
): Promise<AddKnowledgeResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge`, {
    method: 'POST', body: JSON.stringify(params),
  }, cfg)
  if (!('data' in r)) return r
  const d = r.data as { status?: string; id?: string; title?: string; category?: string; existingId?: string; similarity?: number }
  // cerebro returns status:'duplicate' (HTTP 200) when an entry already exists
  if (d.status === 'duplicate') {
    return {
      ok: true,
      action: 'duplicate',
      id: '',
      title: String(d.title ?? ''),
      category: String(d.category ?? ''),
      existingId: typeof d.existingId === 'string' ? d.existingId : undefined,
      similarity: typeof d.similarity === 'number' ? d.similarity : undefined,
    }
  }
  return { ok: true, action: 'created', id: String(d.id ?? ''), title: String(d.title ?? ''), category: String(d.category ?? '') }
}

// ─── 9. updateKnowledge ─────────────────────────────────────────────

export interface UpdateKnowledgeResult { ok: true; id: string }

export interface GetKnowledgeResult { ok: true; entry: Record<string, unknown> }

/** GET /api/v1/knowledge/:id — 按精确 ID 读取一条完整知识。 */
export async function getKnowledge(
  id: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<GetKnowledgeResult | KhDegraded> {
  const normalizedId = id.trim()
  if (!normalizedId) return { ok: false, reason: 'invalid_input', message: 'knowledge id is required' }
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const r = await brainFetch(
    `${cfgOrErr.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(normalizedId)}`,
    { method: 'GET' },
    cfgOrErr,
  )
  if (!('data' in r)) return r
  return { ok: true, entry: r.data as Record<string, unknown> }
}

/**
 * PUT /api/v1/knowledge/:id — 更新知识条目（追加/替换内容/标签/分类）。
 */
export async function updateKnowledge(
  id: string,
  params: { appendContent?: string; replaceContent?: string; additionalTags?: string[]; category?: string },
  env: NodeJS.ProcessEnv = process.env,
): Promise<UpdateKnowledgeResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(id)}`, {
    method: 'PUT', body: JSON.stringify(params),
  }, cfg)
  if (!('data' in r)) return r
  return { ok: true, id }
}

// ─── 10. flagOutdated ───────────────────────────────────────────────

export interface FlagOutdatedResult { ok: true; id: string }

/**
 * POST /api/v1/knowledge/:id/deprecate — 标记知识过时。
 */
export async function flagOutdated(
  id: string,
  reason: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<FlagOutdatedResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(id)}/deprecate`, {
    method: 'POST', body: JSON.stringify({ reason }),
  }, cfg)
  if (!('data' in r)) return r
  return { ok: true, id }
}

// ─── 11. deleteKnowledge ────────────────────────────────────────────

export interface DeleteKnowledgeResult { ok: true; id: string }

/**
 * DELETE /api/v1/knowledge/:id — 物理删除知识条目。
 */
export async function deleteKnowledge(
  id: string,
  reason?: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<DeleteKnowledgeResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const url = `${cfg.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(id)}${reason ? `?reason=${encodeURIComponent(reason)}` : ''}`
  const r = await brainFetch(url, { method: 'DELETE', body: JSON.stringify({}) }, cfg)
  if (!('data' in r)) return r
  return { ok: true, id }
}

// ─── 12. promoteKnowledge ───────────────────────────────────────────

export interface PromoteKnowledgeResult { ok: true; newId?: string; status: string }

/**
 * POST /api/v1/knowledge/:id/promote — 按 owner 层级单条提升。
 */
export async function promoteKnowledge(
  id: string,
  params: { targetOwnerType: string; targetOwnerId: string; reason?: string },
  env: NodeJS.ProcessEnv = process.env,
): Promise<PromoteKnowledgeResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(id)}/promote`, {
    method: 'POST', body: JSON.stringify(params),
  }, cfg)
  if (!('data' in r)) return r
  const d = r.data as { newId?: string; newStatus?: string; status?: string }
  return { ok: true, newId: d.newId, status: d.newStatus ?? d.status ?? 'active' }
}

// ─── 13. demoteKnowledge ────────────────────────────────────────────

export interface DemoteKnowledgeResult { ok: true }

/**
 * POST /api/v1/knowledge/:id/demote — 按 owner 层级单条降级。
 */
export async function demoteKnowledge(
  id: string,
  params: { targetOwnerType: string; targetOwnerId: string; reason?: string },
  env: NodeJS.ProcessEnv = process.env,
): Promise<DemoteKnowledgeResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/knowledge/${encodeURIComponent(id)}/demote`, {
    method: 'POST', body: JSON.stringify(params),
  }, cfg)
  if (!('data' in r)) return r
  return { ok: true }
}

// ─── 14. getWorkingMemory ───────────────────────────────────────────

export interface GetWorkingMemoryResult {
  ok: true
  items: Array<{ section: string; content: string; priority?: number }>
}

/**
 * GET /api/v1/me/working-memory — 读工作记忆（全部分区或指定 section）。
 */
export async function getWorkingMemory(
  section?: string,
  env: NodeJS.ProcessEnv = process.env,
): Promise<GetWorkingMemoryResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const qs = section ? `?section=${encodeURIComponent(section)}` : ''
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/me/working-memory${qs}`, { method: 'GET' }, cfg)
  if (!('data' in r)) return r
  const d = r.data as { items?: unknown[] }
  return {
    ok: true,
    items: (Array.isArray(d.items) ? d.items : []).map((m: any) => ({
      section: String(m.section ?? ''), content: String(m.content ?? ''),
      priority: typeof m.priority === 'number' ? m.priority : undefined,
    })),
  }
}

// ─── 15. updateWorkingMemory ────────────────────────────────────────

export interface UpdateWorkingMemoryResult { ok: true }

/**
 * POST /api/v1/me/working-memory — 写工作记忆（支持 replace 替换整个分区）。
 */
export async function updateWorkingMemory(
  section: string,
  items: Array<{ content: string; priority?: number }>,
  replace = false,
  env: NodeJS.ProcessEnv = process.env,
): Promise<UpdateWorkingMemoryResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/me/working-memory`, {
    method: 'POST', body: JSON.stringify({ section, items, replace }),
  }, cfg)
  if (!('data' in r)) return r
  return { ok: true }
}

// ─── 16. updateUserPreference ───────────────────────────────────────

export interface UpdateUserPreferenceResult { ok: true }

/**
 * PUT /api/v1/me/preferences — 写/删用户偏好。
 * @param action 'set'（默认）| 'delete'
 */
export async function updateUserPreference(
  key: string,
  value: string,
  action: 'set' | 'delete' = 'set',
  env: NodeJS.ProcessEnv = process.env,
): Promise<UpdateUserPreferenceResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/me/preferences`, {
    method: 'PUT', body: JSON.stringify({ key, value, action }),
  }, cfg)
  if (!('data' in r)) return r
  return { ok: true }
}

// ─── 17. getContext (lean) ───────────────────────────────────────────

export interface GetContextResult {
  ok: true
  constraints: Array<{ content: string; priority: number }>
  preferences: Array<{ key: string; value: string }>
  generatedAt?: string
}

/**
 * GET /api/v1/me/context — 读精简版团队上下文（constraints + top-8 preferences）。
 * CLI `synapse context` 使用。
 */
export async function getContext(
  env: NodeJS.ProcessEnv = process.env,
): Promise<GetContextResult | KhDegraded> {
  const cfgOrErr = requireCfg(env)
  if (!('brainBaseUrl' in cfgOrErr)) return cfgOrErr
  const cfg = cfgOrErr
  const r = await brainFetch(`${cfg.brainBaseUrl}/api/v1/me/context`, { method: 'GET' }, cfg)
  if (!('data' in r)) return r
  const d = r.data as { constraints?: unknown[]; preferences?: unknown[]; generatedAt?: string }
  return {
    ok: true,
    constraints: (Array.isArray(d.constraints) ? d.constraints : []).map((c: any) => ({
      content: String(c.content ?? ''), priority: Number(c.priority ?? 0),
    })),
    preferences: (Array.isArray(d.preferences) ? d.preferences : []).map((p: any) => ({
      key: String(p.key ?? ''), value: String(p.value ?? ''),
    })),
    generatedAt: d.generatedAt,
  }
}
