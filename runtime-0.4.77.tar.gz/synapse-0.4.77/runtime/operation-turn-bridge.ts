/**
 * The small adapter used by Chat and Codex to ask Cerebro to classify one
 * user turn.  The adapter deliberately has no intent or domain logic: it
 * builds a correlation-safe request, performs one HTTP call, and applies only
 * Cerebro's explicit ordinary dependency projection.
 */
import { stableUuidV4 } from "../core/stable-uuid.ts"
import { getBrainConfig } from "../transport/brain-config.ts"
import {
  OperationErrorResponseSchema,
  OperationStatusRequestSchema,
  OperationStatusResponseSchema,
  OperationTurnRequestSchema,
  OperationTurnResponseSchema,
  type UnifiedOperationDependency,
} from "@cerebro/wire"

export const OPERATION_TURN_PATH = "/brain/operations/turn" as const
export const OPERATION_STATUS_PATH = "/brain/operations/:operationId" as const
export const OPERATION_TURN_PROTOCOL_VERSION = "1" as const
export const OPERATION_TURN_CONTROL_TIMEOUT_MS = 1_000
export const CEREBRO_UNAVAILABLE_NOTICE = "Cerebro 暂时不可用，主脑操作未执行；普通任务继续。"
export const CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE = "Cerebro 暂时不可用，主脑操作未执行；普通任务依赖关系未知，本轮阻断。"
export const CEREBRO_DEPENDENCY_PENDING_NOTICE = "普通任务依赖 Cerebro 主脑结果，结果未确认前不能继续。"

export type OperationTurnClient = "cerebro-chat" | "codex"
export type OperationTurnOrdinaryDependency = UnifiedOperationDependency

export interface OperationRecentContextEntry {
  turnId?: string
  role: "user" | "assistant"
  source?: "transcript" | "cerebro_receipt" | "adapter"
  content: string
  operationIds?: readonly string[]
  truncated?: boolean
}

export interface OperationTurnContext {
  previousTurnIds?: readonly string[]
  referencedOperationIds?: readonly string[]
}

/**
 * Input supplied by a client adapter. `userInput` is normalized into the
 * canonical `message.text` field; keeping it separate here lets callers build
 * an identity key before any presentation text is selected.
 */
export interface OperationTurnInput {
  client: OperationTurnClient
  sessionId: string
  turnId: string
  messageId?: string
  message?: string
  userInput: string
  cwd?: string
  productionContext?: {
    productionId?: string
    projectId?: string
    repositoryId?: string
  }
  recentContext?: readonly OperationRecentContextEntry[]
  context?: OperationTurnContext
  /**
   * A trusted ordinary-task projection supplied by an upstream contract
   * holder. It is used only when Cerebro cannot return a response; it is
   * deliberately never derived from `userInput`. When omitted, transport
   * failure keeps the dependency unknown and therefore fail-closed.
   */
  ordinaryDependency?: OperationTurnOrdinaryDependency
  idempotencyKey?: string
  signal?: AbortSignal
  env?: NodeJS.ProcessEnv
}

/** Request body sent to Cerebro. Keep this shape aligned with the shared wire
 * contract; optional context fields are omitted when unavailable. */
export interface OperationTurnRequest {
  protocolVersion: typeof OPERATION_TURN_PROTOCOL_VERSION
  client: OperationTurnClient
  message: { id: string; role: "user"; text: string }
  sessionId: string
  turnId: string
  idempotencyKey: string
  cwd?: string
  productionContext?: {
    productionId?: string
    projectId?: string
    repositoryId?: string
  }
  recentContext?: readonly OperationRecentContextEntry[]
  context?: OperationTurnContext
}

export type OperationTurnDecision = "ordinary" | "operation" | "mixed" | "clarify" | "unsupported" | "unavailable"

/** A structural view is intentional here.  The canonical response schema is
 * owned by @cerebro/wire; this view keeps the runtime adapter usable while a
 * new wire package is being built and never invents domain fields. */
export interface OperationTurnResponse {
  protocolVersion?: string
  client?: string
  messageId?: string
  sessionId?: string
  turnId?: string
  idempotencyKey?: string
  decision: OperationTurnDecision
  operations?: readonly Record<string, unknown>[]
  ordinary?: {
    dependency?: OperationTurnOrdinaryDependency
    dependsOn?: readonly string[]
    blockedReason?: { code?: string; message?: string; retryable?: boolean }
    result?: unknown
  }
  clarification?: { question?: string; missing?: readonly string[] }
  unsupported?: { message?: string; requestedResource?: string; requestedAction?: string }
  unavailable?: { message?: string; retryable?: boolean }
  [key: string]: unknown
}

export interface OperationStatusRequest {
  protocolVersion: typeof OPERATION_TURN_PROTOCOL_VERSION
  client: OperationTurnClient
  operationId: string
  sessionId?: string
  idempotencyKey?: string
}

export interface OperationStatusResponse {
  protocolVersion?: string
  client?: string
  operation: Record<string, unknown>
  sessionId?: string
  idempotencyKey?: string
  replayed?: boolean
  [key: string]: unknown
}

export interface OperationErrorResponse {
  status: "error"
  code?: string
  message?: string
  retryable?: boolean
  operationId?: string
  idempotencyKey?: string
  retryAfterMs?: number
  [key: string]: unknown
}

export interface OperationTurnBridgeSuccess {
  available: true
  ordinaryContinue: boolean
  /** True when the ordinary model must wait for the operation result. */
  requiresOperationResult: boolean
  request: OperationTurnRequest
  response: OperationTurnResponse
  operationId?: string
  idempotencyKey: string
  notice?: string
}

export interface OperationTurnBridgeUnavailable {
  available: false
  ordinaryContinue: boolean
  requiresOperationResult: boolean
  request: OperationTurnRequest
  response?: OperationTurnResponse
  error?: OperationErrorResponse
  httpStatus?: number
  operationId?: string
  idempotencyKey: string
  notice: string
}

export type OperationTurnBridgeResult = OperationTurnBridgeSuccess | OperationTurnBridgeUnavailable

export interface OperationStatusInput {
  client: OperationTurnClient
  operationId: string
  sessionId?: string
  idempotencyKey?: string
  signal?: AbortSignal
  env?: NodeJS.ProcessEnv
}

export interface OperationStatusBridgeSuccess {
  available: true
  request: OperationStatusRequest
  response: OperationStatusResponse
  operation: Record<string, unknown>
  operationId: string
  idempotencyKey?: string
}

export interface OperationStatusBridgeUnavailable {
  available: false
  request: OperationStatusRequest
  error?: OperationErrorResponse
  httpStatus?: number
  operationId: string
  idempotencyKey?: string
  retryable?: boolean
  retryAfterMs?: number
  notice: string
}

export type OperationStatusBridgeResult = OperationStatusBridgeSuccess | OperationStatusBridgeUnavailable

export interface OperationTurnBridgeOptions {
  env?: NodeJS.ProcessEnv
  endpoint?: string
  timeoutMs?: number
  fetchImpl?: typeof fetch
}

type OrdinaryDependencyProjection = {
  dependency: "none" | "operation_result" | "blocked" | "unknown"
  ordinaryContinue: boolean
  requiresOperationResult: boolean
  notice?: string
}

/** Generate the same key on retries of the same client/session/turn/message. */
export function operationTurnIdempotencyKey(input: { client: string; sessionId: string; turnId: string; messageId?: string; userInput: string }): string {
  const messageIdentity = input.messageId?.trim() || input.userInput.trim()
  return `synapse-turn:${stableUuidV4(
    "cerebro.operation-turn.v1",
    input.client,
    input.sessionId.trim(),
    input.turnId.trim(),
    messageIdentity,
  )}`
}

/** Build a deterministic request without performing network I/O. */
export function buildOperationTurnRequest(input: OperationTurnInput): OperationTurnRequest {
  const sessionId = nonEmpty(input.sessionId, "sessionId")
  const turnId = nonEmpty(input.turnId, "turnId")
  const userInput = nonEmpty(input.userInput, "userInput")
  const messageText = nonEmpty(input.message ?? input.userInput, "message")
  const messageId = input.messageId?.trim() || stableUuidV4(
    "cerebro.operation-message.v1",
    input.client,
    sessionId,
    turnId,
    input.message ?? userInput,
  )
  const idempotencyKey = input.idempotencyKey?.trim() || operationTurnIdempotencyKey({
    client: input.client,
    sessionId,
    turnId,
    messageId: input.messageId,
    userInput,
  })
  if (idempotencyKey.length < 8 || idempotencyKey.length > 512) {
    throw new TypeError("idempotencyKey must contain 8-512 characters")
  }

  const request: OperationTurnRequest = {
    protocolVersion: OPERATION_TURN_PROTOCOL_VERSION,
    client: input.client,
    message: { id: messageId, role: "user", text: messageText },
    sessionId,
    turnId,
    idempotencyKey,
  }
  if (input.cwd?.trim()) request.cwd = input.cwd.trim()
  if (input.productionContext !== undefined) request.productionContext = { ...input.productionContext }
  if (input.recentContext?.length) {
    request.recentContext = input.recentContext.map((entry) => ({
      ...(entry.turnId?.trim() ? { turnId: entry.turnId.trim() } : {}),
      role: entry.role,
      ...(entry.source ? { source: entry.source } : {}),
      content: entry.content,
      ...(entry.operationIds?.length ? { operationIds: [...entry.operationIds] } : {}),
      ...(entry.truncated ? { truncated: true } : {}),
    }))
  }
  if (input.context) {
    request.context = {
      ...(input.context.previousTurnIds?.length ? { previousTurnIds: [...input.context.previousTurnIds] } : {}),
      ...(input.context.referencedOperationIds?.length ? { referencedOperationIds: [...input.context.referencedOperationIds] } : {}),
    }
  }
  const parsed = OperationTurnRequestSchema.safeParse(request)
  if (!parsed.success) throw new TypeError("operation turn request failed shared wire schema validation")
  return parsed.data as OperationTurnRequest
}

/** Build a status query using only the shared wire contract identity. */
export function buildOperationStatusRequest(input: OperationStatusInput): OperationStatusRequest {
  const operationId = nonEmpty(input.operationId, "operationId")
  const request: OperationStatusRequest = {
    protocolVersion: OPERATION_TURN_PROTOCOL_VERSION,
    client: input.client,
    operationId,
    ...(input.sessionId?.trim() ? { sessionId: input.sessionId.trim() } : {}),
    ...(input.idempotencyKey?.trim() ? { idempotencyKey: input.idempotencyKey.trim() } : {}),
  }
  const parsed = OperationStatusRequestSchema.safeParse(request)
  if (!parsed.success) throw new TypeError("operation status request failed shared wire schema validation")
  return parsed.data as OperationStatusRequest
}

export class OperationTurnBridge {
  private readonly env: NodeJS.ProcessEnv
  private readonly endpoint: string
  private readonly timeoutMs: number
  private readonly fetchImpl: typeof fetch

  constructor(options: OperationTurnBridgeOptions = {}) {
    this.env = options.env ?? process.env
    this.endpoint = options.endpoint ?? OPERATION_TURN_PATH
    this.timeoutMs = options.timeoutMs ?? OPERATION_TURN_CONTROL_TIMEOUT_MS
    this.fetchImpl = options.fetchImpl ?? fetch
    if (!Number.isFinite(this.timeoutMs) || this.timeoutMs < 1 || this.timeoutMs > 10_000) {
      throw new RangeError("operation turn timeout must be between 1 and 10000 milliseconds")
    }
  }

  async submit(input: OperationTurnInput): Promise<OperationTurnBridgeResult> {
    const request = buildOperationTurnRequest(input)
    const cfg = getBrainConfig(input.env ?? this.env)
    const unavailable = (
      response?: OperationTurnResponse,
      notice?: string,
      error?: OperationErrorResponse,
      httpStatus?: number,
    ): OperationTurnBridgeUnavailable => {
      // A transport failure has no response of its own. Only an explicit
      // projection from a trusted contract holder may distinguish an
      // independent ordinary task from one that depends on Cerebro.
      const projection = projectUnavailableDependency(response, input.ordinaryDependency)
      return {
        available: false,
        ordinaryContinue: projection.ordinaryContinue,
        requiresOperationResult: projection.requiresOperationResult,
        request,
        ...(response ? { response } : {}),
        ...(error ? { error } : {}),
        ...(httpStatus !== undefined ? { httpStatus } : {}),
        ...(response ? { operationId: extractOperationId(response) } : {}),
        ...(!response && error?.operationId ? { operationId: error.operationId } : {}),
        idempotencyKey: request.idempotencyKey,
        notice: noticeForUnavailableProjection(projection, response, notice),
      }
    }
    if (!cfg?.machineToken) return unavailable()

    const url = `${cfg.brainBaseUrl}${this.endpoint.startsWith("/") ? this.endpoint : `/${this.endpoint}`}`
    try {
      const timeoutSignal = AbortSignal.timeout(this.timeoutMs)
      const signal = input.signal ? AbortSignal.any([input.signal, timeoutSignal]) : timeoutSignal
      const response = await this.fetchImpl(url, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${cfg.machineToken}`,
        },
        body: JSON.stringify(request),
        signal,
      })
      const payload = await response.json().catch(() => undefined)
      if (!response.ok) {
        const error = parseOperationErrorResponse(payload, request)
        if (error) return unavailable(undefined, error.message?.trim(), error, response.status)
      }
      const identity = extractOperationTurnResponseIdentity(payload)
      // Validate the request/session/turn binding before parsing or projecting
      // any turn response semantics. A stale payload must not influence the
      // current turn even when its ordinary dependency fields look authoritative.
      if (!identity || !responseIdentityMatchesRequest(identity, request)) {
        return unavailable(undefined, undefined, undefined, response.ok ? undefined : response.status)
      }
      // Token/auth failures are transport failures even if a proxy or stale
      // body happens to look like a valid turn response. Never let that body
      // override the caller's explicit fallback dependency projection.
      if (response.status >= 500 && response.status < 600) {
        const parsed = parseOperationTurnResponse(payload)
        // A server failure may carry a contract unavailable projection, but a
        // successful/operation-shaped body on a 5xx is not a valid failure
        // response and must not authorize ordinary continuation.
        if (parsed?.decision === "unavailable") return unavailable(parsed, undefined, undefined, response.status)
        return unavailable(undefined, undefined, undefined, response.status)
      }
      // HTTP errors are transport errors even when a proxy echoes a
      // schema-valid turn-shaped body. Cerebro business decisions use a 2xx
      // turn response; do not let an error status authorize an operation or
      // ordinary continuation.
      if (!response.ok) return unavailable(undefined, undefined, undefined, response.status)
      const parsed = parseOperationTurnResponse(payload)
      if (!parsed) return unavailable()
      if (parsed.decision === "unavailable") {
        return unavailable(parsed, parsed.unavailable?.message?.trim() || CEREBRO_UNAVAILABLE_NOTICE)
      }
      const projection = projectOrdinaryDependency(parsed)
      // `clarify` and `unsupported` may still carry an independent ordinary
      // task. The top-level decision alone cannot decide whether that task
      // should continue; the shared dependency projection is authoritative.
      return {
        available: true,
        ordinaryContinue: projection.ordinaryContinue,
        requiresOperationResult: projection.requiresOperationResult,
        request,
        response: parsed,
        ...(extractOperationId(parsed) ? { operationId: extractOperationId(parsed) } : {}),
        idempotencyKey: request.idempotencyKey,
        ...(parsed.decision === "clarify" ? { notice: parsed.clarification?.question } : {}),
      }
    } catch {
      return unavailable()
    }
  }

  async queryStatus(input: OperationStatusInput): Promise<OperationStatusBridgeResult> {
    const request = buildOperationStatusRequest(input)
    const cfg = getBrainConfig(input.env ?? this.env)
    const unavailable = (
      notice: string,
      error?: OperationErrorResponse,
      httpStatus?: number,
    ): OperationStatusBridgeUnavailable => ({
      available: false,
      request,
      ...(error ? { error } : {}),
      ...(httpStatus !== undefined ? { httpStatus } : {}),
      operationId: error?.operationId ?? request.operationId,
      ...(request.idempotencyKey ? { idempotencyKey: request.idempotencyKey } : {}),
      retryable: error?.retryable,
      retryAfterMs: error?.retryAfterMs,
      notice,
    })
    if (!cfg?.machineToken) return unavailable(CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE)

    const url = new URL(`${cfg.brainBaseUrl}${operationStatusPath(request.operationId)}`)
    url.searchParams.set("client", request.client)
    if (request.sessionId) url.searchParams.set("sessionId", request.sessionId)
    if (request.idempotencyKey) url.searchParams.set("idempotencyKey", request.idempotencyKey)
    try {
      const timeoutSignal = AbortSignal.timeout(this.timeoutMs)
      const signal = input.signal ? AbortSignal.any([input.signal, timeoutSignal]) : timeoutSignal
      const response = await this.fetchImpl(url.toString(), {
        method: "GET",
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${cfg.machineToken}`,
        },
        signal,
      })
      const payload = await response.json().catch(() => undefined)
      if (!response.ok) {
        const error = parseOperationStatusErrorResponse(payload, request)
        return unavailable(error?.message?.trim() || CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE, error, response.status)
      }
      const parsed = parseOperationStatusResponse(payload)
      if (!parsed || !statusResponseMatchesRequest(parsed, request)) {
        return unavailable(CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE)
      }
      return {
        available: true,
        request,
        response: parsed,
        operation: parsed.operation,
        operationId: request.operationId,
        ...(parsed.idempotencyKey ? { idempotencyKey: parsed.idempotencyKey } : {}),
      }
    } catch {
      return unavailable(CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE)
    }
  }
}

export function createOperationTurnBridge(options?: OperationTurnBridgeOptions): OperationTurnBridge {
  return new OperationTurnBridge(options)
}

export async function submitOperationTurn(input: OperationTurnInput, options?: OperationTurnBridgeOptions): Promise<OperationTurnBridgeResult> {
  return createOperationTurnBridge(options).submit(input)
}

export async function queryOperationStatus(input: OperationStatusInput, options?: OperationTurnBridgeOptions): Promise<OperationStatusBridgeResult> {
  return createOperationTurnBridge(options).queryStatus(input)
}

function nonEmpty(value: string, field: string): string {
  const normalized = value.trim()
  if (!normalized) throw new TypeError(`${field} must not be empty`)
  return normalized
}

function parseOperationTurnResponse(value: unknown): OperationTurnResponse | undefined {
  const parsed = OperationTurnResponseSchema.safeParse(value)
  return parsed.success ? parsed.data as OperationTurnResponse : undefined
}

function parseOperationStatusResponse(value: unknown): OperationStatusResponse | undefined {
  const parsed = OperationStatusResponseSchema.safeParse(value)
  return parsed.success ? parsed.data as OperationStatusResponse : undefined
}

function parseOperationErrorResponse(value: unknown, request: OperationTurnRequest): OperationErrorResponse | undefined {
  const parsed = OperationErrorResponseSchema.safeParse(value)
  if (!parsed.success) return undefined
  const error = parsed.data as OperationErrorResponse
  if (error.idempotencyKey !== request.idempotencyKey) return undefined
  return error
}

function parseOperationStatusErrorResponse(value: unknown, request: OperationStatusRequest): OperationErrorResponse | undefined {
  const parsed = OperationErrorResponseSchema.safeParse(value)
  if (!parsed.success) return undefined
  const error = parsed.data as OperationErrorResponse
  if (error.operationId !== request.operationId) return undefined
  if (request.idempotencyKey && error.idempotencyKey !== request.idempotencyKey) return undefined
  return error
}

type OperationTurnResponseIdentity = Pick<
  OperationTurnResponse,
  "protocolVersion" | "client" | "messageId" | "sessionId" | "turnId" | "idempotencyKey"
>

function extractOperationTurnResponseIdentity(value: unknown): OperationTurnResponseIdentity | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined
  const record = value as Record<string, unknown>
  const fields = ["protocolVersion", "client", "messageId", "sessionId", "turnId", "idempotencyKey"] as const
  if (!fields.every((field) => typeof record[field] === "string" && record[field].trim())) return undefined
  return {
    protocolVersion: record.protocolVersion as string,
    client: record.client as string,
    messageId: record.messageId as string,
    sessionId: record.sessionId as string,
    turnId: record.turnId as string,
    idempotencyKey: record.idempotencyKey as string,
  }
}

function responseIdentityMatchesRequest(
  identity: OperationTurnResponseIdentity,
  request: OperationTurnRequest,
): boolean {
  return identity.protocolVersion === request.protocolVersion
    && identity.client === request.client
    && identity.messageId === request.message.id
    && identity.sessionId === request.sessionId
    && identity.turnId === request.turnId
    && identity.idempotencyKey === request.idempotencyKey
}

function statusResponseMatchesRequest(
  response: OperationStatusResponse,
  request: OperationStatusRequest,
): boolean {
  return response.protocolVersion === request.protocolVersion
    && response.client === request.client
    && response.operation.operationId === request.operationId
    && (!request.sessionId || response.sessionId === request.sessionId)
    && (!request.idempotencyKey || response.idempotencyKey === request.idempotencyKey)
}

function operationStatusPath(operationId: string): string {
  return OPERATION_STATUS_PATH.replace(":operationId", encodeURIComponent(operationId))
}

function extractOperationId(response: OperationTurnResponse): string | undefined {
  if (typeof response.operationId === "string" && response.operationId.trim()) return response.operationId
  const operations = response.operations
  if (!Array.isArray(operations)) return undefined
  const operation = operations.find((item) => typeof item?.operationId === "string" && String(item.operationId).trim())
  return operation && typeof operation.operationId === "string" ? operation.operationId : undefined
}

function projectOrdinaryDependency(response: OperationTurnResponse | undefined): OrdinaryDependencyProjection {
  const ordinary = response?.ordinary
  if (!ordinary) {
    return unknownDependencyProjection()
  }
  if (ordinary.dependency === "none") {
    return { dependency: "none", ordinaryContinue: true, requiresOperationResult: false }
  }
  if (ordinary.dependency === "operation_result") {
    const ready = dependenciesExecuted(response)
    return {
      dependency: "operation_result",
      ordinaryContinue: ready,
      requiresOperationResult: !ready,
      ...(ready ? {} : { notice: CEREBRO_DEPENDENCY_PENDING_NOTICE }),
    }
  }
  if (ordinary.dependency !== "blocked") return unknownDependencyProjection()
  return {
    dependency: "blocked",
    ordinaryContinue: false,
    requiresOperationResult: true,
    notice: ordinary.blockedReason?.message?.trim() || CEREBRO_DEPENDENCY_PENDING_NOTICE,
  }
}

function projectUnavailableDependency(
  response: OperationTurnResponse | undefined,
  fallbackDependency: OperationTurnOrdinaryDependency | undefined,
): OrdinaryDependencyProjection {
  if (response?.decision === "unavailable" && response.ordinary) {
    return projectOrdinaryDependency(response)
  }
  if (fallbackDependency === "none") {
    return { dependency: "none", ordinaryContinue: true, requiresOperationResult: false }
  }
  if (fallbackDependency === "operation_result" || fallbackDependency === "blocked") {
    return {
      dependency: fallbackDependency,
      ordinaryContinue: false,
      requiresOperationResult: true,
      notice: CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE,
    }
  }
  return unknownDependencyProjection()
}

function unknownDependencyProjection(): OrdinaryDependencyProjection {
  return {
    dependency: "unknown",
    ordinaryContinue: false,
    requiresOperationResult: false,
    notice: CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE,
  }
}

function noticeForUnavailableProjection(
  projection: OrdinaryDependencyProjection,
  response: OperationTurnResponse | undefined,
  fallbackNotice: string | undefined,
): string {
  if (projection.dependency === "none") {
    return response?.unavailable?.message?.trim() || fallbackNotice || CEREBRO_UNAVAILABLE_NOTICE
  }
  return projection.notice || fallbackNotice || CEREBRO_UNAVAILABLE_FAIL_CLOSED_NOTICE
}

function dependenciesExecuted(response: OperationTurnResponse): boolean {
  const ordinary = response.ordinary
  if (ordinary?.dependency !== "operation_result") return true
  const dependencies = ordinary.dependsOn ?? []
  if (dependencies.length === 0) return false
  const operations = new Map((response.operations ?? [])
    .map((operation) => [typeof operation.operationId === "string" ? operation.operationId : "", operation]))
  return dependencies.every((operationId) => operations.get(operationId)?.status === "executed")
}
