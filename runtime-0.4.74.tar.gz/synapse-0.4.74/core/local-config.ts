/**
 * core/local-config.ts —— 本机 Synapse 配置读写。
 *
 * 写入 ~/.config/synapse/config.json:只存 user_id / brainUrl 等非敏感字段。
 * machine token 不写入 config.json；由 token-store 的 0600 文件保存，环境变量作为回落来源。
 *
 * 幂等、合并语义:已有字段不会被清空(只覆盖明确传入的字段)。
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs"
import { homedir } from "node:os"
import { dirname, join } from "node:path"
import { hasRetiredBrainPort } from "./brain-url-policy.ts"

export interface LocalConfig {
  /** Synapse user_id(解析权威来源,见 core/user-id.ts) */
  user_id?: string
  /** brain HTTP base URL(可选；machine token 不在 config.json 中存储) */
  brain_url?: string
  /** 显式配置该 brain_url 时，是否允许非 loopback HTTP。 */
  allow_insecure_http?: boolean
}

export interface SetLocalConfigOpts {
  /** 覆盖 config 目录(默认 ~/.config/synapse) */
  configDir?: string
  /** Resolve the default config directory from this environment. */
  env?: NodeJS.ProcessEnv
}

function effectiveConfigDir(opts?: SetLocalConfigOpts): string {
  const env = opts?.env ?? process.env
  const home = env["USERPROFILE"]?.trim() || env["HOME"]?.trim() || homedir()
  return opts?.configDir ?? join(home, ".config", "synapse")
}

function configFilePath(opts?: SetLocalConfigOpts): string {
  return join(effectiveConfigDir(opts), "config.json")
}

function readExisting(path: string): LocalConfig {
  if (!existsSync(path)) return {}
  try {
    return JSON.parse(readFileSync(path, "utf8")) as LocalConfig
  } catch {
    return {}
  }
}

/**
 * 写入本机 Synapse 配置(合并已有值,不清空未传入的字段)。
 *
 * 安全原则:
 *  - token 参数从接口上完全不存在(确保调用方不会误传)
 *  - 若 brainUrl 包含 token/secret/key 查询参数,此处不校验但明确记录仅存 URL
 */
export function setLocalConfig(
  values: { userId?: string; brainUrl?: string; allowInsecureHttp?: boolean },
  opts?: SetLocalConfigOpts,
): void {
  const cfgPath = configFilePath(opts)
  mkdirSync(dirname(cfgPath), { recursive: true })

  const existing = readExisting(cfgPath)
  const merged: LocalConfig = { ...existing }

  if (values.userId !== undefined) {
    merged.user_id = values.userId
  }
  if (values.brainUrl !== undefined) {
    if (hasRetiredBrainPort(values.brainUrl)) {
      throw new Error("retired Cerebro endpoint cannot be persisted")
    }
    merged.brain_url = values.brainUrl
  }
  if (values.allowInsecureHttp !== undefined) {
    merged.allow_insecure_http = values.allowInsecureHttp
  }

  writeFileSync(cfgPath, JSON.stringify(merged, null, 2) + "\n", "utf8")
}

/**
 * 读取本机 Synapse 配置(只读,不写)。
 */
export function readLocalConfig(opts?: SetLocalConfigOpts): LocalConfig {
  return readExisting(configFilePath(opts))
}
