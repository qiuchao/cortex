import {
  TaskCapabilityExecuteRequestSchema,
  TaskCapabilityWriteCommandSchema,
  TaskCapabilityWriteInputSchemas,
  type TaskCapabilityExecuteRequest,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import { stableFallbackTurnId } from "./parsers/util.ts"
import { stableUuidV4 } from "./stable-uuid.ts"

export interface TaskTurnEnvelopeBinding {
  draftRequestId: string
  /** Runtime compatibility accepts an already-bound legacy envelope only when it matches exactly. */
  allowMatchingRequestId?: boolean
}

export type BoundTaskTurnEnvelope =
  | { ok: true; request: TaskCapabilityExecuteRequest; command: string }
  | { ok: false; reason: string }

/** A repeated hook callback for the same user turn must reuse one Cerebro draft identity. */
export function taskTurnDraftRequestId(request: InjectRequest, productionId: string): string {
  const turnId = request.turn_id?.trim() || stableFallbackTurnId({
    client: request.client,
    sessionId: request.session_id,
    messageId: request.message_id,
    conversationId: request.conversation_id,
    currentText: request.user_input,
  })
  return stableUuidV4(
    "synapse-task-turn-draft",
    request.client,
    request.session_id || "unknown-session",
    turnId,
    productionId,
    request.user_input,
  )
}

/** Bind daemon-owned draft identity and apply the same strict write-input schema
 * before a turn-scoped Task request can reach Cerebro. */
export function bindTaskTurnEnvelope(
  raw: unknown,
  binding: TaskTurnEnvelopeBinding,
): BoundTaskTurnEnvelope {
  const rawRecord = raw && typeof raw === "object" && !Array.isArray(raw)
    ? raw as Record<string, unknown>
    : undefined
  const writeCommand = TaskCapabilityWriteCommandSchema.safeParse(rawRecord?.["command"])
  if (writeCommand.success && rawRecord?.["requestId"] !== undefined) {
    if (binding.allowMatchingRequestId !== true
      || rawRecord["requestId"] !== binding.draftRequestId) {
      return { ok: false, reason: "Task envelope requestId must be bound by Synapse for this turn" }
    }
  }
  const candidate = writeCommand.success && rawRecord?.["requestId"] === undefined
    ? { ...rawRecord, requestId: binding.draftRequestId }
    : raw
  const parsed = TaskCapabilityExecuteRequestSchema.safeParse(candidate)
  if (!parsed.success) {
    return { ok: false, reason: "Task envelope does not match the typed execution schema" }
  }
  if (!writeCommand.success) {
    return { ok: true, request: parsed.data, command: parsed.data.command }
  }
  const writeInput = TaskCapabilityWriteInputSchemas[writeCommand.data].safeParse(parsed.data.input)
  if (!writeInput.success) {
    return { ok: false, reason: "Task envelope input does not match the selected capability schema" }
  }
  return {
    ok: true,
    // Both the envelope union and its command-specific input schema succeeded;
    // TypeScript cannot correlate those two independently parsed discriminants.
    request: { ...parsed.data, input: writeInput.data } as TaskCapabilityExecuteRequest,
    command: parsed.data.command,
  }
}
