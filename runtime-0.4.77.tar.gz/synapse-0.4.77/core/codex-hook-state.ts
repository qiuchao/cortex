/** Codex stores hook switches by source path + event + group/hook indices. */
import { existsSync, readFileSync, writeFileSync, rmSync } from "node:fs"
import { dirname, join, resolve, win32 } from "node:path"
import { parse, stringify, type TomlTable } from "smol-toml"

export interface CodexHookConfig {
  hooks?: Record<string, Array<{ hooks: Array<{ command: string; commandWindows?: string }> }>>
  disableAllHooks?: boolean
  [key: string]: unknown
}
export interface HookStateStatus { disabledHooks?: string[]; hookStateError?: string }
type Hook = NonNullable<CodexHookConfig["hooks"]>[string][number]["hooks"][number]
type Ref = { id: string; event: string; hook: Hook; owned: boolean }

export function isSynapseCodexHook(hook: Hook): boolean {
  return [hook.command, hook.commandWindows].some((command) => typeof command === "string"
    && /(?:^|[/\\])shims(?:-win)?[/\\]codex[/\\](?:inject|report|guard)(?:\.cmd)?(?:['"]|\s|$)/.test(command))
}
function table(value: unknown, label: string): TomlTable {
  if (value === undefined) return {}
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${label} must be a table`)
  return value as TomlTable
}
function sourcePath(path: string): string {
  // Preserve Windows native drive/UNC syntax when testing on POSIX.
  return win32.isAbsolute(path) && !path.startsWith("/") ? win32.normalize(path) : resolve(path)
}
function canonicalId(id: string): string {
  const match = /^(.*):([^:]+:\d+:\d+)$/.exec(id)
  if (!match) return id
  const path = match[1].replaceAll("\\", "/")
  return `${/^(?:[a-z]:|\/\/)/i.test(path) ? path.toLowerCase() : path}:${match[2]}`
}
function refs(path: string, config: CodexHookConfig): Ref[] {
  const result: Ref[] = []
  if (config.disableAllHooks !== undefined && typeof config.disableAllHooks !== "boolean") throw new Error("disableAllHooks must be boolean")
  const hooks = table(config.hooks, "hooks.json hooks")
  for (const [event, groups] of Object.entries(hooks)) {
    if (!Array.isArray(groups)) throw new Error(`hooks.${event} must be an array`)
    groups.forEach((group, gi) => {
      const commands = table(group, `hooks.${event}[${gi}]`)["hooks"]
      if (!Array.isArray(commands)) throw new Error(`hooks.${event}[${gi}].hooks must be an array`)
      commands.forEach((command, hi) => {
        const hook = table(command, "hook") as unknown as Hook
        const snake = event.replace(/[A-Z]/g, (letter, index) => `${index ? "_" : ""}${letter.toLowerCase()}`)
        result.push({ id: `${sourcePath(path)}:${snake}:${gi}:${hi}`, event, hook, owned: isSynapseCodexHook(hook) })
      })
    })
  }
  return result
}
function readState(path: string) {
  const configPath = join(dirname(path), "config.toml")
  const original = existsSync(configPath) ? readFileSync(configPath, "utf8") : undefined
  let config: TomlTable = {}
  if (original !== undefined) {
    try { config = parse(original) } catch (error) {
      // Parser messages include source excerpts, which may contain credentials.
      const location = error as { line?: number; column?: number }
      const suffix = Number.isInteger(location?.line) && Number.isInteger(location?.column)
        ? ` at line ${location.line}, column ${location.column}` : ""
      throw new Error(`Cannot parse ${configPath}${suffix}`)
    }
  }
  const hooks = table(config["hooks"], "hooks")
  const state = table(hooks["state"], "hooks.state")
  const features = table(config["features"], "features")
  if (features["hooks"] !== undefined && typeof features["hooks"] !== "boolean") throw new Error("features.hooks must be boolean")
  for (const [id, value] of Object.entries(state)) {
    const entry = table(value, `hooks.state.${id}`)
    if (entry["enabled"] !== undefined && typeof entry["enabled"] !== "boolean") throw new Error(`hooks.state.${id}.enabled must be boolean`)
  }
  return { configPath, original, config, hooks, state, globallyDisabled: features["hooks"] === false }
}
export function readCodexHookConfig(path: string): CodexHookConfig {
  let config: CodexHookConfig = {}
  if (existsSync(path)) {
    const source = readFileSync(path, "utf8")
    try { config = JSON.parse(source) } catch {
      throw new Error(`Cannot parse ${path}: invalid JSON`)
    }
  }
  table(config, "hooks.json")
  refs(path, config)
  return config
}
export function codexHookStatus(path: string): HookStateStatus {
  try {
    const config = readCodexHookConfig(path)
    const { state, globallyDisabled } = readState(path)
    const entries = new Map(Object.entries(state).map(([id, value]) => [canonicalId(id), table(value, id)]))
    const disabledHooks = [...new Set(refs(path, config).filter((ref) => ref.owned
      && (globallyDisabled || config.disableAllHooks || entries.get(canonicalId(ref.id))?.["enabled"] === false))
      .map((ref) => ref.event))]
    return disabledHooks.length ? { disabledHooks } : {}
  } catch (error) {
    return { hookStateError: `Codex hook state: ${error instanceof Error ? error.message : String(error)}` }
  }
}

/** Prepare before writing hooks.json; malformed TOML never gets silently replaced. */
export function prepareCodexStateUpdate(path: string, before: CodexHookConfig, after: CodexHookConfig, enableHooks: boolean): (writeHooks: () => void) => void {
  const loaded = readState(path)
  const oldRefs = refs(path, before)
  const newRefs = refs(path, after)
  const entries = Object.entries(loaded.state)
  const next = { ...loaded.state }
  const affected = new Set([...oldRefs, ...newRefs].map((ref) => canonicalId(ref.id)))
  for (const [id] of entries) if (affected.has(canonicalId(id))) delete next[id]
  for (const current of newRefs) {
    const previous = oldRefs.filter((old) => current.owned
      ? old.owned && old.event === current.event
      : old.hook === current.hook)
    const previousIds = new Set(previous.map((ref) => canonicalId(ref.id)))
    let matches = entries.filter(([id]) => previousIds.has(canonicalId(id)))
    // A disabled ID can outlive a missing hooks.json entry. Preserve it on an
    // automatic reinstall, but never borrow an ID formerly owned by another hook.
    if (!previous.length && !oldRefs.some((old) => canonicalId(old.id) === canonicalId(current.id))) {
      matches = entries.filter(([id]) => canonicalId(id) === canonicalId(current.id))
    }
    if (matches.length) {
      const entry = { ...table(matches[0][1], matches[0][0]) }
      // Duplicate historical Synapse hooks collapse conservatively to disabled.
      if (matches.some(([id, value]) => table(value, id)["enabled"] === false)) entry["enabled"] = false
      if (current.owned && enableHooks) entry["enabled"] = true
      next[current.id] = entry
    }
  }
  if (JSON.stringify(next) === JSON.stringify(loaded.state)) return (writeHooks) => writeHooks()
  loaded.hooks["state"] = next
  loaded.config["hooks"] = loaded.hooks
  const output = stringify(loaded.config)
  return (writeHooks) => {
    try {
      writeFileSync(loaded.configPath, output, { encoding: "utf8", mode: 0o600 })
      writeHooks()
    } catch (error) {
      // Keep positional state aligned if persisting hooks.json fails.
      if (loaded.original === undefined) rmSync(loaded.configPath, { force: true })
      else writeFileSync(loaded.configPath, loaded.original, "utf8")
      throw error
    }
  }
}
