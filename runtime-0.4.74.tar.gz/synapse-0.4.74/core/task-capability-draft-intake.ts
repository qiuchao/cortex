import { randomUUID } from "node:crypto"
import {
  TaskCapabilitySourceClientSchema,
  resolveWorkItemCreateIntentKind,
  toTaskOperationId,
  type TaskCapabilitySourceClient,
  type WorkItemCreateIntentKind,
} from "@cerebro/wire"
import type { InjectRequest } from "../transport/contract.ts"
import { taskCapabilityDraftPath } from "../transport/discovery.ts"
import { loadSessionState, persistSessionState } from "./session-store.ts"
import {
  cancelTaskDraftWithReconciliation,
  defaultTaskDraftLifecycle,
  inspectTaskDraftAfterConfirmError,
  type TaskDraftLifecycle,
} from "./task-draft-lifecycle.ts"
import { validateWorkItemContextReceipt } from "../transport/brain-contract-align.ts"
import type { WorkItemContextReceiptAction, WorkItemContextReceiptContinuationIntent } from "./work-item-context-receipt-intent.ts"

export interface TaskContextMissingRef {
  targetPublicId: string
  missingKey: string
}

export interface TaskCapabilityDraftRef {
  draftId: string
  requestId: string
  productionId: string
  expiresAt: string
  resource: TaskCapabilityDraftResource
  command: string
  attempted: boolean
  /** Fixed processing basis for any draft derived from loaded work-item context. */
  contextReceiptId?: string
  contextTargetPublicId?: string
}

export interface TaskDraftContextBinding {
  contextReceiptId: string
  contextTargetPublicId: string
}

export type TaskDraftRequestAuthorization =
  | { authorized: false }
  | { authorized: true; sourceClient: TaskCapabilitySourceClient; binding?: TaskDraftContextBinding }

export type TaskCapabilityDraftResource = "requirement" | "bug" | "iteration" | "work_item"

export interface TaskCapabilityDraftIntake {
  registerRequest?(
    requestId: string,
    productionId: string,
    request: InjectRequest,
    policy?: {
      workItemWritesBlocked?: boolean
      workItemWriteTarget?: string
      contextReceiptId?: string
      contextReceiptValidated?: boolean
      blockingContextMissingKeys?: readonly TaskContextMissingRef[]
    },
  ): void
  authorizeRequest?(
    requestId: string,
    productionId: string,
    request?: { command: string; input: Record<string, unknown> },
  ): TaskDraftRequestAuthorization
  resolveContextMissing?(contextReceiptId: string, targetPublicId: string, missingKeys: readonly string[]): void
  recordContextReceiptValidation?(contextReceiptId: string, validated: boolean): void
  resolveContextReceiptContinuation?(
    request: InjectRequest,
    intent: WorkItemContextReceiptContinuationIntent,
  ): WorkItemContextReceiptAction | { error: string } | undefined
  reissueRequestForContext?(
    contextReceiptId: string,
    targetPublicId: string,
    sourceClient: TaskCapabilitySourceClient,
    writeAuthorized: boolean,
  ): { requestId: string; productionId: string; targetPublicId: string } | undefined
  remember(ref: Pick<TaskCapabilityDraftRef,
    "draftId" | "requestId" | "productionId" | "expiresAt" | "resource" | "command"
    | "contextReceiptId" | "contextTargetPublicId"
  >): void
  ownsAction?(input: string): boolean
  maybeHandle(request: InjectRequest): Promise<string | undefined>
}

export interface TaskCapabilityDraftIntakeDeps {
  createPath?: string
  getDraft?: TaskDraftLifecycle["get"]
  confirmDraft?: TaskDraftLifecycle["confirm"]
  cancelDraft?: TaskDraftLifecycle["cancel"]
  validateContextReceipt?: typeof validateWorkItemContextReceipt
}

interface StoredStateV5 {
  version: 5
  drafts: Record<string, StoredTaskCapabilityDraftRef>
  requestOwners: Record<string, StoredTaskDraftRequestOwner>
}

interface StoredTaskCapabilityDraftRef {
  draftId: string
  requestId: string
  productionId: string
  expiresAt: string
  resource?: TaskCapabilityDraftResource
  command?: string
  attempted: boolean
  contextReceiptId?: string
  contextTargetPublicId?: string
}

interface StoredTaskDraftRequestOwner {
  productionId: string
  expiresAt: number
  /** Optional only so pre-sourceClient v5 state can still be loaded fail-closed. */
  sourceClient?: TaskCapabilitySourceClient
  workItemWritesBlocked: boolean
  createIntentKind?: WorkItemCreateIntentKind
  workItemWriteTarget?: string
  contextReceiptId?: string
  contextReceiptValidated: boolean
  blockingContextMissingKeys: TaskContextMissingRef[]
  sessionId?: string
  registeredAt?: number
}

interface LoadedState {
  drafts: Record<string, StoredTaskCapabilityDraftRef>
  requestOwners: Record<string, StoredTaskDraftRequestOwner>
}

const ACTION = /^(确认|取消)\s*(需求|Bug|缺陷|迭代|工作项)\s*操作\s*[：:]?\s*(OP-[0-9A-F]{8})[。！!]*$/i
const DRAFT_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
const WORK_ITEM_PUBLIC_ID = /^[A-Za-z]{2,6}-(?:R|B)\d{4,}$/i

export function createTaskCapabilityDraftIntake(
  env: NodeJS.ProcessEnv = process.env,
  deps: TaskCapabilityDraftIntakeDeps = {},
): TaskCapabilityDraftIntake {
  const path = deps.createPath ?? taskCapabilityDraftPath(env)
  const state = loadSessionState(path, emptyState, parseState)
  const refs = state.drafts
  const defaults = defaultTaskDraftLifecycle(env)
  const lifecycle: TaskDraftLifecycle = {
    create: defaults.create,
    get: deps.getDraft ?? defaults.get,
    confirm: deps.confirmDraft ?? defaults.confirm,
    cancel: deps.cancelDraft ?? defaults.cancel,
  }
  const validateContextReceiptBeforeConfirm = deps.validateContextReceipt ?? ((input) => validateWorkItemContextReceipt(input, env))
  const acting = new Set<string>()
  const requestOwners = new Map(Object.entries(state.requestOwners))
  const save = () => persistSessionState(path, {
    version: 5,
    drafts: refs,
    requestOwners: Object.fromEntries(requestOwners),
  } satisfies StoredStateV5)

  return {
    registerRequest(requestId, productionId, request, policy = {}) {
      if (!request.session_id) return
      const sourceClient = TaskCapabilitySourceClientSchema.safeParse(request.client)
      if (!sourceClient.success) return
      const blockingContextMissingKeys = uniqueContextMissing(policy.blockingContextMissingKeys ?? [])
      const createIntentKind = resolveWorkItemCreateIntentKind(request.user_input)
      requestOwners.set(requestId, {
        productionId,
        expiresAt: Date.now() + 15 * 60 * 1_000,
        sourceClient: sourceClient.data,
        workItemWritesBlocked: policy.workItemWritesBlocked === true,
        ...(createIntentKind !== "none" ? { createIntentKind } : {}),
        ...(policy.workItemWriteTarget ? { workItemWriteTarget: policy.workItemWriteTarget.toUpperCase() } : {}),
        ...(policy.contextReceiptId ? { contextReceiptId: policy.contextReceiptId.toLowerCase() } : {}),
        contextReceiptValidated: policy.contextReceiptValidated
          ?? (Boolean(policy.contextReceiptId) && blockingContextMissingKeys.length === 0),
        blockingContextMissingKeys,
        sessionId: request.session_id,
        registeredAt: Date.now(),
      })
      if (requestOwners.size > 1_000) {
        const now = Date.now()
        for (const [id, owner] of requestOwners) if (owner.expiresAt <= now) requestOwners.delete(id)
        while (requestOwners.size > 1_000) requestOwners.delete(requestOwners.keys().next().value!)
      }
      try { save() } catch { /* The in-memory identity remains valid for this daemon. */ }
    },

    authorizeRequest(requestId, productionId, request) {
      const owner = requestOwners.get(requestId)
      if (!owner || owner.expiresAt <= Date.now() || owner.productionId !== productionId) return { authorized: false }
      // Legacy v5 owners remain readable so existing draft confirmations work,
      // but cannot authorize a new unattributed draft.
      if (!owner.sourceClient) return { authorized: false }
      if (owner.workItemWritesBlocked) return { authorized: false }
      if (!request) return { authorized: true, sourceClient: owner.sourceClient }
      if (owner.blockingContextMissingKeys.length > 0
        || (owner.contextReceiptId && !owner.contextReceiptValidated)) return { authorized: false }
      if (!isWorkItemWriteCommand(request.command)) return { authorized: true, sourceClient: owner.sourceClient }
      // A standalone creation has no existing work-item target. When a create
      // turn did load one work item, bind that source as its processing basis.
      if (isWorkItemCreateCommand(request.command)) {
        const commandKind = request.command === "bug.create" ? "bug" : "requirement"
        if (owner.createIntentKind !== commandKind) return { authorized: false }
        const parentId = request.command === "requirement.create" && typeof request.input.parentId === "string"
          ? request.input.parentId.toUpperCase()
          : undefined
        if (parentId && parentId !== owner.workItemWriteTarget) return { authorized: false }
        if (!owner.contextReceiptId && !owner.workItemWriteTarget) {
          return { authorized: true, sourceClient: owner.sourceClient }
        }
        return owner.contextReceiptId && owner.workItemWriteTarget && owner.contextReceiptValidated
          ? {
              authorized: true,
              sourceClient: owner.sourceClient,
              binding: contextBinding(owner.contextReceiptId, owner.workItemWriteTarget),
            }
          : { authorized: false }
      }
      if (!owner.workItemWriteTarget
        || primaryWorkItemWriteTarget(request.command, request.input) !== owner.workItemWriteTarget
        || !owner.contextReceiptId
        || !owner.contextReceiptValidated) return { authorized: false }
      return {
        authorized: true,
        sourceClient: owner.sourceClient,
        binding: contextBinding(owner.contextReceiptId, owner.workItemWriteTarget),
      }
    },

    resolveContextMissing(contextReceiptId, targetPublicId, missingKeys) {
      const normalizedReceiptId = contextReceiptId.toLowerCase()
      const normalizedTargetPublicId = targetPublicId.toUpperCase()
      const resolved = new Set(missingKeys)
      if (resolved.size === 0) return
      for (const owner of requestOwners.values()) {
        if (owner.contextReceiptId !== normalizedReceiptId) continue
        owner.contextReceiptValidated = false
        owner.blockingContextMissingKeys = owner.blockingContextMissingKeys.filter((item) => (
          item.targetPublicId !== normalizedTargetPublicId || !resolved.has(item.missingKey)
        ))
      }
      try { save() } catch { /* Keep the resolved in-memory authorization state. */ }
    },

    recordContextReceiptValidation(contextReceiptId, validated) {
      const normalizedReceiptId = contextReceiptId.toLowerCase()
      for (const owner of requestOwners.values()) {
        if (owner.contextReceiptId !== normalizedReceiptId) continue
        owner.contextReceiptValidated = validated && owner.blockingContextMissingKeys.length === 0
      }
      try { save() } catch { /* Keep the validation result in memory. */ }
    },

    resolveContextReceiptContinuation(request, intent) {
      if (!request.session_id) return undefined
      const owners = [...requestOwners.values()].filter((owner) => (
        owner.expiresAt > Date.now()
        && owner.sourceClient === request.client
        && owner.sessionId === request.session_id
        && owner.contextReceiptId
        && owner.blockingContextMissingKeys.length > 0
      )).sort((left, right) => (right.registeredAt ?? 0) - (left.registeredAt ?? 0))
      const latestReceiptId = owners[0]?.contextReceiptId
      if (!latestReceiptId) return undefined
      const latest = owners.filter((owner) => owner.contextReceiptId === latestReceiptId)
      const referenced = new Set(intent.referencedPublicIds.map((item) => item.toUpperCase()))
      const candidates = uniqueContextMissing(latest.flatMap((owner) => owner.blockingContextMissingKeys))
        .filter((item) => referenced.size === 0 || referenced.has(item.targetPublicId) || [...referenced].some((id) => item.missingKey.includes(id)))
      if (candidates.length === 0) {
        return { error: "没有找到这次对话中与所述单号对应的缺失资料，请重新说明要处理哪张单的缺失资料。" }
      }
      const targets = [...new Set(candidates.map((item) => item.targetPublicId))]
      if (targets.length !== 1 || candidates.length !== 1) {
        return { error: "当前有多份缺失资料，无法唯一判断你指的是哪一份。请说明所属单号，以及是缺失的文档还是评论。" }
      }
      const targetPublicId = targets[0]!
      const missingKey = candidates[0]!.missingKey
      if (intent.kind === "ignore") {
        return { kind: "ignore", contextReceiptId: latestReceiptId, requestId: randomUUID(), targetPublicId, missingKeys: [missingKey] }
      }
      const sourcePublicId = missingKey.match(/(?:document|comment):([A-Za-z]{2,6}-(?:R|B)\d{4,})/i)?.[1]?.toUpperCase()
        ?? intent.referencedPublicIds.find((item) => item !== targetPublicId)
        ?? targetPublicId
      return {
        kind: "supplement",
        contextReceiptId: latestReceiptId,
        requestId: randomUUID(),
        targetPublicId,
        sourcePublicId,
        content: intent.content,
        replacesMissingKeys: [missingKey],
      }
    },

    reissueRequestForContext(contextReceiptId, targetPublicId, sourceClient, writeAuthorized) {
      if (!writeAuthorized) return undefined
      const parsedSourceClient = TaskCapabilitySourceClientSchema.safeParse(sourceClient)
      if (!parsedSourceClient.success) return undefined
      const normalizedReceiptId = contextReceiptId.toLowerCase()
      const normalizedTargetPublicId = targetPublicId.toUpperCase()
      const matches = [...requestOwners.entries()].filter(([, owner]) => (
        owner.expiresAt > Date.now()
        && owner.contextReceiptId === normalizedReceiptId
        && owner.workItemWriteTarget === normalizedTargetPublicId
        && owner.contextReceiptValidated
        && owner.blockingContextMissingKeys.length === 0
      ))
      const productionIds = new Set(matches.map(([, owner]) => owner.productionId))
      if (matches.length === 0 || productionIds.size !== 1) return undefined

      const requestId = randomUUID()
      const owner = matches[0]![1]
      for (const [existingRequestId] of matches) requestOwners.delete(existingRequestId)
      requestOwners.set(requestId, {
        ...owner,
        sourceClient: parsedSourceClient.data,
        workItemWritesBlocked: false,
        expiresAt: Date.now() + 15 * 60 * 1_000,
      })
      try { save() } catch {
        requestOwners.delete(requestId)
        for (const [existingRequestId, existingOwner] of matches) requestOwners.set(existingRequestId, existingOwner)
        return undefined
      }
      return { requestId, productionId: owner.productionId, targetPublicId: normalizedTargetPublicId }
    },

    remember(ref) {
      const owner = requestOwners.get(ref.requestId)
      if (!owner || owner.expiresAt <= Date.now() || owner.productionId !== ref.productionId) return
      const existing = refs[ref.draftId]
      const contextReceiptId = ref.resource === "iteration" ? undefined : ref.contextReceiptId ?? owner.contextReceiptId
      const contextTargetPublicId = ref.resource === "iteration"
        ? undefined
        : ref.contextTargetPublicId ?? owner.workItemWriteTarget
      if (Boolean(contextReceiptId) !== Boolean(contextTargetPublicId)) return
      if (ref.contextReceiptId && owner.contextReceiptId && ref.contextReceiptId.toLowerCase() !== owner.contextReceiptId) return
      if (ref.contextTargetPublicId && owner.workItemWriteTarget
        && ref.contextTargetPublicId.toUpperCase() !== owner.workItemWriteTarget) return
      refs[ref.draftId] = existing
        && existing.requestId === ref.requestId
        && existing.productionId === ref.productionId
        ? {
            ...existing,
            expiresAt: ref.expiresAt,
            resource: ref.resource,
            command: ref.command,
            ...(existing.contextReceiptId || contextReceiptId
              ? { contextReceiptId: existing.contextReceiptId ?? contextReceiptId }
              : {}),
            ...(existing.contextTargetPublicId || contextTargetPublicId
              ? { contextTargetPublicId: existing.contextTargetPublicId ?? contextTargetPublicId }
              : {}),
          }
        : {
            ...ref,
            attempted: false,
            ...(contextReceiptId ? { contextReceiptId } : {}),
            ...(contextTargetPublicId ? { contextTargetPublicId } : {}),
          }
      try {
        save()
      } catch {
        // Keep the reference in memory so the current daemon can still confirm/cancel.
        // The next daemon restart will fail closed with an explicit missing-reference message.
      }
    },

    ownsAction(input) {
      const match = input.trim().match(ACTION)
      return Boolean(match && Object.values(refs).some((ref) => operationId(ref.draftId) === match[3]!.toUpperCase()))
    },

    async maybeHandle(request) {
      const match = request.user_input.trim().match(ACTION)
      if (!match) return undefined
      const action = match[1] === "确认" ? "confirm" : "cancel"
      const requestedResource = parseResourceLabel(match[2]!)
      const requestedOperationId = match[3]!.toUpperCase()
      const candidates = Object.values(refs).filter((candidate) => operationId(candidate.draftId) === requestedOperationId)
      if (!candidates.length) return `[Synapse] 本机没有可确认的需求、Bug、迭代或工作项操作 ${requestedOperationId}；请重新发起该操作。`
      if (candidates.length > 1) return `[Synapse] 操作编号 ${requestedOperationId} 无法唯一定位，请提供新的操作编号或重新发起该操作。`
      const ref = candidates[0]!
      if (!ref.resource || !ref.command) {
        try {
          const current = await lifecycle.get(ref.productionId, ref.draftId)
          if (current.id !== ref.draftId || current.requestId !== ref.requestId || current.productionId !== ref.productionId) {
            return `[Synapse] 操作 ${requestedOperationId} 的服务端记录与本地可信引用不一致，未执行写入；请重新生成操作。`
          }
          const resource = resourceFromCommand(current.command)
          if (ref.resource && ref.resource !== resource) {
            return `[Synapse] 操作 ${requestedOperationId} 的服务端类型与本地可信引用不一致，未执行写入；请重新生成操作。`
          }
          ref.resource = resource
          ref.command = current.command
          const contextReceiptId = current.contextReceiptId ?? undefined
          const contextTargetPublicId = current.contextTargetPublicId ?? undefined
          if (Boolean(contextReceiptId) !== Boolean(contextTargetPublicId)) {
            return `[Synapse] 操作 ${requestedOperationId} 的服务端上下文依据不完整，未执行写入；请重新生成操作。`
          }
          if (contextReceiptId && contextTargetPublicId) {
            ref.contextReceiptId = contextReceiptId
            ref.contextTargetPublicId = contextTargetPublicId
          }
        } catch {
          return `[Synapse] 暂时无法确认操作 ${requestedOperationId} 的真实类型，操作引用已保留；请稍后重试。`
        }
        try { save() } catch { /* The resolved in-memory reference remains usable in this daemon. */ }
      }
      const resolvedRef = ref as TaskCapabilityDraftRef
      if (requestedResource !== resolvedRef.resource) {
        return `[Synapse] ${requestedOperationId} 实际是${resourceLabel(resolvedRef.resource)}操作，请回复“${actionText(action, resolvedRef)}”。`
      }
      if (acting.has(ref.draftId)) return `[Synapse] ${resourceLabel(resolvedRef.resource)}操作 ${requestedOperationId} 正在处理，请勿重复操作。`
      acting.add(ref.draftId)
      try {
        return action === "confirm" ? await confirm(resolvedRef) : await cancel(resolvedRef)
      } finally {
        acting.delete(ref.draftId)
      }
    },
  }

  async function confirm(ref: TaskCapabilityDraftRef): Promise<string> {
    let current: Awaited<ReturnType<TaskDraftLifecycle["get"]>> | undefined
    try {
      current = await lifecycle.get(ref.productionId, ref.draftId)
    } catch {
      return `[Synapse] 暂时无法读取${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 的状态，未执行写入；请稍后重试确认。`
    }
    if (!current) {
      return `[Synapse] 暂时无法读取${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 的状态，未执行写入；请稍后重试确认。`
    }
    if (current.status !== "pending") return finishKnownDraft(ref, current)
    const expectedContextReceiptId = ref.contextReceiptId ?? null
    const expectedContextTargetPublicId = ref.contextTargetPublicId ?? null
    if (current.id !== ref.draftId
      || current.requestId !== ref.requestId
      || current.command !== ref.command
      || (current.contextReceiptId ?? null) !== expectedContextReceiptId
      || (current.contextTargetPublicId ?? null) !== expectedContextTargetPublicId) {
      return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 的服务端记录与本次可信操作依据不一致，未执行写入；请重新生成操作。`
    }
    if (requiresContextBinding(ref.command, ref.contextReceiptId)) {
      if (!ref.contextReceiptId || !ref.contextTargetPublicId) {
        return `[Synapse] 工作项操作 ${operationId(ref.draftId)} 缺少可校验的上下文读取回执，未执行写入；请刷新上下文并重新生成操作。`
      }
      const validation = await validateContextReceiptBeforeConfirm({ contextReceiptId: ref.contextReceiptId })
      if (!validation.ok) {
        const terminal = await inspectTaskDraftAfterConfirmError(lifecycle, ref.productionId, ref.draftId)
        if (terminal && terminal.status !== "pending") return finishKnownDraft(ref, terminal)
        return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 发布前上下文校验失败，未执行写入；请稍后重试确认或刷新上下文。`
      }
      if (validation.value.status === "refresh_required") {
        return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 的处理依据已变化，未执行写入：${validation.value.message}。请重新加载受影响工作项并生成新的操作。`
      }
    }
    ref.attempted = true
    try { save() } catch { /* Keep the in-memory reference while the remote operation is authoritative. */ }
    try {
      const receipt = await lifecycle.confirm(ref.productionId, ref.draftId)
      delete refs[ref.draftId]
      saveAfterRemoteWrite(save)
      if (isNoOpResult(receipt.result)) {
        return completedActionContext(
          `${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已确认，但本次未产生新的业务变更；时间 ${receipt.draft.confirmedAt ?? receipt.draft.createdAt}。${resultIdentity(receipt.result, ref.resource)}`,
        )
      }
      return completedActionContext(
        `${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已确认，业务写入已完成；时间 ${receipt.draft.confirmedAt ?? receipt.draft.createdAt}。${resultIdentity(receipt.result, ref.resource)}`,
      )
    } catch (error) {
      const current = await inspectTaskDraftAfterConfirmError(lifecycle, ref.productionId, ref.draftId)
      if (!current || current.status === "pending") {
        const state = current ? "仍为 pending" : "状态暂时不可读取"
        return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 确认结果未知（${state}）；请重试同一条“${actionText("confirm", ref)}”，或回复“${actionText("cancel", ref)}”。`
      }
      delete refs[ref.draftId]
      saveAfterRemoteWrite(save)
      if (current.status === "confirmed") {
        return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已由 Cerebro 确认；时间 ${current.confirmedAt ?? current.createdAt}，请查询对应记录核对。`
      }
      return terminalDraftMessage(ref, current)
    }
  }

  async function cancel(ref: TaskCapabilityDraftRef): Promise<string> {
    try {
      const current = await cancelTaskDraftWithReconciliation(lifecycle, ref.productionId, ref.draftId)
      delete refs[ref.draftId]
      saveAfterRemoteWrite(save)
      if (current.status === "confirmed") {
        return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已由 Cerebro 确认，无法取消；时间 ${current.confirmedAt ?? current.createdAt}，请查询对应记录核对。`
      }
      return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已${terminalStatus(current.status)}，服务端未执行新的业务写入；时间 ${terminalTime(current)}。`
    } catch {
      return `[Synapse] 暂时无法取消${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)}，操作引用已保留；请稍后重试“${actionText("cancel", ref)}”。`
    }
  }

  function finishKnownDraft(ref: TaskCapabilityDraftRef, current: Awaited<ReturnType<TaskDraftLifecycle["get"]>>): string {
    delete refs[ref.draftId]
    saveAfterRemoteWrite(save)
    if (current.status === "confirmed") {
      return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已由 Cerebro 确认；时间 ${current.confirmedAt ?? current.createdAt}，请查询对应记录核对。`
    }
    return terminalDraftMessage(ref, current)
  }
}

function completedActionContext(message: string): string {
  return `[Synapse] ${message}\n[Synapse] 这次确认已由 Synapse 完成。不要再运行任何命令、工具或重复提交；只用普通业务语言向用户简短说明结果，不展示内部字段、路径或实现细节。`
}

function uniqueContextMissing(values: readonly TaskContextMissingRef[]): TaskContextMissingRef[] {
  const unique = new Map<string, TaskContextMissingRef>()
  for (const value of values) {
    const item = { targetPublicId: value.targetPublicId.toUpperCase(), missingKey: value.missingKey }
    unique.set(`${item.targetPublicId}\n${item.missingKey}`, item)
  }
  return [...unique.values()]
}

function emptyState(): LoadedState {
  return { drafts: {}, requestOwners: {} }
}

function parseState(value: unknown): LoadedState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return emptyState()
  const state = value as { version?: unknown; drafts?: unknown; requestOwners?: unknown }
  if (state.version !== 3 && state.version !== 4 && state.version !== 5) return emptyState()

  const drafts = state.drafts && typeof state.drafts === "object" && !Array.isArray(state.drafts)
    ? Object.fromEntries(Object.entries(state.drafts).flatMap(([key, value]) => {
        const parsed = parseStoredDraftRef(key, value)
        return parsed ? [[key, parsed]] : []
      }))
    : {}
  const requestOwners = state.version === 5
    && state.requestOwners && typeof state.requestOwners === "object" && !Array.isArray(state.requestOwners)
    ? Object.fromEntries(Object.entries(state.requestOwners).flatMap(([key, value]) => {
        const parsed = parseStoredRequestOwner(key, value)
        return parsed ? [[key, parsed]] : []
      }))
    : {}
  return { drafts, requestOwners }
}

function parseStoredDraftRef(key: string, value: unknown): StoredTaskCapabilityDraftRef | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined
  const ref = value as Partial<StoredTaskCapabilityDraftRef>
  if (typeof ref.draftId !== "string" || !DRAFT_UUID.test(ref.draftId) || key !== ref.draftId
    || typeof ref.requestId !== "string" || !DRAFT_UUID.test(ref.requestId)
    || typeof ref.productionId !== "string" || !ref.productionId.trim()
    || typeof ref.expiresAt !== "string" || !Number.isFinite(Date.parse(ref.expiresAt))
    || (ref.command !== undefined && typeof ref.command !== "string")
    || (ref.resource !== undefined && !isDraftResource(ref.resource))
    || typeof ref.attempted !== "boolean"
    || (ref.contextReceiptId !== undefined && (typeof ref.contextReceiptId !== "string" || !DRAFT_UUID.test(ref.contextReceiptId)))
    || (ref.contextTargetPublicId !== undefined
      && (typeof ref.contextTargetPublicId !== "string" || !WORK_ITEM_PUBLIC_ID.test(ref.contextTargetPublicId)))
    || Boolean(ref.contextReceiptId) !== Boolean(ref.contextTargetPublicId)) return undefined
  return {
    draftId: ref.draftId,
    requestId: ref.requestId,
    productionId: ref.productionId,
    expiresAt: ref.expiresAt,
    ...(ref.resource ? { resource: ref.resource } : {}),
    ...(ref.command ? { command: ref.command } : {}),
    attempted: ref.attempted,
    ...(ref.contextReceiptId ? { contextReceiptId: ref.contextReceiptId.toLowerCase() } : {}),
    ...(ref.contextTargetPublicId ? { contextTargetPublicId: ref.contextTargetPublicId.toUpperCase() } : {}),
  }
}

function parseStoredRequestOwner(key: string, value: unknown): StoredTaskDraftRequestOwner | undefined {
  if (!DRAFT_UUID.test(key) || !value || typeof value !== "object" || Array.isArray(value)) return undefined
  const owner = value as Partial<StoredTaskDraftRequestOwner>
  if (typeof owner.productionId !== "string" || !owner.productionId.trim()
    || typeof owner.expiresAt !== "number" || !Number.isFinite(owner.expiresAt) || owner.expiresAt <= Date.now()
    || typeof owner.workItemWritesBlocked !== "boolean"
    || typeof owner.contextReceiptValidated !== "boolean"
    || !Array.isArray(owner.blockingContextMissingKeys)
    || (owner.workItemWriteTarget !== undefined
      && (typeof owner.workItemWriteTarget !== "string" || !WORK_ITEM_PUBLIC_ID.test(owner.workItemWriteTarget)))
    || (owner.contextReceiptId !== undefined
      && (typeof owner.contextReceiptId !== "string" || !DRAFT_UUID.test(owner.contextReceiptId)))
    || (owner.sourceClient !== undefined
      && !TaskCapabilitySourceClientSchema.safeParse(owner.sourceClient).success)
    || (owner.createIntentKind !== undefined && !isWorkItemCreateIntentKind(owner.createIntentKind))
    || (owner.sessionId !== undefined && (typeof owner.sessionId !== "string" || !owner.sessionId))
    || (owner.registeredAt !== undefined && (typeof owner.registeredAt !== "number" || !Number.isFinite(owner.registeredAt)))) return undefined
  const blockingContextMissingKeys = owner.blockingContextMissingKeys.flatMap((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return []
    const ref = item as Partial<TaskContextMissingRef>
    return typeof ref.targetPublicId === "string" && WORK_ITEM_PUBLIC_ID.test(ref.targetPublicId)
      && typeof ref.missingKey === "string" && ref.missingKey.startsWith("missing:")
      ? [{ targetPublicId: ref.targetPublicId.toUpperCase(), missingKey: ref.missingKey }]
      : []
  })
  if (blockingContextMissingKeys.length !== owner.blockingContextMissingKeys.length) return undefined
  return {
    productionId: owner.productionId,
    expiresAt: owner.expiresAt,
    ...(owner.sourceClient ? { sourceClient: owner.sourceClient } : {}),
    workItemWritesBlocked: owner.workItemWritesBlocked,
    ...(owner.createIntentKind ? { createIntentKind: owner.createIntentKind } : {}),
    ...(owner.workItemWriteTarget ? { workItemWriteTarget: owner.workItemWriteTarget.toUpperCase() } : {}),
    ...(owner.contextReceiptId ? { contextReceiptId: owner.contextReceiptId.toLowerCase() } : {}),
    contextReceiptValidated: owner.contextReceiptValidated,
    blockingContextMissingKeys: uniqueContextMissing(blockingContextMissingKeys),
    ...(typeof owner.sessionId === "string" && owner.sessionId ? { sessionId: owner.sessionId } : {}),
    ...(typeof owner.registeredAt === "number" && Number.isFinite(owner.registeredAt) ? { registeredAt: owner.registeredAt } : {}),
  }
}

function resultIdentity(value: unknown, resource: TaskCapabilityDraftResource): string {
  if (!value || typeof value !== "object" || Array.isArray(value)) return ""
  const result = value as Record<string, unknown>
  const nested = result.requirement && typeof result.requirement === "object"
    ? result.requirement as Record<string, unknown>
    : result.bug && typeof result.bug === "object"
      ? result.bug as Record<string, unknown>
      : result
  const id = typeof nested.publicId === "string" ? nested.publicId : undefined
  const title = typeof nested.title === "string" ? nested.title : typeof nested.name === "string" ? nested.name : undefined
  if (id) return ` ${resourceLabel(resource)}：${id}${title ? ` ${title}` : ""}。`
  return title ? ` ${resourceLabel(resource)}：${title}。` : ""
}

function isNoOpResult(value: unknown): boolean {
  return Boolean(value && typeof value === "object" && !Array.isArray(value)
    && (value as Record<string, unknown>).noOp === true)
}

function isDraftResource(value: unknown): value is TaskCapabilityDraftResource {
  return value === "requirement" || value === "bug" || value === "iteration" || value === "work_item"
}

function resourceFromCommand(command: string): TaskCapabilityDraftResource {
  if (command.startsWith("requirement.")) return "requirement"
  if (command.startsWith("bug.")) return "bug"
  if (command.startsWith("iteration.")) return "iteration"
  if (command.startsWith("work_item.")) return "work_item"
  throw new Error("unsupported operation resource")
}

function parseResourceLabel(value: string): TaskCapabilityDraftResource {
  if (/^需求$/i.test(value)) return "requirement"
  if (/^(?:bug|缺陷)$/i.test(value)) return "bug"
  if (/^迭代$/i.test(value)) return "iteration"
  return "work_item"
}

function resourceLabel(resource: TaskCapabilityDraftResource): "需求" | "Bug" | "迭代" | "工作项" {
  return resource === "requirement" ? "需求" : resource === "bug" ? "Bug" : resource === "iteration" ? "迭代" : "工作项"
}

function actionText(action: "confirm" | "cancel", ref: Pick<TaskCapabilityDraftRef, "draftId" | "resource">): string {
  return `${action === "confirm" ? "确认" : "取消"}${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)}`
}

function operationId(draftId: string): string {
  return toTaskOperationId(draftId)
}

function isWorkItemWriteCommand(command: string): boolean {
  return command.startsWith("requirement.") || command.startsWith("bug.") || command.startsWith("work_item.")
}

function isWorkItemCreateCommand(command: string): boolean {
  return command === "requirement.create" || command === "bug.create"
}

function isWorkItemCreateIntentKind(value: unknown): value is WorkItemCreateIntentKind {
  return value === "bug" || value === "requirement" || value === "ambiguous" || value === "none"
}

function requiresContextBinding(command: string, contextReceiptId?: string): boolean {
  if (command.startsWith("iteration.")) return false
  if (isWorkItemCreateCommand(command)) return Boolean(contextReceiptId)
  return isWorkItemWriteCommand(command)
}

function contextBinding(contextReceiptId: string, contextTargetPublicId: string): TaskDraftContextBinding {
  return {
    contextReceiptId: contextReceiptId.toLowerCase(),
    contextTargetPublicId: contextTargetPublicId.toUpperCase(),
  }
}

function primaryWorkItemWriteTarget(command: string, input: Record<string, unknown>): string | undefined {
  const value = command.startsWith("requirement.bug.")
    ? input.bugId
    : input.targetPublicId ?? input.requirementId ?? input.bugId
  return typeof value === "string" ? value.toUpperCase() : undefined
}

function terminalStatus(status: string): string {
  return status === "cancelled" ? "取消" : status === "expired" ? "过期" : status === "failed" ? "执行失败" : status
}

function terminalDraftMessage(
  ref: Pick<TaskCapabilityDraftRef, "draftId" | "resource" | "command">,
  current: Awaited<ReturnType<TaskDraftLifecycle["get"]>>,
): string {
  const time = terminalTime(current)
  if (current.status === "failed" && current.errorSnapshot?.code === "FORBIDDEN") {
    if (ref.command === "work_item.comment.update") {
      return `[Synapse] 这条评论只有发布者本人可以修改，本次没有改动；时间 ${time}。`
    }
    if (ref.command === "work_item.comment.delete") {
      return `[Synapse] 这条评论只有发布者本人可以删除，本次没有删除；时间 ${time}。`
    }
    return `[Synapse] 你没有执行这项操作的权限，本次没有改动；时间 ${time}。`
  }
  return `[Synapse] ${resourceLabel(ref.resource)}操作 ${operationId(ref.draftId)} 已${terminalStatus(current.status)}，未执行新的业务写入；时间 ${time}。`
}

function terminalTime(value: { cancelledAt?: string | null; expiredAt?: string | null; failedAt?: string | null; createdAt: string }): string {
  return value.cancelledAt ?? value.expiredAt ?? value.failedAt ?? value.createdAt
}

function saveAfterRemoteWrite(save: () => void): void {
  try { save() } catch { /* Cerebro receipt remains authoritative. */ }
}
