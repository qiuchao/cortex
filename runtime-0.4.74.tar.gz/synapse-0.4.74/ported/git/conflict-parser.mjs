#!/usr/bin/env node
/**
 * scripts/conflict-parser.mjs — git 冲突标记解析 + 决策应用（纯函数，可单测）
 *
 * 解析含 git 冲突标记（<<<<<<< / ======= / >>>>>>>）的文件内容为结构化冲突点，
 * 并支持把逐点决策（ours / theirs / manual）应用回文件内容。
 *
 * 设计约束：
 *   - 纯函数、零副作用、零 I/O，便于确定性单测（与 stash-track-helper.mjs 同 ES module 风格）。
 *   - 解析结果只在内部使用；展示给用户时由 agent 翻译成人话，绝不暴露 git 冲突标记（R9 GP-2）。
 *   - applyDecisions 防御性处理「未决策」点：保留冲突标记不静默丢弃（数据安全）。
 *   - diff3/zdiff3 支持：`||||||| base` 段在解析时静默丢弃，不并入 ours（fix-2）。
 *   - 未闭合冲突块：循环结束后若 state 非 normal，回吐原始标记 + 缓冲内容，不静默丢弃（fix-1）。
 *
 * 支撑需求：R4（冲突诊断逐点解析）/ R5（按冲突点分别应用不同策略）
 *
 * ADR: git-operation-state-machine
 */

/**
 * @typedef {Object} ConflictPoint
 * @property {string} file   文件名（展示用）
 * @property {number} index  该文件第几处冲突（从 1 起）
 * @property {string} ours   HEAD（本地）的内容
 * @property {string} theirs 对方（主干 / 合并来源）的内容
 */

/**
 * 解析含冲突标记的文件内容为结构化冲突点列表。
 *
 * 支持标准 merge 格式和 diff3/zdiff3 格式（`||||||| base` 段静默丢弃）。
 *
 * @param {string} content - 含 <<<<<<<、=======、>>>>>>> 的原始文件内容
 * @param {string} filename - 文件名（展示用）
 * @returns {ConflictPoint[]}
 */
export function parseConflicts(content, filename) {
  const conflicts = []
  const lines = String(content ?? "").split("\n")
  // state: 'normal' | 'ours' | 'base' | 'theirs'
  // 'base' = diff3 的 ||||||| base 段，内容直接丢弃
  let state = "normal"
  let oursLines = []
  let theirsLines = []
  let index = 0

  for (const line of lines) {
    if (line.startsWith("<<<<<<< ")) {
      state = "ours"
      oursLines = []
    } else if (line.startsWith("||||||| ") && state === "ours") {
      // diff3/zdiff3：进入 base 丢弃态（ours 已收集完毕）
      state = "base"
    } else if (line === "=======" && (state === "ours" || state === "base")) {
      // 标准 merge：ours → theirs；diff3：base → theirs
      state = "theirs"
      theirsLines = []
    } else if (line.startsWith(">>>>>>> ") && state === "theirs") {
      index++
      conflicts.push({
        file: filename,
        index,
        ours: oursLines.join("\n"),
        theirs: theirsLines.join("\n"),
      })
      state = "normal"
      oursLines = []
      theirsLines = []
    } else if (state === "ours") {
      oursLines.push(line)
    } else if (state === "base") {
      // base 段内容丢弃（不计入 ours / theirs）
    } else if (state === "theirs") {
      theirsLines.push(line)
    }
    // state === "normal"：普通行，parseConflicts 不收集（调用方只需冲突点）
  }
  return conflicts
}

/**
 * @typedef {Object} Decision
 * @property {'ours'|'theirs'|'manual'} strategy 决策策略
 * @property {string} [resolved] manual 策略时用户确认的最终内容
 */

/**
 * 把一组逐点决策应用回文件内容，输出解决冲突后的文件内容。
 *
 * @param {string} content - 含冲突标记的原始内容
 * @param {Map<number, Decision>} decisions - key = 冲突点 index（从 1 起）
 * @returns {string} 解决冲突后的文件内容
 */
export function applyDecisions(content, decisions) {
  const lines = String(content ?? "").split("\n")
  const result = []
  // state: 'normal' | 'ours' | 'base' | 'theirs'
  let state = "normal"
  let index = 0
  let oursLines = []
  let baseLines = []   // diff3 base 段，应用时亦丢弃（不写入输出）
  let theirsLines = []

  for (const line of lines) {
    if (line.startsWith("<<<<<<< ")) {
      state = "ours"
      oursLines = []
    } else if (line.startsWith("||||||| ") && state === "ours") {
      // diff3/zdiff3：进入 base 丢弃态
      state = "base"
      baseLines = []
    } else if (line === "=======" && (state === "ours" || state === "base")) {
      state = "theirs"
      theirsLines = []
    } else if (line.startsWith(">>>>>>> ") && state === "theirs") {
      index++
      const decision = decisions && decisions.get(index)
      if (!decision) {
        // 未决策的点：防御性保留冲突标记（不应发生，绝不静默丢弃用户内容）
        result.push("<<<<<<< HEAD")
        result.push(...oursLines)
        result.push("=======")
        result.push(...theirsLines)
        result.push(">>>>>>> remote")
      } else if (decision.strategy === "ours") {
        result.push(...oursLines)
      } else if (decision.strategy === "theirs") {
        result.push(...theirsLines)
      } else if (decision.strategy === "manual" && decision.resolved !== undefined) {
        result.push(decision.resolved)
      } else {
        // manual 但 resolved 未设置：防御性保留冲突标记，不崩溃
        result.push("<<<<<<< HEAD")
        result.push(...oursLines)
        result.push("=======")
        result.push(...theirsLines)
        result.push(">>>>>>> remote")
      }
      state = "normal"
      oursLines = []
      baseLines = []
      theirsLines = []
    } else if (state === "ours") {
      oursLines.push(line)
    } else if (state === "base") {
      baseLines.push(line) // 记录但不写入输出（仅供防御性回吐使用）
    } else if (state === "theirs") {
      theirsLines.push(line)
    } else {
      result.push(line)
    }
  }

  // 修复 1：循环结束后若有未闭合冲突块，回吐原始标记 + 缓冲内容，不静默丢弃
  if (state === "ours") {
    // 只进入了 ours 段，还未遇到 ======= 或 >>>>>>>
    result.push("<<<<<<< HEAD")
    result.push(...oursLines)
  } else if (state === "base") {
    // 进入了 diff3 base 段，但没有 >>>>>>> 结束
    result.push("<<<<<<< HEAD")
    result.push(...oursLines)
    result.push(`||||||| base`)
    result.push(...baseLines)
  } else if (state === "theirs") {
    // 进入了 theirs 段，但没有 >>>>>>> 结束标记
    result.push("<<<<<<< HEAD")
    result.push(...oursLines)
    result.push("=======")
    result.push(...theirsLines)
  }

  return result.join("\n")
}
