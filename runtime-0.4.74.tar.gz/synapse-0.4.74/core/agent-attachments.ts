import { randomUUID } from "node:crypto"
import { z } from "zod"

import { uploadBugAttachments, type BugAttachmentFile } from "../transport/brain-contract-align.ts"
import type { InjectRequest } from "../transport/contract.ts"
import { probeClaudeTranscriptAttachments } from "./parsers/claude-transcript-attachments.ts"
import { probeCodexTranscriptAttachments } from "./parsers/codex-transcript-attachments.ts"
import { materializeInlineImages } from "./parsers/inline-image-attachments.ts"

export const AgentAttachmentPrepareRequest = z.object({
  handle: z.string().uuid(),
}).strict()

export type AgentAttachmentPrepareResult =
  | { ok: true; attachmentTokens: string[]; files: Array<{ fileName: string }> }
  | { ok: false; reason: "validation_error" | "attachment_resolution_failed" | "attachment_upload_failed"; message: string; httpStatus: number }

interface RegisteredAgentAttachmentBase {
  productionId: string
  requireFiles: boolean
  mode: "upload" | "assert-empty"
}

type RegisteredAgentAttachmentTurn = RegisteredAgentAttachmentBase & (
  | { kind: "direct"; files: BugAttachmentFile[] }
  | { kind: "codex-transcript"; client: "codex"; sessionId: string; turnId: string; transcriptPath: string; prompt: string; cwd?: string }
  | { kind: "claude-transcript"; client: "claude-code"; sessionId: string; promptId: string; transcriptPath: string; prompt: string; cwd?: string }
)

export interface AgentAttachmentPrepareDeps {
  resolveCodexAttachments?: (request: RegisteredAgentAttachmentTurn) => BugAttachmentFile[] | undefined
  resolveClaudeAttachments?: (request: RegisteredAgentAttachmentTurn) => BugAttachmentFile[] | undefined
  uploadAttachments?: (files: readonly BugAttachmentFile[], productionId: string) => Promise<string[]>
  now?: () => number
}

export interface AgentAttachmentIntake {
  register(request: InjectRequest, productionId: string, options?: {
    requireFiles?: boolean
    mode?: "upload" | "assert-empty"
  }): string | undefined
  prepare(raw: unknown): Promise<AgentAttachmentPrepareResult>
}

export type AgentCreateAttachmentPlan =
  | { action: "none" }
  | {
      action: "prepare"
      mode: "upload" | "assert-empty"
      policy: "bug-upload" | "requirement-empty-check"
      requireFiles: boolean
    }
  | { action: "blocked"; message: string }

const HANDLE_TTL_MS = 15 * 60 * 1_000
const MAX_HANDLES = 1_000

/** A direct Task draft is safe only when the current hook proves no local files were attached. */
export function hasKnownNoAgentAttachments(request: InjectRequest): boolean {
  if (request.attachment_error || request.attachment_observation === "present" || request.attachments?.length) return false
  if (request.attachment_observation === "none") return true
  const source = request.deferred_attachment_source
  if (!source) return false
  if (request.client === "codex" && source.kind === "codex-transcript"
    && request.session_id && request.turn_id) {
    const probe = probeCodexTranscriptAttachments({
      transcriptPath: source.transcriptPath,
      sessionId: request.session_id,
      turnId: request.turn_id,
      prompt: request.user_input,
      cwd: request.cwd,
    })
    return probe.matched && !probe.attachments?.length
  }
  if (request.client === "claude-code" && source.kind === "claude-transcript"
    && request.session_id && request.message_id) {
    const probe = probeClaudeTranscriptAttachments({
      transcriptPath: source.transcriptPath,
      sessionId: request.session_id,
      promptId: request.message_id,
      prompt: request.user_input,
    })
    return probe.matched && !probe.attachments?.length
  }
  return false
}

/** Resolve every create client through the same fail-closed attachment policy. */
export function planAgentCreateAttachments(
  request: InjectRequest,
  kind: "bug" | "requirement",
  attachmentRequested: boolean,
): AgentCreateAttachmentPlan {
  if (request.attachment_error) {
    return {
      action: "blocked",
      message: `当前客户端报告了附件，但 Synapse 无法完整、安全地解析：${request.attachment_error}`,
    }
  }
  const source = request.deferred_attachment_source
  const filesPresent = Boolean(request.attachments?.length)
  const sourceContainsFiles = source?.kind === "inline-images" && source.images.length > 0
  const attachmentsPresent = filesPresent || sourceContainsFiles || request.attachment_observation === "present"

  if (kind === "requirement") {
    if (attachmentRequested || attachmentsPresent) {
      return {
        action: "blocked",
        message: "需求创建不支持附件；请移除当前回合文件，或改为创建支持附件的 Bug。",
      }
    }
    if (hasKnownNoAgentAttachments(request)) return { action: "none" }
    if (isDeferredTranscriptSource(request)) {
      return {
        action: "prepare",
        mode: "assert-empty",
        policy: "requirement-empty-check",
        requireFiles: false,
      }
    }
    return {
      action: "blocked",
      message: "当前客户端未能证明本回合没有附件，无法安全创建需求；请重试该请求。",
    }
  }

  if (hasKnownNoAgentAttachments(request) && !attachmentRequested) return { action: "none" }
  if (hasResolvableAttachmentSource(request)) {
    return {
      action: "prepare",
      mode: "upload",
      policy: "bug-upload",
      requireFiles: attachmentRequested || attachmentsPresent,
    }
  }
  return {
    action: "blocked",
    message: attachmentRequested || attachmentsPresent
      ? "当前客户端报告或要求携带附件，但 Synapse 无法为本回合建立安全附件来源。"
      : "当前客户端未能证明本回合没有附件，也没有提供可安全解析的附件来源。",
  }
}

/**
 * Registers attachment sources only while handling a trusted hook request.
 * The model receives an opaque handle, never a filesystem path or product ID.
 */
export function createAgentAttachmentIntake(
  env: NodeJS.ProcessEnv = process.env,
  deps: AgentAttachmentPrepareDeps = {},
): AgentAttachmentIntake {
  const entries = new Map<string, {
    request: RegisteredAgentAttachmentTurn
    expiresAt: number
    result?: Promise<AgentAttachmentPrepareResult>
  }>()
  const now = deps.now ?? Date.now

  return {
    register(request, productionId, options) {
      if (request.attachment_error) return undefined
      const source = request.deferred_attachment_source
      const requireFiles = options?.requireFiles === true
      const mode = options?.mode ?? "upload"
      const directFiles = request.attachments?.map((file) => ({ ...file })) ?? []
      const registered: RegisteredAgentAttachmentTurn | undefined = source?.kind === "inline-images" && source.images.length
        ? inlineImageRegistration(source.images, directFiles, productionId, requireFiles, mode, env)
        : directFiles.length
          ? { kind: "direct", productionId, requireFiles, mode, files: directFiles }
          : request.client === "codex" && source?.kind === "codex-transcript" && request.session_id && request.turn_id
        ? {
            kind: "codex-transcript" as const,
            client: "codex" as const,
            productionId,
            requireFiles,
            mode,
            sessionId: request.session_id,
            turnId: request.turn_id,
            transcriptPath: source.transcriptPath,
            prompt: request.user_input,
            ...(request.cwd ? { cwd: request.cwd } : {}),
          }
        : request.client === "claude-code" && source?.kind === "claude-transcript" && request.session_id && request.message_id
          ? {
              kind: "claude-transcript" as const,
              client: "claude-code" as const,
              productionId,
              requireFiles,
              mode,
              sessionId: request.session_id,
              promptId: request.message_id,
              transcriptPath: source.transcriptPath,
              prompt: request.user_input,
              ...(request.cwd ? { cwd: request.cwd } : {}),
            }
          : undefined
      if (!registered) return undefined
      prune(entries, now())
      const handle = randomUUID()
      entries.set(handle, {
        request: registered,
        expiresAt: now() + HANDLE_TTL_MS,
      })
      return handle
    },

    async prepare(raw) {
      const parsed = AgentAttachmentPrepareRequest.safeParse(raw)
      if (!parsed.success) {
        const issues = parsed.error.issues.slice(0, 4).map((issue) => `${issue.path.join(".") || "request"}: ${issue.message}`).join("; ")
        return { ok: false, reason: "validation_error", message: `attachment request validation failed: ${issues}`, httpStatus: 400 }
      }
      const entry = entries.get(parsed.data.handle)
      if (!entry || entry.expiresAt <= now()) {
        entries.delete(parsed.data.handle)
        return { ok: false, reason: "validation_error", message: "attachment handle is invalid or expired", httpStatus: 400 }
      }
      entry.result ??= prepareRegisteredAgentAttachments(entry.request, env, deps)
      return entry.result
    },
  }
}

async function prepareRegisteredAgentAttachments(
  request: RegisteredAgentAttachmentTurn,
  env: NodeJS.ProcessEnv,
  deps: AgentAttachmentPrepareDeps,
): Promise<AgentAttachmentPrepareResult> {
  let resolution: { matched: boolean; files?: BugAttachmentFile[] }
  try {
    resolution = await resolveRegisteredAgentAttachments(request, env, deps)
  } catch {
    resolution = { matched: false }
  }
  if (!resolution.matched) {
    return {
      ok: false,
      reason: "attachment_resolution_failed",
      message: request.mode === "assert-empty"
        ? "current-turn attachments could not be verified; do not create a requirement until the client exposes an attachment-free turn"
        : "current-turn attachments are not available from the client transcript; retry the Bug request and do not create it without the requested files",
      httpStatus: 409,
    }
  }
  const files = resolution.files ?? []
  if (request.mode === "assert-empty") {
    return files.length
      ? {
          ok: false,
          reason: "attachment_resolution_failed",
          message: "requirement.create does not support attachments; create a Bug instead or remove the current-turn files",
          httpStatus: 409,
        }
      : { ok: true, attachmentTokens: [], files: [] }
  }
  if (request.requireFiles && !files.length) {
    return {
      ok: false,
      reason: "attachment_resolution_failed",
      message: "the current Bug request requires attachments, but the client exposed no recoverable files; retry and attach the files again",
      httpStatus: 409,
    }
  }
  if (!files.length) return { ok: true, attachmentTokens: [], files: [] }

  try {
    const upload = deps.uploadAttachments ?? ((items, productionId) => uploadBugAttachments(items, productionId, env))
    const attachmentTokens = await upload(files, request.productionId)
    return {
      ok: true,
      attachmentTokens,
      files: files.map((file) => ({ fileName: file.fileName ?? file.path.split(/[\\/]/).at(-1) ?? "attachment" })),
    }
  } catch (error) {
    return {
      ok: false,
      reason: "attachment_upload_failed",
      message: `attachment upload failed: ${error instanceof Error ? error.message : String(error)}`,
      httpStatus: 502,
    }
  }
}

async function resolveRegisteredAgentAttachments(
  request: RegisteredAgentAttachmentTurn,
  env: NodeJS.ProcessEnv,
  deps: AgentAttachmentPrepareDeps,
): Promise<{ matched: boolean; files?: BugAttachmentFile[] }> {
  if (request.kind === "direct") return { matched: true, files: request.files }
  if (request.kind === "codex-transcript" && deps.resolveCodexAttachments) {
    const files = deps.resolveCodexAttachments(request)
    return files === undefined ? { matched: false } : { matched: true, files }
  }
  if (request.kind === "claude-transcript" && deps.resolveClaudeAttachments) {
    const files = deps.resolveClaudeAttachments(request)
    return files === undefined ? { matched: false } : { matched: true, files }
  }

  // The client writes its user record only after UserPromptSubmit returns. A
  // fast first tool call can race that flush, so retry only the unmatched case.
  for (const delayMs of [0, 25, 75, 150, 300]) {
    if (delayMs) await delay(delayMs)
    const result = request.kind === "codex-transcript"
      ? probeCodexTranscriptAttachments({
          transcriptPath: request.transcriptPath,
          sessionId: request.sessionId,
          turnId: request.turnId,
          prompt: request.prompt,
          cwd: request.cwd,
        })
      : probeClaudeTranscriptAttachments({
          transcriptPath: request.transcriptPath,
          sessionId: request.sessionId,
          promptId: request.promptId,
          prompt: request.prompt,
        }, env)
    if (result.matched) return { matched: true, files: result.attachments }
  }
  return { matched: false }
}

function inlineImageRegistration(
  images: readonly { mimeType: string; base64: string }[],
  directFiles: readonly BugAttachmentFile[],
  productionId: string,
  requireFiles: boolean,
  mode: "upload" | "assert-empty",
  env: NodeJS.ProcessEnv,
): RegisteredAgentAttachmentTurn | undefined {
  if (images.length + directFiles.length > 20) return undefined
  try {
    return {
      kind: "direct",
      productionId,
      requireFiles,
      mode,
      files: [...directFiles, ...materializeInlineImages(images, "kimi-attachments", env)],
    }
  } catch {
    return undefined
  }
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function isDeferredTranscriptSource(request: InjectRequest): boolean {
  const source = request.deferred_attachment_source
  return request.client === "codex" && source?.kind === "codex-transcript"
      && Boolean(request.session_id && request.turn_id)
    || request.client === "claude-code" && source?.kind === "claude-transcript"
      && Boolean(request.session_id && request.message_id)
}

function hasResolvableAttachmentSource(request: InjectRequest): boolean {
  if (request.attachments?.length) return true
  if (request.deferred_attachment_source?.kind === "inline-images"
    && request.deferred_attachment_source.images.length > 0) return true
  return isDeferredTranscriptSource(request)
}

function prune(entries: Map<string, { expiresAt: number }>, now: number): void {
  if (entries.size < MAX_HANDLES) return
  for (const [handle, entry] of entries) if (entry.expiresAt <= now) entries.delete(handle)
  while (entries.size >= MAX_HANDLES) entries.delete(entries.keys().next().value!)
}
