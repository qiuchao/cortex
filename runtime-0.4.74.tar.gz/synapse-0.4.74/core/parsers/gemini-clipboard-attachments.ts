import { lstatSync, readFileSync, realpathSync, statSync } from "node:fs"
import { homedir } from "node:os"
import { basename, dirname, isAbsolute, join, posix, resolve, win32 } from "node:path"

import type { ParsedAttachments } from "./util.ts"

const MAX_ATTACHMENTS = 20
const MAX_IMAGE_BYTES = 10 * 1024 * 1024
const CLIPBOARD_NAME = /^clipboard-\d+\.(?:png|jpg)$/i

export interface GeminiClipboardAttachmentRequest {
  prompt: string
  transcriptPath: string
  cwd: string
}

/** Recover only Gemini's own clipboard files, never arbitrary user @files. */
export function parseGeminiClipboardAttachments(
  request: GeminiClipboardAttachmentRequest,
  env: NodeJS.ProcessEnv = process.env,
): ParsedAttachments {
  const promptReferences = atFileReferences(request.prompt)
  // Gemini 0.52 serializes pasted images as @.../images/clipboard-* before
  // BeforeAgent. Other @files are prompt context, not implicit Bug uploads.
  if (!promptReferences.length) return { observation: "none" }
  const references = promptReferences.filter((reference) => CLIPBOARD_NAME.test(basename(reference)))
  if (!references.length) return { observation: "unknown" }
  try {
    const transcript = secureRealFile(request.transcriptPath)
    const chats = dirname(transcript)
    if (!samePlatformPath(chats, join(dirname(chats), "chats"))) throw new Error("invalid Gemini transcript directory")
    const projectTemp = dirname(chats)
    const geminiTemp = dirname(projectTemp)
    const expectedGeminiTemp = resolve(geminiHome(env), "tmp")
    if (!samePlatformPath(geminiTemp, expectedGeminiTemp)) throw new Error("Gemini transcript is outside its temp root")

    const marker = secureRealFile(join(projectTemp, ".project_root"))
    const recordedRoot = readFileSync(marker, "utf8").trim()
    if (!recordedRoot || !samePlatformPath(resolve(recordedRoot), resolve(request.cwd))) {
      throw new Error("Gemini project ownership does not match the hook cwd")
    }

    const imagesDir = resolve(projectTemp, "images")
    const candidates = references
      .map((reference) => isAbsolute(reference) ? resolve(reference) : resolve(request.cwd, reference))
      .filter((path) => samePlatformPath(dirname(path), imagesDir) && CLIPBOARD_NAME.test(basename(path)))
    // A normal @file, including a similarly named file elsewhere, is not a
    // Gemini clipboard attachment and must remain ordinary prompt context.
    if (!candidates.length) return { observation: "unknown" }
    if (candidates.length > MAX_ATTACHMENTS) return attachmentError("too many Gemini clipboard attachments")
    const files = candidates.map((candidate) => {
      const path = secureRealFile(candidate)
      const info = statSync(path)
      if (info.size <= 0 || info.size > MAX_IMAGE_BYTES) throw new Error("invalid or oversized Gemini clipboard image")
      const bytes = readFileSync(path)
      const mimeType = basename(path).toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg"
      if (!matchesSignature(mimeType, bytes)) throw new Error("Gemini clipboard image content does not match its extension")
      return { path, fileName: basename(path), mimeType }
    })
    return { files, observation: "present" }
  } catch {
    return attachmentError("Synapse could not safely resolve the Gemini clipboard attachment")
  }
}

function atFileReferences(prompt: string): string[] {
  const found: string[] = []
  const pattern = /@(?:"([^"\r\n]+)"|'([^'\r\n]+)'|([^\s<>"']+))/g
  for (const match of prompt.matchAll(pattern)) {
    const value = (match[1] ?? match[2] ?? match[3] ?? "").trim()
    if (!found.includes(value)) found.push(value)
  }
  return found
}

function secureRealFile(path: string): string {
  if (!path || !isAbsolute(path)) throw new Error("expected an absolute file path")
  const normalized = resolve(path)
  const info = lstatSync(normalized)
  if (!info.isFile() || info.isSymbolicLink() || !samePlatformPath(realpathSync(normalized), normalized)) {
    throw new Error("expected a real non-symbolic file")
  }
  return normalized
}

export function samePlatformPath(
  left: string,
  right: string,
  platform: NodeJS.Platform = process.platform,
): boolean {
  const pathApi = platform === "win32" ? win32 : posix
  const normalizedLeft = pathApi.normalize(left)
  const normalizedRight = pathApi.normalize(right)
  return platform === "win32"
    ? normalizedLeft.toLowerCase() === normalizedRight.toLowerCase()
    : normalizedLeft === normalizedRight
}

function geminiHome(env: NodeJS.ProcessEnv): string {
  const base = env["GEMINI_CLI_HOME"]?.trim() || env["HOME"]?.trim() || homedir()
  return join(base, ".gemini")
}

function matchesSignature(mimeType: "image/png" | "image/jpeg", bytes: Buffer): boolean {
  return mimeType === "image/png"
    ? bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
    : bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
}

function attachmentError(error: string): ParsedAttachments {
  return { observation: "present", error }
}
