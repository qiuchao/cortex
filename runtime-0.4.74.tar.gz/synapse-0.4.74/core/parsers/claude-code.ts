/**
 * core/parsers/claude-code.ts —— 运行时侧解析 Claude Code 的 hook 原始 stdin。
 *
 * 薄壳(shims/claude-code/*)只把 CC hook 的原始 stdin 原样 POST 过来 + 标 client header;
 * **所有解析在运行时这里做**(方案 A:薄壳零业务逻辑)。这样加客户端只需加一个 parser,
 * runtime/core 其余零改动(Phase 3 fan-out 的零 diff 承诺)。
 *
 * CC hook 载荷(官方格式):
 *   UserPromptSubmit → { session_id, cwd, hook_event_name:"UserPromptSubmit", prompt, ... }
 *   Stop / SessionEnd → { session_id, cwd, hook_event_name, ... }
 *
 * 解析容错:字段缺失/类型不对 → 给安全缺省(空串),绝不 throw(解析失败不该炸 inject)。
 */
import type { InjectRequest, ReportRequest } from "../../transport/contract.ts"
import { str, asObject, parseAttachments, stableTurnAnchor, supportRails, transcriptTail } from "./util.ts"

/** 把 CC 原始 hook JSON 解析为规范 InjectRequest。 */
export function parseInject(raw: unknown): InjectRequest {
  const o = asObject(raw)
  const parsedAttachments = parseAttachments(o)
  const user_input = str(o, "prompt")
  const session_id = str(o, "session_id")
  const message_id = str(o, "prompt_id", "message_id", "request_id", "hook_request_id", "id") || undefined
  const conversation_id = str(o, "conversation_id", "conversationId") || undefined
  const turn_id = stableTurnAnchor(
    o,
    { client: "claude-code", sessionId: session_id, messageId: message_id, conversationId: conversation_id, currentText: user_input },
    "turn_id", "prompt_id", "message_id", "request_id", "hook_request_id", "id",
  )
  const transcriptPath = str(o, "transcript_path")
  return {
    client: "claude-code",
    event: str(o, "hook_event_name") || "UserPromptSubmit",
    project: str(o, "cwd") || undefined,
    cwd: str(o, "cwd") || undefined,
    user_input,
    session_id,
    turn_id,
    message_id,
    conversation_id,
    attachments: parsedAttachments.files,
    attachment_observation: parsedAttachments.observation,
    attachment_error: parsedAttachments.error,
    deferred_attachment_source: !parsedAttachments.files?.length && transcriptPath && str(o, "prompt_id")
      ? { kind: "claude-transcript", transcriptPath }
      : undefined,
    transcript_tail: transcriptTail(o),
    support_rails: supportRails(o),
  }
}

/** 把 CC 原始 hook JSON 解析为规范 ReportRequest。 */
export function parseReport(raw: unknown): ReportRequest {
  const o = asObject(raw)
  const event = str(o, "hook_event_name") || "Stop"
  return {
    client: "claude-code",
    event,
    session_id: str(o, "session_id"),
    // CC 没有专门的 turn_id;若载荷带则用,否则留空 —— 回合级幂等仅在有 turn_id 时生效
    // (CC 的 Stop 每回合触发一次,通常无需去重;Codex 才是多次触发需 turn_id 的场景)。
    turn_id: str(o, "turn_id") || undefined,
    project: str(o, "cwd") || undefined,
    cwd: str(o, "cwd") || undefined,
  }
}
