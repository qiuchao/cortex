/**
 * core/handlers/verify-done.ts —— report 的确定性 handler(同步、在 report ACK 上)。
 *
 * 方案 R3:三 handler 里唯一**同步**的一个。done=产出物存在性,确定性,fail-closed。
 * 薄封装 core/done-contract.ts,便于 report.ts 统一调度 + 单测隔离。
 */
import { verifyDone, type VerifyDoneResult } from "../done-contract.ts"

export interface VerifyDoneInput {
  /** 任务下发的 done 契约(缺失/非法 → fail-closed) */
  done_contract?: unknown
  cwd: string
}

export function handleVerifyDone(input: VerifyDoneInput): VerifyDoneResult {
  return verifyDone(input.done_contract, input.cwd)
}
