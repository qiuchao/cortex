/** Private, process-owned stdio worker. No shared endpoint and no cached ACL decisions. */
import { readFileSync } from "node:fs"
import { execFileSync, spawn } from "node:child_process"
import { fileURLToPath } from "node:url"
import { basename, dirname, resolve } from "node:path"

// The same installed system executable as the narrow Windows shell allowlist.
const powershell = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
const script = fileURLToPath(new URL("./iteration-result-windows-helper.ps1", import.meta.url))
const native = fileURLToPath(new URL("./iteration-result-windows-native.cs", import.meta.url))
const validId = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/
const helper = readFileSync(script, "utf8").split("\n").slice(1).join("\n")
function args(root: string, once = "", id = ""): string[] {
  if (process.platform !== "win32" || basename(root) !== "iteration-delivery") throw new Error("invalid Windows iteration root")
  // This is an installed, package-owned resource. Never derive a source path
  // from the caller-controlled spool root before native reparse/ACL checks.
  const prefix = `$NativeSource=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${Buffer.from(native).toString("base64")}'));$RootBase64='${Buffer.from(resolve(root)).toString("base64")}';$Once='${once}';$Id='${id}';`
  return ["-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(prefix + helper, "utf16le").toString("base64")]
}
export function initializeWindowsIterationDirectory(root: string): void {
  execFileSync(powershell, args(root, "init"), { timeout: 10000, stdio: "ignore", windowsHide: true })
}
export function assertWindowsIterationPath(path: string, directory: boolean): void {
  const match = directory ? undefined : /^response-([a-f0-9-]{36})\.json$/.exec(basename(path))
  if (!directory && !match) throw new Error("invalid Windows iteration file")
  execFileSync(powershell, args(directory ? path : dirname(path), "check", match?.[1] ?? ""), { timeout: 10000, stdio: "ignore", windowsHide: true })
}
export function createWindowsIterationFiles(root: string) {
  const child = spawn(powershell, args(root), { stdio: ["pipe", "pipe", "pipe"], windowsHide: true })
  let failed = false, closing = false, sequence = 0, queued = 0, buffer = "", queue: Promise<unknown> = Promise.resolve()
  let pending: { seq?: number; id?: string; op?: string; resolve: (value: string | null) => void; reject: (error: Error) => void; timer: ReturnType<typeof setTimeout> } | undefined
  function fail() {
    if (failed) return
    failed = true
    const item = pending; pending = undefined
    if (item) { clearTimeout(item.timer); item.reject(new Error("private iteration helper unavailable")) }
    child.stdin.destroy(); child.kill()
  }
  function expect(seq?: number, id?: string, op?: string) {
    return new Promise<string | null>((resolve, reject) => {
      if (failed || closing || pending) { reject(new Error("private iteration helper unavailable")); return }
      pending = { seq, id, op, resolve, reject, timer: setTimeout(fail, seq === undefined ? 10000 : 3000) }
    })
  }
  const ready = expect()
  // Mark rejection handled immediately, while callers may still be doing other work.
  void ready.catch(() => undefined)
  child.stdout.setEncoding("utf8")
  child.stdout.on("data", (part: string) => {
    buffer += part
    if (Buffer.byteLength(buffer) > 32768) { fail(); return }
    let end: number
    while ((end = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, end).trim(); buffer = buffer.slice(end + 1)
      const item = pending
      if (!item) { fail(); return }
      try {
        const value = JSON.parse(line)
        const keys = Object.keys(value).sort().join(",")
        if (item.op === "read" && keys === "id,pending,seq" && value.pending === true && value.seq === item.seq && value.id === item.id) {
          pending = undefined; clearTimeout(item.timer); item.resolve(null); continue
        }
        if (item.seq === undefined ? keys !== "ready" || value.ready !== true
          : keys !== "data,id,ok,seq" || value.seq !== item.seq || value.id !== item.id || value.ok !== true || typeof value.data !== "string" || value.data.length > 22000) { fail(); return }
        pending = undefined; clearTimeout(item.timer); item.resolve(value.data ?? "")
      } catch { fail(); return }
    }
  })
  child.stderr.on("data", fail)
  child.on("error", fail)
  child.stdin.on("error", fail)
  // close also fires when spawn fails before an OS process exists; exit does not.
  const exited = new Promise<void>(resolve => child.once("close", () => { if (!closing || pending) fail(); resolve() }))
  function request(op: "prepare" | "commit" | "abort" | "read" | "remove", id: string, data?: string, deadline?: number) {
    if (!validId.test(id)) return Promise.reject(new Error("invalid private iteration id"))
    if (++queued > 64) { queued--; fail(); return Promise.reject(new Error("private iteration helper capacity exceeded")) }
    const result = queue.then(async () => {
      await ready
      if (failed || closing) throw new Error("private iteration helper unavailable")
      const seq = ++sequence, message = JSON.stringify({ op, id, seq, ...(data === undefined ? {} : { data, deadline }) })
      if (Buffer.byteLength(message) > 32768) { fail(); throw new Error("private iteration message too large") }
      const reply = expect(seq, id, op)
      child.stdin.write(message + "\n")
      return reply
    })
    queue = result.finally(() => { queued-- }).catch(() => undefined)
    return result
  }
  return {
    ready,
    prepare: (id: string) => request("prepare", id),
    commit: (id: string, text: string, deadline: number) => request("commit", id, Buffer.from(text).toString("base64"), deadline),
    remove: (id: string) => request("remove", id),
    abort: (id: string) => request("abort", id),
    async read(id: string) {
      const value = await request("read", id)
      return value === null ? undefined : Buffer.from(value, "base64").toString("utf8")
    },
    async stop() {
      if (closing) { await exited; return }
      closing = true
      if (pending) fail()
      child.stdin.end()
      const timer = setTimeout(() => child.kill(), 1000)
      try { await exited } finally { clearTimeout(timer) }
    },
  }
}
export type WindowsIterationFiles = ReturnType<typeof createWindowsIterationFiles>
