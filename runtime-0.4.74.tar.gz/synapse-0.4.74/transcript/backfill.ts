/**
 * transcript/backfill.ts —— 历史回填安全闸(方案 pre-mortem E / spec §118)。
 *
 * 全量原始对话上传**不可逆**。bulk backfill 必须:
 *   - 显式 ack: transcript.backfill.confirmed(默认 false → 拒绝);
 *   - dry-run: 先打印 count + paths + user_id,让人核对;
 *   - 路径白名单;
 *   - 幂等游标(复用 scanner 的 cursor,重跑不重传);
 *   - pause 开关(随时叫停)。
 *
 * 回填与稳态是**同一套读文件逻辑**(scanOnce)——回填只是"第一次 minAgeMs 放宽 + 需 ack"。
 */
import { defaultScanConfigs, scanOnce, type ClientScanConfig, type TranscriptRecord } from "./scanner.ts"
import type { CursorStore } from "./cursor.ts"

export interface BackfillPlan {
  userId: string | null
  fileCount: number
  recordCount: number
  paths: string[]
  /** 未 ack / 无 user_id / paused 等导致的拒绝原因 */
  refused?: "not_confirmed" | "no_user_id" | "paused" | "no_allowlist"
}

export interface BackfillOptions {
  cursors: CursorStore
  userId: string | null
  /** 必须显式 true,否则拒绝(默认 false) */
  confirmed?: boolean
  /** pause 开关:true → 立即停 */
  paused?: boolean
  /** 路径白名单(回填强制要求非空,防止误扫全盘) */
  allowlist?: string[]
  configs?: ClientScanConfig[]
  now?: () => number
}

/**
 * dry-run:只统计将上传什么,不产生副作用(不推进游标 —— 用只读 cursor 视图)。
 */
export function backfillDryRun(opts: BackfillOptions): BackfillPlan {
  if (!opts.userId) return { userId: null, fileCount: 0, recordCount: 0, paths: [], refused: "no_user_id" }
  if (opts.paused) return { userId: opts.userId, fileCount: 0, recordCount: 0, paths: [], refused: "paused" }
  if (!opts.allowlist || opts.allowlist.length === 0) {
    return { userId: opts.userId, fileCount: 0, recordCount: 0, paths: [], refused: "no_allowlist" }
  }

  // 用一份**只读快照 cursor**跑扫描,避免 dry-run 推进真实游标
  const snapshot = snapshotCursor(opts.cursors)
  const res = scanOnce({
    configs: opts.configs ?? defaultScanConfigs(),
    cursors: snapshot,
    userId: opts.userId,
    minAgeMs: 0, // 回填:历史文件都算(不设 age gate)
    allowlist: opts.allowlist,
    now: opts.now,
  })
  const paths = res.records.map((r) => `${r.client}:${r.session_id}`)
  return {
    userId: opts.userId,
    fileCount: res.records.length,
    recordCount: res.records.reduce((n, r) => n + r.messages.length, 0),
    paths,
  }
}

/**
 * 真正执行回填:需 confirmed。返回记录 + 推进真实游标(幂等,重跑零新增)。
 * **不做网络上传** —— 交给 upload.ts;这里只产出 + 推进游标(可测)。
 */
export function backfillRun(opts: BackfillOptions): { plan: BackfillPlan; records: TranscriptRecord[] } {
  if (!opts.confirmed) {
    return {
      plan: { userId: opts.userId, fileCount: 0, recordCount: 0, paths: [], refused: "not_confirmed" },
      records: [],
    }
  }
  if (!opts.userId) {
    return { plan: { userId: null, fileCount: 0, recordCount: 0, paths: [], refused: "no_user_id" }, records: [] }
  }
  if (opts.paused) {
    return { plan: { userId: opts.userId, fileCount: 0, recordCount: 0, paths: [], refused: "paused" }, records: [] }
  }
  if (!opts.allowlist || opts.allowlist.length === 0) {
    return { plan: { userId: opts.userId, fileCount: 0, recordCount: 0, paths: [], refused: "no_allowlist" }, records: [] }
  }

  const res = scanOnce({
    configs: opts.configs ?? defaultScanConfigs(),
    cursors: opts.cursors, // 真实游标 → 推进(幂等)
    userId: opts.userId,
    minAgeMs: 0,
    allowlist: opts.allowlist,
    now: opts.now,
  })
  opts.cursors.save()
  return {
    plan: {
      userId: opts.userId,
      fileCount: res.records.length,
      recordCount: res.records.reduce((n, r) => n + r.messages.length, 0),
      paths: res.records.map((r) => `${r.client}:${r.session_id}`),
    },
    records: res.records,
  }
}

/** 只读游标快照:读透传真实值,写只落在内存副本(dry-run 不污染真实游标)。 */
function snapshotCursor(real: CursorStore): CursorStore {
  const overlay = { ...real.all() }
  return {
    get: (p) => overlay[p],
    set: (p, c) => {
      overlay[p] = c
    },
    all: () => ({ ...overlay }),
    save: () => {
      /* no-op:dry-run 不持久化 */
    },
  }
}
