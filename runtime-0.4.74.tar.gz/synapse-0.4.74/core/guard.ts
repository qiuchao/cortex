/**
 * core/guard.ts —— PreToolUse 硬护栏入口(行为流)。
 *
 * 方案 §3 Phase 4 / spec §80-82:客户端在执行工具(bash git 命令)前调 guard,
 * 运行时用 PolicyLoader 判定 → deny + 提示改道 / allow。各一级客户端通过原生
 * PreToolUse/BeforeTool/tool.execute.before 接入同一判定入口。
 *
 * 护栏 fail-closed:判定过程本身出错时,对**明确的 git 写操作**倾向拒绝(宁误拦不放过);
 * 但为避免误伤,这里只在 pack 明确 deny 时拒,pack 放行/降级时 allow。
 */
import { PolicyLoader } from "../policy/loader.ts"
import type { PolicyContext } from "./../policy/pack.ts"

/**
 * Git 硬护栏临时开关。当前默认暂停；保留全部 hook、policy pack 与规则实现。
 * 后续恢复时为 daemon 设置 SYNAPSE_GIT_GUARD_ENABLED=true 并重启即可。
 */
export function isGitGuardEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return env["SYNAPSE_GIT_GUARD_ENABLED"]?.trim().toLowerCase() === "true"
}

/** 各客户端 PreToolUse 载荷里 bash 命令的字段各不同,这里做通用兜底提取。 */
export function extractCommand(raw: unknown): string {
  if (!raw || typeof raw !== "object") return ""
  const o = raw as Record<string, unknown>
  // CC: tool_input.command;通用兜底:command / input.command / tool_input.command。
  // 命令可能是 string 或 argv 数组(数组形态若返回 "" 会静默绕过护栏 → join 归一,安全评审 M2)。
  const coerce = (v: unknown): string => {
    if (typeof v === "string") return v
    if (Array.isArray(v)) return v.filter((x) => typeof x === "string").join(" ")
    return ""
  }
  const direct = coerce(o["command"])
  if (direct) return direct
  const ti = o["tool_input"]
  if (ti && typeof ti === "object") {
    const c = coerce((ti as Record<string, unknown>)["command"])
    if (c) return c
  }
  const inp = o["input"]
  if (inp && typeof inp === "object") {
    const c = coerce((inp as Record<string, unknown>)["command"])
    if (c) return c
  }
  return ""
}

/** 哪些客户端支持工具执行前硬护栏。OpenCode 1.17.11+ 通过 tool.execute.before 接入。 */
export function hardGuardCapable(client: string): boolean {
  return client === "claude-code" || client === "codex" || client === "gemini-cli"
    || client === "opencode" || client === "kimi-code"
}

export interface GuardResult {
  /** true=放行,false=拒绝(阻止工具执行) */
  allow: boolean
  /** 拒绝时给模型的改道提示 */
  reason?: string
  enforcement?: "enforced" | "degraded" | "unavailable"
}

export interface GuardDeps {
  loader?: PolicyLoader
  /** 测试/嵌入调用可显式覆盖；daemon 默认读取 SYNAPSE_GIT_GUARD_ENABLED。 */
  enabled?: boolean
}

export async function handleGuard(
  input: { client: string; command: string; cwd?: string },
  deps: GuardDeps = {},
): Promise<GuardResult> {
  if (!(deps.enabled ?? isGitGuardEnabled())) {
    return {
      allow: true,
      enforcement: "unavailable",
      reason: "Synapse Git guard is temporarily paused by runtime configuration.",
    }
  }

  const loader = deps.loader ?? new PolicyLoader()
  const ctx: PolicyContext = {
    client: input.client,
    hardGuardCapable: hardGuardCapable(input.client),
    cwd: input.cwd,
  }
  const r = await loader.validate(
    { kind: "git.command", command: input.command, cwd: input.cwd },
    ctx,
  )
  return { allow: r.ok, reason: r.reason, enforcement: r.enforcement }
}
