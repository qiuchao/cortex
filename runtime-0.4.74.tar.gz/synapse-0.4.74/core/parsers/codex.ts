/**
 * core/parsers/codex.ts —— 运行时侧解析 Codex 的 hook 原始 stdin。
 *
 * Codex hook 载荷(输入与 CC 近似;输出使用 Codex 0.144.x raw-text context 通道):
 *   inject ← UserPromptSubmit  { session_id, cwd, prompt, ... }
 *   report ← Stop(无专用 SessionEnd,可能多次触发 → 运行时按 turn_id 幂等)
 *
 * 差异仅字段名兜底;所有业务逻辑在运行时,与 CC 共享同一 inject/report 路径。
 */
import type { InjectRequest, ReportRequest } from "../../transport/contract.ts"
import { str, asObject, parseAttachments, stableTurnAnchor, supportRails, transcriptTail } from "./util.ts"

export function parseInject(raw: unknown): InjectRequest {
  const o = asObject(raw)
  const user_input = str(o, "prompt") || str(o, "input") || str(o, "message")
  const session_id = str(o, "session_id")
  const message_id = str(o, "message_id", "request_id", "id") || undefined
  const conversation_id = str(o, "conversation_id", "conversationId") || undefined
  const turn_id = stableTurnAnchor(
    o,
    { client: "codex", sessionId: session_id, messageId: message_id, conversationId: conversation_id, currentText: user_input },
    "turn_id", "message_id", "request_id", "id",
  )
  const parsedAttachments = parseAttachments(o)
  const directAttachments = parsedAttachments.files
  const transcriptPath = str(o, "transcript_path")
  return {
    client: "codex",
    event: str(o, "hook_event_name") || "UserPromptSubmit",
    project: str(o, "cwd") || undefined,
    cwd: str(o, "cwd") || undefined,
    // Codex 载荷里用户输入可能叫 prompt / input / message,逐个兜底
    user_input,
    session_id,
    turn_id,
    message_id,
    conversation_id,
    attachments: directAttachments,
    attachment_observation: parsedAttachments.observation,
    attachment_error: parsedAttachments.error,
    deferred_attachment_source: !directAttachments?.length && transcriptPath
      ? { kind: "codex-transcript", transcriptPath }
      : undefined,
    transcript_tail: transcriptTail(o),
    support_rails: supportRails(o),
  }
}

export function parseReport(raw: unknown): ReportRequest {
  const o = asObject(raw)
  return {
    client: "codex",
    event: str(o, "hook_event_name") || "Stop",
    session_id: str(o, "session_id"),
    // Codex Stop 多次触发 → turn_id 幂等键(有则用,无则运行时按 session+event 兜底)
    turn_id: str(o, "turn_id") || str(o, "id") || undefined,
    project: str(o, "cwd") || undefined,
    cwd: str(o, "cwd") || undefined,
  }
}
