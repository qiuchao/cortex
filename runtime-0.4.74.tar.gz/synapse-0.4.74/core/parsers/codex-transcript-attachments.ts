import { basename, isAbsolute, resolve } from "node:path"

import type { InjectAttachment } from "../../transport/contract.ts"
import { asObject, str } from "./util.ts"
import { readJsonlPrefix, scanJsonlTail } from "./transcript-jsonl.ts"

const PREFIX_BYTES = 256 * 1024
const TAIL_BYTES = 8 * 1024 * 1024
const MAX_ATTACHMENTS = 20

export interface CodexTranscriptAttachmentRequest {
  transcriptPath: string
  sessionId: string
  turnId: string
  prompt?: string
  cwd?: string
}

export interface CodexTranscriptAttachmentProbe {
  matched: boolean
  attachments?: InjectAttachment[]
}

/**
 * Codex UserPromptSubmit does not expose local images directly. Its official
 * hook contract does expose transcript_path, session_id, and turn_id, so this
 * adapter recovers only the images belonging to that exact prompt and turn.
 * The JSONL shape is deliberately isolated here because Codex documents it as
 * an unstable convenience format. At UserPromptSubmit time Codex 0.147 writes
 * task_started/turn_context first but appends the user record only after the
 * hook returns, so an unmatched probe must remain fail-closed rather than wait
 * on a record whose persistence is blocked by this hook.
 */
export function codexTranscriptAttachments(request: CodexTranscriptAttachmentRequest): InjectAttachment[] | undefined {
  return probeCodexTranscriptAttachments(request).attachments
}

/** Distinguish a verified attachment-free turn from an unreadable transcript. */
export function probeCodexTranscriptAttachments(request: CodexTranscriptAttachmentRequest): CodexTranscriptAttachmentProbe {
  if (!request.transcriptPath || !request.sessionId || !request.turnId) return { matched: false }
  const prefix = readJsonlPrefix(request.transcriptPath, PREFIX_BYTES)
  if (!prefix || !transcriptOwnsSession(prefix, request.sessionId)) return { matched: false }
  return scanJsonlTail(request.transcriptPath, { initialBytes: TAIL_BYTES, maxBytes: TAIL_BYTES }, (records) => (
    currentTurnImages(records, request)
  )) ?? { matched: false }
}

function transcriptOwnsSession(records: Record<string, unknown>[], sessionId: string): boolean {
  return records.some((record) => {
    if (str(record, "type") !== "session_meta") return false
    const payload = asObject(record["payload"])
    return str(payload, "session_id", "id") === sessionId
  })
}

function currentTurnImages(
  records: Record<string, unknown>[],
  request: CodexTranscriptAttachmentRequest,
): { matched: boolean; attachments?: InjectAttachment[] } {
  let inCurrentTurn = false
  let matchingImages: string[] | undefined
  let matched = false

  for (const record of records) {
    const recordType = str(record, "type")
    const payload = asObject(record["payload"])
    if (recordType === "response_item") {
      const metadata = asObject(payload["internal_chat_message_metadata_passthrough"])
      if (str(payload, "type") !== "message" || str(payload, "role") !== "user" || str(metadata, "turn_id") !== request.turnId) continue
      const content = payload["content"]
      if (!Array.isArray(content)) continue
      const texts = content.flatMap((item) => {
        const entry = asObject(item)
        return str(entry, "type") === "input_text" ? [str(entry, "text")] : []
      })
      if (request.prompt && !texts.includes(request.prompt)) continue
      matched = true
      matchingImages = imagePathsFromCodexContent(content)
      continue
    }
    if (recordType !== "event_msg") continue
    const payloadType = str(payload, "type")
    if (payloadType === "task_started") {
      inCurrentTurn = str(payload, "turn_id") === request.turnId
      continue
    }
    if (!inCurrentTurn || payloadType !== "user_message" || (request.prompt && str(payload, "message") !== request.prompt)) continue
    matched = true
    const images = payload["local_images"]
    if (Array.isArray(images)) matchingImages = images.filter((item): item is string => typeof item === "string" && Boolean(item.trim()))
  }

  if (!matchingImages?.length) return { matched }
  const unique = [...new Set(matchingImages.map((path) => path.trim()))].slice(0, MAX_ATTACHMENTS)
  return {
    matched: true,
    attachments: unique.map((path) => {
      const absolutePath = !isAbsolute(path) && request.cwd ? resolve(request.cwd, path) : path
      return { path: absolutePath, fileName: basename(absolutePath) }
    }),
  }
}

function imagePathsFromCodexContent(content: unknown[]): string[] {
  const paths: string[] = []
  const imageTag = /^\s*<image\b[^>]*\bpath=(?:"([^"]+)"|'([^']+)')[^>]*>\s*$/
  for (let index = 0; index + 2 < content.length; index += 1) {
    const opening = asObject(content[index])
    const image = asObject(content[index + 1])
    const closing = asObject(content[index + 2])
    if (str(opening, "type") !== "input_text" || str(image, "type") !== "input_image" || str(closing, "type") !== "input_text") continue
    if (!/^\s*<\/image>\s*$/.test(str(closing, "text"))) continue
    const match = str(opening, "text").match(imageTag)
    const path = match?.[1] ?? match?.[2]
    if (path?.trim()) paths.push(path.trim())
  }
  return paths
}
