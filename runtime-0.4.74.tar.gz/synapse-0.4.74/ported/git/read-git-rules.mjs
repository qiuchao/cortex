#!/usr/bin/env node
/**
 * scripts/read-git-rules.mjs — 安全读取 .synapse/git-rules.json 的辅助脚本
 *
 * 通过 process.argv 接收参数，避免在 shell 命令行内嵌 `node -e "..."`
 * 时单引号/双引号边界转义地狱（尤其 Windows / 特殊路径）。
 *
 * 用法：
 *   node scripts/read-git-rules.mjs <rules-file> <field>
 *
 *   <rules-file>  .synapse/git-rules.json 的路径（通过命令行参数传入，非内嵌字符串）
 *   <field>       要读取的字段：
 *                   lfsThreshold        → 输出正整数（默认 10）
 *                   sensitivePatterns   → 每行输出一个字符串 pattern
 *                   sensitiveFilePatterns → 每行输出一个文件名 pattern（层 A，ADR: gateway-two-layer-sensitive-detection）
 *                   all                 → 输出完整 JSON 对象（解析失败输出 '{}')
 *
 * fail-safe 语义（ADR: gateway-sensitive-pattern-allowlist）：
 *   - 文件不存在         → 返回默认值，静默跳过（正常情况，非错误）
 *   - 文件存在+解析失败  → 抛出 Error，由调用方决定 warn 留痕策略
 *                          （gateway::collectFrom() 的 catch 会调用 warnStderr）
 *   - 字段不存在         → 返回对应类型的默认值（string[]→[]，number→默认）
 *
 * 原 "任何读取/解析失败一律降级输出默认值" 的注释仅适用于「文件不存在」的分支；
 * 「文件存在但内容损坏」属错误，需留痕，由此改为抛出。
 *
 * ADR: git-safety-gateway（确定性读取，不在命令行拼字符串）
 * ADR: gateway-sensitive-pattern-allowlist（fail-safe 留痕语义）
 */

import { readFileSync, existsSync } from "node:fs"
import { fileURLToPath } from "node:url"
import { realpathSync } from "node:fs"

/**
 * 读取并解析 rules 文件。
 *   - 文件不存在 → 返回 null（静默，正常情况）
 *   - 文件存在 + 读取/解析失败 → 抛出 Error（由调用方留痕处理）
 *   - 成功 → 返回解析后的对象；格式非对象 → 抛出 Error
 */
function readRules(filePath) {
  if (!filePath) return null
  if (!existsSync(filePath)) return null  // 文件不存在 → 静默跳过

  // 文件存在：读取/解析失败视为错误，抛出让调用方留痕
  let raw
  try {
    raw = readFileSync(filePath, "utf8")
  } catch (err) {
    throw new Error(`读取文件失败: ${err?.message ?? err}`)
  }
  // BOM 兼容
  if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1)

  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (err) {
    throw new Error(`JSON 解析失败: ${err?.message ?? err}`)
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("格式错误：顶层不是 JSON 对象")
  }
  return parsed
}

/**
 * 读取 rules 文件指定字段，返回与 CLI 输出语义一致的值：
 *   lfsThreshold      → number（默认 10）
 *   sensitivePatterns → string[]（默认空数组）
 *   dualSyncPatterns  → string[]（POSIX ERE 兼容，\d 已替换为 [0-9]）
 *   all（默认）        → object（文件不存在返回 {}）
 *
 * fail-safe 语义：
 *   - 文件不存在 → 返回默认值（静默，不抛出）
 *   - 文件存在 + 解析失败 → 抛出 Error（调用方决定留痕策略）
 *
 * 供 git-safety-gateway.mjs 直接 import 复用，消除子进程开销，零行为漂移。
 * @param {string} filePath rules 文件路径
 * @param {string} field 字段名
 */
export function readRulesField(filePath, field = "all") {
  // readRules: 不存在→null（静默），存在+损坏→抛出 Error（由调用方 warnStderr）
  const rules = readRules(filePath)
  switch (field) {
    case "lfsThreshold": {
      const n = rules ? Number(rules.lfsThresholdMB) : NaN
      return Number.isFinite(n) && n > 0 ? Math.floor(n) : 10
    }
    case "sensitivePatterns": {
      if (rules && Array.isArray(rules.sensitivePatterns)) {
        return rules.sensitivePatterns.filter(
          (p) => typeof p === "string" && p
        )
      }
      return []
    }
    case "sensitivePatternIgnores": {
      // ADR: gateway-sensitive-pattern-allowlist
      // ⚠️ 不做 dualSyncPatterns 那样的 \d→[0-9] 转换：
      //    ignores 与 builtin 源字符串字面比对，转换会导致永远匹配不上。
      if (rules && Array.isArray(rules.sensitivePatternIgnores)) {
        return rules.sensitivePatternIgnores.filter(
          (p) => typeof p === "string" && p
        )
      }
      return []
    }
    case "sensitiveFilePatterns": {
      // ADR: gateway-two-layer-sensitive-detection
      // ⚠️ 不做 \d→[0-9] 转换：文件名层正则按 JS RegExp 语义，字面 builtin 比对无需转换。
      if (rules && Array.isArray(rules.sensitiveFilePatterns)) {
        return rules.sensitiveFilePatterns.filter(
          (p) => typeof p === "string" && p
        )
      }
      return []
    }
    case "dualSyncPatterns": {
      const patterns =
        rules && Array.isArray(rules.dualSyncPatterns)
          ? rules.dualSyncPatterns
          : ["^branch/release\\d+(/|$)"]
      // 将 \d 替换为 [0-9]，确保与 shell grep -E (POSIX ERE) 兼容
      return patterns.map((p) => p.replace(/\\d/g, "[0-9]"))
    }
    case "all":
    default:
      return rules ?? {}
  }
}

// ─── CLI 入口判定（被 import 时不执行）──────────────────────────────────────
const isMain = (() => {
  try {
    return (
      process.argv[1] &&
      fileURLToPath(import.meta.url) === realpathSync(process.argv[1])
    )
  } catch {
    return fileURLToPath(import.meta.url) === process.argv[1]
  }
})()

if (isMain) {
  const rulesFile = process.argv[2]
  const field = process.argv[3] ?? "all"

  let value
  try {
    value = readRulesField(rulesFile, field)
  } catch (err) {
    // 文件存在但损坏：warn 到 stderr，输出对应字段默认值，非 0 退出
    process.stderr.write(
      `[synapse] WARNING: 读取 git-rules.json 失败（${field}）: ${err?.message ?? err}\n`
    )
    switch (field) {
      case "lfsThreshold":
        process.stdout.write("10")
        break
      case "sensitivePatterns":
      case "sensitivePatternIgnores":
      case "sensitiveFilePatterns":
      case "dualSyncPatterns":
        // 空输出（无 pattern）
        break
      case "all":
      default:
        process.stdout.write("{}")
        break
    }
    process.exit(1)
  }

  switch (field) {
    case "lfsThreshold": {
      process.stdout.write(String(value))
      break
    }
    case "sensitivePatterns": {
      for (const p of value) process.stdout.write(p + "\n")
      break
    }
    case "sensitivePatternIgnores": {
      for (const p of value) process.stdout.write(p + "\n")
      break
    }
    case "sensitiveFilePatterns": {
      for (const p of value) process.stdout.write(p + "\n")
      break
    }
    case "dualSyncPatterns": {
      process.stdout.write(value.join("\n"))
      break
    }
    case "all":
    default: {
      process.stdout.write(
        value && Object.keys(value).length ? JSON.stringify(value) : "{}"
      )
      break
    }
  }
}
