/**
 * runtime/doctor.ts —— `synapse doctor`:一屏诊断(方案 §3 Phase 6 / spec 可观测)。
 *
 * 报告:运行时存活 / socket / 鉴权模式 / brain 可达 / per-client 能力
 *      / 语料游标 / user_id 解析 / shim 安装状态。只读,不改状态。
 */
import { existsSync } from "node:fs"
import { execFile } from "node:child_process"
import { request, type RequestOptions } from "node:http"
import { isRunning, readPid, readDiscovery } from "./lifecycle.ts"
import { socketPath, shouldUseLoopbackTcp } from "../transport/discovery.ts"
import { resolveUserId } from "../core/user-id.ts"
import { GATEWAY_PATH } from "../policy/packs/git/index.ts"
import { isShimInstalled, isGuardWired, getHookStateStatus } from "../core/shim-installer.ts"
import { getBrainConfig } from "../transport/brain-config.ts"
import { readMachineId, tokenPresent } from "../core/token-store.ts"
import type { ClientId } from "../core/shim-installer.ts"
import { readToken as readLoopbackToken } from "../transport/auth.ts"
import { KnowledgeCapabilityCatalogSchema, TaskCapabilityCatalogueSchema } from "@cerebro/wire"
import { isGitGuardEnabled } from "../core/guard.ts"
import { resolveAgentLauncherSpec } from "./agent-capability-broker.ts"
import { resolveRepoContext } from "../transport/brain-contract-align.ts"

export interface DoctorReport {
  runtime: {
    running: boolean
    pid: number | null
    socket: string
    socketExists: boolean
    authMode: "unix-socket" | "named-pipe" | "loopback-tcp"
    startedAt: string | null
    /**
     * 数据通路真的可达(走薄壳同款传输探 /health)。
     * - undefined:未探活(同步 buildDoctorReport,向后兼容)。
     * - true/false:探活结果。**这是去「假绿」的关键**——hook 写进配置(shimInstalled)
     *   不代表通路可达(Windows named-pipe↔unix-socket 缺口就是配置全绿但通路全断)。
     */
    pathReachable?: boolean
  }
  identity: {
    userIdResolved: boolean
    /** 不回显 user_id 明文(可能含身份);只报是否解析到 */
  }
  git: {
    gatewayPresent: boolean
    gatewayPath: string
    guardEnabled: boolean
  }
  clients: Array<{ client: string; hardGuard: boolean; shimInstalled: boolean; disabledHooks?: string[]; hookStateError?: string; note?: string }>
  /** brain 连接状态(可选) */
  brain?: {
    configured: boolean
    /** token 文件存在且非空,或 env 有 CEREBRO_MACHINE_TOKEN */
    tokenPresent: boolean
    /** reachable 探活(未配置时 undefined) */
    reachable?: boolean
    /** catalogue 请求通过 machine token 鉴权；未探活或本地 IPC 失败时 undefined。 */
    authenticated?: boolean
  }
  capabilityContract?: {
    compatible: boolean
    protocolVersion?: string
    message?: string
  }
  agentExecutor?: {
    reachable: boolean
    operational: boolean
    message?: string
  }
  agentLauncher?: {
    reachable: boolean
    operational: boolean
    message?: string
  }
  sedimentation?: {
    reportReceived: number
    turnResolved: number
    turnMissing: number
    saved: number
    rejected: number
    duplicate: number
    failed: number
  }
}

// antigravity 暂缓接入(当前无成员使用),不在支持矩阵内;Cursor 同样 deferred。
const TIER1 = ["claude-code", "codex", "gemini-cli", "opencode", "kimi-code"] as const

function authModeFor(env: NodeJS.ProcessEnv): "unix-socket" | "named-pipe" | "loopback-tcp" {
  if (shouldUseLoopbackTcp(env)) return "loopback-tcp"
  return process.platform === "win32" ? "named-pipe" : "unix-socket"
}

/**
 * 同步诊断(不探活,pathReachable=undefined)。向后兼容。
 * ⚠️ hardGuard 在同步版仅反映「client 能力 + shim 已装配置」,**不代表通路可达**;
 *    去假绿请用 buildDoctorReportWithProbe()(CLI 默认已切到它)。
 */
export function buildDoctorReport(env: NodeJS.ProcessEnv = process.env): DoctorReport {
  const disc = readDiscovery(env)
  const sock = socketPath(env)
  const brainCfg = getBrainConfig(env)
  const runtimeRunning = isRunning(env)
  // 运行中的 daemon 以其启动时写入的发现态为准；旧版发现文件没有该字段时，
  // 按旧版始终启用处理。daemon 未运行时才展示当前 shell 将用于下次启动的配置。
  const gitGuardEnabled = runtimeRunning
    ? (disc?.git_guard_enabled ?? true)
    : isGitGuardEnabled(env)

  return {
    runtime: {
      running: runtimeRunning,
      pid: readPid(env),
      socket: sock,
      socketExists: process.platform === "win32" ? true : existsSync(sock),
      authMode: authModeFor(env),
      startedAt: disc?.started_at ?? null,
      pathReachable: undefined,
    },
    identity: {
      userIdResolved: resolveUserId({ env }) !== null,
    },
    git: {
      gatewayPresent: existsSync(GATEWAY_PATH),
      gatewayPath: GATEWAY_PATH,
      guardEnabled: gitGuardEnabled,
    },
    clients: TIER1.map((c) => ({
      client: c,
      ...getHookStateStatus(c),
      // 同步版:未探活 → hardGuard 只看「guard 真接线」(去假绿:配置引用 guard 薄壳 + 文件存在);
      // pathReachable 未知,通路可达性由探活版再叠加(见 buildDoctorReportWithProbe)。
      hardGuard: gitGuardEnabled && safeIsGuardWired(c as ClientId),
      shimInstalled: safeIsShimInstalled(c as ClientId),
      note:
        !gitGuardEnabled
          ? "Git 护栏已暂时停用，当前不可用；设置 SYNAPSE_GIT_GUARD_ENABLED=true 并重启 Synapse 可恢复"
          : undefined,
    })),
    brain: {
      configured: brainCfg !== null,
      tokenPresent: tokenPresent({ env }),
      reachable: undefined,
    },
  }
}

/**
 * 带真实通路探活的诊断(去「假绿」)。走薄壳同款传输对 daemon /health 发一次真实请求:
 *   - loopback-tcp:GET http://127.0.0.1:<port>/health(/health 不需 token 即可探活)。
 *   - unix-socket:node:http 连 socket GET /health。
 * 探不通 → runtime.pathReachable=false,且 **hardGuard 一律置 false**(不再假绿)。
 *
 * 这是 Windows 缺口的核心修复:配置全绿但 named-pipe↔unix-socket 对不上时,探活会失败,
 * doctor 如实报 unavailable,而非误报 hardGuard:true。
 */
export async function buildDoctorReportWithProbe(
  env: NodeJS.ProcessEnv = process.env,
): Promise<DoctorReport> {
  const base = buildDoctorReport(env)
  const health = base.runtime.running ? await probeDaemon(env, "/health", false) : { reached: false }
  const reachable = health.reached && health.status === 200
  base.runtime.pathReachable = reachable
  const healthMetrics = asMetrics(health.body)
  if (healthMetrics) {
    base.sedimentation = {
      reportReceived: healthMetrics.report_received ?? 0,
      turnResolved: healthMetrics.turn_resolved ?? 0,
      turnMissing: healthMetrics.turn_missing ?? 0,
      saved: healthMetrics.sediment_saved ?? 0,
      rejected: healthMetrics.sediment_rejected ?? 0,
      duplicate: healthMetrics.sediment_duplicate ?? 0,
      failed: healthMetrics.sediment_failed ?? 0,
    }
  }
  // 通路不可达 → hardGuard 一律 false(去假绿);可达 → 看「guard 真接线」(不再用静态能力清单)。
  base.clients = base.clients.map((c) => ({
    ...c,
    hardGuard: base.git.guardEnabled && reachable && safeIsGuardWired(c.client as ClientId),
  }))
  const workspace = reachable
    ? await resolveRepoContext(process.cwd(), readMachineId({ env }), env)
    : null
  const agentPath = workspace?.productionId
    ? `/agent/capabilities?productionId=${encodeURIComponent(workspace.productionId)}`
    : "/agent/capabilities"
  const agentProbe = reachable ? await probeDaemon(env, agentPath, true) : { reached: false }
  base.agentExecutor = {
    reachable: agentProbe.reached,
    operational: false,
    message: agentProbe.reached ? undefined : "local agent route unreachable",
  }
  if (agentProbe.reached && agentProbe.status === 200) {
    const parsed = parseAgentCapabilityCatalogue(agentProbe.body)
    base.capabilityContract = parsed.compatible
      ? { compatible: true, protocolVersion: parsed.protocolVersion }
      : { compatible: false, message: "daemon returned an incompatible capability catalogue" }
    base.agentExecutor.operational = parsed.compatible
    base.agentExecutor.message = parsed.compatible ? undefined : base.capabilityContract.message
    if (base.brain) {
      base.brain.reachable = true
      base.brain.authenticated = true
    }
  } else if (agentProbe.reached) {
    const error = asErrorBody(agentProbe.body)
    const brainAnswered = agentProbe.status !== undefined && agentProbe.status >= 400 && agentProbe.status < 500 && error.error !== "unauthorized"
    if (base.brain) {
      base.brain.reachable = brainAnswered ? true : false
      base.brain.authenticated = error.reason === "permission_denied" ? false : undefined
    }
    base.capabilityContract = {
      compatible: false,
      message: error.message ?? `agent catalogue returned HTTP ${agentProbe.status ?? 0}`,
    }
    base.agentExecutor.message = base.capabilityContract.message
  }
  base.agentLauncher = base.agentExecutor.operational
    ? await probeAgentLauncher(env, workspace?.productionId)
    : {
        reachable: false,
        operational: false,
        message: "agent launcher was not probed because the daemon executor is unavailable",
      }
  return base
}

interface DaemonProbe {
  reached: boolean
  status?: number
  body?: unknown
}

function probeAgentLauncher(env: NodeJS.ProcessEnv, productionId?: string): Promise<NonNullable<DoctorReport["agentLauncher"]>> {
  const launcher = resolveAgentLauncherSpec()
  if (!launcher) {
    return Promise.resolve({ reachable: false, operational: false, message: "agent launcher is unavailable" })
  }
  return new Promise((resolve) => {
    execFile(
      launcher.command,
      [...launcher.args, "agent", "describe", "--json", ...(productionId ? ["--production-id", productionId] : [])],
      { env, timeout: 5_000, windowsHide: true, maxBuffer: 2 * 1024 * 1024 },
      (error, stdout, stderr) => {
        if (error) {
          let message = stderr.trim() || error.message
          try {
            const parsed = JSON.parse(stdout) as { message?: string }
            if (parsed.message) message = parsed.message
          } catch { /* 保留进程错误 */ }
          resolve({ reachable: false, operational: false, message })
          return
        }
        try {
          const parsed = parseAgentCapabilityCatalogue(JSON.parse(stdout))
          resolve(parsed.compatible
            ? { reachable: true, operational: true }
            : { reachable: true, operational: false, message: "agent launcher returned an incompatible capability catalogue" })
        } catch {
          resolve({ reachable: true, operational: false, message: "agent launcher returned invalid JSON" })
        }
      },
    )
  })
}

function parseAgentCapabilityCatalogue(value: unknown): { compatible: boolean; protocolVersion?: string } {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { compatible: false }
  const { taskCatalogue, ...knowledge } = value as Record<string, unknown>
  const parsedKnowledge = KnowledgeCapabilityCatalogSchema.safeParse(knowledge)
  if (!parsedKnowledge.success) return { compatible: false }
  if (taskCatalogue !== undefined && !TaskCapabilityCatalogueSchema.safeParse(taskCatalogue).success) return { compatible: false }
  return { compatible: true, protocolVersion: parsedKnowledge.data.protocolVersion }
}

/** 走 daemon 实际发现的传输；agent 路由在 TCP 模式附加本地 loopback token。 */
function probeDaemon(
  env: NodeJS.ProcessEnv,
  path: string,
  authenticated: boolean,
): Promise<DaemonProbe> {
  return new Promise((resolve) => {
    let done = false
    const finish = (v: DaemonProbe) => {
      if (done) return
      done = true
      resolve(v)
    }
    // 探活传输**以 daemon 实际写入的发现文件为准**(disc.transport/port),不再自行按 env 重推——
    // 否则 SYNAPSE_TRANSPORT 在 daemon 启动与 doctor 运行之间不一致时会探错通路 → 假红,
    // 反噬「去假绿」目标。这正是刚加的 DiscoveryInfo.transport/port 字段的用途:薄壳读它,doctor 也读它。
    const disc = readDiscovery(env)
    const useTcp = disc?.transport ? disc.transport === "loopback-tcp" : shouldUseLoopbackTcp(env)
    let opts: RequestOptions
    if (useTcp) {
      const port = disc?.port
      if (!port) return finish({ reached: false })
      const token = authenticated ? readLoopbackToken(env) : null
      opts = {
        host: "127.0.0.1",
        port,
        path,
        method: "GET",
        timeout: 2000,
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      }
    } else {
      opts = { socketPath: disc?.socket_path ?? socketPath(env), path, method: "GET", timeout: 2000 }
    }
    const req = request(opts, (res) => {
      let body = ""
      res.setEncoding("utf8")
      res.on("data", (chunk) => { body += chunk })
      res.on("end", () => {
        let parsed: unknown = body
        try { parsed = body ? JSON.parse(body) : undefined } catch { /* 保留文本用于诊断 */ }
        finish({ reached: true, status: res.statusCode ?? 0, body: parsed })
      })
    })
    req.on("error", () => finish({ reached: false }))
    req.on("timeout", () => {
      req.destroy()
      finish({ reached: false })
    })
    req.end()
  })
}

function asErrorBody(value: unknown): { error?: string; reason?: string; message?: string } {
  return value && typeof value === "object" ? value as { error?: string; reason?: string; message?: string } : {}
}

function asMetrics(value: unknown): Record<string, number> | undefined {
  if (!value || typeof value !== "object") return undefined
  const metrics = (value as Record<string, unknown>)["metrics"]
  if (!metrics || typeof metrics !== "object" || Array.isArray(metrics)) return undefined
  const result: Record<string, number> = {}
  for (const [key, item] of Object.entries(metrics)) {
    if (typeof item === "number" && Number.isFinite(item)) result[key] = item
  }
  return result
}

/** 安全包装:isShimInstalled 出错时降级返回 false,不让 doctor 崩 */
function safeIsShimInstalled(client: ClientId): boolean {
  try {
    return isShimInstalled(client)
  } catch {
    return false
  }
}

/** 安全包装:isGuardWired 出错时降级返回 false,不让 doctor 崩 */
function safeIsGuardWired(client: ClientId): boolean {
  try {
    return isGuardWired(client)
  } catch {
    return false
  }
}

/** 渲染成人读文本。 */
export function renderDoctor(r: DoctorReport): string {
  const L: string[] = []
  L.push("Synapse doctor")
  L.push("──────────────")
  L.push(`runtime      : ${r.runtime.running ? "running" : "STOPPED"}${r.runtime.pid ? ` (pid ${r.runtime.pid})` : ""}`)
  L.push(`socket       : ${r.runtime.socket} ${r.runtime.socketExists ? "✓" : "✗ (missing)"}`)
  L.push(`auth mode    : ${r.runtime.authMode}`)
  const reach =
    r.runtime.pathReachable === undefined
      ? "not probed"
      : r.runtime.pathReachable
        ? "reachable ✓"
        : "UNREACHABLE ✗ (shim 通路不通 —— 注入/护栏/上报实际失效,别信配置绿)"
  L.push(`data path    : ${reach}`)
  L.push(`started at   : ${r.runtime.startedAt ?? "-"}`)
  L.push(`user_id      : ${r.identity.userIdResolved ? "resolved ✓" : "UNRESOLVED (backfill will refuse)"}`)
  L.push(`git gateway  : ${r.git.gatewayPresent ? "present ✓" : "MISSING ✗"} (${r.git.gatewayPath})`)
  L.push(`git guard    : ${r.git.guardEnabled ? "enabled ✓" : "PAUSED"}`)
  if (r.brain) {
    const brainStatus = !r.brain.configured
      ? "not configured"
      : r.brain.reachable === undefined
        ? "configured (reachable: not probed)"
        : r.brain.reachable
          ? "configured ✓ (reachable)"
          : "configured ✗ (unreachable)"
    L.push(`brain        : ${brainStatus}`)
    const tokenStatus = r.brain.tokenPresent ? "present ✓" : "MISSING ✗ (run: echo <token> | synapse set-token)"
    L.push(`brain token  : ${tokenStatus}`)
    const authStatus = r.brain.authenticated === undefined
      ? "not probed"
      : r.brain.authenticated ? "authenticated ✓" : "AUTH FAILED ✗"
    L.push(`brain auth   : ${authStatus}`)
  }
  if (r.capabilityContract) {
    L.push(`capability   : ${r.capabilityContract.compatible ? `compatible ✓ (${r.capabilityContract.protocolVersion})` : `INCOMPATIBLE ✗ (${r.capabilityContract.message ?? "unknown"})`}`)
  }
  if (r.agentExecutor) {
    L.push(`agent route  : ${r.agentExecutor.reachable ? "reachable" : "UNREACHABLE ✗"}`)
    L.push(`agent exec   : ${r.agentExecutor.operational ? "operational ✓" : `UNAVAILABLE ✗ (${r.agentExecutor.message ?? "unknown"})`}`)
  }
  if (r.agentLauncher) {
    L.push(`agent launch : ${r.agentLauncher.operational ? "operational ✓" : `UNAVAILABLE ✗ (${r.agentLauncher.message ?? "unknown"})`}`)
  }
  if (r.sedimentation) {
    const s = r.sedimentation
    const terminal = s.saved + s.rejected + s.duplicate + s.failed
    const state = s.reportReceived === 0
      ? "no reports yet"
      : s.turnResolved === 0 && s.turnMissing > 0
        ? "BROKEN ✗ (all reported turns missing transcript)"
        : s.failed > 0
          ? "DEGRADED ✗ (knowledge saves failed)"
          : terminal < s.reportReceived
            ? "processing"
            : "operational ✓"
    L.push(`sedimentation: ${state}`)
    L.push(`  reports=${s.reportReceived} resolved=${s.turnResolved} missing=${s.turnMissing} saved=${s.saved} rejected=${s.rejected} duplicate=${s.duplicate} failed=${s.failed}`)
  }
  L.push("clients      :")
  for (const c of r.clients) {
    const shimMark = c.shimInstalled ? "✓" : "✗"
    // 探活失败但已装 shim → 明示 degraded(去假绿),不再只印 NO。
    const guardMark = c.hardGuard
      ? "yes"
      : c.shimInstalled && r.runtime.pathReachable === false
        ? "NO (unreachable)"
        : "NO "
    // 诚实负例的补救提示:shim 已装、通路没不可达,但 guard 未接线(典型是从旧版升级来、
    // 配置里没有 guard hook)→ 提示重跑 install(clean-then-add 会补上 guard)。
    const needsReinstall =
      !c.note && c.shimInstalled && !c.hardGuard && r.runtime.pathReachable !== false
    const stateHint = c.hookStateError ?? (c.disabledHooks?.length
      ? `hooks disabled: ${c.disabledHooks.join(", ")} — synapse install ${c.client} --enable-hooks (global switches remain unchanged)`
      : undefined)
    const hint = [stateHint, c.note ?? (needsReinstall && !stateHint ? `未接 guard —— 重跑 synapse install ${c.client} 以启用` : undefined)].filter(Boolean).join(" · ")
    L.push(
      `  - ${c.client.padEnd(12)} hard-guard=${guardMark} shim=${shimMark}${hint ? `  · ${hint}` : ""}`,
    )
  }
  return L.join("\n")
}
