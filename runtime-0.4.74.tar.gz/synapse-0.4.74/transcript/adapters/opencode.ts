import { DatabaseSync } from "node:sqlite"

export interface OpenCodeSessionMeta {
  id: string
  projectPath: string
  title?: string
  createdAtMs: number
  updatedAtMs: number
}

interface SqlRow { [key: string]: unknown }

function numberValue(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) ? value : 0
}

function stringValue(value: unknown): string {
  return typeof value === "string" ? value : ""
}

function parseData(value: unknown): Record<string, unknown> {
  if (typeof value !== "string") return {}
  try {
    const parsed = JSON.parse(value) as unknown
    return parsed !== null && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : {}
  } catch {
    return {}
  }
}

function open(path: string): DatabaseSync {
  return new DatabaseSync(path, { readOnly: true })
}

export function listOpenCodeSessions(path: string): OpenCodeSessionMeta[] {
  const db = open(path)
  try {
    return (db.prepare(
      `SELECT id, directory, title, time_created, time_updated
       FROM session
       WHERE parent_id IS NULL
       ORDER BY time_updated ASC`,
    ).all() as SqlRow[]).flatMap((row) => {
      const id = stringValue(row["id"])
      const projectPath = stringValue(row["directory"])
      if (!id || !projectPath) return []
      const title = stringValue(row["title"]).trim()
      return [{
        id,
        projectPath,
        ...(title ? { title } : {}),
        createdAtMs: numberValue(row["time_created"]),
        updatedAtMs: numberValue(row["time_updated"]),
      }]
    })
  } finally {
    db.close()
  }
}

export function loadOpenCodeMessages(path: string, sessionId: string): unknown[] {
  const db = open(path)
  try {
    const rows = db.prepare(
      `SELECT m.id, m.time_created, m.data AS message_data,
              p.id AS part_id, p.time_created AS part_created, p.data AS part_data
       FROM message m
       LEFT JOIN part p ON p.message_id = m.id AND p.session_id = m.session_id
       WHERE m.session_id = ?
       ORDER BY m.time_created ASC, p.time_created ASC, p.id ASC`,
    ).all(sessionId) as SqlRow[]

    const messages = new Map<string, Record<string, unknown>>()
    for (const row of rows) {
      const id = stringValue(row["id"])
      if (!id) continue
      let message = messages.get(id)
      if (!message) {
        const data = parseData(row["message_data"])
        message = {
          id,
          role: data["role"],
          content: [],
          timestamp: new Date(numberValue(row["time_created"])).toISOString(),
          tokens: data["tokens"],
          model: data["model"] ?? data["modelID"],
        }
        messages.set(id, message)
      }
      const partId = stringValue(row["part_id"])
      if (!partId) continue
      const part = parseData(row["part_data"])
      ;(message["content"] as unknown[]).push({ id: partId, ...part })
    }
    return [...messages.values()]
  } finally {
    db.close()
  }
}
