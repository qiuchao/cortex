export interface ResolvedRulesPath {
  path: string
  retired: boolean
}

export function resolveGlobalGitRulesPath(home?: string): ResolvedRulesPath
export function resolveProjectGitRulesPath(projectRoot: string): ResolvedRulesPath
