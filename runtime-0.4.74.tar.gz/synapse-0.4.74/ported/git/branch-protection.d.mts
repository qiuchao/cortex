export type BranchState =
  | { state: "branch"; branch: string }
  | { state: "detached" }
  | { state: "not-repo" }
  | { state: "error"; message: string }

export function readBranchState(cwd: string): BranchState
export function readCurrentBranch(cwd: string): string | undefined
export function isProtectedBranch(branch: string | undefined): boolean
