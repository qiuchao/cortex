/**
 * core/handlers/judge-sediment.ts —— report 的非确定性 handler(**detached**,绝不阻塞 Stop)。
 *
 * 方案 R3 / spec §94:每回合结束判定"这轮是否解决了值得沉淀的问题"→ 是则**当下写 KH**
 * (颗粒度=单个问题)。判定必须便宜:
 *   1) 确定性启发式预过滤 —— 绝大多数轮次一眼否掉(闲聊/无实质产出),不动模型;
 *   2) 仅"疑似有价值"才动小模型(此处留 hook,默认用启发式产出的摘要,模型可后插);
 *   3) 通过 → sedimentInsight() 立即写入 REST /api/v1/knowledge/sediment。
 *
 * 幂等:按 turn_id 去重(Codex Stop 可能多次触发同一回合)。
 *
 * ⚠️ 这是软判定(方案五大不确定性来源之一):有漏报/误报,靠护栏兜底,不追求完美。
 */
import { sedimentInsight } from "../../transport/brain-contract-align.ts"
import { stableFallbackTurnId } from "../parsers/util.ts"

/** 沉淀写函数签名(默认 sedimentInsight,走 REST;测试可注入 mock)。 */
export type SedimentSave = (
  insight: string,
  category: string | undefined,
  cwd: string | undefined,
  machineId: string | undefined,
  captureMode: "explicit" | "automatic",
) => Promise<{
  ok: boolean
  id?: string
  action?: "created" | "merged" | "skipped" | "failed"
  skipReason?: string
}>

/** seenTurns 幂等集合的上限(常驻进程防无界增长)。 */
export const SEEN_TURNS_CAP = 10_000
export const ACCEPTED_SESSIONS_CAP = 10_000
export const AUTO_SEDIMENT_COOLDOWN_MS = 10 * 60 * 1000

export interface SedimentTurn {
  client?: string
  /** 回合幂等键 */
  turn_id?: string
  session_id: string
  /** 本回合可供判定的文本材料(用户输入 + 助手输出摘要等,运行时按 client 提供) */
  text?: string
  project?: string
  /** Synapse daemon 当前工作目录(转发给 /knowledge/sediment,用于 repo 归属推断) */
  cwd?: string
  /** Cortex 独立 machineId(转发给 /knowledge/sediment,与 per-user token 正交) */
  machineId?: string
}

export interface JudgeSedimentResult {
  sedimented: boolean
  reason: "prefilter_rejected" | "brain_rejected" | "cooldown" | "duplicate" | "empty" | "saved" | "save_failed"
  /** 沉淀写入的 KH 条目 id(saved 时有) */
  id?: string
}

export interface JudgeSedimentDeps {
  /** 沉淀写(默认 sedimentInsight,走 REST /api/v1/knowledge/sediment);测试可注入 mock。 */
  save?: SedimentSave
  /** 已见过的 turn_id 集合(幂等);由 report.ts 持有并跨回合复用。 */
  seenTurns?: Set<string>
  /** 可选:小模型精判(默认不接,走启发式)。返回 null=不值得,或 {insight,category}=值得。 */
  smallModelJudge?: (turn: SedimentTurn) => Promise<{ insight: string; category: string } | null>
  /** 会话级频率闸门：只在主脑接受写入或判重后开始冷却。 */
  acceptedSessions?: Map<string, number>
  cooldownMs?: number
  now?: () => number
}

/**
 * 确定性启发式预过滤:判断这轮是否**疑似**解决了值得沉淀的问题。
 * 目标:极便宜地把绝大多数无价值轮次否掉(宁可放过也不每轮变重)。
 */
export function heuristicPrefilter(turn: SedimentTurn): boolean {
  const text = assistantText((turn.text ?? "").trim())
  if (text.length < 20) return false

  // 长度不是价值。候选必须形成至少一种完整、可复用的知识结构，而非只命中一个宽泛词。
  const causal = /(root cause|caused by|because|due to|原因(?:是|在于)|根因|由于|因为|导致)/i.test(text)
  const resolution = /(fixed by|solution|workaround|resolved by|解决方案|修复(?:方式|为|是|通过)|解决(?:方式|为|是|通过)|规避(?:方式|方法)|改为|应当改用)/i.test(text)
  const decision = /(architecture decision|we (?:chose|decided)|trade-?off|决定(?:采用|使用|选择)|架构(?:决定|选择)|取舍|最终选择|(?:采用|选择|使用).{1,80}作为)/i.test(text)
  const rationale = /(because|so that|in order to|therefore|为了|因为|以便|以(?:保证|确保|避免)|从而|因此|权衡|保证|确保|避免|防止)/i.test(text)
  const constraint = /(must not|must|only|cannot|requires?|禁止|必须|只能|不能|务必|要求)/i.test(text)
  const consequence = /(otherwise|prevents?|ensures?|会导致|否则|避免|确保|不然|后果)/i.test(text)
  const concrete = /(`[^`]+`|\b\d+\.\d+(?:\.\d+)?\b|(?:^|\s)(?:[\w.-]+\/)+[\w.-]+|\b[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+\b)/m.test(text)

  return (causal && resolution)
    || (decision && rationale)
    || (constraint && (consequence || concrete))
}

function assistantText(text: string): string {
  const marker = /\[assistant\]\s*/gi
  let match: RegExpExecArray | null
  let start = -1
  while ((match = marker.exec(text)) !== null) start = marker.lastIndex
  return start >= 0 ? text.slice(start).trim() : text
}

export async function handleJudgeSediment(
  turn: SedimentTurn,
  deps: JudgeSedimentDeps = {},
): Promise<JudgeSedimentResult> {
  const seen = deps.seenTurns
  const text = (turn.text ?? "").trim()
  const keys = [
    turn.turn_id,
    text
      ? stableFallbackTurnId({ client: "sediment", sessionId: turn.session_id, currentText: text })
      : undefined,
  ].filter((key): key is string => Boolean(key))

  // 幂等:优先用客户端 turn_id，同时登记正文指纹，拦住 Stop/SessionEnd 对同一尾轮的双报。
  if (keys.length > 0 && seen) {
    if (keys.some((key) => seen.has(key))) return { sedimented: false, reason: "duplicate" }
    // 常驻进程里 seenTurns 会无界增长 → 加上限,超了丢最旧(FIFO 近似 LRU;
    // Set 迭代顺序即插入顺序)。turn_id 幂等只需覆盖近期回合,老的丢掉无害。
    while (seen.size + keys.length > SEEN_TURNS_CAP) {
      const oldest = seen.values().next().value
      if (oldest === undefined) break
      seen.delete(oldest)
    }
    for (const key of keys) seen.add(key)
  }

  if (!text) return { sedimented: false, reason: "empty" }

  // 1) 便宜启发式:绝大多数轮次在这里否掉
  if (!heuristicPrefilter(turn)) {
    return { sedimented: false, reason: "prefilter_rejected" }
  }

  const acceptedSessions = deps.acceptedSessions
  const now = deps.now?.() ?? Date.now()
  const sessionKey = `${turn.client ?? "unknown"}\n${turn.session_id}`
  const lastAcceptedAt = acceptedSessions?.get(sessionKey)
  if (lastAcceptedAt !== undefined && now - lastAcceptedAt < (deps.cooldownMs ?? AUTO_SEDIMENT_COOLDOWN_MS)) {
    return { sedimented: false, reason: "cooldown" }
  }
  if (lastAcceptedAt !== undefined) acceptedSessions?.delete(sessionKey)

  // 2) 疑似有价值 → 精判(小模型可选;默认用启发式摘要直接沉淀)
  let payload: { insight: string; category: string } | null
  if (deps.smallModelJudge) {
    payload = await deps.smallModelJudge(turn)
    if (!payload) return { sedimented: false, reason: "prefilter_rejected" }
  } else {
    payload = { insight: text.slice(0, 2000), category: "gotcha" }
  }

  // 3) 立即写主脑（颗粒度=单个问题，不等会话结束）。
  const save = deps.save ?? sedimentInsight
  const res = await save(payload.insight, payload.category, turn.cwd, turn.machineId, "automatic")
  if (res.ok && res.action === "skipped" && res.skipReason?.startsWith("judge_")) {
    return { sedimented: false, reason: "brain_rejected" }
  }
  if (res.ok) {
    if (acceptedSessions) {
      while (acceptedSessions.size >= ACCEPTED_SESSIONS_CAP) {
        const oldest = acceptedSessions.keys().next().value
        if (oldest === undefined) break
        acceptedSessions.delete(oldest)
      }
      acceptedSessions.set(sessionKey, now)
    }
    if (res.action === "skipped") return { sedimented: false, reason: "duplicate", id: res.id }
    return { sedimented: true, reason: "saved", id: res.id }
  }
  return { sedimented: false, reason: "save_failed" }
}
