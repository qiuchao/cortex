/**
 * transport/kh-types.ts —— 知识检索结果类型(本地定义,供 Cerebro REST 客户端复用)。
 *
 * inject 向量检索 + report 沉淀当前走 Cerebro REST(transport/brain-contract-align.ts 的
 * searchKnowledge / sedimentInsight)。这里保留纯类型,供 inject 下游(formatInsights)
 * 与 searchKnowledge 共用。**不含任何传输逻辑。**
 */

/** 检索命中的单条经验。 */
export interface KhInsight {
  id: string
  title: string
  content: string
  category: string
  /** owner/可见性范围(REST knowledge search 不返回,留空;保留字段兼容下游)。 */
  scope: string
  confidence: number
  tags?: string[]
  /** 命中路径(vector / bm25 / keyword),便于展示。 */
  source?: string
}

/** 检索成功。 */
export interface KhSearchResult {
  ok: true
  query: string
  insights: KhInsight[]
  hint?: string
}

/** 检索降级(主脑不可达 / 未配置 / 空输入)。 */
export interface KhDegraded {
  ok: false
  reason: "transport_unavailable" | "kh_returned_error" | "invalid_input" | "validation_error" | "permission_denied" | "turn_scope_denied" | "not_found"
  message: string
  /** 已收到主脑的确定性 HTTP 响应时保留状态码；网络/超时则省略。 */
  httpStatus?: number
  fallback?: unknown
}
