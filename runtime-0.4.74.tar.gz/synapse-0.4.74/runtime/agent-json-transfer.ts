import { createHash, randomUUID } from "node:crypto"
import {
  closeSync,
  existsSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmdirSync,
  unlinkSync,
  utimesSync,
  writeFileSync,
} from "node:fs"
import { join } from "node:path"
import { TextDecoder } from "node:util"
import { TASK_CAPABILITY_EXECUTE_MAX_JSON_BYTES } from "@cerebro/wire"

// Keep the encoded argv comfortably below Windows' 32,767-character command
// line ceiling, including the executable path and transfer metadata.
export const AGENT_JSON_CHUNK_MAX_BYTES = 16 * 1024
export const AGENT_JSON_GIT_BASH_CHUNK_MAX_BYTES = 4 * 1024
export const AGENT_JSON_CHUNK_MAX_CHARS = Math.ceil(AGENT_JSON_CHUNK_MAX_BYTES * 4 / 3)
export const AGENT_JSON_TRANSFER_MAX_BYTES = TASK_CAPABILITY_EXECUTE_MAX_JSON_BYTES
export const AGENT_JSON_BRIDGE_MAX_BYTES = AGENT_JSON_TRANSFER_MAX_BYTES + 64 * 1024
export const AGENT_JSON_TRANSFER_TTL_MS = 5 * 60_000
export const AGENT_JSON_TRANSFER_MAX_AGE_MS = 24 * 60 * 60_000

export const AGENT_JSON_TRANSFER_MAX_CHUNKS = Math.ceil(
  AGENT_JSON_TRANSFER_MAX_BYTES / AGENT_JSON_GIT_BASH_CHUNK_MAX_BYTES,
)
const CLOCK_SKEW_MS = 30_000
const MANIFEST_NAME = "manifest.json"
const TRANSFER_ID_RE = /^[A-Za-z0-9_-]{16,128}$/
const TRANSFER_DIR_RE = /^json-transfer-([a-f0-9]{64})$/
const PROCESSING_DIR_RE = /^json-transfer-processing-([a-f0-9]{64})-[a-f0-9-]{36}$/
const TRANSFER_CHOOSING_FILE_RE = /^json-transfer-choosing-([a-f0-9]{64})-([a-f0-9-]{36})\.json$/
const TRANSFER_TICKET_FILE_RE = /^json-transfer-ticket-([a-f0-9]{64})-([a-f0-9-]{36})\.json$/
const TRANSFER_LOCK_DIR_RE = /^json-transfer-lock-([a-f0-9]{64})$/
const CHUNK_FILE_RE = /^chunk-(\d{6})\.b64$/
const PROTOCOL_VERSION = "synapse-agent-json-transfer.v1"
const TRANSFER_LOCK_WAIT_MS = 5_000
const LOCK_SLEEP = new Int32Array(new SharedArrayBuffer(4))

export interface AgentJsonPayloadTooLarge {
  ok: false
  reason: "PAYLOAD_TOO_LARGE"
  message: string
}

export function assertAgentJsonByteLength(
  byteLength: number,
  maxBytes = AGENT_JSON_TRANSFER_MAX_BYTES,
): void {
  if (!Number.isSafeInteger(byteLength) || byteLength < 0 || byteLength > maxBytes) {
    throw new Error(`agent JSON payload exceeds ${maxBytes} bytes`)
  }
}

export function decodeAgentJsonBase64Url(
  value: unknown,
  maxBytes = AGENT_JSON_TRANSFER_MAX_BYTES,
): string {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) {
    throw new Error("invalid base64url")
  }
  if (value.length > Math.ceil(maxBytes * 4 / 3)) {
    throw new Error(`agent JSON payload exceeds ${maxBytes} bytes`)
  }
  const decoded = Buffer.from(value, "base64url")
  if (decoded.length === 0 || decoded.toString("base64url") !== value) {
    throw new Error("invalid base64url")
  }
  assertAgentJsonByteLength(decoded.length, maxBytes)
  return decodeUtf8(decoded)
}

export async function readAgentJsonStream(
  source: AsyncIterable<string | Uint8Array>,
  maxBytes = AGENT_JSON_TRANSFER_MAX_BYTES,
): Promise<string | null> {
  const chunks: Buffer[] = []
  let byteLength = 0
  for await (const chunk of source) {
    const bytes = Buffer.from(chunk)
    byteLength += bytes.length
    assertAgentJsonByteLength(byteLength, maxBytes)
    chunks.push(bytes)
  }
  const text = decodeUtf8(Buffer.concat(chunks, byteLength)).trim()
  return text || null
}

function decodeUtf8(bytes: Uint8Array): string {
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes)
}

export function agentJsonPayloadTooLarge(maxBytes = AGENT_JSON_TRANSFER_MAX_BYTES): AgentJsonPayloadTooLarge {
  return {
    ok: false,
    reason: "PAYLOAD_TOO_LARGE",
    message: `agent JSON payload exceeds ${maxBytes} bytes`,
  }
}

interface TransferManifest {
  protocolVersion: typeof PROTOCOL_VERSION
  transferId: string
  action: string
  bindingHash: string
  chunkCount: number
  createdAt: string
}

export interface AgentJsonTransferChunkInput {
  action: string
  binding?: string
  transferId: string
  chunkIndex: number
  chunkCount: number
  encodedChunk: string
  now?: number
}

export interface AgentJsonTransferFinalizeInput {
  action: string
  binding?: string
  transferId: string
  chunkCount: number
  now?: number
}

export interface AgentJsonChunkAccepted {
  status: "chunk_accepted"
  chunkIndex: number
  chunkCount: number
  duplicate: boolean
}

export function acceptAgentJsonTransferChunk(
  spoolPath: string,
  input: AgentJsonTransferChunkInput,
): AgentJsonChunkAccepted {
  assertSpoolDirectory(spoolPath)
  validateTransferIdentity(input.transferId, input.action)
  validateChunkCount(input.chunkCount)
  if (!Number.isSafeInteger(input.chunkIndex) || input.chunkIndex < 0 || input.chunkIndex >= input.chunkCount) {
    throw new Error("chunk index is outside the declared transfer")
  }
  if (!input.encodedChunk || input.encodedChunk.length > AGENT_JSON_CHUNK_MAX_CHARS
    || !/^[A-Za-z0-9_-]+$/.test(input.encodedChunk)) {
    throw new Error(`chunk must be 1-${AGENT_JSON_CHUNK_MAX_CHARS} base64url characters`)
  }
  const decodedChunk = decodeCanonicalChunk(input.encodedChunk)
  const maxChunkBytes = Math.min(
    AGENT_JSON_CHUNK_MAX_BYTES,
    Math.floor(AGENT_JSON_TRANSFER_MAX_BYTES / input.chunkCount),
  )
  if (decodedChunk.length > maxChunkBytes) {
    throw new Error(`decoded chunk must not exceed ${maxChunkBytes} bytes for ${input.chunkCount} chunks`)
  }

  const now = input.now ?? Date.now()
  const transferPath = transferDirectoryPath(spoolPath, input)
  return withTransferLock(spoolPath, input, () => {
    ensureTransferDirectory(transferPath)
    assertRealDirectory(transferPath)
    const manifest = ensureTransferManifest(transferPath, input, now)
    validateManifest(manifest, input, now, transferPath)
    const chunkPath = join(transferPath, chunkFileName(input.chunkIndex))
    let duplicate = false
    if (existsSync(chunkPath)) {
      const current = readTransferFile(chunkPath, AGENT_JSON_CHUNK_MAX_CHARS)
      if (current !== input.encodedChunk) throw new Error("duplicate chunk content conflicts with the accepted chunk")
      duplicate = true
    } else {
      writeExclusiveFile(chunkPath, input.encodedChunk)
    }
    utimesSync(transferPath, new Date(now), new Date(now))
    return {
      status: "chunk_accepted",
      chunkIndex: input.chunkIndex,
      chunkCount: input.chunkCount,
      duplicate,
    }
  })
}

export function finalizeAgentJsonTransfer(
  spoolPath: string,
  input: AgentJsonTransferFinalizeInput,
): string {
  assertSpoolDirectory(spoolPath)
  validateTransferIdentity(input.transferId, input.action)
  validateChunkCount(input.chunkCount)
  const now = input.now ?? Date.now()
  const transferPath = transferDirectoryPath(spoolPath, input)
  const processingPath = join(
    spoolPath,
    `json-transfer-processing-${transferDigest(`${input.action}\n${input.transferId}`)}-${randomUUID()}`,
  )
  return withTransferLock(spoolPath, input, (heartbeat) => {
    let claimed = false
    try {
      assertRealDirectory(transferPath)
      const manifest = readManifest(transferPath)
      validateManifest(manifest, input, now, transferPath)
      const chunks = inspectChunks(transferPath, input.chunkCount, heartbeat)
      if (chunks.count !== input.chunkCount) {
        throw new Error(`chunk transfer is incomplete: received ${chunks.count} of ${input.chunkCount}`)
      }
      if (chunks.decodedBytes > AGENT_JSON_TRANSFER_MAX_BYTES) throw new Error("chunk transfer exceeds the maximum JSON size")

      renameSync(transferPath, processingPath)
      claimed = true
      heartbeat(processingPath)

      const parts: Buffer[] = []
      let decodedBytes = 0
      for (let index = 0; index < input.chunkCount; index++) {
        if (index % 128 === 0) heartbeat(processingPath)
        const encoded = readTransferFile(join(processingPath, chunkFileName(index)), AGENT_JSON_CHUNK_MAX_CHARS)
        const decoded = decodeCanonicalChunk(encoded)
        decodedBytes += decoded.length
        if (decodedBytes > AGENT_JSON_TRANSFER_MAX_BYTES) throw new Error("chunk transfer exceeds the maximum JSON size")
        parts.push(decoded)
      }
      const decoded = Buffer.concat(parts, decodedBytes)
      return decodeUtf8(decoded)
    } finally {
      if (claimed) removeTransferPath(processingPath)
    }
  })
}

/** Returns true when the entry belongs to the JSON transfer protocol. */
export function removeAgentJsonTransferEntryIfStale(
  spoolPath: string,
  name: string,
  now = Date.now(),
): boolean {
  const transferMatch = TRANSFER_DIR_RE.exec(name)
  const processingMatch = PROCESSING_DIR_RE.exec(name)
  // Lock entries are never reclaimed while the daemon is running. A process
  // that crashes can only strand its unique transfer ID; bridge startup clears
  // all protocol state before publishing the new private spool path.
  if (TRANSFER_LOCK_DIR_RE.test(name)
    || TRANSFER_CHOOSING_FILE_RE.test(name)
    || TRANSFER_TICKET_FILE_RE.test(name)) return true
  const digest = transferMatch?.[1] ?? processingMatch?.[1]
  if (!digest) return false
  const target = join(spoolPath, name)
  try {
    withTransferDigestLock(spoolPath, digest, () => {
      const stat = lstatSync(target)
      if (stat.isSymbolicLink() || !stat.isDirectory()) {
        removeTransferPath(target)
        return
      }
      if (now - stat.mtimeMs > AGENT_JSON_TRANSFER_TTL_MS) {
        removeTransferPath(target)
        return
      }
      if (transferMatch) {
        // A fresh directory can briefly precede its exclusive manifest write.
        // Leave malformed recent entries for the inactivity cleanup instead
        // of racing an active receiver.
        try {
          const createdAt = Date.parse(readManifest(target).createdAt)
          if (!Number.isFinite(createdAt)
            || createdAt < now - AGENT_JSON_TRANSFER_MAX_AGE_MS
            || createdAt > now + CLOCK_SKEW_MS) {
            removeTransferPath(target)
          }
        } catch {
          // The inactivity limit removes an abandoned or malformed directory.
        }
      }
    }, 0)
  } catch { /* entry disappeared or its transfer is active */ }
  return true
}

export function cleanupAgentJsonTransfers(spoolPath: string): void {
  let names: string[]
  try { names = readdirSync(spoolPath) } catch { return }
  for (const name of names) {
    if (TRANSFER_DIR_RE.test(name)
      || PROCESSING_DIR_RE.test(name)
      || TRANSFER_CHOOSING_FILE_RE.test(name)
      || TRANSFER_TICKET_FILE_RE.test(name)
      || TRANSFER_LOCK_DIR_RE.test(name)) {
      removeTransferPath(join(spoolPath, name))
    }
  }
}

function ensureTransferManifest(
  transferPath: string,
  input: AgentJsonTransferChunkInput,
  now: number,
): TransferManifest {
  assertRealDirectory(transferPath)
  const manifestPath = join(transferPath, MANIFEST_NAME)
  if (!existsSync(manifestPath)) {
    const manifest: TransferManifest = {
      protocolVersion: PROTOCOL_VERSION,
      transferId: input.transferId,
      action: input.action,
      bindingHash: bindingHash(input.binding),
      chunkCount: input.chunkCount,
      createdAt: new Date(now).toISOString(),
    }
    writeExclusiveFile(manifestPath, JSON.stringify(manifest))
    utimesSync(transferPath, new Date(now), new Date(now))
    return manifest
  }
  return readManifest(transferPath)
}

function readManifest(transferPath: string): TransferManifest {
  const raw = readTransferFile(join(transferPath, MANIFEST_NAME), 4096)
  let manifest: unknown
  try { manifest = JSON.parse(raw) } catch { throw new Error("invalid chunk transfer manifest") }
  if (!manifest || typeof manifest !== "object" || Array.isArray(manifest)) {
    throw new Error("invalid chunk transfer manifest")
  }
  return manifest as TransferManifest
}

function validateManifest(
  manifest: TransferManifest,
  input: AgentJsonTransferChunkInput | AgentJsonTransferFinalizeInput,
  now: number,
  transferPath: string,
): void {
  const createdAt = Date.parse(manifest.createdAt)
  if (manifest.protocolVersion !== PROTOCOL_VERSION
    || manifest.transferId !== input.transferId
    || manifest.action !== input.action
    || manifest.bindingHash !== bindingHash(input.binding)
    || manifest.chunkCount !== input.chunkCount) {
    throw new Error("chunk transfer metadata conflicts with the accepted transfer")
  }
  const activityAt = lstatSync(transferPath).mtimeMs
  if (!Number.isFinite(createdAt)
    || createdAt < now - AGENT_JSON_TRANSFER_MAX_AGE_MS
    || createdAt > now + CLOCK_SKEW_MS
    || !Number.isFinite(activityAt)
    || activityAt < now - AGENT_JSON_TRANSFER_TTL_MS
    || activityAt > now + CLOCK_SKEW_MS) {
    throw new Error("chunk transfer has expired")
  }
}

function ensureTransferDirectory(path: string): void {
  try {
    mkdirSync(path, { mode: 0o700 })
  } catch (error) {
    if (!isErrorCode(error, "EEXIST")) throw error
  }
  assertRealDirectory(path)
}

function withTransferLock<T>(
  spoolPath: string,
  input: Pick<AgentJsonTransferChunkInput, "transferId" | "action">,
  operation: (heartbeat: (activePath?: string) => void) => T,
): T {
  return withTransferDigestLock(
    spoolPath,
    transferDigest(`${input.action}\n${input.transferId}`),
    operation,
    TRANSFER_LOCK_WAIT_MS,
  )
}

/**
 * The directory creation is the only lock linearization point. Runtime code
 * never reclaims a lock, which avoids deleting a replacement owner (ABA).
 * Crash leftovers are removed once, before a bridge publishes its spool.
 */
function withTransferDigestLock<T>(
  spoolPath: string,
  digest: string,
  operation: (heartbeat: (activePath?: string) => void) => T,
  waitMs: number,
): T {
  const lockPath = join(spoolPath, `json-transfer-lock-${digest}`)
  const deadline = Date.now() + waitMs
  while (true) {
    try {
      mkdirSync(lockPath, { mode: 0o700 })
      break
    } catch (error) {
      const contention = isErrorCode(error, "EEXIST")
      if (!isRetryableAgentJsonTransferLockError(error)) throw error
      if (Date.now() >= deadline) {
        if (contention) throw new Error("chunk transfer is busy")
        throw error
      }
      Atomics.wait(LOCK_SLEEP, 0, 0, 10)
    }
  }
  try {
    const heartbeat = (activePath?: string) => {
      const time = new Date()
      utimesSync(lockPath, time, time)
      if (activePath) utimesSync(activePath, time, time)
    }
    heartbeat()
    return operation(heartbeat)
  } finally {
    try { rmdirSync(lockPath) } catch { /* startup cleanup handles a stranded lock */ }
  }
}

export function isRetryableAgentJsonTransferLockError(
  error: unknown,
  platform: NodeJS.Platform = process.platform,
): boolean {
  return isErrorCode(error, "EEXIST")
    || (platform === "win32" && (isErrorCode(error, "EPERM") || isErrorCode(error, "EBUSY")))
}

function isErrorCode(error: unknown, code: string): boolean {
  return Boolean(error && typeof error === "object" && "code" in error && error.code === code)
}

function inspectChunks(
  transferPath: string,
  chunkCount: number,
  heartbeat: (activePath?: string) => void,
): { count: number; decodedBytes: number } {
  let count = 0
  let decodedBytes = 0
  for (const name of readdirSync(transferPath)) {
    if (name === MANIFEST_NAME) continue
    if (count % 128 === 0) heartbeat(transferPath)
    const match = CHUNK_FILE_RE.exec(name)
    if (!match) throw new Error("chunk transfer contains an unexpected entry")
    const index = Number(match[1])
    if (!Number.isSafeInteger(index) || index < 0 || index >= chunkCount) {
      throw new Error("chunk transfer contains an out-of-range chunk")
    }
    const stat = lstatSync(join(transferPath, name))
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size < 1 || stat.size > AGENT_JSON_CHUNK_MAX_CHARS) {
      throw new Error("chunk transfer contains an invalid chunk file")
    }
    count++
    decodedBytes += decodeCanonicalChunk(readFileSync(join(transferPath, name), "utf8")).length
  }
  return { count, decodedBytes }
}

function decodeCanonicalChunk(encoded: string): Buffer {
  if (!encoded || !/^[A-Za-z0-9_-]+$/.test(encoded)) throw new Error("chunk is not base64url")
  const decoded = Buffer.from(encoded, "base64url")
  if (decoded.length === 0 || decoded.toString("base64url") !== encoded) {
    throw new Error("chunk is not canonical base64url")
  }
  return decoded
}

function validateTransferIdentity(transferId: string, action: string): void {
  if (!TRANSFER_ID_RE.test(transferId)) throw new Error("transfer ID must be 16-128 base64url characters")
  if (!/^[a-z][a-z-]{1,31}$/.test(action)) throw new Error("invalid transfer action")
}

function validateChunkCount(chunkCount: number): void {
  if (!Number.isSafeInteger(chunkCount) || chunkCount < 1 || chunkCount > AGENT_JSON_TRANSFER_MAX_CHUNKS) {
    throw new Error(`chunk count must be 1-${AGENT_JSON_TRANSFER_MAX_CHUNKS}`)
  }
}

function bindingHash(binding = ""): string {
  return createHash("sha256").update(binding).digest("hex")
}

function transferDigest(transferId: string): string {
  return createHash("sha256").update(transferId).digest("hex")
}

function transferDirectoryPath(
  spoolPath: string,
  input: Pick<AgentJsonTransferChunkInput, "transferId" | "action" | "binding">,
): string {
  return join(spoolPath, `json-transfer-${transferDigest(`${input.action}\n${input.transferId}`)}`)
}

function chunkFileName(index: number): string {
  return `chunk-${String(index).padStart(6, "0")}.b64`
}

function assertSpoolDirectory(path: string): void {
  const stat = lstatSync(path)
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("invalid agent spool directory")
  if (typeof process.getuid === "function" && stat.uid !== process.getuid()) {
    throw new Error("agent spool directory is not owned by the current user")
  }
  if (process.platform !== "win32" && (stat.mode & 0o077) !== 0) {
    throw new Error("agent spool directory is accessible by group or others")
  }
}

function assertRealDirectory(path: string): void {
  const stat = lstatSync(path)
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("chunk transfer path is not a real directory")
  if (typeof process.getuid === "function" && stat.uid !== process.getuid()) {
    throw new Error("chunk transfer directory is not owned by the current user")
  }
  if (process.platform !== "win32" && (stat.mode & 0o077) !== 0) {
    throw new Error("chunk transfer directory is accessible by group or others")
  }
}

function readTransferFile(path: string, maxBytes: number): string {
  const stat = lstatSync(path)
  if (!stat.isFile() || stat.isSymbolicLink() || stat.size < 1 || stat.size > maxBytes) {
    throw new Error("invalid chunk transfer file")
  }
  return readFileSync(path, "utf8")
}

function writeExclusiveFile(path: string, content: string): void {
  let fd: number | undefined
  try {
    fd = openSync(path, "wx", 0o600)
    writeFileSync(fd, content, "utf8")
    closeSync(fd)
    fd = undefined
  } finally {
    if (fd !== undefined) try { closeSync(fd) } catch { /* best effort */ }
  }
}

function removeTransferPath(path: string): void {
  let stat
  try { stat = lstatSync(path) } catch { return }
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    try { unlinkSync(path) } catch { /* best effort */ }
    return
  }
  let names: string[]
  try { names = readdirSync(path) } catch { return }
  for (const name of names) {
    const child = join(path, name)
    try {
      const childStat = lstatSync(child)
      if (childStat.isDirectory() && !childStat.isSymbolicLink()) {
        removeTransferPath(child)
      } else {
        unlinkSync(child)
      }
    } catch { /* best effort */ }
  }
  try { rmdirSync(path) } catch { /* best effort */ }
}
