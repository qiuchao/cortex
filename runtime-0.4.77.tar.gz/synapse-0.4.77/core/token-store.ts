/**
 * core/token-store.ts —— machine token 的 0600 文件读写。
 *
 * token 落 0600 文件(runtimeDir/token),目录 0700。
 * 安全模型与 unix socket 文件系统鉴权同级(参见 DECISIONS.md D8)。
 *
 * - writeToken: 写入 token(幂等覆盖),确保 0600 权限。
 * - readToken:  读取文件内容(trim),不存在/读失败返回 undefined。
 * - tokenPresent: token 文件存在且非空,OR env 有 CEREBRO_MACHINE_TOKEN。
 */
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs"
import { randomUUID } from "node:crypto"
import { dirname } from "node:path"
import { runtimeDir, tokenPath, machineIdPath } from "../transport/discovery.ts"

export interface TokenStoreOpts {
  env?: NodeJS.ProcessEnv
}

/**
 * 把 token 写入 tokenPath() 文件,权限严格 0600,目录 0700。
 * 幂等:文件已存在则覆盖。
 */
export function writeToken(token: string, opts?: TokenStoreOpts): void {
  const env = opts?.env ?? process.env
  const dir = runtimeDir(env)
  mkdirSync(dir, { recursive: true, mode: 0o700 })
  const path = tokenPath(env)
  writeFileSync(path, token, { encoding: "utf8", mode: 0o600 })
  // 已存在的文件 writeFileSync mode 参数不改权限;显式 chmod 保证
  chmodSync(path, 0o600)
}

/**
 * 读取 token 文件内容(trim)。
 * 文件不存在或读取失败返回 undefined(不抛)。
 */
export function readToken(opts?: TokenStoreOpts): string | undefined {
  const env = opts?.env ?? process.env
  const path = tokenPath(env)
  if (!existsSync(path)) return undefined
  try {
    const content = readFileSync(path, "utf8").trim()
    return content || undefined
  } catch {
    return undefined
  }
}

/**
 * token 是否可用:token 文件存在且非空,OR env CEREBRO_MACHINE_TOKEN 有值。
 */
export function tokenPresent(opts?: TokenStoreOpts): boolean {
  const env = opts?.env ?? process.env
  if (readToken(opts)) return true
  const envToken = env["CEREBRO_MACHINE_TOKEN"]?.trim()
  return !!envToken
}

/**
 * 读取 machine-id 文件内容(trim)。
 * 文件不存在或读取失败返回 undefined(不抛)。
 *
 * machineId = Cortex 桌面首启生成的 machineId(per-device,独立于 per-user token)。
 * 文件路径:~/.synapse/run/machine-id(与短生命周期 runtimeDir/token 物理隔离)。
 */
export function readMachineId(opts?: TokenStoreOpts): string | undefined {
  const env = opts?.env ?? process.env
  const trustedOverride = env["SYNAPSE_MACHINE_ID"]?.trim()
  if (trustedOverride) return trustedOverride
  const path = machineIdPath(env)
  if (!existsSync(path)) return undefined
  try {
    const content = readFileSync(path, "utf8").trim()
    return content || undefined
  } catch {
    return undefined
  }
}

/**
 * 返回稳定的 per-device machineId；Cortex 尚未创建文件时由 Synapse 补建。
 * 两端共用同一路径，因此先创建者胜出，后续均只读同一个 UUID。
 */
export function ensureMachineId(opts?: TokenStoreOpts): string | undefined {
  const existing = readMachineId(opts)
  if (existing) return existing
  const env = opts?.env ?? process.env
  const path = machineIdPath(env)
  try {
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
    const machineId = randomUUID()
    writeFileSync(path, machineId, {
      encoding: "utf8",
      mode: 0o600,
      flag: "wx",
    })
    chmodSync(path, 0o600)
    return machineId
  } catch {
    return readMachineId(opts)
  }
}
