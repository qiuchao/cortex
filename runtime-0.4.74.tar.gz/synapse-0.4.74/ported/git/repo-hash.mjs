#!/usr/bin/env node
/**
 * scripts/repo-hash.mjs — 计算当前 git 仓库的稳定 hash（多 worktree 安全）
 *
 * ADR: git-stash-tracking-runtime / git-safety-gateway（.sh → .mjs 全平台统一迁移）
 *
 * 主要用途：被 git-safety-gateway.mjs / stash-track-write.mjs 直接 import：
 *   import { computeRepoHash } from "./repo-hash.mjs"
 *   const h = computeRepoHash()  // 16 位 hex 或空串
 *
 * CLI 用途（对齐旧 repo-hash 子命令在 gateway 内的调用）：
 *   node repo-hash.mjs            → stdout 输出 hash（exit 0）/ 空则 exit 1
 *   node repo-hash.mjs repo-hash  → 同上
 *
 * 🔴 必须用 --git-common-dir（不是 --show-toplevel）：
 *    git stash 栈存于 <git-common-dir>/refs/stash（整仓共享），
 *    --show-toplevel 对不同 worktree 返回不同路径 → repoHash 分裂 → stash-tracking.json 分裂。
 *
 * 算法（与旧 repo-hash.sh compute_repo_hash() 等价）：
 *   raw      = git rev-parse --git-common-dir   （⚠️ 非 --show-toplevel）
 *   canon    = realpathSync(raw)                 （标准化：解符号链接 + 绝对路径；失败回退 raw）
 *   repoHash = sha256(canon) 取 hex 前 16 位
 */
// ADR:git-stash-tracking-runtime

import { execSync } from "node:child_process"
import { realpathSync } from "node:fs"
import { createHash } from "node:crypto"
import { fileURLToPath } from "node:url"

/**
 * 计算当前 git 仓库的稳定 hash（16 位 hex）。
 * 任何失败（非 git 仓库等）一律返回空串（fail-safe，调用方负责降级）。
 * @returns {string} 16 位 hex 或空串
 */
export function computeRepoHash() {
  // 1. 用 --git-common-dir（同仓所有 worktree 返回同一 .git）
  let raw = ""
  try {
    raw = execSync("git rev-parse --git-common-dir", {
      stdio: ["pipe", "pipe", "pipe"],
    })
      .toString()
      .trim()
  } catch {
    return ""
  }
  if (!raw) return ""

  // 2. 转绝对路径（解符号链接）；失败回退原值（与 .sh realpath || "$raw" 一致）
  let canon = raw
  try {
    canon = realpathSync(raw)
  } catch {
    canon = raw
  }

  // 3. sha256 hex 前 16 位
  let hashFull = ""
  try {
    hashFull = createHash("sha256").update(canon).digest("hex")
  } catch {
    return ""
  }
  if (!hashFull) return ""

  return hashFull.slice(0, 16)
}

// ─── CLI 入口判定（仅当被 node 直接执行时，import 复用不触发）─────────────────
const isMain = (() => {
  try {
    return process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(process.argv[1])
  } catch {
    return fileURLToPath(import.meta.url) === process.argv[1]
  }
})()

if (isMain) {
  const hash = computeRepoHash()
  if (!hash) {
    process.stderr.write(
      "[repo-hash] WARNING: 无法计算 repoHash（非 git 仓库 / 环境异常）\n"
    )
    process.exit(1)
  }
  process.stdout.write(hash + "\n")
}
